<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		sandbox
	</title><g fill="#36c"><path d="M5 19H3v-2h2zm4 0H7v-2h2zm4 0h-2v-2h2zm4 0h-2v-2h2zM5 15H3v-2h2zm12 0h-2v-2h2zm-.339-9.404-5.375 5.376-.096.039-1.767.707-.65-.65.706-1.768.04-.096 5.375-5.376zM5 11H3V9h2zm12 0h-2V9h2zM5 7H3V5h2zm14.49-4.232-1.414 1.414-1.767-1.768L17.723 1zM5 3H3V1h2zm4 0H7V1h2zm4 0h-2V1h2z"/></g></svg>
