<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		ellipsis horizontal
	</title><g fill="#fff"><path d="M5 11.5H2v-3h3zm6.5 0h-3v-3h3zm6.5 0h-3v-3h3z"/></g></svg>
