/**
 * DaxDuckDex Privacy-First Analytics v1.0
 * Collecteur léger et respectueux de la vie privée
 */

class DaxAnalytics {
    constructor() {
        this.apiBase = 'https://api.makdulac.com';
        this.sessionId = this.generateSessionId();
        this.startTime = Date.now();
        this.isEnabled = true;
        this.batchData = {
            pageViews: [],
            searches: [],
            characterViews: []
        };
        
        // Vérifier si l'utilisateur a désactivé l'analytics
        if (localStorage.getItem('dax_analytics_disabled') === 'true') {
            this.isEnabled = false;
            console.log('📊 Analytics disabled by user preference');
            return;
        }
        
        this.init();
    }
    
    init() {
        try {
            // Enregistrer la vue de la page actuelle
            this.trackPageView();
            
            // Envoyer les données toutes les 30 secondes
            setInterval(() => {
                this.sendBatch();
            }, 30000);
            
            // Nettoyer avant fermeture de page
            window.addEventListener('beforeunload', () => {
                this.sendBatchSync();
            });
            
            console.log('📊 DaxAnalytics initialized (privacy-first)');
        } catch (error) {
            console.warn('Analytics initialization failed (non-critical):', error);
            this.isEnabled = false;
        }
    }
    
    generateSessionId() {
        return Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    trackPageView(page = null) {
        if (!this.isEnabled) return;
        
        try {
            const currentPage = page || this.getCurrentPage();
            
            this.batchData.pageViews.push({
                page: currentPage,
                timestamp: Date.now(),
                sessionId: this.sessionId,
                referrer: this.getAnonymizedReferrer(),
                userAgent: this.getAnonymizedUserAgent(),
                deviceType: this.getDeviceType()
            });
            
            // Log local pour debug
            console.log('📊 Page view tracked:', currentPage);
        } catch (error) {
            console.warn('Page view tracking failed:', error);
        }
    }
    
    trackSearch(searchTerm, resultsCount = 0) {
        if (!this.isEnabled || !searchTerm || searchTerm.length < 2) return;
        
        try {
            // Nettoyer et anonymiser le terme de recherche
            const cleanTerm = this.cleanSearchTerm(searchTerm);
            if (!cleanTerm) return;
            
            this.batchData.searches.push({
                term: cleanTerm,
                resultsCount: resultsCount,
                timestamp: Date.now(),
                sessionId: this.sessionId
            });
            
            console.log('🔍 Search tracked:', cleanTerm, '(' + resultsCount + ' results)');
        } catch (error) {
            console.warn('Search tracking failed:', error);
        }
    }
    
    trackCharacterView(characterName) {
        if (!this.isEnabled || !characterName) return;
        
        try {
            this.batchData.characterViews.push({
                character: characterName,
                timestamp: Date.now(),
                sessionId: this.sessionId
            });
            
            console.log('👤 Character view tracked:', characterName);
        } catch (error) {
            console.warn('Character view tracking failed:', error);
        }
    }
    
    getCurrentPage() {
        const path = window.location.pathname;
        
        if (path === '/' || path === '/index.html') return '/';
        if (path.includes('daxduckdx') || path.includes('daxduckdex')) return '/daxduckdex';
        
        return path;
    }
    
    getAnonymizedReferrer() {
        try {
            const referrer = document.referrer;
            if (!referrer) return 'direct';
            
            const referrerDomain = new URL(referrer).hostname;
            const currentDomain = window.location.hostname;
            
            if (referrerDomain === currentDomain) return 'internal';
            if (referrerDomain.includes('google')) return 'search_engine';
            if (referrerDomain.includes('bing')) return 'search_engine';
            if (referrerDomain.includes('duckduckgo')) return 'search_engine';
            if (referrerDomain.includes('reddit')) return 'social';
            if (referrerDomain.includes('twitter') || referrerDomain.includes('x.com')) return 'social';
            
            return 'external';
        } catch (e) {
            return 'unknown';
        }
    }
    
    getAnonymizedUserAgent() {
        const ua = navigator.userAgent || '';
        
        if (ua.includes('Chrome') && !ua.includes('Edg')) return 'Chrome';
        if (ua.includes('Firefox')) return 'Firefox';
        if (ua.includes('Safari') && !ua.includes('Chrome')) return 'Safari';
        if (ua.includes('Edg')) return 'Edge';
        if (ua.includes('Opera')) return 'Opera';
        
        return 'Other';
    }
    
    getDeviceType() {
        const ua = navigator.userAgent || '';
        
        if (/Tablet|iPad/i.test(ua)) return 'Tablet';
        if (/Mobile|Android|iPhone/i.test(ua)) return 'Mobile';
        
        return 'Desktop';
    }
    
    cleanSearchTerm(term) {
        if (typeof term !== 'string') return null;
        
        // Nettoyer et normaliser
        let cleaned = term.toLowerCase().trim();
        
        // Filtrer les termes trop longs ou vides
        if (cleaned.length > 50 || cleaned.length < 2) return null;
        
        // Filtrer les termes qui pourraient contenir des infos personnelles
        const personalIndicators = ['email', '@', '.com', '.fr', 'phone', 'tel'];
        for (let indicator of personalIndicators) {
            if (cleaned.includes(indicator)) {
                return '[filtered]';
            }
        }
        
        return cleaned;
    }
    
    sendBatch() {
        if (!this.isEnabled) return;
        
        const hasData = this.batchData.pageViews.length > 0 || 
                       this.batchData.searches.length > 0 || 
                       this.batchData.characterViews.length > 0;
        
        if (!hasData) return;
        
        const payload = {
            sessionId: this.sessionId,
            pageViews: this.batchData.pageViews.splice(0, 10), // Max 10 par batch
            searches: this.batchData.searches.splice(0, 10),
            characterViews: this.batchData.characterViews.splice(0, 10),
            timestamp: Date.now()
        };
        
        this.sendData('/api/analytics/batch', payload);
    }
    
    sendBatchSync() {
        if (!this.isEnabled || !navigator.sendBeacon) return;
        
        const hasData = this.batchData.pageViews.length > 0 || 
                       this.batchData.searches.length > 0 || 
                       this.batchData.characterViews.length > 0;
        
        if (!hasData) return;
        
        const payload = {
            sessionId: this.sessionId,
            pageViews: this.batchData.pageViews,
            searches: this.batchData.searches,
            characterViews: this.batchData.characterViews,
            sessionDuration: Date.now() - this.startTime,
            timestamp: Date.now()
        };
        
        try {
            navigator.sendBeacon(
                this.apiBase + '/api/analytics/batch',
                JSON.stringify(payload)
            );
        } catch (error) {
            // Fail silently
        }
    }
    
    async sendData(endpoint, data) {
        if (!this.isEnabled) return;
        
        try {
            const response = await fetch(this.apiBase + endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
                credentials: 'omit'
            });
            
            if (!response.ok) {
                console.warn('Analytics send failed:', response.status);
            }
            
        } catch (error) {
            // Fail silently to avoid impacting user experience
            console.warn('Analytics error (non-critical):', error.message);
        }
    }
    
    // Méthodes de contrôle utilisateur
    disable() {
        this.isEnabled = false;
        localStorage.setItem('dax_analytics_disabled', 'true');
        console.log('📊 Analytics disabled by user');
    }
    
    enable() {
        this.isEnabled = true;
        localStorage.removeItem('dax_analytics_disabled');
        console.log('📊 Analytics enabled by user');
    }
    
    getPrivacyInfo() {
        return {
            dataCollected: [
                'Page views (anonymized paths only)',
                'Search terms (filtered and cleaned)',
                'Character views (character names only)',
                'Device type (Desktop/Mobile/Tablet)',
                'Browser type (Chrome/Firefox/Safari etc.)',
                'Referrer type (search_engine/social/direct etc.)'
            ],
            dataNotCollected: [
                'Personal information',
                'IP addresses (server-side hashing only)',
                'Precise location data',
                'Persistent tracking cookies',
                'Cross-site tracking',
                'User identification'
            ],
            retention: '30 days maximum',
            purpose: 'Improve site performance and user experience'
        };
    }
}

// Initialisation automatique
if (typeof window !== 'undefined') {
    // Attendre que le DOM soit prêt
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            try {
                window.daxAnalytics = new DaxAnalytics();
            } catch (error) {
                console.warn('Analytics failed to initialize (non-critical):', error);
            }
        });
    } else {
        try {
            window.daxAnalytics = new DaxAnalytics();
        } catch (error) {
            console.warn('Analytics failed to initialize (non-critical):', error);
        }
    }
}

// Exposer pour usage manuel si nécessaire
if (typeof window !== 'undefined') {
    window.DaxAnalytics = DaxAnalytics;
}
