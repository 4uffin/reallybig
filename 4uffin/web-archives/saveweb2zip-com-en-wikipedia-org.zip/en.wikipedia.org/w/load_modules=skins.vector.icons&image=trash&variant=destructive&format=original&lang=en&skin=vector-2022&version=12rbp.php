<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		trash
	</title><g fill="#d73333"><path d="m16 8-1.087 12H5.087L4 8h2l.913 10h6.174L14 8zm-3-4h5v2H2V4h5V0h6zM9 4h2V2H9z"/></g></svg>
