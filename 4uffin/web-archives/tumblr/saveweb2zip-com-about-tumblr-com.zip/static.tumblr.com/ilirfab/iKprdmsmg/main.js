document.addEventListener("DOMContentLoaded", function() {
	const isVisible = (el) => el.classList.contains('show');
	const toggleVisibility = (el) => el.classList.toggle('show');
	const policyMenuItem = document.getElementById('policy-menu-item');
	const resourcesMenuItem = document.getElementById('resources-menu-item');
	const languageMenuItem = document.getElementById('language-menu-item');
	const policyMenuItemBurger = document.getElementById('policy-menu-item-burger');
	const resourcesMenuItemBurger = document.getElementById('resources-menu-item-burger');
	const languageMenuItemBurger = document.getElementById('language-menu-item-burger');
	const burgerMenuItem = document.getElementById('burger-menu-item');

	const toggleResourceVisibility = (e) => {
		const dropdown = document.getElementById("resources-dropdown");

		if (!isVisible(dropdown)) {
			const container = e.target;
			const maybeCollapseDropdown = (e) => {
				if (!container.contains(e.target)) {
					toggleVisibility(dropdown);
				}

				if (!isVisible(dropdown)) {
					document.removeEventListener('click', maybeCollapseDropdown);
				}
			}

			document.addEventListener('click', maybeCollapseDropdown);
		}

		toggleVisibility(dropdown);
	}

	const togglePolicyVisibility = (e) => {
		const dropdown = document.getElementById("policy-dropdown")

		if (!isVisible(dropdown)) {
			const container = e.target;
			const maybeCollapseDropdown = (e) => {
				if (!container.contains(e.target)) {
					toggleVisibility(dropdown);
				}

				if (!isVisible(dropdown)) {
					document.removeEventListener('click', maybeCollapseDropdown);
				}
			}

			document.addEventListener('click', maybeCollapseDropdown);
		}

		toggleVisibility(dropdown);
	}

	const toggleLanguageVisibility = (e) => {
		const dropdown = document.getElementById("language-dropdown")

		if (!isVisible(dropdown)) {
			const container = e.target;
			const maybeCollapseDropdown = (e) => {
				if (!container.contains(e.target)) {
					toggleVisibility(dropdown);
				}

				if (!isVisible(dropdown)) {
					document.removeEventListener('click', maybeCollapseDropdown);
				}
			}

			document.addEventListener('click', maybeCollapseDropdown);
		}

		toggleVisibility(dropdown);
	}
// burger items
	const toggleResourceBurgerVisibility = (e) => {
		const dropdown = document.getElementById("resources-dropdown-burger");

		if (!isVisible(dropdown)) {
			const container = e.target;
			const maybeCollapseDropdown = (e) => {
				if (!container.contains(e.target)) {
					toggleVisibility(dropdown);
				}

				if (!isVisible(dropdown)) {
					document.removeEventListener('click', maybeCollapseDropdown);
				}
			}

			document.addEventListener('click', maybeCollapseDropdown);
		}

		toggleVisibility(dropdown);
	}

	const togglePolicyBurgerVisibility = (e) => {
		const dropdown = document.getElementById("policy-dropdown-burger")

		if (!isVisible(dropdown)) {
			const container = e.target;
			const maybeCollapseDropdown = (e) => {
				if (!container.contains(e.target)) {
					toggleVisibility(dropdown);
				}

				if (!isVisible(dropdown)) {
					document.removeEventListener('click', maybeCollapseDropdown);
				}
			}

			document.addEventListener('click', maybeCollapseDropdown);
		}

		toggleVisibility(dropdown);
	}

	const toggleLanguageBurgerVisibility = (e) => {
		const dropdown = document.getElementById("language-dropdown-burger")

		if (!isVisible(dropdown)) {
			const container = e.target;
			const maybeCollapseDropdown = (e) => {
				if (!container.contains(e.target)) {
					toggleVisibility(dropdown);
				}

				if (!isVisible(dropdown)) {
					document.removeEventListener('click', maybeCollapseDropdown);
				}
			}

			document.addEventListener('click', maybeCollapseDropdown);
		}

		toggleVisibility(dropdown);
	}

	const toggleBurgerVisibility = (e) => {
		const dropdown = document.getElementById("burger-dropdown");

		if (!isVisible(dropdown)) {
			const container = e.target;
			const maybeCollapseDropdown = (e) => {
				if (!container.contains(e.target)) {
					toggleVisibility(dropdown);
				}

				if (!isVisible(dropdown)) {
					document.removeEventListener('click', maybeCollapseDropdown);
				}
			}

			document.addEventListener('click', maybeCollapseDropdown);
		}

		toggleVisibility(dropdown);
	}

	resourcesMenuItem.addEventListener('click', toggleResourceVisibility);
	policyMenuItem.addEventListener('click', togglePolicyVisibility);
	languageMenuItem.addEventListener('click', toggleLanguageVisibility);
	resourcesMenuItemBurger.addEventListener('click', toggleResourceBurgerVisibility);
	policyMenuItemBurger.addEventListener('click', togglePolicyBurgerVisibility);
	languageMenuItemBurger.addEventListener('click', toggleLanguageBurgerVisibility);
	burgerMenuItem.addEventListener('click', toggleBurgerVisibility);

	fetch('https://api.tumblr.com/v2/stats')
		.then(res => res.json())
		.then(res => {
			const data = res.response;
			const blogCount = document.createTextNode(data.tumblelog_count.toLocaleString());
			const blogCountEl = document.getElementById('blog-count');
			blogCountEl.appendChild(blogCount);

			const blogCountYesterday = document.createTextNode(data.blogs_yesterday.toLocaleString());
			const blogCountYesterdayEl = document.getElementById('blog-count-yesterday');
			blogCountYesterdayEl.appendChild(blogCountYesterday);

			const postCountYesterday = document.createTextNode(data.posts_yesterday.toLocaleString());
			const postCountYesterdayEl = document.getElementById('post-count-yesterday');
			postCountYesterdayEl.appendChild(postCountYesterday);

			const languageCount = document.createTextNode(data.language_count.toLocaleString());
			const languageCountEl = document.getElementById('language-count');
			languageCountEl.appendChild(languageCount);

			const topics = data.trending_topics;
			const topicsEl = document.getElementById('trending-topics');
			topics.map(topic => {
				const text = document.createTextNode(topic);
				const listItem = document.createElement('li');
				listItem.appendChild(text);
				topicsEl.appendChild(listItem);
			});
		})
		.catch(() => {
			// If the api fetch fails, hide the top ten facts section.
			const section = document.getElementById('quick-facts');
			section.style.display = 'none';
		});
});
