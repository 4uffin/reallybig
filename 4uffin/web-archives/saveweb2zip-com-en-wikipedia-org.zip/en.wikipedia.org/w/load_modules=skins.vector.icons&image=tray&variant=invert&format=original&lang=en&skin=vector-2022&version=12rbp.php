<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		tray
	</title><g fill="#fff"><path d="M19 19H1V1h18zM3 17h14v-5h-3.112l-1.714 2H7.826l-1.714-2H3zm0-7h4.031l1.714 2h2.51l1.714-2H17V3H3z"/></g></svg>
