<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		user group
	</title><g fill="#fff"><path d="M7 10c.91 0 1.764.244 2.5.67A5 5 0 0 1 12 10h3a5 5 0 0 1 5 5v2H0v-2a5 5 0 0 1 5-5zm5 2q-.473.002-.901.138c.567.81.901 1.797.901 2.862h6a3 3 0 0 0-3-3zM6 3a3 3 0 1 1 0 6 3 3 0 0 1 0-6m7.5 0a3 3 0 1 1 0 6 3 3 0 0 1 0-6m0 2a1 1 0 1 0 0 2 1 1 0 0 0 0-2"/></g></svg>
