<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		search
	</title><g fill="#fff"><path d="M8 1a7 7 0 0 1 5.605 11.191l5.102 5.102-1.414 1.414-5.102-5.102A7 7 0 1 1 8 1m0 2a5 5 0 1 0 0 10A5 5 0 0 0 8 3"/></g></svg>
