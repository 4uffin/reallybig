<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		eye
	</title><g fill="#000"><path d="M10 7.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5"/><path d="M5.05 5.036a7 7 0 0 1 9.9 0l4.257 4.257v1.415l-4.258 4.256a7 7 0 0 1-9.9 0L.794 10.708V9.293zm8.485 1.414a5 5 0 0 0-7.07 0L2.915 10l3.55 3.55a5 5 0 0 0 7.07 0l3.55-3.55z"/></g></svg>
