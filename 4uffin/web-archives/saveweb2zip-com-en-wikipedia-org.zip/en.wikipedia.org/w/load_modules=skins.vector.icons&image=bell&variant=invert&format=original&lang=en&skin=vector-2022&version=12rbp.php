<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		bell
	</title><g fill="#fff"><path d="M10 1c.69 0 1.25.56 1.25 1.25v.392a5.59 5.59 0 0 1 4.342 5.45v3.583l2.717 3.737L17.5 17h-5.25a2.25 2.25 0 0 1-4.488.23L7.75 17H2.5l-.809-1.588 2.717-3.737V8.092a5.59 5.59 0 0 1 4.342-5.45V2.25C8.75 1.56 9.31 1 10 1"/></g></svg>
