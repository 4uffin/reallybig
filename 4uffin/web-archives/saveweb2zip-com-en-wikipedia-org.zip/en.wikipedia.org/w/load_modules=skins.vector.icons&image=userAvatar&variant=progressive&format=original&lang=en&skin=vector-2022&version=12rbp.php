<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		user
	</title><g fill="#36c"><path d="M12 11a6 6 0 0 1 6 6v2H2v-2a6 6 0 0 1 6-6zM10 1a4 4 0 1 1 0 8 4 4 0 0 1 0-8"/></g></svg>
