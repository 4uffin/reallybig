<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		log out
	</title><g fill="#36c"><path d="M17 3H3v14h14v2H1V1h16z"/><path d="M19 9.293v1.414l-4.69 4.707L12.895 14l3-3H6V9h9.896l-3-3 1.414-1.414z"/></g></svg>
