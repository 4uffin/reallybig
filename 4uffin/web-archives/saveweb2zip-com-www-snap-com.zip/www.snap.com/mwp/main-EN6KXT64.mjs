
      // Merge in the client-visible compile-time environment.
      window.process = {
        ...window.process,
        env: {
          ...window.process?.env,
          ...({"CI_COMMIT":"603dc64e15eb4bcf3f57cafd92106160eb13822a","CI_PIPELINE_ID":"5553a0b4-798a-4111-a873-3c771a178b29","GOOGLE_CLOUD_PROJECT":"marketing-web-platform","DEPLOYMENT_TYPE":"production","NODE_ENV":"production","PREVIEW":"false","SITE_CONFIG":"snap"})
        }
      };

      // Stop crashing when certain node libraries are imported.
      window.global = window.global ?? {};
    
import{a as n0,b as qe,c as Ln,d as d0}from"./chunks/chunk-6HRF3ZRU.mjs";import{a as md,b as Rt,c as t0,d as o0,e as es,f as l0,g as p0,h as c0}from"./chunks/chunk-5UGDMMGM.mjs";import{a as Ql}from"./chunks/chunk-IYAGGEMV.mjs";import{$ as M0,A as hn,B as Td,C as ns,D as Ad,E as y0,F as m0,G as g0,H as _d,I as f0,J as b0,K as wd,L as ci,M as rs,O as S0,P as as,Q as ee,R as Ia,S as h0,T as C0,U as x0,V as v0,W as I0,X as ka,Y as k0,Z as vt,_ as V,a as cd,aa as T0,b as rk,ba as ap,c as ak,ca as Dd,d as zf,da as Pd,e as ik,ea as Te,f as sk,fa as A0,g as qi,ga as _0,h as gn,ha as w0,i as lk,ia as Me,j as pk,ja as D0,k as dd,ka as P0,l as ud,la as Re,m as E,ma as Vr,n as Fr,na as Hn,o as Kl,oa as Ma,p as ck,pa as Or,q as yd,qa as ge,r as tt,ra as ot,s as rp,t as r0,u as Ft,v as kd,w as u0,x as Hr,y as GU,z as Md}from"./chunks/chunk-RCLN6RMH.mjs";import{A as Zk,B as e0,C as He,D as or,E as xd,F as rn,G as no,a as Qf,b as ne,c as zk,d as Uk,e as Wk,f as De,g as Zl,h as Qk,i as et,j as $n,k as qk,l as ep,m as tp,n as op,o as np,p as jf,q as Yf,r as Xf,s as Jf,t as Zf,u as eb,v as Kk,w as jk,x as Yk,y as Xk,z as Jk}from"./chunks/chunk-CUEYYI4K.mjs";import{a as tb,b as Id,c as ro,d as is,e as N0}from"./chunks/chunk-DBKVQXQB.mjs";import"./chunks/chunk-Z7NU7ONH.mjs";import{a as vd,b as ts,c as xa,d as os,e as i0,f as Vt,g as va}from"./chunks/chunk-42JKMCAQ.mjs";import"./chunks/chunk-6TMDV4II.mjs";import{a as nr,b as E0}from"./chunks/chunk-M4TX3MZU.mjs";import"./chunks/chunk-YGC4JQES.mjs";import{a as a0}from"./chunks/chunk-ZWXBYFFL.mjs";import{a as Ee}from"./chunks/chunk-X222VCYE.mjs";import"./chunks/chunk-HEVRBIZO.mjs";import{a as JI,b as pd,c as ZI,d as ek,e as tk,f as ok,g as nk,h as Ze,i as xt,j as lt,k as Vk,l as Sn,m as Yo}from"./chunks/chunk-3DCHICCX.mjs";import{b as Br,c as fn,d as Ko}from"./chunks/chunk-UZNJ7OIX.mjs";import"./chunks/chunk-U4JR7UHG.mjs";import{a as OU}from"./chunks/chunk-VV4OENPR.mjs";import{a as s0}from"./chunks/chunk-ZMT4S4XL.mjs";import{a as ma}from"./chunks/chunk-AO6ENGLD.mjs";import{$ as vo,A as jl,Aa as Sa,B as Ct,Ba as yo,C as r,Ca as ut,D as Lt,Da as qt,E as fa,Ea as Sd,F as gk,Fa as Dk,G as fk,Ga as Pk,H as Sk,Ha as Nk,I as er,Ia as Ek,Ja as Rk,K as hk,Ka as Fk,La as Bk,Ma as $k,N as $r,Na as Lk,O as dt,P as Ck,Pa as ha,Q as xk,Qa as hd,R as jo,Ra as Cd,S as vk,Sa as qf,T as Ik,Ta as Ca,U as Qt,Ua as Jl,V as N,Va as Lr,W as H,Wa as Hk,X as Yl,Y as Xe,Ya as Gk,Z as kk,_ as Ht,a as BI,aa as bn,b as w,ba as Mk,c as Co,ca as uo,d as BU,da as li,e as $U,ea as ji,f as $I,fa as Tk,g as LI,ga as fd,ha as Wf,i as HI,ia as Yi,ja as Io,la as tr,m as Fo,ma as Bn,n as h,na as Xi,o as dk,oa as Xl,p as qo,pa as Y,q as c,qa as VU,r as Ki,ra as pe,sa as i,t as uk,ta as x,u as yk,ua as Ak,v as xo,va as _k,w as Uf,wa as wk,xa as Ji,ya as bd,z as mk,za as ba}from"./chunks/chunk-J5LOCUUB.mjs";import{a as Zi,b as Ok,c as pi,e as Kf}from"./chunks/chunk-TYV4YHRN.mjs";import{C as gd,F as bk,a as ad,b as GI,d as id,h as zI,i as ya,j as sd,o as QI,p as ld,q as qI,r as KI,u as jI,w as YI,x as XI}from"./chunks/chunk-N3TCCOLI.mjs";import{A as WI,B as Qo,b as xe,d as T,f as Ae,m as VI,n as LU,o as ql,p as OI,y as UI,z as HU}from"./chunks/chunk-DA3UZLSS.mjs";var B0=xe((dne,qU)=>{qU.exports={warning:"\u062A\u062D\u0630\u064A\u0631",message:`\u0644\u0627 \u062A\u062F\u062E\u0644 \u0631\u0645\u0632\u064B\u0627 \u0644\u0627 \u062A\u0641\u0647\u0645\u0647 \u0623\u0648 \u062A\u0644\u0635\u0642\u0647.
\u0642\u062F \u064A\u0633\u0645\u062D \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0648\u062D\u062F\u0629 \u0627\u0644\u062A\u062D\u0643\u0645 \u0647\u0630\u0647 \u0644\u0644\u0645\u0639\u062A\u062F\u064A\u0646 \u0628\u0627\u0646\u062A\u062D\u0627\u0644 \u0634\u062E\u0635\u064A\u062A\u0643 \u0648\u0633\u0631\u0642\u0629 \u0645\u0639\u0644\u0648\u0645\u0627\u062A\u0643 \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0647\u062C\u0645\u0629 \u062A\u0633\u0645\u0649 "\u0627\u0644\u0647\u062C\u0648\u0645 \u0627\u0644\u0630\u0627\u062A\u064A XSS".`}});var $0=xe((une,KU)=>{KU.exports={warning:"\u09B8\u09A4\u09B0\u09CD\u0995\u09C0\u0995\u09B0\u09A3!",message:`\u0986\u09AA\u09A8\u09BF \u09AC\u09C1\u099D\u09A4\u09C7 \u09AA\u09BE\u09B0\u099B\u09C7 \u09A8\u09BE \u098F\u09AE\u09A8 \u0995\u09CB\u09A1 \u09B2\u09BF\u0996\u09AC\u09C7 \u09A8\u09BE \u09AC\u09BE \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09AC\u09C7\u09A8 \u09A8\u09BE\u0964
\u098F\u0987 \u0995\u09A8\u09B8\u09CB\u09B2\u099F\u09BF \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C7 \u0986\u0995\u09CD\u09B0\u09AE\u09A3\u0995\u09BE\u09B0\u09C0\u09B0\u09BE \u0986\u09AA\u09A8\u09BE\u09B0 \u099B\u09A6\u09CD\u09AE\u09AC\u09C7\u09B6 \u09A7\u09BE\u09B0\u09A3 \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7 \u098F\u09AC\u0982 Self-XSS \u09A8\u09BE\u09AE\u0995 \u0986\u0995\u09CD\u09B0\u09AE\u09A3 \u09AA\u09A6\u09CD\u09A7\u09A4\u09BF \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09A4\u09A5\u09CD\u09AF \u099A\u09C1\u09B0\u09BF \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u0964`}});var L0=xe((yne,jU)=>{jU.exports={warning:"\u09B8\u09A4\u09B0\u09CD\u0995\u09A4\u09BE!",message:`\u0986\u09AA\u09A8\u09BF \u09AC\u09C1\u099D\u09A4\u09C7 \u09AA\u09BE\u09B0\u099B\u09C7 \u09A8\u09BE \u098F\u09AE\u09A8 \u0995\u09CB\u09A1 \u09B2\u09BF\u0996\u09AC\u09C7\u09A8 \u09A8\u09BE \u09AC\u09BE \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09AC\u09C7\u09A8 \u09A8\u09BE\u0964
\u098F\u0987 \u0995\u09A8\u09B8\u09CB\u09B2\u099F\u09BF \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C7 \u0986\u0995\u09CD\u09B0\u09AE\u09A3\u0995\u09BE\u09B0\u09C0\u09B0\u09BE \u0986\u09AA\u09A8\u09BE\u09B0 \u099B\u09A6\u09CD\u09AE\u09AC\u09C7\u09B6 \u09A8\u09BF\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7 \u098F\u09AC\u0982 Self-XSS \u09A8\u09BE\u09AE\u09C7 \u098F\u0995\u099F\u09BF \u0986\u0995\u09CD\u09B0\u09AE\u09A3 \u09AA\u09A6\u09CD\u09A7\u09A4\u09BF \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09A4\u09A5\u09CD\u09AF \u09B9\u09BE\u09A4\u09BF\u09DF\u09C7 \u09A8\u09BF\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u0964`}});var H0=xe((mne,YU)=>{YU.exports={warning:"ADVARSEL!",message:`Undlad at indtaste eller inds\xE6tte kode, som du ikke forst\xE5r.
Brug af denne konsol kan s\xE6tte hackere i stand til at efterligne dig og stj\xE6le dine oplysninger ved hj\xE6lp af et angreb ved navn Self-XSS.`}});var V0=xe((gne,XU)=>{XU.exports={warning:"WARNUNG!",message:`Gib oder f\xFCge keinen Code ein, den du nicht verstehst.
Diese Konsole erm\xF6glicht es Angreifern, sich als du auszugeben und deine Daten mithilfe eines Angriffs namens Self-XSS zu stehlen.`}});var O0=xe((fne,JU)=>{JU.exports={warning:"\u03A0\u03A1\u039F\u03A3\u039F\u03A7\u0397!",message:`\u039C\u03B7\u03BD \u03B5\u03B9\u03C3\u03AC\u03B3\u03B5\u03B9\u03C2 \u03AE \u03BA\u03AC\u03BD\u03B5\u03B9\u03C2 \u03B5\u03C0\u03B9\u03BA\u03CC\u03BB\u03BB\u03B7\u03C3\u03B7 \u03BA\u03C9\u03B4\u03B9\u03BA\u03CE\u03BD \u03C0\u03BF\u03C5 \u03B4\u03B5\u03BD \u03BA\u03B1\u03C4\u03B1\u03BD\u03BF\u03B5\u03AF\u03C2.
\u0397 \u03C7\u03C1\u03AE\u03C3\u03B7 \u03B1\u03C5\u03C4\u03AE\u03C2 \u03C4\u03B7\u03C2 \u03BA\u03BF\u03BD\u03C3\u03CC\u03BB\u03B1\u03C2 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03B9\u03B8\u03B1\u03BD\u03CC \u03BD\u03B1 \u03B5\u03C0\u03B9\u03C4\u03C1\u03AD\u03C8\u03B5\u03B9 \u03C3\u03C4\u03BF\u03C5\u03C2 \u03B5\u03B9\u03C3\u03B2\u03BF\u03BB\u03B5\u03AF\u03C2 \u03BD\u03B1 \u03C0\u03C1\u03BF\u03C3\u03C0\u03BF\u03B9\u03B7\u03B8\u03BF\u03CD\u03BD \u03CC\u03C4\u03B9 \u03B5\u03AF\u03C3\u03B1\u03B9 \u03B5\u03C3\u03CD \u03BA\u03B1\u03B9 \u03BD\u03B1 \u03BA\u03BB\u03AD\u03C8\u03BF\u03C5\u03BD \u03C4\u03B9\u03C2 \u03C0\u03BB\u03B7\u03C1\u03BF\u03C6\u03BF\u03C1\u03AF\u03B5\u03C2 \u03C3\u03BF\u03C5 \u03BC\u03AD\u03C3\u03C9 \u03BC\u03B9\u03B1\u03C2 \u03B5\u03C0\u03AF\u03B8\u03B5\u03C3\u03B7\u03C2 \u03C0\u03BF\u03C5 \u03BB\u03AD\u03B3\u03B5\u03C4\u03B1\u03B9 Self-XSS.`}});var G0=xe((bne,ZU)=>{ZU.exports={warning:"WARNING!",message:`Do not enter or paste code that you do not understand.
Using this console could allow attackers to impersonate you and steal your information using an attack called Self-XSS.`}});var z0=xe((Sne,eW)=>{eW.exports={warning:"WARNING!",message:`Do not enter or paste code that you do not understand.
Using this console may allow attackers to impersonate you and steal your information using an attack called Self-XSS.`}});var U0=xe((hne,tW)=>{tW.exports={warning:"\xA1ADVERTENCIA!",message:`No ingreses ni pegues c\xF3digo que no entiendas.
Si us\xE1s esta consola, los atacantes podr\xEDan hacerse pasar por vos y robar tu informaci\xF3n por medio de un ataque llamado Self-XSS.`}});var W0=xe((Cne,oW)=>{oW.exports={warning:"\xA1ADVERTENCIA!",message:`No introduzcas ni pegues c\xF3digos que no comprendas.
Si usas esta consola, los atacantes podr\xEDan suplantar tu identidad y robar tu informaci\xF3n mediante un ataque llamado Self-XSS.`}});var Q0=xe((xne,nW)=>{nW.exports={warning:"\xA1ADVERTENCIA!",message:`No escribas o pegues c\xF3digo que no entiendas.
Usar esta consola podr\xEDa permitir que personas malintencionadas roben tu identidad y tu informaci\xF3n usando un ataque llamado Self-XSS.`}});var q0=xe((vne,rW)=>{rW.exports={warning:"\xA1ADVERTENCIA!",message:`No ingreses ni pegues c\xF3digo que no entiendes.
Si usas esta consola, puedes permitir que los atacantes se hagan pasar por ti y roben tu informaci\xF3n con un ataque conocido como Self-XSS.`}});var K0=xe((Ine,aW)=>{aW.exports={warning:"VAROITUS!",message:`\xC4l\xE4 anna tai liit\xE4 t\xE4h\xE4n koodia, jota et ymm\xE4rr\xE4.
T\xE4m\xE4n konsolin k\xE4ytt\xE4minen saattaa johtaa XSS-hy\xF6kk\xE4ykseen, jolloin hy\xF6kk\xE4\xE4j\xE4t pystyv\xE4t esiintym\xE4\xE4n sinuna ja varastamaan tietosi.`}});var j0=xe((kne,iW)=>{iW.exports={warning:"BABALA!",message:`Huwag maglagay o mag-paste ng code na hindi mo naiintindihan
Ang paggamit sa console na ito ay puwedeng magbigay-daan sa mga attacker na magpanggap bilang ikaw at nakawin ang iyong impormasyon gamit ang isang attack na tinatawag na Self-XSS.`}});var Y0=xe((Mne,sW)=>{sW.exports={warning:"ATTENTION\xA0!",message:`Ne saisissez pas ou ne collez pas de code que vous ne comprenez pas.
L'utilisation de cette console risque de permettre aux hackers de se faire passer pour vous et de voler vos informations au moyen d'une attaque appel\xE9e Self-XSS.`}});var X0=xe((Tne,lW)=>{lW.exports={warning:"\u0A9A\u0AC7\u0AA4\u0AB5\u0AA3\u0AC0!",message:`\u0AA4\u0AAE\u0AC7 \u0AB8\u0AAE\u0A9C\u0AA4\u0ABE \u0AA8 \u0AB9\u0ACB \u0A8F\u0AB5\u0ACB \u0A95\u0ACB\u0AA1 \u0AB2\u0A96\u0AB6\u0ACB \u0A95\u0AC7 \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0AB6\u0ACB \u0AA8\u0AB9\u0AC0\u0A82.
\u0A86 \u0A95\u0AA8\u0ACD\u0AB8\u0ACB\u0AB2\u0AA8\u0ACB \u0A89\u0AAA\u0AAF\u0ACB\u0A97 \u0A95\u0AB0\u0AB5\u0ABE\u0AA5\u0AC0 \u0AB9\u0AC1\u0AAE\u0AB2\u0ABE\u0A96\u0ACB\u0AB0\u0ACB \u0AB8\u0AC7\u0AB2\u0ACD\u0AAB-XSS \u0AA8\u0ABE\u0AAE\u0AA8\u0ABE \u0AB9\u0AC1\u0AAE\u0AB2\u0ABE\u0AA8\u0ACB \u0A89\u0AAA\u0AAF\u0ACB\u0A97 \u0A95\u0AB0\u0AC0\u0AA8\u0AC7 \u0AA4\u0AAE\u0AC7 \u0AB9\u0ACB\u0AB5\u0ABE\u0AA8\u0AC1\u0A82 \u0A85\u0AA8\u0AC1\u0A95\u0AB0\u0AA3 \u0A95\u0AB0\u0AC0 \u0AB6\u0A95\u0AC7 \u0A9B\u0AC7 \u0A85\u0AA8\u0AC7 \u0AA4\u0AAE\u0ABE\u0AB0\u0AC0 \u0AAE\u0ABE\u0AB9\u0ABF\u0AA4\u0AC0 \u0A9A\u0ACB\u0AB0\u0AC0 \u0AB6\u0A95\u0AC7 \u0A9B\u0AC7.`}});var J0=xe((Ane,pW)=>{pW.exports={warning:"\u091A\u0947\u0924\u093E\u0935\u0928\u0940!",message:`\u0915\u094B\u0908 \u0910\u0938\u093E \u0915\u094B\u0921 \u0926\u0930\u094D\u091C \u092F\u093E \u092A\u0947\u0938\u094D\u091F \u0928 \u0915\u0930\u0947\u0902 \u091C\u094B \u0906\u092A\u0915\u0940 \u0938\u092E\u091D \u0938\u0947 \u092A\u0930\u0947 \u0939\u094B\u0964
\u0907\u0938 \u0915\u0902\u0938\u094B\u0932 \u0915\u093E \u0907\u0938\u094D\u0924\u0947\u092E\u093E\u0932 \u0915\u0930\u0928\u0947 \u0938\u0947 \u0939\u092E\u0932\u093E\u0935\u0930 Self-XSS \u0915\u0939\u0947 \u091C\u093E\u0928\u0947 \u0935\u093E\u0932\u0947 \u0939\u092E\u0932\u0947 \u0915\u093E \u0907\u0938\u094D\u0924\u0947\u092E\u093E\u0932 \u0915\u0930\u0924\u0947 \u0939\u0941\u090F \u0906\u092A\u0915\u093E \u092D\u0947\u0937 \u0927\u093E\u0930\u0923 \u0915\u0930\u0915\u0947 \u0906\u092A\u0915\u0940 \u091C\u093E\u0928\u0915\u093E\u0930\u0940 \u091A\u0941\u0930\u093E \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\u0964`}});var Z0=xe((_ne,cW)=>{cW.exports={warning:"PERINGATAN!",message:`Jangan memasukkan atau menempelkan kode yang tidak Anda pahami.
Menggunakan konsol ini dapat memberikan akses kepada penyerang untuk menyamar sebagai Anda dan mencuri informasi menggunakan serangan yang disebut Self-XSS.`}});var eM=xe((wne,dW)=>{dW.exports={warning:"ATTENZIONE!",message:`Non inserire o incollare codici che non conosci.
L'utilizzo di questa console potrebbe consentire a utenti malintenzionati di assumere la tua identit\xE0 e rubare le tue informazioni tramite un attacco chiamato Self-XSS.`}});var tM=xe((Dne,uW)=>{uW.exports={warning:"\u8B66\u544A\uFF01",message:`\u4E0D\u660E\u306A\u30B3\u30FC\u30C9\u3092\u5165\u529B\u307E\u305F\u306F\u8CBC\u308A\u4ED8\u3051\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u3002
\u3053\u306E\u30B3\u30F3\u30BD\u30FC\u30EB\u3092\u4F7F\u7528\u3059\u308B\u3068\u3001\u653B\u6483\u8005\u304CSelf-XSS\u3068\u3044\u3046\u653B\u6483\u3092\u4F7F\u7528\u3057\u3066\u3042\u306A\u305F\u306B\u306A\u308A\u3059\u307E\u3057\u3001\u60C5\u5831\u3092\u76D7\u3080\u3053\u3068\u304C\u3067\u304D\u307E\u3059\u3002`}});var oM=xe((Pne,yW)=>{yW.exports={warning:"\u0C8E\u0C9A\u0CCD\u0C9A\u0CB0\u0CBF\u0C95\u0CC6!",message:`\u0CA8\u0CBF\u0CAE\u0C97\u0CC6 \u0C85\u0CB0\u0CCD\u0CA5\u0CB5\u0CBE\u0C97\u0CA6 \u0C95\u0CCB\u0CA1\u0CCD \u0C85\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CAE\u0CC2\u0CA6\u0CBF\u0CB8\u0CAC\u0CC7\u0CA1\u0CBF \u0C85\u0CA5\u0CB5\u0CBE \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CAC\u0CC7\u0CA1\u0CBF.
\u0C88 \u0C95\u0CA8\u0CCD\u0CB8\u0CCB\u0CB2\u0CCD \u0CAC\u0CB3\u0CB8\u0CC1\u0CB5\u0CC1\u0CA6\u0CB0\u0CBF\u0C82\u0CA6 \u0CA6\u0CBE\u0CB3\u0CBF\u0C95\u0CCB\u0CB0\u0CB0\u0CC1 \u0CA8\u0CBF\u0CAE\u0CCD\u0CAE\u0C82\u0CA4\u0CC6 \u0CB8\u0CCB\u0C97\u0CC1 \u0CB9\u0CBE\u0C95\u0CB2\u0CC1 \u0CAE\u0CA4\u0CCD\u0CA4\u0CC1 Self-XSS \u0C8E\u0CA8\u0CCD\u0CA8\u0CC1\u0CB5 \u0C92\u0C82\u0CA6\u0CC1 \u0CA6\u0CBE\u0CB3\u0CBF\u0CAF\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAC\u0CB3\u0CB8\u0CBF\u0C95\u0CCA\u0C82\u0CA1\u0CC1 \u0CA8\u0CBF\u0CAE\u0CCD\u0CAE \u0CAE\u0CBE\u0CB9\u0CBF\u0CA4\u0CBF\u0CAF\u0CA8\u0CCD\u0CA8\u0CC1 \u0C95\u0CA6\u0CBF\u0CAF\u0CB2\u0CC1 \u0C85\u0CB5\u0C95\u0CBE\u0CB6 \u0CAE\u0CBE\u0CA1\u0CBF\u0C95\u0CCA\u0CA1\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1.`}});var nM=xe((Nne,mW)=>{mW.exports={warning:"\uACBD\uACE0!",message:`\uBAA8\uB974\uB294 \uCF54\uB4DC\uB97C \uC785\uB825\uD558\uAC70\uB098 \uBD99\uC5EC\uB123\uC9C0 \uB9C8\uC138\uC694.
\uC774 \uCF58\uC194\uC744 \uC0AC\uC6A9\uD558\uBA74 \uD574\uCEE4\uAC00 Self-XSS\uB77C\uACE0 \uBD88\uB9AC\uB294 \uACF5\uACA9\uC744 \uC0AC\uC6A9\uD574 \uD68C\uC6D0\uB2D8\uC744 \uC0AC\uCE6D\uD558\uC5EC \uAC1C\uC778 \uC815\uBCF4\uB97C \uD6D4\uCCD0 \uAC08 \uC218\uB3C4 \uC788\uC2B5\uB2C8\uB2E4.`}});var rM=xe((Ene,gW)=>{gW.exports={warning:"\u0D2E\u0D41\u0D28\u0D4D\u0D28\u0D31\u0D3F\u0D2F\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D!",message:`\u0D28\u0D3F\u0D19\u0D4D\u0D19\u0D7E\u0D15\u0D4D\u0D15\u0D4D \u0D2E\u0D28\u0D38\u0D4D\u0D38\u0D3F\u0D32\u0D3E\u0D15\u0D3E\u0D24\u0D4D\u0D24 \u0D15\u0D4B\u0D21\u0D4D \u0D28\u0D7D\u0D15\u0D41\u0D15\u0D2F\u0D4B \u0D12\u0D1F\u0D4D\u0D1F\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15\u0D2F\u0D4B \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D30\u0D41\u0D24\u0D4D.
\u0D08 \u0D15\u0D7A\u0D38\u0D4B\u0D7E \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D3F\u0D32\u0D42\u0D1F\u0D46, Self-XSS \u0D0E\u0D28\u0D4D\u0D28\u0D4D \u0D05\u0D31\u0D3F\u0D2F\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D41\u0D28\u0D4D\u0D28 \u0D06\u0D15\u0D4D\u0D30\u0D2E\u0D23\u0D02 \u0D35\u0D34\u0D3F \u0D05\u0D31\u0D4D\u0D31\u0D3E\u0D15\u0D4D\u0D15\u0D7C\u0D2E\u0D3E\u0D7C\u0D15\u0D4D\u0D15\u0D4D \u0D28\u0D3F\u0D19\u0D4D\u0D19\u0D33\u0D41\u0D1F\u0D46 \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D2E\u0D4B\u0D37\u0D4D\u0D1F\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D28\u0D41\u0D02 \u0D28\u0D3F\u0D19\u0D4D\u0D19\u0D33\u0D3E\u0D2F\u0D3F \u0D06\u0D7E\u0D2E\u0D3E\u0D31\u0D3E\u0D1F\u0D4D\u0D1F\u0D02 \u0D28\u0D1F\u0D24\u0D4D\u0D24\u0D3E\u0D28\u0D41\u0D02 \u0D15\u0D34\u0D3F\u0D2F\u0D41\u0D02.`}});var aM=xe((Rne,fW)=>{fW.exports={warning:"\u091A\u0947\u0924\u093E\u0935\u0923\u0940!",message:`\u0924\u0941\u092E\u094D\u0939\u093E\u0932\u093E \u0938\u092E\u091C\u0924 \u0928\u0938\u0947\u0932 \u0905\u0938\u093E \u0915\u094B\u0921 \u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F \u0915\u093F\u0902\u0935\u093E \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u0942 \u0928\u0915\u093E.
\u0939\u093E \u0915\u0902\u0938\u094B\u0932 \u0935\u093E\u092A\u0930\u0923\u094D\u092F\u093E\u0928\u0947 \u0906\u0915\u094D\u0930\u092E\u0923\u0915\u0930\u094D\u0924\u094D\u092F\u093E\u0902\u0928\u093E Self-XSS \u0928\u093E\u0935\u093E\u091A\u093E \u0906\u0915\u094D\u0930\u092E\u0923 \u0935\u093E\u092A\u0930\u0942\u0928 \u0924\u0941\u092E\u091A\u0940 \u0924\u094B\u0924\u092F\u093E\u0917\u093F\u0930\u0940 \u0915\u0930\u0923\u094D\u092F\u093E\u091A\u0940 \u0906\u0923\u093F \u0924\u0941\u092E\u091A\u0940 \u092E\u093E\u0939\u093F\u0924\u0940 \u091A\u094B\u0930\u0923\u094D\u092F\u093E\u091A\u0940 \u0905\u0928\u0941\u092E\u0924\u0940 \u092E\u093F\u0933\u0942 \u0936\u0915\u0924\u0947.`}});var iM=xe((Fne,bW)=>{bW.exports={warning:"AMARAN!",message:`Jangan masukkan atau tampal kod yang anda tidak faham.
Penggunaan konsol ini membenarkan penyerang untuk menyamar sebagai anda dan mencuri maklumat anda menggunakan serangan yang dipanggil XSS-Kendiri (Self-XSS)`}});var sM=xe((Bne,SW)=>{SW.exports={warning:"ADVARSEL!",message:`Ikke skriv inn eller lim inn kode som du ikke forst\xE5r.
Hvis du bruker denne konsollen, kan du gi uvedkommende anledning til \xE5 etterligne deg og stjele informasjon gjennom s\xE5kalte XSS-angrep.`}});var lM=xe(($ne,hW)=>{hW.exports={warning:"WAARSCHUWING!",message:`Voer geen code in en plak geen code die je niet begrijpt.
Met deze console kunnen aanvallers zich mogelijk als jou voordoen en gegevens stelen via een aanval die Self-XSS heet.`}});var pM=xe((Lne,CW)=>{CW.exports={warning:"\u0A1A\u0A47\u0A24\u0A3E\u0A35\u0A28\u0A40!",message:`\u0A09\u0A39 \u0A15\u0A4B\u0A21 \u0A26\u0A3E\u0A16\u0A32 \u0A1C\u0A3E\u0A02 \u0A2A\u0A47\u0A38\u0A1F \u0A28\u0A3E \u0A15\u0A30\u0A4B \u0A1C\u0A3F\u0A38 \u0A26\u0A40 \u0A24\u0A41\u0A39\u0A3E\u0A28\u0A42\u0A70 \u0A38\u0A2E\u0A1D \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A48\u0964
\u0A07\u0A38 \u0A15\u0A70\u0A38\u0A4B\u0A32 \u0A26\u0A40 \u0A35\u0A30\u0A24\u0A4B\u0A02 \u0A15\u0A30\u0A28 \u0A28\u0A3E\u0A32 \u0A39\u0A2E\u0A32\u0A3E\u0A35\u0A30 \u0A24\u0A41\u0A39\u0A3E\u0A21\u0A40 \u0A2A\u0A1B\u0A3E\u0A23 \u0A2C\u0A23\u0A3E \u0A38\u0A15\u0A26\u0A47 \u0A39\u0A28 \u0A05\u0A24\u0A47 Self-XSS \u0A28\u0A3E\u0A2E\u0A15 \u0A39\u0A2E\u0A32\u0A47 \u0A26\u0A40 \u0A35\u0A30\u0A24\u0A4B\u0A02 \u0A15\u0A30\u0A15\u0A47 \u0A24\u0A41\u0A39\u0A3E\u0A21\u0A40 \u0A1C\u0A3E\u0A23\u0A15\u0A3E\u0A30\u0A40 \u0A1A\u0A4B\u0A30\u0A40 \u0A15\u0A30 \u0A38\u0A15\u0A26\u0A47 \u0A39\u0A28\u0964`}});var cM=xe((Hne,xW)=>{xW.exports={warning:"OSTRZE\u017BENIE!",message:`Nie wpisuj ani nie wklejaj kodu, kt\xF3rego nie rozumiesz.
U\u017Cywanie tej konsoli mo\u017Ce umo\u017Cliwia\u0107 osobom, kt\xF3re wykorzystuj\u0105 atak Self-XSS, podszywanie si\u0119 pod Ciebie i wykradanie informacji.`}});var dM=xe((Vne,vW)=>{vW.exports={warning:"AVISO!",message:`N\xE3o insira nem cole c\xF3digos que voc\xEA n\xE3o entende.
O uso deste console pode permitir que invasores se passem por voc\xEA e roubem suas informa\xE7\xF5es usando um ataque chamado Self-XSS.`}});var uM=xe((One,IW)=>{IW.exports={warning:"AVISO!",message:`N\xE3o introduzas nem coles c\xF3digo que n\xE3o compreendes.
A utiliza\xE7\xE3o desta consola pode permitir que atacantes se fa\xE7am passar por ti e roubem as tuas informa\xE7\xF5es atrav\xE9s de um ataque chamado Self-XSS.`}});var yM=xe((Gne,kW)=>{kW.exports={warning:"AVERTIZARE!",message:`Nu introdu sau lipi cod pe care nu \xEEl \xEEn\u021Belegi.
Dac\u0103 folose\u0219ti aceast\u0103 consol\u0103, le po\u021Bi permite atacatorilor s\u0103 \xEE\u021Bi fure identitatea \u0219i informa\u021Biile printr-un atac denumit Self-XSS.`}});var mM=xe((zne,MW)=>{MW.exports={warning:"\u0412\u041D\u0418\u041C\u0410\u041D\u0418\u0415!",message:`\u041D\u0435 \u0432\u0432\u043E\u0434\u0438\u0442\u0435 \u0438 \u043D\u0435 \u0432\u0441\u0442\u0430\u0432\u043B\u044F\u0439\u0442\u0435 \u043A\u043E\u0434, \u0444\u0443\u043D\u043A\u0446\u0438\u0438 \u043A\u043E\u0442\u043E\u0440\u043E\u0433\u043E \u0432\u044B \u043D\u0435 \u043F\u043E\u043D\u0438\u043C\u0430\u0435\u0442\u0435.
\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0435 \u044D\u0442\u043E\u0439 \u043A\u043E\u043D\u0441\u043E\u043B\u0438 \u043C\u043E\u0436\u0435\u0442 \u043F\u043E\u0437\u0432\u043E\u043B\u0438\u0442\u044C \u0437\u043B\u043E\u0443\u043C\u044B\u0448\u043B\u0435\u043D\u043D\u0438\u043A\u0430\u043C \u0432\u044B\u0434\u0430\u0442\u044C \u0441\u0435\u0431\u044F \u0437\u0430 \u0432\u0430\u0441 \u0438 \u0443\u043A\u0440\u0430\u0441\u0442\u044C \u0432\u0430\u0448\u0443 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u0441 \u043F\u043E\u043C\u043E\u0449\u044C\u044E \u0430\u0442\u0430\u043A\u0438 \u0442\u0438\u043F\u0430 Self-XSS.`}});var gM=xe((Une,TW)=>{TW.exports={warning:"VARNING!",message:`Ange inte eller klistra in kod du inte f\xF6rst\xE5r.
N\xE4r du anv\xE4nder den h\xE4r konsolen kan hackare h\xE4rma din identitet eller stj\xE4la din information med en attack som heter Self-XSS.`}});var fM=xe((Wne,AW)=>{AW.exports={warning:"\u0B8E\u0B9A\u0BCD\u0B9A\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC8!",message:`\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD \u0BAA\u0BC1\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BCD\u0B9F\u0BC8 \u0B89\u0BB3\u0BCD\u0BB3\u0BBF\u0B9F\u0BBE\u0BA4\u0BC0\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0B92\u0B9F\u0BCD\u0B9F\u0BBE\u0BA4\u0BC0\u0BB0\u0BCD\u0B95\u0BB3\u0BCD.
\u0B87\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0B9F\u0BCD\u0B9F\u0BC1\u0BAA\u0BCD\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0BA4\u0BCD \u0BA4\u0BBF\u0BB0\u0BC8\u0BAF\u0BC8(Console\u0B90)\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BB5\u0BA4\u0BA9\u0BCD \u0BAE\u0BC2\u0BB2\u0BAE\u0BCD,\u0BA4\u0BC0\u0B99\u0BCD\u0B95\u0BBF\u0BB4\u0BC8\u0BAA\u0BCD\u0BAA\u0BB5\u0BB0\u0BCD\u0B95\u0BB3\u0BCD Self-XSS \u0B8E\u0BA9\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BAE\u0BCD \u0BA4\u0BBE\u0B95\u0BCD\u0B95\u0BC1\u0BA4\u0BB2\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BBF \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BC8\u0BAA\u0BCD\u0BAA\u0BCB\u0BB2\u0BCD \u0BA8\u0B9F\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0B95\u0BB5\u0BB2\u0BCD\u0B95\u0BB3\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB0\u0BC1\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BC1\u0BAE\u0BCD.`}});var bM=xe((Qne,_W)=>{_W.exports={warning:"\u0C39\u0C46\u0C1A\u0C4D\u0C1A\u0C30\u0C3F\u0C15!",message:`\u0C2E\u0C40\u0C15\u0C41 \u0C05\u0C30\u0C4D\u0C25\u0C02 \u0C15\u0C3E\u0C28\u0C3F \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C28\u0C3F \u0C0E\u0C02\u0C1F\u0C30\u0C4D \u0C32\u0C47\u0C26\u0C3E \u0C2A\u0C47\u0C38\u0C4D\u0C1F\u0C4D \u0C1A\u0C47\u0C2F\u0C15\u0C02\u0C21\u0C3F.
\u0C08 \u0C15\u0C28\u0C4D\u0C38\u0C4B\u0C32\u0C4D\u200C\u0C28\u0C3F \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C02\u0C1A\u0C21\u0C02 \u0C35\u0C32\u0C28 \u0C26\u0C3E\u0C21\u0C3F \u0C1A\u0C47\u0C38\u0C47\u0C35\u0C3E\u0C30\u0C41 \u0C2E\u0C3F\u0C2E\u0C4D\u0C2E\u0C32\u0C4D\u0C28\u0C3F \u0C05\u0C28\u0C41\u0C15\u0C30\u0C3F\u0C38\u0C4D\u0C24\u0C42 \u0C2E\u0C30\u0C3F\u0C2F\u0C41 Self-XSS \u0C05\u0C28\u0C47 \u0C26\u0C3E\u0C21\u0C3F\u0C28\u0C3F \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C02\u0C1A\u0C3F \u0C2E\u0C40 \u0C38\u0C2E\u0C3E\u0C1A\u0C3E\u0C30\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C26\u0C4A\u0C02\u0C17\u0C3F\u0C32\u0C3F\u0C02\u0C1A\u0C35\u0C1A\u0C4D\u0C1A\u0C41.`}});var SM=xe((qne,wW)=>{wW.exports={warning:"\u0E04\u0E33\u0E40\u0E15\u0E37\u0E2D\u0E19!",message:`\u0E2D\u0E22\u0E48\u0E32\u0E43\u0E2A\u0E48\u0E2B\u0E23\u0E37\u0E2D\u0E27\u0E32\u0E07\u0E23\u0E2B\u0E31\u0E2A\u0E17\u0E35\u0E48\u0E04\u0E38\u0E13\u0E44\u0E21\u0E48\u0E40\u0E02\u0E49\u0E32\u0E43\u0E08\u0E25\u0E07\u0E44\u0E1B
\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E04\u0E2D\u0E19\u0E42\u0E0B\u0E25\u0E19\u0E35\u0E49\u0E2D\u0E32\u0E08\u0E17\u0E33\u0E43\u0E2B\u0E49\u0E1C\u0E39\u0E49\u0E42\u0E08\u0E21\u0E15\u0E35\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E41\u0E2D\u0E1A\u0E2D\u0E49\u0E32\u0E07\u0E27\u0E48\u0E32\u0E40\u0E1B\u0E47\u0E19\u0E04\u0E38\u0E13 \u0E41\u0E25\u0E30\u0E02\u0E42\u0E21\u0E22\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13\u0E42\u0E14\u0E22\u0E43\u0E0A\u0E49\u0E01\u0E32\u0E23\u0E42\u0E08\u0E21\u0E15\u0E35\u0E17\u0E35\u0E48\u0E40\u0E23\u0E35\u0E22\u0E01\u0E27\u0E48\u0E32 Self-XSS`}});var hM=xe((Kne,DW)=>{DW.exports={warning:"D\u0130KKAT!",message:`Anlamad\u0131\u011F\u0131n\u0131z kodu girmeyin veya yap\u0131\u015Ft\u0131rmay\u0131n.
Bu konsolu kullanmak, sald\u0131rganlar\u0131n sizi taklit etmesine ve Self-XSS adl\u0131 bir sald\u0131r\u0131 kullanarak bilgilerinizi \xE7almas\u0131na izin verebilir.`}});var CM=xe((jne,PW)=>{PW.exports={warning:"\u0627\u0646\u062A\u0628\u0627\u06C1!",message:`\u0627\u06CC\u0633\u0627 \u06A9\u0648\u0688 \u062F\u0631\u062C \u06CC\u0627 \u067E\u06CC\u0633\u0679 \u0646\u06C1 \u06A9\u0631\u06CC\u06BA \u062C\u0648 \u0622\u067E \u0633\u0645\u062C\u06BE\u062A\u06D2 \u0646\u06C1 \u06C1\u0648\u06BA\u06D4
\u06CC\u06C1 \u06A9\u0646\u0633\u0648\u0644 \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u0631\u0646\u06D2 \u0633\u06D2 \u062D\u0645\u0644\u06C1 \u0622\u0648\u0631\u0648\u06BA \u06A9\u0648 Self-XSS \u0646\u0627\u0645\u06CC \u062D\u0645\u0644\u06D2 \u06A9\u06D2 \u0630\u0631\u06CC\u0639\u06D2 \u0622\u067E \u06A9\u06CC \u0646\u0642\u0627\u0644\u06CC \u0627\u0648\u0631 \u0622\u067E \u06A9\u06CC \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0686\u0631\u0627\u0646\u06D2 \u06A9\u0627 \u0645\u0648\u0642\u0639 \u0645\u0644 \u0633\u06A9\u062A\u0627 \u06C1\u06D2\u06D4`}});var xM=xe((Yne,NW)=>{NW.exports={warning:"C\u1EA2NH B\xC1O!",message:`\u0110\u1EEBng nh\u1EADp hay d\xE1n m\xE3 m\xE0 b\u1EA1n kh\xF4ng hi\u1EC3u r\xF5.
N\u1EBFu b\u1EA1n s\u1EED d\u1EE5ng console n\xE0y, nh\u1EEFng k\u1EBB t\u1EA5n c\xF4ng c\xF3 th\u1EC3 m\u1EA1o nh\u1EADn b\u1EA1n, r\u1ED3i \u0111\xE1nh c\u1EAFp th\xF4ng tin c\u1EE7a b\u1EA1n b\u1EB1ng c\xE1ch s\u1EED d\u1EE5ng ph\u01B0\u01A1ng ph\xE1p t\u1EA5n c\xF4ng Self-XSS.`}});var vM=xe((Xne,EW)=>{EW.exports={warning:"\u8B66\u544A\uFF01",message:`\u8BF7\u52FF\u8F93\u5165\u6216\u7C98\u8D34\u4F60\u4E0D\u4E86\u89E3\u7684\u4EE3\u7801\u3002
\u5982\u679C\u4F7F\u7528\u6B64\u63A7\u5236\u53F0\uFF0C\u53EF\u80FD\u4F1A\u8BA9\u653B\u51FB\u8005\u80FD\u591F\u4F7F\u7528\u79F0\u4E3A Self-XSS \u7684\u653B\u51FB\u6A21\u4EFF\u4F60\u548C\u7A83\u53D6\u4F60\u7684\u4FE1\u606F\u3002`}});var IM=xe((Jne,RW)=>{RW.exports={warning:"\u8B66\u544A\uFF01",message:`\u8ACB\u52FF\u8F38\u5165\u6216\u8CBC\u4E0A\u4F60\u4E0D\u4E86\u89E3\u7684\u4EE3\u78BC\u3002
\u4F7F\u7528\u6B64\u64CD\u4F5C\u4ECB\u9762\u53EF\u80FD\u6703\u8B93\u653B\u64CA\u8005\u5047\u5192\u4F60\u7684\u8EAB\u5206\uFF0C\u4E26\u4F7F\u7528 Self-XSS \u653B\u64CA\u65B9\u5F0F\u4F86\u7ACA\u53D6\u4F60\u7684\u8CC7\u8A0A\u3002`}});var kM=xe(nb=>{"use strict";Object.defineProperty(nb,"__esModule",{value:!0});var FW=B0(),BW=$0(),$W=L0(),LW=H0(),HW=V0(),VW=O0(),OW=G0(),GW=z0(),zW=U0(),UW=W0(),WW=Q0(),QW=q0(),qW=K0(),KW=j0(),jW=Y0(),YW=X0(),XW=J0(),JW=Z0(),ZW=eM(),eQ=tM(),tQ=oM(),oQ=nM(),nQ=rM(),rQ=aM(),aQ=iM(),iQ=sM(),sQ=lM(),lQ=pM(),pQ=cM(),cQ=dM(),dQ=uM(),uQ=yM(),yQ=mM(),mQ=gM(),gQ=fM(),fQ=bM(),bQ=SM(),SQ=hM(),hQ=CM(),CQ=xM(),xQ=vM(),vQ=IM(),IQ={"ar-aa":FW,"bn-bd":BW,"bn-in":$W,"da-dk":LW,"de-de":HW,"el-gr":VW,"en-gb":OW,"en-us":GW,"es-ar":zW,"es-es":UW,"es-mx":WW,es:QW,"fi-fi":qW,"fil-ph":KW,"fr-fr":jW,"gu-in":YW,"hi-in":XW,"id-id":JW,"it-it":ZW,"ja-jp":eQ,"kn-in":tQ,"ko-kr":oQ,"ml-in":nQ,"mr-in":rQ,"ms-my":aQ,"nb-no":iQ,"nl-nl":sQ,"pa-in":lQ,"pl-pl":pQ,"pt-br":cQ,"pt-pt":dQ,"ro-ro":uQ,"ru-ru":yQ,"sv-se":mQ,"ta-in":gQ,"te-in":fQ,"th-th":bQ,"tr-tr":SQ,"ur-pk":hQ,"vi-vn":CQ,"zh-cn":xQ,"zh-tw":vQ};nb.default=IQ});var TM=xe(Nd=>{"use strict";Object.defineProperty(Nd,"__esModule",{value:!0});Nd.printWarning=void 0;var rb=kM(),MM="en-us";function kQ(e){e===void 0&&(e=MM),e=e&&e.toLowerCase();var t=rb.default[e]?rb.default[e]:rb.default[MM];console.log("%c"+t.warning,"font-size: 30px; color: #F61F1F; background-color: #FFFF00;"),console.log("%c"+t.message,"font-size: 16px; color: #464656; background-color: #FFF;")}Nd.printWarning=kQ});var _M=xe(ab=>{"use strict";var AM=ma();ab.createRoot=AM.createRoot,ab.hydrateRoot=AM.hydrateRoot;var tre});var CP=xe(ju=>{"use strict";Object.defineProperty(ju,"__esModule",{value:!0});var kp,LS=w(),pt=(kp=LS)&&typeof kp=="object"&&"default"in kp?kp.default:kp;function hP(e,t){return(hP=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(o,n){return o.__proto__=n,o})(e,t)}function kt(e){if(e===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return e}(function(e,t){t===void 0&&(t={});var o=t.insertAt;if(typeof document<"u"){var n=document.head||document.getElementsByTagName("head")[0],a=document.createElement("style");a.type="text/css",o==="top"&&n.firstChild?n.insertBefore(a,n.firstChild):n.appendChild(a),a.styleSheet?a.styleSheet.cssText=e:a.appendChild(document.createTextNode(e))}})('.multiSelectContainer,.multiSelectContainer *,.multiSelectContainer :after,.multiSelectContainer :before{box-sizing:border-box}.multiSelectContainer{position:relative;text-align:left;width:100%}.disable_ms{opacity:.5;pointer-events:none}.display-none{display:none}.searchWrapper{border:1px solid #ccc;border-radius:4px;min-height:22px;padding:5px;position:relative}.multiSelectContainer input{background:transparent;border:none;margin-top:3px}.multiSelectContainer input:focus{outline:none}.chip{align-items:center;background:#0096fb;border-radius:11px;color:#fff;display:inline-flex;font-size:13px;line-height:19px;margin-bottom:5px;margin-right:5px;padding:4px 10px}.chip,.singleChip{white-space:nowrap}.singleChip{background:none;border-radius:none;color:inherit}.singleChip i{display:none}.closeIcon{cursor:pointer;float:right;height:13px;margin-left:5px;width:13px}.optionListContainer{background:#fff;border-radius:4px;margin-top:1px;position:absolute;width:100%;z-index:2}.multiSelectContainer ul{border:1px solid #ccc;border-radius:4px;display:block;margin:0;max-height:250px;overflow-y:auto;padding:0}.multiSelectContainer li{padding:10px}.multiSelectContainer li:hover{background:#0096fb;color:#fff;cursor:pointer}.checkbox{margin-right:10px}.disableSelection{opacity:.5;pointer-events:none}.highlightOption{background:#0096fb;color:#fff}.displayBlock{display:block}.displayNone{display:none}.notFound{display:block;padding:10px}.singleSelect{padding-right:20px}li.groupHeading{color:#908e8e;padding:5px 15px;pointer-events:none}li.groupChildEle{padding-left:30px}.icon_down_dir{position:absolute;right:10px;top:50%;transform:translateY(-50%);width:14px}.icon_down_dir:before{content:"\\e803"}.custom-close{display:flex}');var SP={circle:"data:image/svg+xml,%3Csvg%20height%3D%22512px%22%20id%3D%22Layer_1%22%20style%3D%22enable-background%3Anew%200%200%20512%20512%3B%22%20version%3D%221.1%22%20viewBox%3D%220%200%20512%20512%22%20width%3D%22512px%22%20xml%3Aspace%3D%22preserve%22%20%20%20%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20%20%20%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%3E%20%20%20%20%3Cstyle%20type%3D%22text%2Fcss%22%3E%20%20%20%20%20%20%20%20.st0%7B%20%20%20%20%20%20%20%20%20%20%20%20fill%3A%23fff%3B%20%20%20%20%20%20%20%20%7D%20%3C%2Fstyle%3E%20%20%20%20%3Cg%3E%20%20%20%20%20%20%20%20%3Cpath%20class%3D%22st0%22%20d%3D%22M256%2C33C132.3%2C33%2C32%2C133.3%2C32%2C257c0%2C123.7%2C100.3%2C224%2C224%2C224c123.7%2C0%2C224-100.3%2C224-224C480%2C133.3%2C379.7%2C33%2C256%2C33z%20%20%20%20M364.3%2C332.5c1.5%2C1.5%2C2.3%2C3.5%2C2.3%2C5.6c0%2C2.1-0.8%2C4.2-2.3%2C5.6l-21.6%2C21.7c-1.6%2C1.6-3.6%2C2.3-5.6%2C2.3c-2%2C0-4.1-0.8-5.6-2.3L256%2C289.8%20%20%20l-75.4%2C75.7c-1.5%2C1.6-3.6%2C2.3-5.6%2C2.3c-2%2C0-4.1-0.8-5.6-2.3l-21.6-21.7c-1.5-1.5-2.3-3.5-2.3-5.6c0-2.1%2C0.8-4.2%2C2.3-5.6l75.7-76%20%20%20l-75.9-75c-3.1-3.1-3.1-8.2%2C0-11.3l21.6-21.7c1.5-1.5%2C3.5-2.3%2C5.6-2.3c2.1%2C0%2C4.1%2C0.8%2C5.6%2C2.3l75.7%2C74.7l75.7-74.7%20%20%20c1.5-1.5%2C3.5-2.3%2C5.6-2.3c2.1%2C0%2C4.1%2C0.8%2C5.6%2C2.3l21.6%2C21.7c3.1%2C3.1%2C3.1%2C8.2%2C0%2C11.3l-75.9%2C75L364.3%2C332.5z%22%2F%3E%20%20%20%20%3C%2Fg%3E%3C%2Fsvg%3E",circle2:"data:image/svg+xml,%3Csvg%20viewBox%3D%220%200%2096%2096%22%20%20%20%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%20%20%20%20%3Cstyle%20type%3D%22text%2Fcss%22%3E%20%20%20%20%20%20%20%20.st0%7B%20%20%20%20%20%20%20%20%20%20%20%20fill%3A%23fff%3B%20%20%20%20%20%20%20%20%7D%20%3C%2Fstyle%3E%20%20%20%20%3Cg%3E%20%20%20%20%20%20%20%20%3Cpath%20class%3D%22st0%22%20d%3D%22M48%2C0A48%2C48%2C0%2C1%2C0%2C96%2C48%2C48.0512%2C48.0512%2C0%2C0%2C0%2C48%2C0Zm0%2C84A36%2C36%2C0%2C1%2C1%2C84%2C48%2C36.0393%2C36.0393%2C0%2C0%2C1%2C48%2C84Z%22%2F%3E%20%20%20%20%20%20%20%20%3Cpath%20class%3D%22st0%22%20d%3D%22M64.2422%2C31.7578a5.9979%2C5.9979%2C0%2C0%2C0-8.4844%2C0L48%2C39.5156l-7.7578-7.7578a5.9994%2C5.9994%2C0%2C0%2C0-8.4844%2C8.4844L39.5156%2C48l-7.7578%2C7.7578a5.9994%2C5.9994%2C0%2C1%2C0%2C8.4844%2C8.4844L48%2C56.4844l7.7578%2C7.7578a5.9994%2C5.9994%2C0%2C0%2C0%2C8.4844-8.4844L56.4844%2C48l7.7578-7.7578A5.9979%2C5.9979%2C0%2C0%2C0%2C64.2422%2C31.7578Z%22%2F%3E%20%20%20%20%3C%2Fg%3E%3C%2Fsvg%3E",close:"data:image/svg+xml,%3Csvg%20height%3D%22135.467mm%22%20style%3D%22shape-rendering%3AgeometricPrecision%3B%20text-rendering%3AgeometricPrecision%3B%20image-rendering%3AoptimizeQuality%3B%20fill-rule%3Aevenodd%3B%20clip-rule%3Aevenodd%22%20viewBox%3D%220%200%2013547%2013547%22%20width%3D%22135.467mm%22%20xml%3Aspace%3D%22preserve%22%20%20%20%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20%20%20%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%3E%20%20%20%20%3Cdefs%3E%20%20%20%20%20%20%20%20%3Cstyle%20type%3D%22text%2Fcss%22%3E%20%20%20%20%20%20%20%20%20%20%20%20.fil0%20%7Bfill%3Anone%7D%20%20%20%20%20%20%20%20%20%20%20%20.fil1%20%7Bfill%3A%23fff%7D%20%20%20%20%20%20%20%20%3C%2Fstyle%3E%20%20%20%20%3C%2Fdefs%3E%20%20%20%20%3Cg%20id%3D%22Ebene_x0020_1%22%3E%20%20%20%20%20%20%20%20%3Cpolygon%20class%3D%22fil0%22%20points%3D%220%2C0%2013547%2C0%2013547%2C13547%200%2C13547%20%22%2F%3E%20%20%20%20%20%20%20%20%3Cpath%20class%3D%22fil1%22%20d%3D%22M714%2012832l12118%200%200%20-12117%20-12118%200%200%2012117zm4188%20-2990l1871%20-1871%201871%201871%201197%20-1197%20-1871%20-1871%201871%20-1871%20-1197%20-1197%20-1871%201871%20-1871%20-1871%20-1197%201197%201871%201871%20-1871%201871%201197%201197z%22%2F%3E%20%20%20%20%3C%2Fg%3E%3C%2Fsvg%3E",cancel:"data:image/svg+xml,%3Csvg%20height%3D%22512px%22%20id%3D%22Layer_1%22%20style%3D%22enable-background%3Anew%200%200%20512%20512%3B%22%20version%3D%221.1%22%20viewBox%3D%220%200%20512%20512%22%20width%3D%22512px%22%20xml%3Aspace%3D%22preserve%22%20%20%20%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20%20%20%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%3E%20%20%20%20%3Cstyle%20type%3D%22text%2Fcss%22%3E%20%20%20%20%20%20%20%20.st0%7B%20%20%20%20%20%20%20%20%20%20%20%20fill%3A%23fff%3B%20%20%20%20%20%20%20%20%7D%20%3C%2Fstyle%3E%20%20%20%20%3Cpath%20class%3D%22st0%22%20d%3D%22M443.6%2C387.1L312.4%2C255.4l131.5-130c5.4-5.4%2C5.4-14.2%2C0-19.6l-37.4-37.6c-2.6-2.6-6.1-4-9.8-4c-3.7%2C0-7.2%2C1.5-9.8%2C4%20%20L256%2C197.8L124.9%2C68.3c-2.6-2.6-6.1-4-9.8-4c-3.7%2C0-7.2%2C1.5-9.8%2C4L68%2C105.9c-5.4%2C5.4-5.4%2C14.2%2C0%2C19.6l131.5%2C130L68.4%2C387.1%20%20c-2.6%2C2.6-4.1%2C6.1-4.1%2C9.8c0%2C3.7%2C1.4%2C7.2%2C4.1%2C9.8l37.4%2C37.6c2.7%2C2.7%2C6.2%2C4.1%2C9.8%2C4.1c3.5%2C0%2C7.1-1.3%2C9.8-4.1L256%2C313.1l130.7%2C131.1%20%20c2.7%2C2.7%2C6.2%2C4.1%2C9.8%2C4.1c3.5%2C0%2C7.1-1.3%2C9.8-4.1l37.4-37.6c2.6-2.6%2C4.1-6.1%2C4.1-9.8C447.7%2C393.2%2C446.2%2C389.7%2C443.6%2C387.1z%22%2F%3E%3C%2Fsvg%3E"};function zq(e){var t,o,n=LS.useRef(null);return o=e.outsideClick,LS.useEffect((function(){function a(s){t.current&&!t.current.contains(s.target)&&o()}return document.addEventListener("mousedown",a),function(){document.removeEventListener("mousedown",a)}}),[t=n]),pt.createElement("div",{ref:n},e.children)}var $S=(function(e){var t,o;function n(s){var l;return(l=e.call(this,s)||this).state={inputValue:"",options:s.options,filteredOptions:s.options,unfilteredOptions:s.options,selectedValues:Object.assign([],s.selectedValues),preSelectedValues:Object.assign([],s.selectedValues),toggleOptionsList:!1,highlightOption:s.avoidHighlightFirstOption?-1:0,showCheckbox:s.showCheckbox,keepSearchTerm:s.keepSearchTerm,groupedObject:[],closeIconType:SP[s.closeIcon]||SP.circle},l.optionTimeout=null,l.searchWrapper=pt.createRef(),l.searchBox=pt.createRef(),l.onChange=l.onChange.bind(kt(l)),l.onKeyPress=l.onKeyPress.bind(kt(l)),l.onFocus=l.onFocus.bind(kt(l)),l.onBlur=l.onBlur.bind(kt(l)),l.renderMultiselectContainer=l.renderMultiselectContainer.bind(kt(l)),l.renderSelectedList=l.renderSelectedList.bind(kt(l)),l.onRemoveSelectedItem=l.onRemoveSelectedItem.bind(kt(l)),l.toggelOptionList=l.toggelOptionList.bind(kt(l)),l.onArrowKeyNavigation=l.onArrowKeyNavigation.bind(kt(l)),l.onSelectItem=l.onSelectItem.bind(kt(l)),l.filterOptionsByInput=l.filterOptionsByInput.bind(kt(l)),l.removeSelectedValuesFromOptions=l.removeSelectedValuesFromOptions.bind(kt(l)),l.isSelectedValue=l.isSelectedValue.bind(kt(l)),l.fadeOutSelection=l.fadeOutSelection.bind(kt(l)),l.isDisablePreSelectedValues=l.isDisablePreSelectedValues.bind(kt(l)),l.renderGroupByOptions=l.renderGroupByOptions.bind(kt(l)),l.renderNormalOption=l.renderNormalOption.bind(kt(l)),l.listenerCallback=l.listenerCallback.bind(kt(l)),l.resetSelectedValues=l.resetSelectedValues.bind(kt(l)),l.getSelectedItems=l.getSelectedItems.bind(kt(l)),l.getSelectedItemsCount=l.getSelectedItemsCount.bind(kt(l)),l.hideOnClickOutside=l.hideOnClickOutside.bind(kt(l)),l.onCloseOptionList=l.onCloseOptionList.bind(kt(l)),l.isVisible=l.isVisible.bind(kt(l)),l}o=e,(t=n).prototype=Object.create(o.prototype),t.prototype.constructor=t,hP(t,o);var a=n.prototype;return a.initialSetValue=function(){var s=this.props,l=s.groupBy,p=this.state.options;s.showCheckbox||s.singleSelect||this.removeSelectedValuesFromOptions(!1),l&&this.groupByOptions(p)},a.resetSelectedValues=function(){var s=this,l=this.state.unfilteredOptions;return new Promise((function(p){s.setState({selectedValues:[],preSelectedValues:[],options:l,filteredOptions:l},(function(){p(),s.initialSetValue()}))}))},a.getSelectedItems=function(){return this.state.selectedValues},a.getSelectedItemsCount=function(){return this.state.selectedValues.length},a.componentDidMount=function(){this.initialSetValue(),this.searchWrapper.current.addEventListener("click",this.listenerCallback)},a.componentDidUpdate=function(s){var l=this.props,p=l.options,d=l.selectedValues,u=s.selectedValues;JSON.stringify(s.options)!==JSON.stringify(p)&&this.setState({options:p,filteredOptions:p,unfilteredOptions:p},this.initialSetValue),JSON.stringify(u)!==JSON.stringify(d)&&this.setState({selectedValues:Object.assign([],d),preSelectedValues:Object.assign([],d)},this.initialSetValue)},a.listenerCallback=function(){this.searchBox.current.focus()},a.componentWillUnmount=function(){this.optionTimeout&&clearTimeout(this.optionTimeout),this.searchWrapper.current.removeEventListener("click",this.listenerCallback)},a.removeSelectedValuesFromOptions=function(s){var l=this.props,p=l.isObject,d=l.displayValue,u=l.groupBy,y=this.state,m=y.selectedValues,g=m===void 0?[]:m,f=y.unfilteredOptions;if(!s&&u&&this.groupByOptions(y.options),g.length||s){if(p){var b=f.filter((function(C){return g.findIndex((function(v){return v[d]===C[d]}))===-1}));return u&&this.groupByOptions(b),void this.setState({options:b,filteredOptions:b},this.filterOptionsByInput)}var S=f.filter((function(C){return g.indexOf(C)===-1}));this.setState({options:S,filteredOptions:S},this.filterOptionsByInput)}},a.groupByOptions=function(s){var l=this.props.groupBy,p=s.reduce((function(d,u){var y=u[l]||"Others";return d[y]=d[y]||[],d[y].push(u),d}),Object.create({}));this.setState({groupedObject:p})},a.onChange=function(s){var l=this.props.onSearch;this.setState({inputValue:s.target.value},this.filterOptionsByInput),l&&l(s.target.value)},a.onKeyPress=function(s){var l=this.props.onKeyPressFn;l&&l(s,s.target.value)},a.filterOptionsByInput=function(){var s,l=this,p=this.state,d=p.inputValue,u=this.props,y=u.displayValue;s=p.filteredOptions.filter(u.isObject?function(m){return l.matchValues(m[y],d)}:function(m){return l.matchValues(m,d)}),this.groupByOptions(s),this.setState({options:s})},a.matchValues=function(s,l){return this.props.caseSensitiveSearch?s.indexOf(l)>-1:s.toLowerCase?s.toLowerCase().indexOf(l.toLowerCase())>-1:s.toString().indexOf(l)>-1},a.onArrowKeyNavigation=function(s){var l=this.state,p=l.options,d=l.highlightOption,u=l.toggleOptionsList,y=l.selectedValues;if(s.keyCode!==8||l.inputValue||this.props.disablePreSelectedValues||!y.length||this.onRemoveSelectedItem(y.length-1),p.length){if(s.keyCode===38)this.setState(d>0?function(m){return{highlightOption:m.highlightOption-1}}:{highlightOption:p.length-1});else if(s.keyCode===40)this.setState(d<p.length-1?function(m){return{highlightOption:m.highlightOption+1}}:{highlightOption:0});else if(s.key==="Enter"&&p.length&&u){if(d===-1)return;this.onSelectItem(p[d])}}},a.onRemoveSelectedItem=function(s){var l,p=this,d=this.state.selectedValues,u=this.props,y=u.onRemove,m=u.showCheckbox,g=u.displayValue;l=u.isObject?d.findIndex((function(f){return f[g]===s[g]})):d.indexOf(s),d.splice(l,1),y(d,s),this.setState({selectedValues:d},(function(){m||p.removeSelectedValuesFromOptions(!0)})),this.props.closeOnSelect||this.searchBox.current.focus()},a.onSelectItem=function(s){var l=this,p=this.state.selectedValues,d=this.props,u=d.selectionLimit,y=d.onSelect,m=d.singleSelect,g=d.showCheckbox;if(this.state.keepSearchTerm||this.setState({inputValue:""}),m)return this.onSingleSelect(s),void y([s],s);this.isSelectedValue(s)?this.onRemoveSelectedItem(s):u!=p.length&&(p.push(s),y(p,s),this.setState({selectedValues:p},(function(){g?l.filterOptionsByInput():l.removeSelectedValuesFromOptions(!0)})),this.props.closeOnSelect||this.searchBox.current.focus())},a.onSingleSelect=function(s){this.setState({selectedValues:[s],toggleOptionsList:!1})},a.isSelectedValue=function(s){var l=this.props,p=l.displayValue,d=this.state.selectedValues;return l.isObject?d.filter((function(u){return u[p]===s[p]})).length>0:d.filter((function(u){return u===s})).length>0},a.renderOptionList=function(){var s=this.props,l=s.groupBy,p=s.style,d=s.emptyRecordMsg,u=s.loadingMessage,y=u===void 0?"loading...":u,m=this.state.options;return s.loading?pt.createElement("ul",{className:"optionContainer",style:p.optionContainer},typeof y=="string"&&pt.createElement("span",{style:p.loadingMessage,className:"notFound"},y),typeof y!="string"&&y):pt.createElement("ul",{className:"optionContainer",style:p.optionContainer},m.length===0&&pt.createElement("span",{style:p.notFound,className:"notFound"},d),l?this.renderGroupByOptions():this.renderNormalOption())},a.renderGroupByOptions=function(){var s=this,l=this.props,p=l.isObject,d=p!==void 0&&p,u=l.displayValue,y=l.showCheckbox,m=l.style,g=l.singleSelect,f=this.state.groupedObject;return Object.keys(f).map((function(b){return pt.createElement(pt.Fragment,{key:b},pt.createElement("li",{className:"groupHeading",style:m.groupHeading},b),f[b].map((function(S,C){var v=s.isSelectedValue(S);return pt.createElement("li",{key:"option"+C,style:m.option,className:"groupChildEle option "+(v?"selected":"")+" "+(s.fadeOutSelection(S)?"disableSelection":"")+" "+(s.isDisablePreSelectedValues(S)?"disableSelection":""),onClick:function(){return s.onSelectItem(S)}},y&&!g&&pt.createElement("input",{type:"checkbox",className:"checkbox",readOnly:!0,checked:v}),s.props.optionValueDecorator(d?S[u]:(S||"").toString(),S))})))}))},a.renderNormalOption=function(){var s=this,l=this.props,p=l.isObject,d=p!==void 0&&p,u=l.displayValue,y=l.showCheckbox,m=l.style,g=l.singleSelect,f=this.state.highlightOption;return this.state.options.map((function(b,S){var C=s.isSelectedValue(b);return pt.createElement("li",{key:"option"+S,style:m.option,className:"option "+(C?"selected":"")+" "+(f===S?"highlightOption highlight":"")+" "+(s.fadeOutSelection(b)?"disableSelection":"")+" "+(s.isDisablePreSelectedValues(b)?"disableSelection":""),onClick:function(){return s.onSelectItem(b)}},y&&!g&&pt.createElement("input",{type:"checkbox",readOnly:!0,className:"checkbox",checked:C}),s.props.optionValueDecorator(d?b[u]:(b||"").toString(),b))}))},a.renderSelectedList=function(){var s=this,l=this.props,p=l.isObject,d=p!==void 0&&p,u=l.displayValue,y=l.style,m=l.singleSelect,g=l.customCloseIcon,f=this.state,b=f.closeIconType;return f.selectedValues.map((function(S,C){return pt.createElement("span",{className:"chip  "+(m&&"singleChip")+" "+(s.isDisablePreSelectedValues(S)&&"disableSelection"),key:C,style:y.chips},s.props.selectedValueDecorator(d?S[u]:(S||"").toString(),S),!s.isDisablePreSelectedValues(S)&&(g?pt.createElement("i",{className:"custom-close",onClick:function(){return s.onRemoveSelectedItem(S)}},g):pt.createElement("img",{className:"icon_cancel closeIcon",src:b,onClick:function(){return s.onRemoveSelectedItem(S)}})))}))},a.isDisablePreSelectedValues=function(s){var l=this.props,p=l.displayValue,d=this.state.preSelectedValues;return!(!l.disablePreSelectedValues||!d.length)&&(l.isObject?d.filter((function(u){return u[p]===s[p]})).length>0:d.filter((function(u){return u===s})).length>0)},a.fadeOutSelection=function(s){var l=this.props,p=l.selectionLimit;if(!l.singleSelect){var d=this.state.selectedValues;return p!=-1&&p==d.length&&(p==d.length?!l.showCheckbox||!this.isSelectedValue(s):void 0)}},a.toggelOptionList=function(){this.setState({toggleOptionsList:!this.state.toggleOptionsList,highlightOption:this.props.avoidHighlightFirstOption?-1:0})},a.onCloseOptionList=function(){this.setState({toggleOptionsList:!1,highlightOption:this.props.avoidHighlightFirstOption?-1:0,inputValue:""})},a.onFocus=function(){this.state.toggleOptionsList?clearTimeout(this.optionTimeout):this.toggelOptionList()},a.onBlur=function(){this.setState({inputValue:""},this.filterOptionsByInput),this.optionTimeout=setTimeout(this.onCloseOptionList,250)},a.isVisible=function(s){return!!s&&!!(s.offsetWidth||s.offsetHeight||s.getClientRects().length)},a.hideOnClickOutside=function(){var s=this,l=document.getElementsByClassName("multiselect-container")[0];document.addEventListener("click",(function(p){l&&!l.contains(p.target)&&s.isVisible(l)&&s.toggelOptionList()}))},a.renderMultiselectContainer=function(){var s=this.state,l=s.inputValue,p=s.toggleOptionsList,d=s.selectedValues,u=this.props,y=u.placeholder,m=u.style,g=u.singleSelect,f=u.id,b=u.name,S=u.hidePlaceholder,C=u.disable,v=u.showArrow,k=u.customArrow;return pt.createElement("div",{className:"multiselect-container multiSelectContainer "+(C?"disable_ms":"")+" "+(u.className||""),id:f||"multiselectContainerReact",style:m.multiselectContainer},pt.createElement("div",{className:"search-wrapper searchWrapper "+(g?"singleSelect":""),ref:this.searchWrapper,style:m.searchBox,onClick:g?this.toggelOptionList:function(){}},!u.hideSelectedList&&this.renderSelectedList(),pt.createElement("input",{type:"text",ref:this.searchBox,className:"searchBox "+(g&&d.length?"display-none":""),id:(f||"search")+"_input",name:(b||"search_name")+"_input",onChange:this.onChange,onKeyPress:this.onKeyPress,value:l,onFocus:this.onFocus,onBlur:this.onBlur,placeholder:g&&d.length||S&&d.length?"":y,onKeyDown:this.onArrowKeyNavigation,style:m.inputField,autoComplete:"off",disabled:g||C}),(g||v)&&pt.createElement(pt.Fragment,null,k?pt.createElement("span",{className:"icon_down_dir"},k):pt.createElement("img",{src:"data:image/svg+xml,%3Csvg%20height%3D%2232%22%20viewBox%3D%220%200%2032%2032%22%20width%3D%2232%22%20%20%20%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%20%20%20%20%3Cg%20id%3D%22background%22%3E%20%20%20%20%20%20%20%20%3Crect%20fill%3D%22none%22%20height%3D%2232%22%20width%3D%2232%22%2F%3E%20%20%20%20%3C%2Fg%3E%20%20%20%20%3Cg%20id%3D%22arrow_x5F_down%22%3E%20%20%20%20%20%20%20%20%3Cpolygon%20points%3D%222.002%2C10%2016.001%2C24%2030.002%2C10%20%20%22%2F%3E%20%20%20%20%3C%2Fg%3E%3C%2Fsvg%3E",className:"icon_cancel icon_down_dir"}))),pt.createElement("div",{className:"optionListContainer "+(p?"displayBlock":"displayNone"),onMouseDown:function(I){I.preventDefault()}},this.renderOptionList()))},a.render=function(){return pt.createElement(zq,{outsideClick:this.onCloseOptionList},this.renderMultiselectContainer())},n})(pt.Component);$S.defaultProps={options:[],disablePreSelectedValues:!1,selectedValues:[],isObject:!0,displayValue:"model",showCheckbox:!1,selectionLimit:-1,placeholder:"Select",groupBy:"",style:{},emptyRecordMsg:"No Options Available",onSelect:function(){},onRemove:function(){},onKeyPressFn:function(){},closeIcon:"circle2",singleSelect:!1,caseSensitiveSearch:!1,id:"",name:"",closeOnSelect:!0,avoidHighlightFirstOption:!1,hidePlaceholder:!1,showArrow:!1,keepSearchTerm:!1,customCloseIcon:"",className:"",customArrow:void 0,selectedValueDecorator:function(e){return e},optionValueDecorator:function(e){return e}},ju.Multiselect=$S,ju.default=$S});var vP=xe((USe,xP)=>{"use strict";xP.exports=CP()});var ZP=xe((axe,JP)=>{"use strict";var bK=typeof Element<"u",SK=typeof Map=="function",hK=typeof Set=="function",CK=typeof ArrayBuffer=="function"&&!!ArrayBuffer.isView;function ry(e,t){if(e===t)return!0;if(e&&t&&typeof e=="object"&&typeof t=="object"){if(e.constructor!==t.constructor)return!1;var o,n,a;if(Array.isArray(e)){if(o=e.length,o!=t.length)return!1;for(n=o;n--!==0;)if(!ry(e[n],t[n]))return!1;return!0}var s;if(SK&&e instanceof Map&&t instanceof Map){if(e.size!==t.size)return!1;for(s=e.entries();!(n=s.next()).done;)if(!t.has(n.value[0]))return!1;for(s=e.entries();!(n=s.next()).done;)if(!ry(n.value[1],t.get(n.value[0])))return!1;return!0}if(hK&&e instanceof Set&&t instanceof Set){if(e.size!==t.size)return!1;for(s=e.entries();!(n=s.next()).done;)if(!t.has(n.value[0]))return!1;return!0}if(CK&&ArrayBuffer.isView(e)&&ArrayBuffer.isView(t)){if(o=e.length,o!=t.length)return!1;for(n=o;n--!==0;)if(e[n]!==t[n])return!1;return!0}if(e.constructor===RegExp)return e.source===t.source&&e.flags===t.flags;if(e.valueOf!==Object.prototype.valueOf&&typeof e.valueOf=="function"&&typeof t.valueOf=="function")return e.valueOf()===t.valueOf();if(e.toString!==Object.prototype.toString&&typeof e.toString=="function"&&typeof t.toString=="function")return e.toString()===t.toString();if(a=Object.keys(e),o=a.length,o!==Object.keys(t).length)return!1;for(n=o;n--!==0;)if(!Object.prototype.hasOwnProperty.call(t,a[n]))return!1;if(bK&&e instanceof Element)return!1;for(n=o;n--!==0;)if(!((a[n]==="_owner"||a[n]==="__v"||a[n]==="__o")&&e.$$typeof)&&!ry(e[a[n]],t[a[n]]))return!1;return!0}return e!==e&&t!==t}JP.exports=function(t,o){try{return ry(t,o)}catch(n){if((n.message||"").match(/stack|recursion/i))return console.warn("react-fast-compare cannot handle circular refs"),!1;throw n}}});var tN=xe((ixe,eN)=>{"use strict";var xK=function(e,t,o,n,a,s,l,p){if(!e){var d;if(t===void 0)d=new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");else{var u=[o,n,a,s,l,p],y=0;d=new Error(t.replace(/%s/g,function(){return u[y++]})),d.name="Invariant Violation"}throw d.framesToPop=1,d}};eN.exports=xK});var nN=xe((sxe,oN)=>{"use strict";oN.exports=function(t,o,n,a){var s=n?n.call(a,t,o):void 0;if(s!==void 0)return!!s;if(t===o)return!0;if(typeof t!="object"||!t||typeof o!="object"||!o)return!1;var l=Object.keys(t),p=Object.keys(o);if(l.length!==p.length)return!1;for(var d=Object.prototype.hasOwnProperty.bind(o),u=0;u<l.length;u++){var y=l[u];if(!d(y))return!1;var m=t[y],g=o[y];if(s=n?n.call(a,m,g,y):void 0,s===!1||s===void 0&&m!==g)return!1}return!0}});var _N=xe((Rxe,AN)=>{"use strict";var Rs=1e3,Fs=Rs*60,Bs=Fs*60,Ci=Bs*24,FK=Ci*7,BK=Ci*365.25;AN.exports=function(e,t){t=t||{};var o=typeof e;if(o==="string"&&e.length>0)return $K(e);if(o==="number"&&isFinite(e))return t.long?HK(e):LK(e);throw new Error("val is not a non-empty string or a valid number. val="+JSON.stringify(e))};function $K(e){if(e=String(e),!(e.length>100)){var t=/^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);if(t){var o=parseFloat(t[1]),n=(t[2]||"ms").toLowerCase();switch(n){case"years":case"year":case"yrs":case"yr":case"y":return o*BK;case"weeks":case"week":case"w":return o*FK;case"days":case"day":case"d":return o*Ci;case"hours":case"hour":case"hrs":case"hr":case"h":return o*Bs;case"minutes":case"minute":case"mins":case"min":case"m":return o*Fs;case"seconds":case"second":case"secs":case"sec":case"s":return o*Rs;case"milliseconds":case"millisecond":case"msecs":case"msec":case"ms":return o;default:return}}}}function LK(e){var t=Math.abs(e);return t>=Ci?Math.round(e/Ci)+"d":t>=Bs?Math.round(e/Bs)+"h":t>=Fs?Math.round(e/Fs)+"m":t>=Rs?Math.round(e/Rs)+"s":e+"ms"}function HK(e){var t=Math.abs(e);return t>=Ci?py(e,t,Ci,"day"):t>=Bs?py(e,t,Bs,"hour"):t>=Fs?py(e,t,Fs,"minute"):t>=Rs?py(e,t,Rs,"second"):e+" ms"}function py(e,t,o,n){var a=t>=o*1.5;return Math.round(e/o)+" "+n+(a?"s":"")}});var DN=xe((Fxe,wN)=>{"use strict";function VK(e){o.debug=o,o.default=o,o.coerce=d,o.disable=l,o.enable=a,o.enabled=p,o.humanize=_N(),o.destroy=u,Object.keys(e).forEach(y=>{o[y]=e[y]}),o.names=[],o.skips=[],o.formatters={};function t(y){let m=0;for(let g=0;g<y.length;g++)m=(m<<5)-m+y.charCodeAt(g),m|=0;return o.colors[Math.abs(m)%o.colors.length]}o.selectColor=t;function o(y){let m,g=null,f,b;function S(...C){if(!S.enabled)return;let v=S,k=Number(new Date),I=k-(m||k);v.diff=I,v.prev=m,v.curr=k,m=k,C[0]=o.coerce(C[0]),typeof C[0]!="string"&&C.unshift("%O");let A=0;C[0]=C[0].replace(/%([a-zA-Z%])/g,(B,M)=>{if(B==="%%")return"%";A++;let _=o.formatters[M];if(typeof _=="function"){let P=C[A];B=_.call(v,P),C.splice(A,1),A--}return B}),o.formatArgs.call(v,C),(v.log||o.log).apply(v,C)}return S.namespace=y,S.useColors=o.useColors(),S.color=o.selectColor(y),S.extend=n,S.destroy=o.destroy,Object.defineProperty(S,"enabled",{enumerable:!0,configurable:!1,get:()=>g!==null?g:(f!==o.namespaces&&(f=o.namespaces,b=o.enabled(y)),b),set:C=>{g=C}}),typeof o.init=="function"&&o.init(S),S}function n(y,m){let g=o(this.namespace+(typeof m>"u"?":":m)+y);return g.log=this.log,g}function a(y){o.save(y),o.namespaces=y,o.names=[],o.skips=[];let m=(typeof y=="string"?y:"").trim().replace(/\s+/g,",").split(",").filter(Boolean);for(let g of m)g[0]==="-"?o.skips.push(g.slice(1)):o.names.push(g)}function s(y,m){let g=0,f=0,b=-1,S=0;for(;g<y.length;)if(f<m.length&&(m[f]===y[g]||m[f]==="*"))m[f]==="*"?(b=f,S=g,f++):(g++,f++);else if(b!==-1)f=b+1,S++,g=S;else return!1;for(;f<m.length&&m[f]==="*";)f++;return f===m.length}function l(){let y=[...o.names,...o.skips.map(m=>"-"+m)].join(",");return o.enable(""),y}function p(y){for(let m of o.skips)if(s(y,m))return!1;for(let m of o.names)if(s(y,m))return!0;return!1}function d(y){return y instanceof Error?y.stack||y.message:y}function u(){console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.")}return o.enable(o.load()),o}wN.exports=VK});var PN=xe((Zo,cy)=>{"use strict";Zo.formatArgs=GK;Zo.save=zK;Zo.load=UK;Zo.useColors=OK;Zo.storage=WK();Zo.destroy=(()=>{let e=!1;return()=>{e||(e=!0,console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."))}})();Zo.colors=["#0000CC","#0000FF","#0033CC","#0033FF","#0066CC","#0066FF","#0099CC","#0099FF","#00CC00","#00CC33","#00CC66","#00CC99","#00CCCC","#00CCFF","#3300CC","#3300FF","#3333CC","#3333FF","#3366CC","#3366FF","#3399CC","#3399FF","#33CC00","#33CC33","#33CC66","#33CC99","#33CCCC","#33CCFF","#6600CC","#6600FF","#6633CC","#6633FF","#66CC00","#66CC33","#9900CC","#9900FF","#9933CC","#9933FF","#99CC00","#99CC33","#CC0000","#CC0033","#CC0066","#CC0099","#CC00CC","#CC00FF","#CC3300","#CC3333","#CC3366","#CC3399","#CC33CC","#CC33FF","#CC6600","#CC6633","#CC9900","#CC9933","#CCCC00","#CCCC33","#FF0000","#FF0033","#FF0066","#FF0099","#FF00CC","#FF00FF","#FF3300","#FF3333","#FF3366","#FF3399","#FF33CC","#FF33FF","#FF6600","#FF6633","#FF9900","#FF9933","#FFCC00","#FFCC33"];function OK(){if(typeof window<"u"&&window.process&&(window.process.type==="renderer"||window.process.__nwjs))return!0;if(typeof navigator<"u"&&navigator.userAgent&&navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/))return!1;let e;return typeof document<"u"&&document.documentElement&&document.documentElement.style&&document.documentElement.style.WebkitAppearance||typeof window<"u"&&window.console&&(window.console.firebug||window.console.exception&&window.console.table)||typeof navigator<"u"&&navigator.userAgent&&(e=navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/))&&parseInt(e[1],10)>=31||typeof navigator<"u"&&navigator.userAgent&&navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/)}function GK(e){if(e[0]=(this.useColors?"%c":"")+this.namespace+(this.useColors?" %c":" ")+e[0]+(this.useColors?"%c ":" ")+"+"+cy.exports.humanize(this.diff),!this.useColors)return;let t="color: "+this.color;e.splice(1,0,t,"color: inherit");let o=0,n=0;e[0].replace(/%[a-zA-Z%]/g,a=>{a!=="%%"&&(o++,a==="%c"&&(n=o))}),e.splice(n,0,t)}Zo.log=console.debug||console.log||(()=>{});function zK(e){try{e?Zo.storage.setItem("debug",e):Zo.storage.removeItem("debug")}catch{}}function UK(){let e;try{e=Zo.storage.getItem("debug")||Zo.storage.getItem("DEBUG")}catch{}return!e&&typeof process<"u"&&"env"in process&&(e=process.env.DEBUG),e}function WK(){try{return localStorage}catch{}}cy.exports=DN()(Zo);var{formatters:QK}=cy.exports;QK.j=function(e){try{return JSON.stringify(e)}catch(t){return"[UnexpectedJSONParseError]: "+t.message}}});var RN=xe((Bxe,EN)=>{"use strict";var NN=PN()("jsonp");EN.exports=jK;var qK=0;function KK(){}function jK(e,t,o){typeof t=="function"&&(o=t,t={}),t||(t={});var n=t.prefix||"__jp",a=t.name||n+qK++,s=t.param||"callback",l=t.timeout!=null?t.timeout:6e4,p=encodeURIComponent,d=document.getElementsByTagName("script")[0]||document.head,u,y;l&&(y=setTimeout(function(){m(),o&&o(new Error("Timeout"))},l));function m(){u.parentNode&&u.parentNode.removeChild(u),window[a]=KK,y&&clearTimeout(y)}function g(){window[a]&&m()}return window[a]=function(f){NN("jsonp got",f),m(),o&&o(null,f)},e+=(~e.indexOf("?")?"&":"?")+s+"="+p(a),e=e.replace("?&","?"),NN('jsonp req "%s"',e),u=document.createElement("script"),u.src=e,d.parentNode.insertBefore(u,d),g}});var sC=xe(u$=>{"use strict";var Ws=function(){return Ws=Object.assign||function(t){for(var o,n=1,a=arguments.length;n<a;n++){o=arguments[n];for(var s in o)Object.prototype.hasOwnProperty.call(o,s)&&(t[s]=o[s])}return t},Ws.apply(this,arguments)},Cr=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function vY(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var Ve={},Ti={};Object.defineProperty(Ti,"__esModule",{value:!0});Ti.BLOCKS=void 0;var o$;(function(e){e.DOCUMENT="document",e.PARAGRAPH="paragraph",e.HEADING_1="heading-1",e.HEADING_2="heading-2",e.HEADING_3="heading-3",e.HEADING_4="heading-4",e.HEADING_5="heading-5",e.HEADING_6="heading-6",e.OL_LIST="ordered-list",e.UL_LIST="unordered-list",e.LIST_ITEM="list-item",e.HR="hr",e.QUOTE="blockquote",e.EMBEDDED_ENTRY="embedded-entry-block",e.EMBEDDED_ASSET="embedded-asset-block",e.EMBEDDED_RESOURCE="embedded-resource-block",e.TABLE="table",e.TABLE_ROW="table-row",e.TABLE_CELL="table-cell",e.TABLE_HEADER_CELL="table-header-cell"})(o$||(Ti.BLOCKS=o$={}));var Qs={};Object.defineProperty(Qs,"__esModule",{value:!0});Qs.INLINES=void 0;var n$;(function(e){e.ASSET_HYPERLINK="asset-hyperlink",e.EMBEDDED_ENTRY="embedded-entry-inline",e.EMBEDDED_RESOURCE="embedded-resource-inline",e.ENTRY_HYPERLINK="entry-hyperlink",e.HYPERLINK="hyperlink",e.RESOURCE_HYPERLINK="resource-hyperlink"})(n$||(Qs.INLINES=n$={}));var Jp={};Object.defineProperty(Jp,"__esModule",{value:!0});Jp.MARKS=void 0;var r$;(function(e){e.BOLD="bold",e.ITALIC="italic",e.UNDERLINE="underline",e.CODE="code",e.SUPERSCRIPT="superscript",e.SUBSCRIPT="subscript",e.STRIKETHROUGH="strikethrough"})(r$||(Jp.MARKS=r$={}));var s$={};(function(e){var t=Cr&&Cr.__spreadArray||function(l,p,d){if(d||arguments.length===2)for(var u=0,y=p.length,m;u<y;u++)(m||!(u in p))&&(m||(m=Array.prototype.slice.call(p,0,u)),m[u]=p[u]);return l.concat(m||Array.prototype.slice.call(p))},o;Object.defineProperty(e,"__esModule",{value:!0}),e.V1_MARKS=e.V1_NODE_TYPES=e.TEXT_CONTAINERS=e.HEADINGS=e.CONTAINERS=e.VOID_BLOCKS=e.TABLE_BLOCKS=e.LIST_ITEM_BLOCKS=e.TOP_LEVEL_BLOCKS=void 0;var n=Ti,a=Qs,s=Jp;e.TOP_LEVEL_BLOCKS=[n.BLOCKS.PARAGRAPH,n.BLOCKS.HEADING_1,n.BLOCKS.HEADING_2,n.BLOCKS.HEADING_3,n.BLOCKS.HEADING_4,n.BLOCKS.HEADING_5,n.BLOCKS.HEADING_6,n.BLOCKS.OL_LIST,n.BLOCKS.UL_LIST,n.BLOCKS.HR,n.BLOCKS.QUOTE,n.BLOCKS.EMBEDDED_ENTRY,n.BLOCKS.EMBEDDED_ASSET,n.BLOCKS.EMBEDDED_RESOURCE,n.BLOCKS.TABLE],e.LIST_ITEM_BLOCKS=[n.BLOCKS.PARAGRAPH,n.BLOCKS.HEADING_1,n.BLOCKS.HEADING_2,n.BLOCKS.HEADING_3,n.BLOCKS.HEADING_4,n.BLOCKS.HEADING_5,n.BLOCKS.HEADING_6,n.BLOCKS.OL_LIST,n.BLOCKS.UL_LIST,n.BLOCKS.HR,n.BLOCKS.QUOTE,n.BLOCKS.EMBEDDED_ENTRY,n.BLOCKS.EMBEDDED_ASSET,n.BLOCKS.EMBEDDED_RESOURCE],e.TABLE_BLOCKS=[n.BLOCKS.TABLE,n.BLOCKS.TABLE_ROW,n.BLOCKS.TABLE_CELL,n.BLOCKS.TABLE_HEADER_CELL],e.VOID_BLOCKS=[n.BLOCKS.HR,n.BLOCKS.EMBEDDED_ENTRY,n.BLOCKS.EMBEDDED_ASSET,n.BLOCKS.EMBEDDED_RESOURCE],e.CONTAINERS=(o={},o[n.BLOCKS.OL_LIST]=[n.BLOCKS.LIST_ITEM],o[n.BLOCKS.UL_LIST]=[n.BLOCKS.LIST_ITEM],o[n.BLOCKS.LIST_ITEM]=e.LIST_ITEM_BLOCKS,o[n.BLOCKS.QUOTE]=[n.BLOCKS.PARAGRAPH],o[n.BLOCKS.TABLE]=[n.BLOCKS.TABLE_ROW],o[n.BLOCKS.TABLE_ROW]=[n.BLOCKS.TABLE_CELL,n.BLOCKS.TABLE_HEADER_CELL],o[n.BLOCKS.TABLE_CELL]=[n.BLOCKS.PARAGRAPH,n.BLOCKS.UL_LIST,n.BLOCKS.OL_LIST],o[n.BLOCKS.TABLE_HEADER_CELL]=[n.BLOCKS.PARAGRAPH],o),e.HEADINGS=[n.BLOCKS.HEADING_1,n.BLOCKS.HEADING_2,n.BLOCKS.HEADING_3,n.BLOCKS.HEADING_4,n.BLOCKS.HEADING_5,n.BLOCKS.HEADING_6],e.TEXT_CONTAINERS=t([n.BLOCKS.PARAGRAPH],e.HEADINGS,!0),e.V1_NODE_TYPES=[n.BLOCKS.DOCUMENT,n.BLOCKS.PARAGRAPH,n.BLOCKS.HEADING_1,n.BLOCKS.HEADING_2,n.BLOCKS.HEADING_3,n.BLOCKS.HEADING_4,n.BLOCKS.HEADING_5,n.BLOCKS.HEADING_6,n.BLOCKS.OL_LIST,n.BLOCKS.UL_LIST,n.BLOCKS.LIST_ITEM,n.BLOCKS.HR,n.BLOCKS.QUOTE,n.BLOCKS.EMBEDDED_ENTRY,n.BLOCKS.EMBEDDED_ASSET,a.INLINES.HYPERLINK,a.INLINES.ENTRY_HYPERLINK,a.INLINES.ASSET_HYPERLINK,a.INLINES.EMBEDDED_ENTRY,"text"],e.V1_MARKS=[s.MARKS.BOLD,s.MARKS.CODE,s.MARKS.ITALIC,s.MARKS.UNDERLINE]})(s$);var l$={};Object.defineProperty(l$,"__esModule",{value:!0});var p$={};Object.defineProperty(p$,"__esModule",{value:!0});var om={};Object.defineProperty(om,"__esModule",{value:!0});om.EMPTY_DOCUMENT=void 0;var a$=Ti;om.EMPTY_DOCUMENT={nodeType:a$.BLOCKS.DOCUMENT,data:{},content:[{nodeType:a$.BLOCKS.PARAGRAPH,data:{},content:[{nodeType:"text",value:"",marks:[],data:{}}]}]};var Zp={};Object.defineProperty(Zp,"__esModule",{value:!0});Zp.isInline=MY;Zp.isBlock=TY;Zp.isText=AY;var IY=Ti,kY=Qs;function c$(e,t){for(var o=0,n=Object.keys(e);o<n.length;o++){var a=n[o];if(t===e[a])return!0}return!1}function MY(e){return c$(kY.INLINES,e.nodeType)}function TY(e){return c$(IY.BLOCKS,e.nodeType)}function AY(e){return e.nodeType==="text"}function _Y(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var iC={};Object.defineProperty(iC,"__esModule",{value:!0});iC.getSchemaWithNodeType=wY;function wY(e){try{return _Y("./generated/".concat(e,".json"))}catch{throw new Error('Schema for nodeType "'.concat(e,'" was not found.'))}}(function(e){var t=Cr&&Cr.__createBinding||(Object.create?(function(m,g,f,b){b===void 0&&(b=f);var S=Object.getOwnPropertyDescriptor(g,f);(!S||("get"in S?!g.__esModule:S.writable||S.configurable))&&(S={enumerable:!0,get:function(){return g[f]}}),Object.defineProperty(m,b,S)}):(function(m,g,f,b){b===void 0&&(b=f),m[b]=g[f]})),o=Cr&&Cr.__setModuleDefault||(Object.create?(function(m,g){Object.defineProperty(m,"default",{enumerable:!0,value:g})}):function(m,g){m.default=g}),n=Cr&&Cr.__exportStar||function(m,g){for(var f in m)f!=="default"&&!Object.prototype.hasOwnProperty.call(g,f)&&t(g,m,f)},a=Cr&&Cr.__importStar||function(m){if(m&&m.__esModule)return m;var g={};if(m!=null)for(var f in m)f!=="default"&&Object.prototype.hasOwnProperty.call(m,f)&&t(g,m,f);return o(g,m),g};Object.defineProperty(e,"__esModule",{value:!0}),e.getSchemaWithNodeType=e.helpers=e.EMPTY_DOCUMENT=e.MARKS=e.INLINES=e.BLOCKS=void 0;var s=Ti;Object.defineProperty(e,"BLOCKS",{enumerable:!0,get:function(){return s.BLOCKS}});var l=Qs;Object.defineProperty(e,"INLINES",{enumerable:!0,get:function(){return l.INLINES}});var p=Jp;Object.defineProperty(e,"MARKS",{enumerable:!0,get:function(){return p.MARKS}}),n(s$,e),n(l$,e),n(p$,e);var d=om;Object.defineProperty(e,"EMPTY_DOCUMENT",{enumerable:!0,get:function(){return d.EMPTY_DOCUMENT}});var u=a(Zp);e.helpers=u;var y=iC;Object.defineProperty(e,"getSchemaWithNodeType",{enumerable:!0,get:function(){return y.getSchemaWithNodeType}})})(Ve);var DY=/["'&<>]/,PY=NY;function NY(e){var t=""+e,o=DY.exec(t);if(!o)return t;var n,a="",s=0,l=0;for(s=o.index;s<t.length;s++){switch(t.charCodeAt(s)){case 34:n="&quot;";break;case 38:n="&amp;";break;case 39:n="&#39;";break;case 60:n="&lt;";break;case 62:n="&gt;";break;default:continue}l!==s&&(a+=t.substring(l,s)),l=s+1,a+=n}return l!==s?a+t.substring(l,s):a}var Xp=vY(PY),mt,oa,EY=function(e){return'"'.concat(e.replace(/"/g,"&quot;"),'"')},RY=(mt={},mt[Ve.BLOCKS.PARAGRAPH]=function(e,t){return"<p>".concat(t(e.content),"</p>")},mt[Ve.BLOCKS.HEADING_1]=function(e,t){return"<h1>".concat(t(e.content),"</h1>")},mt[Ve.BLOCKS.HEADING_2]=function(e,t){return"<h2>".concat(t(e.content),"</h2>")},mt[Ve.BLOCKS.HEADING_3]=function(e,t){return"<h3>".concat(t(e.content),"</h3>")},mt[Ve.BLOCKS.HEADING_4]=function(e,t){return"<h4>".concat(t(e.content),"</h4>")},mt[Ve.BLOCKS.HEADING_5]=function(e,t){return"<h5>".concat(t(e.content),"</h5>")},mt[Ve.BLOCKS.HEADING_6]=function(e,t){return"<h6>".concat(t(e.content),"</h6>")},mt[Ve.BLOCKS.EMBEDDED_ENTRY]=function(e,t){return"<div>".concat(t(e.content),"</div>")},mt[Ve.BLOCKS.EMBEDDED_RESOURCE]=function(e,t){return"<div>".concat(t(e.content),"</div>")},mt[Ve.BLOCKS.UL_LIST]=function(e,t){return"<ul>".concat(t(e.content),"</ul>")},mt[Ve.BLOCKS.OL_LIST]=function(e,t){return"<ol>".concat(t(e.content),"</ol>")},mt[Ve.BLOCKS.LIST_ITEM]=function(e,t){return"<li>".concat(t(e.content),"</li>")},mt[Ve.BLOCKS.QUOTE]=function(e,t){return"<blockquote>".concat(t(e.content),"</blockquote>")},mt[Ve.BLOCKS.HR]=function(){return"<hr/>"},mt[Ve.BLOCKS.TABLE]=function(e,t){return"<table>".concat(t(e.content),"</table>")},mt[Ve.BLOCKS.TABLE_ROW]=function(e,t){return"<tr>".concat(t(e.content),"</tr>")},mt[Ve.BLOCKS.TABLE_HEADER_CELL]=function(e,t){return"<th>".concat(t(e.content),"</th>")},mt[Ve.BLOCKS.TABLE_CELL]=function(e,t){return"<td>".concat(t(e.content),"</td>")},mt[Ve.INLINES.ASSET_HYPERLINK]=function(e){return aC(Ve.INLINES.ASSET_HYPERLINK,e)},mt[Ve.INLINES.ENTRY_HYPERLINK]=function(e){return aC(Ve.INLINES.ENTRY_HYPERLINK,e)},mt[Ve.INLINES.RESOURCE_HYPERLINK]=function(e){return i$(Ve.INLINES.RESOURCE_HYPERLINK,e)},mt[Ve.INLINES.EMBEDDED_ENTRY]=function(e){return aC(Ve.INLINES.EMBEDDED_ENTRY,e)},mt[Ve.INLINES.EMBEDDED_RESOURCE]=function(e){return i$(Ve.INLINES.EMBEDDED_RESOURCE,e)},mt[Ve.INLINES.HYPERLINK]=function(e,t){var o=typeof e.data.uri=="string"?e.data.uri:"";return"<a href=".concat(EY(o),">").concat(t(e.content),"</a>")},mt),FY=(oa={},oa[Ve.MARKS.BOLD]=function(e){return"<b>".concat(e,"</b>")},oa[Ve.MARKS.ITALIC]=function(e){return"<i>".concat(e,"</i>")},oa[Ve.MARKS.UNDERLINE]=function(e){return"<u>".concat(e,"</u>")},oa[Ve.MARKS.CODE]=function(e){return"<code>".concat(e,"</code>")},oa[Ve.MARKS.SUPERSCRIPT]=function(e){return"<sup>".concat(e,"</sup>")},oa[Ve.MARKS.SUBSCRIPT]=function(e){return"<sub>".concat(e,"</sub>")},oa[Ve.MARKS.STRIKETHROUGH]=function(e){return"<s>".concat(e,"</s>")},oa),aC=function(e,t){return"<span>type: ".concat(Xp(e)," id: ").concat(Xp(t.data.target.sys.id),"</span>")},i$=function(e,t){return"<span>type: ".concat(Xp(e)," urn: ").concat(Xp(t.data.target.sys.urn),"</span>")};function BY(e,t){return t===void 0&&(t={}),!e||!e.content?"":d$(e.content,{renderNode:Ws(Ws({},RY),t.renderNode),renderMark:Ws(Ws({},FY),t.renderMark),preserveWhitespace:t.preserveWhitespace})}function d$(e,t){var o=t.renderNode,n=t.renderMark,a=t.preserveWhitespace;return e.map(function(s){return $Y(s,{renderNode:o,renderMark:n,preserveWhitespace:a})}).join("")}function $Y(e,t){var o=t.renderNode,n=t.renderMark,a=t.preserveWhitespace;if(Ve.helpers.isText(e)){var s=Xp(e.value);return a&&(s=s.replace(/\n/g,"<br/>").replace(/ {2,}/g,function(p){return"&nbsp;".repeat(p.length)})),e.marks.length>0?e.marks.reduce(function(p,d){return n[d.type]?n[d.type](p):p},s):s}else{var l=function(p){return d$(p,{renderMark:n,renderNode:o,preserveWhitespace:a})};return!e.nodeType||!o[e.nodeType]?"":o[e.nodeType](e,l)}}u$.documentToHtmlString=BY});var T5=xe((rBe,M5)=>{"use strict";var TX={}.toString;M5.exports=Array.isArray||function(e){return TX.call(e)=="[object Array]"}});var D5=xe((aBe,js)=>{"use strict";var km=T5();js.exports=w5;js.exports.parse=EC;js.exports.compile=wX;js.exports.tokensToFunction=A5;js.exports.tokensToRegExp=_5;var AX=new RegExp(["(\\\\.)","([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"].join("|"),"g");function EC(e,t){for(var o=[],n=0,a=0,s="",l=t&&t.delimiter||"/",p;(p=AX.exec(e))!=null;){var d=p[0],u=p[1],y=p.index;if(s+=e.slice(a,y),a=y+d.length,u){s+=u[1];continue}var m=e[a],g=p[2],f=p[3],b=p[4],S=p[5],C=p[6],v=p[7];s&&(o.push(s),s="");var k=g!=null&&m!=null&&m!==g,I=C==="+"||C==="*",A=C==="?"||C==="*",D=g||l,B=b||S,M=g||(typeof o[o.length-1]=="string"?o[o.length-1]:"");o.push({name:f||n++,prefix:g||"",delimiter:D,optional:A,repeat:I,partial:k,asterisk:!!v,pattern:B?NX(B):v?".*":_X(D,M)})}return a<e.length&&(s+=e.substr(a)),s&&o.push(s),o}function _X(e,t){return!t||t.indexOf(e)>-1?"[^"+Ai(e)+"]+?":Ai(t)+"|(?:(?!"+Ai(t)+")[^"+Ai(e)+"])+?"}function wX(e,t){return A5(EC(e,t),t)}function DX(e){return encodeURI(e).replace(/[\/?#]/g,function(t){return"%"+t.charCodeAt(0).toString(16).toUpperCase()})}function PX(e){return encodeURI(e).replace(/[?#]/g,function(t){return"%"+t.charCodeAt(0).toString(16).toUpperCase()})}function A5(e,t){for(var o=new Array(e.length),n=0;n<e.length;n++)typeof e[n]=="object"&&(o[n]=new RegExp("^(?:"+e[n].pattern+")$",FC(t)));return function(a,s){for(var l="",p=a||{},d=s||{},u=d.pretty?DX:encodeURIComponent,y=0;y<e.length;y++){var m=e[y];if(typeof m=="string"){l+=m;continue}var g=p[m.name],f;if(g==null)if(m.optional){m.partial&&(l+=m.prefix);continue}else throw new TypeError('Expected "'+m.name+'" to be defined');if(km(g)){if(!m.repeat)throw new TypeError('Expected "'+m.name+'" to not repeat, but received `'+JSON.stringify(g)+"`");if(g.length===0){if(m.optional)continue;throw new TypeError('Expected "'+m.name+'" to not be empty')}for(var b=0;b<g.length;b++){if(f=u(g[b]),!o[y].test(f))throw new TypeError('Expected all "'+m.name+'" to match "'+m.pattern+'", but received `'+JSON.stringify(f)+"`");l+=(b===0?m.prefix:m.delimiter)+f}continue}if(f=m.asterisk?PX(g):u(g),!o[y].test(f))throw new TypeError('Expected "'+m.name+'" to match "'+m.pattern+'", but received "'+f+'"');l+=m.prefix+f}return l}}function Ai(e){return e.replace(/([.+*?=^!:${}()[\]|\/\\])/g,"\\$1")}function NX(e){return e.replace(/([=!:$\/()])/g,"\\$1")}function RC(e,t){return e.keys=t,e}function FC(e){return e&&e.sensitive?"":"i"}function EX(e,t){var o=e.source.match(/\((?!\?)/g);if(o)for(var n=0;n<o.length;n++)t.push({name:n,prefix:null,delimiter:null,optional:!1,repeat:!1,partial:!1,asterisk:!1,pattern:null});return RC(e,t)}function RX(e,t,o){for(var n=[],a=0;a<e.length;a++)n.push(w5(e[a],t,o).source);var s=new RegExp("(?:"+n.join("|")+")",FC(o));return RC(s,t)}function FX(e,t,o){return _5(EC(e,o),t,o)}function _5(e,t,o){km(t)||(o=t||o,t=[]),o=o||{};for(var n=o.strict,a=o.end!==!1,s="",l=0;l<e.length;l++){var p=e[l];if(typeof p=="string")s+=Ai(p);else{var d=Ai(p.prefix),u="(?:"+p.pattern+")";t.push(p),p.repeat&&(u+="(?:"+d+u+")*"),p.optional?p.partial?u=d+"("+u+")?":u="(?:"+d+"("+u+"))?":u=d+"("+u+")",s+=u}}var y=Ai(o.delimiter||"/"),m=s.slice(-y.length)===y;return n||(s=(m?s.slice(0,-y.length):s)+"(?:"+y+"(?=$))?"),a?s+="$":s+=n&&m?"":"(?="+y+"|$)",RC(new RegExp("^"+s,FC(o)),t)}function w5(e,t,o){return km(t)||(o=t||o,t=[]),o=o||{},e instanceof RegExp?EX(e,t):km(e)?RX(e,t,o):FX(e,t,o)}});var zm=xe(dx=>{"use strict";Object.defineProperty(dx,"__esModule",{value:!0});function NJ(e){return e&&typeof e=="object"&&"default"in e?e.default:e}var px=w(),Je=NJ(px),rl=function(){return rl=Object.assign||function(t){for(var o,n=1,a=arguments.length;n<a;n++){o=arguments[n];for(var s in o)Object.prototype.hasOwnProperty.call(o,s)&&(t[s]=o[s])}return t},rl.apply(this,arguments)},Tr=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function sa(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function la(e,t){return t={exports:{}},e(t,t.exports),t.exports}var ye=la(function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.BLOCKS=void 0;var o;(function(n){n.DOCUMENT="document",n.PARAGRAPH="paragraph",n.HEADING_1="heading-1",n.HEADING_2="heading-2",n.HEADING_3="heading-3",n.HEADING_4="heading-4",n.HEADING_5="heading-5",n.HEADING_6="heading-6",n.OL_LIST="ordered-list",n.UL_LIST="unordered-list",n.LIST_ITEM="list-item",n.HR="hr",n.QUOTE="blockquote",n.EMBEDDED_ENTRY="embedded-entry-block",n.EMBEDDED_ASSET="embedded-asset-block",n.EMBEDDED_RESOURCE="embedded-resource-block",n.TABLE="table",n.TABLE_ROW="table-row",n.TABLE_CELL="table-cell",n.TABLE_HEADER_CELL="table-header-cell"})(o||(t.BLOCKS=o={}))});sa(ye);var m8e=ye.BLOCKS,Ja=la(function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.INLINES=void 0;var o;(function(n){n.HYPERLINK="hyperlink",n.ENTRY_HYPERLINK="entry-hyperlink",n.ASSET_HYPERLINK="asset-hyperlink",n.RESOURCE_HYPERLINK="resource-hyperlink",n.EMBEDDED_ENTRY="embedded-entry-inline",n.EMBEDDED_RESOURCE="embedded-resource-inline"})(o||(t.INLINES=o={}))});sa(Ja);var g8e=Ja.INLINES,Ni=la(function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.MARKS=void 0;var o;(function(n){n.BOLD="bold",n.ITALIC="italic",n.UNDERLINE="underline",n.CODE="code",n.SUPERSCRIPT="superscript",n.SUBSCRIPT="subscript"})(o||(t.MARKS=o={}))});sa(Ni);var f8e=Ni.MARKS,jn=la(function(e,t){var o=Tr&&Tr.__spreadArray||function(a,s,l){if(l||arguments.length===2)for(var p=0,d=s.length,u;p<d;p++)(u||!(p in s))&&(u||(u=Array.prototype.slice.call(s,0,p)),u[p]=s[p]);return a.concat(u||Array.prototype.slice.call(s))},n;Object.defineProperty(t,"__esModule",{value:!0}),t.V1_MARKS=t.V1_NODE_TYPES=t.TEXT_CONTAINERS=t.HEADINGS=t.CONTAINERS=t.VOID_BLOCKS=t.TABLE_BLOCKS=t.LIST_ITEM_BLOCKS=t.TOP_LEVEL_BLOCKS=void 0,t.TOP_LEVEL_BLOCKS=[ye.BLOCKS.PARAGRAPH,ye.BLOCKS.HEADING_1,ye.BLOCKS.HEADING_2,ye.BLOCKS.HEADING_3,ye.BLOCKS.HEADING_4,ye.BLOCKS.HEADING_5,ye.BLOCKS.HEADING_6,ye.BLOCKS.OL_LIST,ye.BLOCKS.UL_LIST,ye.BLOCKS.HR,ye.BLOCKS.QUOTE,ye.BLOCKS.EMBEDDED_ENTRY,ye.BLOCKS.EMBEDDED_ASSET,ye.BLOCKS.EMBEDDED_RESOURCE,ye.BLOCKS.TABLE],t.LIST_ITEM_BLOCKS=[ye.BLOCKS.PARAGRAPH,ye.BLOCKS.HEADING_1,ye.BLOCKS.HEADING_2,ye.BLOCKS.HEADING_3,ye.BLOCKS.HEADING_4,ye.BLOCKS.HEADING_5,ye.BLOCKS.HEADING_6,ye.BLOCKS.OL_LIST,ye.BLOCKS.UL_LIST,ye.BLOCKS.HR,ye.BLOCKS.QUOTE,ye.BLOCKS.EMBEDDED_ENTRY,ye.BLOCKS.EMBEDDED_ASSET,ye.BLOCKS.EMBEDDED_RESOURCE],t.TABLE_BLOCKS=[ye.BLOCKS.TABLE,ye.BLOCKS.TABLE_ROW,ye.BLOCKS.TABLE_CELL,ye.BLOCKS.TABLE_HEADER_CELL],t.VOID_BLOCKS=[ye.BLOCKS.HR,ye.BLOCKS.EMBEDDED_ENTRY,ye.BLOCKS.EMBEDDED_ASSET,ye.BLOCKS.EMBEDDED_RESOURCE],t.CONTAINERS=(n={},n[ye.BLOCKS.OL_LIST]=[ye.BLOCKS.LIST_ITEM],n[ye.BLOCKS.UL_LIST]=[ye.BLOCKS.LIST_ITEM],n[ye.BLOCKS.LIST_ITEM]=t.LIST_ITEM_BLOCKS,n[ye.BLOCKS.QUOTE]=[ye.BLOCKS.PARAGRAPH],n[ye.BLOCKS.TABLE]=[ye.BLOCKS.TABLE_ROW],n[ye.BLOCKS.TABLE_ROW]=[ye.BLOCKS.TABLE_CELL,ye.BLOCKS.TABLE_HEADER_CELL],n[ye.BLOCKS.TABLE_CELL]=[ye.BLOCKS.PARAGRAPH],n[ye.BLOCKS.TABLE_HEADER_CELL]=[ye.BLOCKS.PARAGRAPH],n),t.HEADINGS=[ye.BLOCKS.HEADING_1,ye.BLOCKS.HEADING_2,ye.BLOCKS.HEADING_3,ye.BLOCKS.HEADING_4,ye.BLOCKS.HEADING_5,ye.BLOCKS.HEADING_6],t.TEXT_CONTAINERS=o([ye.BLOCKS.PARAGRAPH],t.HEADINGS,!0),t.V1_NODE_TYPES=[ye.BLOCKS.DOCUMENT,ye.BLOCKS.PARAGRAPH,ye.BLOCKS.HEADING_1,ye.BLOCKS.HEADING_2,ye.BLOCKS.HEADING_3,ye.BLOCKS.HEADING_4,ye.BLOCKS.HEADING_5,ye.BLOCKS.HEADING_6,ye.BLOCKS.OL_LIST,ye.BLOCKS.UL_LIST,ye.BLOCKS.LIST_ITEM,ye.BLOCKS.HR,ye.BLOCKS.QUOTE,ye.BLOCKS.EMBEDDED_ENTRY,ye.BLOCKS.EMBEDDED_ASSET,Ja.INLINES.HYPERLINK,Ja.INLINES.ENTRY_HYPERLINK,Ja.INLINES.ASSET_HYPERLINK,Ja.INLINES.EMBEDDED_ENTRY,"text"],t.V1_MARKS=[Ni.MARKS.BOLD,Ni.MARKS.CODE,Ni.MARKS.ITALIC,Ni.MARKS.UNDERLINE]});sa(jn);var b8e=jn.V1_MARKS,S8e=jn.V1_NODE_TYPES,h8e=jn.TEXT_CONTAINERS,C8e=jn.HEADINGS,x8e=jn.CONTAINERS,v8e=jn.VOID_BLOCKS,I8e=jn.TABLE_BLOCKS,k8e=jn.LIST_ITEM_BLOCKS,M8e=jn.TOP_LEVEL_BLOCKS,C6=la(function(e,t){Object.defineProperty(t,"__esModule",{value:!0})});sa(C6);var x6=la(function(e,t){Object.defineProperty(t,"__esModule",{value:!0})});sa(x6);var cx=la(function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.EMPTY_DOCUMENT=void 0,t.EMPTY_DOCUMENT={nodeType:ye.BLOCKS.DOCUMENT,data:{},content:[{nodeType:ye.BLOCKS.PARAGRAPH,data:{},content:[{nodeType:"text",value:"",marks:[],data:{}}]}]}});sa(cx);var T8e=cx.EMPTY_DOCUMENT,Sc=la(function(e,t){Object.defineProperty(t,"__esModule",{value:!0}),t.isText=t.isBlock=t.isInline=void 0;function o(l,p){for(var d=0,u=Object.keys(l);d<u.length;d++){var y=u[d];if(p===l[y])return!0}return!1}function n(l){return o(Ja.INLINES,l.nodeType)}t.isInline=n;function a(l){return o(ye.BLOCKS,l.nodeType)}t.isBlock=a;function s(l){return l.nodeType==="text"}t.isText=s});sa(Sc);var A8e=Sc.isText,_8e=Sc.isBlock,w8e=Sc.isInline,al=la(function(e,t){var o=Tr&&Tr.__createBinding||(Object.create?(function(p,d,u,y){y===void 0&&(y=u);var m=Object.getOwnPropertyDescriptor(d,u);(!m||("get"in m?!d.__esModule:m.writable||m.configurable))&&(m={enumerable:!0,get:function(){return d[u]}}),Object.defineProperty(p,y,m)}):(function(p,d,u,y){y===void 0&&(y=u),p[y]=d[u]})),n=Tr&&Tr.__setModuleDefault||(Object.create?(function(p,d){Object.defineProperty(p,"default",{enumerable:!0,value:d})}):function(p,d){p.default=d}),a=Tr&&Tr.__exportStar||function(p,d){for(var u in p)u!=="default"&&!Object.prototype.hasOwnProperty.call(d,u)&&o(d,p,u)},s=Tr&&Tr.__importStar||function(p){if(p&&p.__esModule)return p;var d={};if(p!=null)for(var u in p)u!=="default"&&Object.prototype.hasOwnProperty.call(p,u)&&o(d,p,u);return n(d,p),d};Object.defineProperty(t,"__esModule",{value:!0}),t.helpers=t.EMPTY_DOCUMENT=t.MARKS=t.INLINES=t.BLOCKS=void 0,Object.defineProperty(t,"BLOCKS",{enumerable:!0,get:function(){return ye.BLOCKS}}),Object.defineProperty(t,"INLINES",{enumerable:!0,get:function(){return Ja.INLINES}}),Object.defineProperty(t,"MARKS",{enumerable:!0,get:function(){return Ni.MARKS}}),a(jn,t),a(C6,t),a(x6,t),Object.defineProperty(t,"EMPTY_DOCUMENT",{enumerable:!0,get:function(){return cx.EMPTY_DOCUMENT}});var l=s(Sc);t.helpers=l});sa(al);var EJ=al.helpers,D8e=al.EMPTY_DOCUMENT,nl=al.MARKS,Kn=al.INLINES,jt=al.BLOCKS;function RJ(e,t){return px.isValidElement(e)&&e.key===null?px.cloneElement(e,{key:t}):e}function FJ(e,t){return e.map(function(o,n){return RJ(v6(o,t),n)})}function v6(e,t){var o=t.renderNode,n=t.renderMark,a=t.renderText,s=t.preserveWhitespace;if(EJ.isText(e)){var l=a?a(e.value):e.value;if(s){l=l.replace(/ {2,}/g,function(y){return"\xA0".repeat(y.length)});var p=l.split(`
`),d=[];p.forEach(function(y,m){d.push(y),m!==p.length-1&&d.push(Je.createElement("br",null))}),l=d}return e.marks.reduce(function(y,m){return n[m.type]?n[m.type](y):y},l)}else{var u=FJ(e.content,t);return!e.nodeType||!o[e.nodeType]?Je.createElement(Je.Fragment,null,u):o[e.nodeType](e,u)}}var ct,Xa,BJ=(ct={},ct[jt.DOCUMENT]=function(e,t){return t},ct[jt.PARAGRAPH]=function(e,t){return Je.createElement("p",null,t)},ct[jt.HEADING_1]=function(e,t){return Je.createElement("h1",null,t)},ct[jt.HEADING_2]=function(e,t){return Je.createElement("h2",null,t)},ct[jt.HEADING_3]=function(e,t){return Je.createElement("h3",null,t)},ct[jt.HEADING_4]=function(e,t){return Je.createElement("h4",null,t)},ct[jt.HEADING_5]=function(e,t){return Je.createElement("h5",null,t)},ct[jt.HEADING_6]=function(e,t){return Je.createElement("h6",null,t)},ct[jt.EMBEDDED_ENTRY]=function(e,t){return Je.createElement("div",null,t)},ct[jt.EMBEDDED_RESOURCE]=function(e,t){return Je.createElement("div",null,t)},ct[jt.UL_LIST]=function(e,t){return Je.createElement("ul",null,t)},ct[jt.OL_LIST]=function(e,t){return Je.createElement("ol",null,t)},ct[jt.LIST_ITEM]=function(e,t){return Je.createElement("li",null,t)},ct[jt.QUOTE]=function(e,t){return Je.createElement("blockquote",null,t)},ct[jt.HR]=function(){return Je.createElement("hr",null)},ct[jt.TABLE]=function(e,t){return Je.createElement("table",null,Je.createElement("tbody",null,t))},ct[jt.TABLE_ROW]=function(e,t){return Je.createElement("tr",null,t)},ct[jt.TABLE_HEADER_CELL]=function(e,t){return Je.createElement("th",null,t)},ct[jt.TABLE_CELL]=function(e,t){return Je.createElement("td",null,t)},ct[Kn.ASSET_HYPERLINK]=function(e){return lx(Kn.ASSET_HYPERLINK,e)},ct[Kn.ENTRY_HYPERLINK]=function(e){return lx(Kn.ENTRY_HYPERLINK,e)},ct[Kn.RESOURCE_HYPERLINK]=function(e){return h6(Kn.RESOURCE_HYPERLINK,e)},ct[Kn.EMBEDDED_ENTRY]=function(e){return lx(Kn.EMBEDDED_ENTRY,e)},ct[Kn.EMBEDDED_RESOURCE]=function(e,t){return h6(Kn.EMBEDDED_RESOURCE,e)},ct[Kn.HYPERLINK]=function(e,t){return Je.createElement("a",{href:e.data.uri},t)},ct),$J=(Xa={},Xa[nl.BOLD]=function(e){return Je.createElement("b",null,e)},Xa[nl.ITALIC]=function(e){return Je.createElement("i",null,e)},Xa[nl.UNDERLINE]=function(e){return Je.createElement("u",null,e)},Xa[nl.CODE]=function(e){return Je.createElement("code",null,e)},Xa[nl.SUPERSCRIPT]=function(e){return Je.createElement("sup",null,e)},Xa[nl.SUBSCRIPT]=function(e){return Je.createElement("sub",null,e)},Xa);function lx(e,t){return Je.createElement("span",{key:t.data.target.sys.id},"type: ",t.nodeType," id: ",t.data.target.sys.id)}function h6(e,t){return Je.createElement("span",{key:t.data.target.sys.urn},"type: ",t.nodeType," urn: ",t.data.target.sys.urn)}function LJ(e,t){return t===void 0&&(t={}),e?v6(e,{renderNode:rl(rl({},BJ),t.renderNode),renderMark:rl(rl({},$J),t.renderMark),renderText:t.renderText,preserveWhitespace:t.preserveWhitespace}):null}dx.documentToReactComponents=LJ});var bU=xe((fTt,fU)=>{"use strict";var ed={simple:function(e){return e.length?e.join(""):""},json:function(e){if(!e.length)return"";for(var t=[],o=e.length-1;o>=0;o--)t.push(JSON.stringify(e[o]));return t.join("")}};function qoe(e){return e.forEach(function(t){if(typeof t=="string"&&!ed.hasOwnProperty(t))throw new Error('promise-memoize: unknown value "'+t+'" in resolve option')}),function(t){var o=Math.min(e.length,t.length);if(!o)return"";for(var n=[],a=0;a<o;a++)typeof e[a]=="string"?n.push(ed[e[a]]([t[a]])):n.push(e[a](t[a]));return n.join("")}}fU.exports=function(t){if(typeof t>"u")return ed.simple;if(typeof t=="string"&&ed.hasOwnProperty(t))return ed[t];if(Array.isArray(t))return qoe(t);if(Object.prototype.toString.call(t)==="[object Function]")return t;throw new Error("promise-memoize: invalid resolve option")}});var vU=xe((bTt,xU)=>{"use strict";var Koe=bU();function joe(){return!0}function Yoe(){return!1}function SU(e){return e.then(joe,Yoe)}function Xoe(e){return e}function Joe(e){throw e}function hU(e){return e.then(Xoe,Joe)}function Zoe(e,t){return{result:e,args:t,expire_id:0,prefetch_id:0,need_prefetch:!1}}function Hf(e,t){e[t]&&(clearTimeout(e[t].expire_id),clearTimeout(e[t].prefetch_id),delete e[t])}function ene(e,t){e[t]&&(e[t].need_prefetch=!0)}function tne(e){var t=e[0],o=e[1],n=e[2],a=e[3];if(o[n]){if(t){if(!a.maxAge)return;o[n].expire_id=setTimeout(Hf,a.maxAge,o,n),o[n].prefetch_id=setTimeout(ene,a.maxAge*.7,o,n),o[n].expire_id.unref&&o[n].expire_id.unref(),o[n].prefetch_id.unref&&o[n].prefetch_id.unref();return}if(!a.maxErrorAge){Hf(o,n);return}o[n].expire_id=setTimeout(Hf,a.maxErrorAge,o,n),o[n].expire_id.unref&&o[n].expire_id.unref()}}function CU(e,t,o){var n=e[t].result.constructor;n.all([SU(e[t].result),e,t,o]).then(tne)}function one(e){var t=e[0],o=e[1],n=e[2],a=e[3],s=e[4][0];o[n]&&t&&(o[n].result=s,clearTimeout(o[n].expire_id),CU(o,n,a))}function nne(e,t,o){var n=hU(o.fn.apply(null,e[t].args)),a=n.constructor;e[t].need_prefetch=!1,a.all([SU(n),e,t,o,[n]]).then(one)}xU.exports=function(t,o){var n={},a=o||{},s=Koe(a.resolve),l={fn:t,maxAge:a.maxAge||0,maxErrorAge:a.maxErrorAge||0};function p(){for(var d=new Array(arguments.length),u=0;u<d.length;u++)d[u]=arguments[u];var y=s(d);return n[y]?n[y].need_prefetch&&nne(n,y,l):(n[y]=Zoe(hU(l.fn.apply(null,d)),l.maxAge||l.maxErrorAge?d:null),CU(n,y,l)),n[y].result}return p.clear=function(){var d=Object.keys(n);return d.forEach(function(u){Hf(n,u)}),d.length},p}});var kU=xe((STt,IU)=>{"use strict";IU.exports=vU()});var zU=Object.defineProperty,Gr=(e,t)=>zU(e,"name",{value:t,configurable:!0}),ss,ob=(ss=class{constructor(t){this.onDataListeners=new Map,this.onErrorListeners=new Map,this.unsettledPromises=new Map,this.settledPromiseCount=0,this.register=Gr(o=>{let n=this.clock();if(this.resultCache.has(o.dataId)){let s=this.resultCache.get(o.dataId);if(s.expiryTime>=n)return s.error?{error:s.error,hasLoaded:!0,isLoading:!1}:{data:s.data,hasLoaded:!0,isLoading:!1};this.delete(o.dataId)}if(this.onDataListeners.has(o.dataId)||this.onDataListeners.set(o.dataId,new Set),this.onErrorListeners.has(o.dataId)||this.onErrorListeners.set(o.dataId,new Set),o.onData&&this.onDataListeners.get(o.dataId).add(o.onData),o.onError&&this.onErrorListeners.get(o.dataId).add(o.onError),this.unsettledPromises.has(o.dataId))return{hasLoaded:!1,isLoading:!0};let a=o.dataAsync();return this.unsettledPromises.set(o.dataId,a),a.then(s=>{this.resultCache.set(o.dataId,{data:s,expiryTime:this.clock()+(o.ttlMs??this.defaultExpiryTimeMs)});let l=this.onDataListeners.get(o.dataId);for(let p of l)try{p(s)}catch(d){try{this.errorHandler(d)}catch{}}l.clear()}).catch(s=>{this.resultCache.set(o.dataId,{error:s,expiryTime:this.clock()+(o.ttlMs??this.defaultExpiryTimeMs)});let l=this.onErrorListeners.get(o.dataId);for(let p of l)try{p(s)}catch(d){try{this.errorHandler(d)}catch{}}l.clear()}).finally(()=>{this.unsettledPromises.delete(o.dataId),this.settledPromiseCount++}),{isLoading:!0,hasLoaded:!1}},"register"),this.countUnsettledPromises=Gr(()=>this.unsettledPromises.size,"countUnsettledPromises"),this.countSettledPromises=Gr(()=>this.settledPromiseCount,"countSettledPromises"),this.unawaitedPromiseKeys=Gr(()=>[...this.unsettledPromises.keys()],"unawaitedPromiseKeys"),this.allUnawaitedPromises=Gr(async()=>{await Promise.allSettled(this.unsettledPromises.values())},"allUnawaitedPromises"),this.getCache=Gr(()=>(this.cleanCache(),this.resultCache),"getCache"),this.cleanCache=Gr(()=>{let o=0;return this.resultCache.forEach((n,a)=>{n.expiryTime<this.clock()&&(this.delete(a),o++)}),o},"cleanCache"),this.delete=Gr(o=>{this.resultCache.delete(o),this.onDataListeners.delete(o),this.onErrorListeners.delete(o)},"delete"),this.clock=t.clock??Date.now,this.resultCache=t.cache??new Map,this.defaultExpiryTimeMs=t.defaultExpiryTimeMs??3e4,this.errorHandler=t.errorHandler??console.error}},Gr(ss,"AsyncDataController"),ss),R0=new ob({clock:Date.now});var UU=Object.defineProperty,WU=(e,t)=>UU(e,"name",{value:t,configurable:!0}),QU={platformVersion:"platformVersion",architecture:"architecture",bitness:"bitness",model:"model",fullBrowsers:"fullVersionList"},ls,F0=(ls=class extends JI{constructor(t=window){super({}),this.featuresWindow=t}computeLowEntropyHints(){let t=nk(this.featuresWindow.navigator.userAgent);return{browsers:this.featuresWindow.navigator.userAgentData?.brands?.map(n=>({brand:tk(n.brand),majorVersion:Number(ek(n.version))}))??t.browsers,platform:ok(this.featuresWindow.navigator.userAgentData?.platform)??t.platform,isMobile:this.featuresWindow.navigator.userAgentData?.mobile??t.isMobile,saveData:this.featuresWindow.navigator.connection?.saveData??t.isMobile,isSnapchatWebview:t.isSnapchatWebview}}async computeHighEntropyHintsAsync(...t){let o=await this.featuresWindow.navigator.userAgentData?.getHighEntropyValues(t.map(l=>QU[l]).filter(Boolean)),n=this.featuresWindow.matchMedia("(prefers-reduced-motion: reduce)").matches,a=this.featuresWindow.matchMedia("(prefers-color-scheme: dark)").matches,s=this.featuresWindow.matchMedia("(prefers-color-scheme: light)").matches;return{viewportWidth:this.featuresWindow.innerWidth,viewportHeight:this.featuresWindow.innerHeight,fullBrowsers:o?.fullVersionList?.map(l=>({brand:l.brand,fullVersion:l.version})),model:o?.model,downlinkMbps:this.featuresWindow.navigator.connection?.downlink,devicePixelRatio:this.featuresWindow.devicePixelRatio,connection:this.featuresWindow.navigator.connection?.effectiveType,architecture:o?.architecture,bitness:o?.bitness?Number(o?.bitness):void 0,reduceMotion:n,colorScheme:a?"dark":s?"light":void 0,platformVersion:o?.platformVersion}}},WU(ls,"ClientBrowserFeature"),ls);var wU=T(TM()),Of=T(_M());var zr=T(w(),1),MQ=Object.defineProperty,TQ=(e,t)=>MQ(e,"name",{value:t,configurable:!0}),ib=(0,zr.createContext)({controller:R0});function an(e){let{controller:t}=(0,zr.useContext)(ib),[o,n]=(0,zr.useState)(0),a=(0,zr.useCallback)(l=>{e.onData?.(l),n(p=>p+1)},[n,e.onData]),s=(0,zr.useCallback)(l=>{e.onError?.(l),n(p=>p+1)},[n,e.onError]);return e.skip?{hasLoaded:!0,isLoading:!1}:t.register({...e,onError:s,onData:a})}TQ(an,"useAsyncData");var sn={Click:"Click",Warning:"Warning",LocaleSelect:"LocaleSelect"};var HM=T(w());var ie={Left:"Left",Start:"Start",Center:"Center",End:"End",Right:"Right"},Xo={Top:"Top",Middle:"Middle",Bottom:"Bottom"},di={TopRight:"TopRight",TopLeft:"TopLeft",TopCenter:"TopCenter",BottomLeft:"BottomLeft",BottomRight:"BottomRight",BottomCenter:"BottomCenter"};var Ed={Normal:"Normal",Fixed:"Fixed"};var Rd="[locale specific font fallback]",wM={"bn-BD":"Noto Sans Bengali","bn-IN":"Noto Sans Bengali","zh-Hans":"Noto Sans SC","zh-Hant":"Noto Sans TC","hi-IN":"Noto Sans Devanagari","mr-IN":"Noto Sans Devanagari","gu-IN":"Noto Sans Gujarati","ja-JP":"Noto Sans Japanese","kn-IN":"Noto Sans Kannada","ko-KR":"Noto Sans KR","ml-IN":"Noto Sans Malayalam",pa:"Noto Sans Gurmukhi","ta-IN":"Noto Sans Tamil","te-IN":"Noto Sans Telugu"},DM={"--h1-font-family":`Program OT, Helvetica Heading, Tahoma Heading, ${Rd}, Arial, sans-serif`,"--h2-font-family":`Program OT, Helvetica Heading, Tahoma Heading, ${Rd}, Arial, sans-serif`};var Ur={M100:c`
    font-size: 36px;
    line-height: 42px;
    font-weight: 600;
  `,M200:c`
    font-size: 32px;
    line-height: 40px;
    font-weight: 600;
  `,M300:c`
    font-size: 24px;
    line-height: 28px;
    font-weight: 500;
  `,M400:c`
    font-size: 20px;
    font-weight: 600;
    line-height: 23px;
  `,M500:c`
    font-size: 18px;
    font-weight: 400;
    line-height: 28px;
  `,M600:c`
    font-size: 16px;
    font-weight: 500;
    line-height: 19px;
  `,M700:c`
    font-size: 12px;
    font-weight: 600;
    line-height: 14px;
  `},hre={H100:c`
    font-size: 64px;
    font-weight: 600;
    line-height: 70px;
    ${N} {
      ${Ur.M100}
    }
  `,H200:c`
    font-size: 48px;
    font-weight: 600;
    line-height: 64px;
    ${N} {
      ${Ur.M200}
    }
  `,H300:c`
    font-size: 28px;
    font-weight: 500;
    line-height: 34px;
    ${N} {
      ${Ur.M300}
    }
  `,H400:c`
    font-size: 24px;
    font-weight: 500;
    line-height: 29px;
    ${N} {
      ${Ur.M400}
    }
  `,H500:c`
    font-size: 20px;
    font-weight: 500;
    line-height: 28px;
    ${N} {
      ${Ur.M500}
    }
  `,H600:c`
    font-size: 16px;
    font-weight: 500;
    line-height: 19px;
    ${N} {
      ${Ur.M600}
    }
  `,H700:c`
    font-size: 12px;
    font-weight: 600;
    line-height: 14px;
    ${N} {
      ${Ur.M700}
    }
  `},Cre={P100:c`
    font-size: 16px;
    font-weight: 400;
    line-height: 26px;
  `};var PM=c`
  overflow: -moz-scrollbars-none; /* Hide scroll bar in Firefox */
  -ms-overflow-style: none; /* Hide scroll bar in IE */
  ::-webkit-scrollbar {
    width: 0 !important; /* Hide scrollbar in Webkit browsers */
  }
`;var sb=e=>{switch(e){case ie.Center:return"center";case ie.Start:case ie.Left:return"start";case ie.End:case ie.Right:return"end";default:throw new Error(`specified alignment: ${e} is not accounted for!`)}},rr=e=>{switch(e){case ie.Center:return"center";case ie.Start:case ie.Left:return"flex-start";case ie.End:case ie.Right:return"flex-end";default:throw new Error(`specified alignment: ${e} is not accounted for!`)}},ui=Object.values(ie),Tre=Object.fromEntries(ui.map(e=>[e,c`
      text-align: ${sb(e)};
    `])),Are=Object.fromEntries(ui.map(e=>[e,c`
      align-items: ${rr(e)};
    `])),_re=Object.fromEntries(ui.map(e=>[e,c`
      justify-items: ${rr(e)};
    `])),NM=Object.fromEntries(ui.map(e=>[e,c`
      justify-content: ${rr(e)};
    `])),wre=Object.fromEntries(ui.map(e=>[e,c`
      ${N} {
        justify-content: ${rr(e)};
      }
    `])),Ta=Object.fromEntries(ui.map(e=>[e,c`
      text-align: ${sb(e)};
      align-items: ${rr(e)};
      justify-items: ${rr(e)};
      justify-content: ${rr(e)};
    `])),ar=Object.fromEntries(ui.map(e=>[e,c`
      ${N} {
        text-align: ${sb(e)};
        align-items: ${rr(e)};
        justify-items: ${rr(e)};
        justify-content: ${rr(e)};
      }
    `]));var EM=T(w()),Fd=(0,EM.createContext)(void 0);var Bd=e=>{if(!(!e||Number.isNaN(e.getTime())))return e.toISOString().substring(0,10)};var AQ=(e,t="")=>e.replace(Rd,t).replace(/,\s*,/g,","),_Q=e=>hk.includes(e),wQ=(e,t)=>{let o={};for(let n of Object.keys(e))if(_Q(n)){let a=e[n]??"";o[n]=AQ(a,t)}return o},RM=(e,t,o)=>{if(!t)return;let n=wM[e];if(!n||!o)return t;let a=wQ(o,n);return Xi(t,{name:`${t.name}Localized${e}`,fontFamily:[...t.fontFamily,n],"sdsm-default":{name:t["sdsm-default"].name,legacyName:t["sdsm-default"].legacyName,sdsm:{...t["sdsm-default"].sdsm,...a}}})};var Pe=e=>e?Bn(e):void 0;var lb=/^(?:[a-z]+:)?\/\//i,$d=(e,t)=>{if(!e||!lb.test(e))return e;try{let o=new URL(e);return Object.entries(t).forEach(([n,a])=>{o.searchParams.set(n,a)}),o.toString()}catch{return}};var Ld=T(w());function FM(e){let[t,o]=(0,Ld.useState)(!0);return(0,Ld.useEffect)(()=>{let n=()=>o(!1),a=()=>o(!0);return e?(window.addEventListener("blur",n),window.addEventListener("focus",a)):(window.removeEventListener("blur",n),window.removeEventListener("focus",n)),()=>{window.removeEventListener("blur",n),window.removeEventListener("focus",n)}},[e]),{isFocused:t}}var BM=T(w()),Hd=(0,BM.createContext)({multipleOpen:!1,openIds:[],setOpenIds:()=>null});var $M=c`
  padding-bottom: ${r("--spacing-l")};
`,LM=c`
  border-bottom: 1px solid ${r("--accordion-header-divider-border-color")};
  color: ${r("--accordion-header-color")};
  margin-block: 0;
  padding: ${r("--accordion-header-padding")} 0;

  ${H} {
    font-size: ${r("--accordion-header-desktop-font-size")};
    font-weight: ${r("--accordion-header-desktop-font-weight")};
    line-height: ${r("--accordion-header-desktop-font-line-height")};
  }

  ${N} {
    font-size: ${r("--accordion-header-mobile-font-size")};
    font-weight: ${r("--accordion-header-mobile-font-weight")};
    line-height: ${r("--accordion-header-mobile-font-line-height")};
  }
`;var VM=({children:e,multipleOpen:t=!1,title:o,titleDataset:n,openIdsOverride:a,setOpenIdsOverride:s})=>{Y("sdsm-accordion");let[l,p]=(0,HM.useState)([]);return i(Hd.Provider,{value:{multipleOpen:t,openIds:a??l,setOpenIds:s??p},children:x("div",{"data-testid":"accordion",className:h("sdsm-accordion",$M),children:[o?i("h4",{className:LM,...ne(n),children:o}):null,e]})})};var ko=T(w());var ps=T(w());var DQ={initialValue:"off",onToggle:xo,transitionDurationMs:250},Vd=e=>{let{initialValue:t,onToggle:o,transitionDurationMs:n}={...DQ,...e},[a,s]=(0,ps.useState)(t),l=(0,ps.useCallback)((y,m)=>{y!==m&&(s(y),o(y,m))},[o,s]);(0,ps.useEffect)(()=>{let y;return a==="turning-off"&&(y=setTimeout(l.bind(void 0,"off","turning-off"),n)),a==="turning-on"&&(y=setTimeout(l.bind(void 0,"on","turning-on"),n)),()=>{y&&clearTimeout(y)}},[a,n,l]);let p=()=>{a==="off"&&l("turning-on",a)},d=()=>{a==="on"&&l("turning-off",a)};return{state:a,toggle:(y="toggle")=>{y==="on"?p():y==="off"?d():a==="turning-off"||a==="off"?p():d()}}};var Aa=T(w());var pb=qo`
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
`,cb=qo`
    0% {
      opacity: 1;
    }
    100% {
      opacity: 0;
    }
`,Od=e=>["duration","curve","delay","iterationCount","direction","fillMode","playState"].map(n=>e[n]).filter(n=>!!n).join(" "),OM=(e={duration:"250ms",curve:"ease-out"})=>c`
  animation: ${pb} ${Od(e)};
`,GM=(e={duration:"250ms",curve:"ease-out"})=>c`
  animation: ${cb} ${Od(e)};
`;var db="cubic-bezier(0.4, 0.0, 0.2, 1)",ub="cubic-bezier(0.0, 0.0, 0.2, 1)",zM=(e={duration:"250ms",curve:db})=>c`
  @keyframes slideUp {
    0% {
      transform: translateY(0);
    }
    100% {
      transform: translateY(-100vh);
    }
  }

  animation: slideUp ${Od(e)};
`,UM=(e={duration:"250ms",curve:ub})=>c`
  @keyframes slideDown {
    0% {
      transform: translateY(-100vh);
    }
    100% {
      transform: translateY(0);
    }
  }

  animation: slideDown ${Od(e)};
`;var Gd="--animation-duration",WM=c`
  & > summary {
    /* Prevents selection when rapidly expanding and collapsing the content */
    user-select: none;

    cursor: pointer;
  }

  scroll-margin: 40px;

  /* Prevents keyboard selection of focusable elements that the panel is collapsed. */
  &[data-state='off'] > summary + * {
    visibility: hidden;
  }
`,QM=c`
  &[data-state='turning-on'] > summary + * {
    animation: ${pb} var(${Gd}) ease-out;
  }

  &[data-state='turning-off'] > summary + * {
    animation: ${cb} var(${Gd}) ease-out;
  }
`,qM=c`
  justify-self: center;
  width: 12px;
  height: 12px;

  transform: rotate(0deg); /* 'up' */
  transition: transform 250ms;

  details[data-state='on'] > summary > &,
  details[data-state='turning-on'] > summary > & {
    transform: rotate(180deg); /* 'down', ccw */
  }

  *[dir='rtl'] details[data-state='on'] > summary > &,
  *[dir='rtl'] details[data-state='turning-on'] > summary > & {
    transform: rotate(-180deg); /* 'down', clockwise */
  }
  position: absolute;
  right: 0;

  /* stylelint-disable-next-line no-descending-specificity */
  *[dir='rtl'] & {
    right: unset;
    left: 0;
  }
`,KM=c`
  margin: 0;
  position: relative; /* To position the chveron absolutely. */

  /* In webkit the arrow is rendered as a list icon; so we hide that, too. */
  /* We add our own arrow so we need to hid the default one. */
  ::-webkit-details-marker {
    display: none;
  }
  list-style-type: none;

  display: flex;
  align-items: center;
`;var ln=({showChevron:e=!0,chevronProps:t,onToggle:o,summaryOnClick:n,summary:a,summaryProps:s,children:l,className:p,fadeInAnimation:d=!0,transitionDurationMs:u,open:y,detailsRef:m,summaryRef:g,disableScrollToOnOpen:f,forceOpenAttribute:b,...S})=>{let C=!Ct(y);Y("sdsm-detail-summary");let v=(0,Aa.useRef)(),k=(0,Aa.useRef)(null),I=(0,Aa.useCallback)(L=>{m&&(m.current=L),k.current=L},[m]),{state:A,toggle:D}=Vd({initialValue:C&&y?"on":"off",transitionDurationMs:u});(0,Aa.useEffect)(()=>{C&&D(y?"on":"off")},[C,y,D]),(0,Aa.useEffect)(()=>{C||!o||o(A==="on"?"on":"off")},[o,A,C]);let B=L=>{n?.(L),L.preventDefault(),C?o?.(y?"off":"on"):D(),f||(clearTimeout(v.current),(C?!y:!k?.current?.open)&&(v.current=setTimeout(()=>{k?.current?.scrollIntoView({behavior:"smooth",block:"nearest"})},u)))},M=b||A!=="off",{className:_,dataset:P,...$}=s??{},R=L=>{if(typeof L=="string")return L};return x("details",{ref:I,className:h("sdsm-detail-summary",WM,p,{[QM]:d}),open:M,"data-state":A,...S,style:{...S.style,[Gd]:`${u??250}ms`},children:[x("summary",{ref:g,role:"button",tabIndex:0,title:R(a),className:h(KM,_),onClick:B,...ne(P),...$,children:[a,e&&i(De,{className:h(qM,t?.className),name:"chevron-down",fill:t?.fill})]}),l]})};ln.displayName="DetailsSummary";var jM=c`
  border-bottom: 1px solid ${r("--accordion-divider-border-color")};
  scroll-margin: 40px;
  overflow-y: hidden;
  overflow-x: auto;

  ${H} {
    font-size: ${r("--accordion-item-body-desktop-font-size")};
    line-height: ${r("--accordion-item-body-desktop-font-line-height")};
  }

  ${N} {
    font-size: ${r("--accordion-item-body-mobile-font-size")};
    line-height: ${r("--accordion-item-body-mobile-font-line-height")};
  }

  /* Body content — everything after the summary. Applies padding via motif var.
     Also targets legacy <section> wrapper used by some DetailsSummary consumers. */
  > :not(summary) {
    padding: ${r("--accordion-item-body-padding")};
  }

  section {
    margin-bottom: 0;
  }
`,YM=c`
  align-items: center;
  color: ${r("--accordion-item-color")};
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  margin: 0;
  padding: ${r("--accordion-item-padding")};
  padding-inline-end: 52px;
  user-select: none;

  ${H} {
    font-size: ${r("--accordion-item-desktop-font-size")};
    font-weight: ${r("--accordion-item-desktop-font-weight")};
    line-height: ${r("--accordion-item-desktop-font-line-height")};
  }

  ${N} {
    font-size: ${r("--accordion-item-mobile-font-size")};
    font-weight: ${r("--accordion-item-mobile-font-weight")};
    line-height: ${r("--accordion-item-mobile-font-line-height")};
  }

  /* Prevents keyboard selection of focusable elements that the panel is collapsed. */
  &[data-state='off'] + * {
    visibility: hidden;
  }

  /* In webkit the arrow is rendered as a list icon; so we hide that, too. */
  /* We add our own arrow so we need to hid the default one. */
  ::-webkit-details-marker {
    display: none;
  }
  list-style-type: none;

  > svg {
    right: ${r("--accordion-item-icon-inset")};
  }

  *[dir='rtl'] & svg {
    left: ${r("--accordion-item-icon-inset")};
    right: unset;
  }
`,zd=c`
  width: 20px;
  height: 20px;
  /* Override the inline fill="var(--icon-color)" so the chevron uses the item icon color. */
  fill: ${r("--accordion-item-icon-color")};
  /* we override top here since its already centered by flex */
  top: unset;
`;var yb=400,XM="ease-out",mb=({id:e,anchorId:t,title:o,children:n,titleDataset:a,className:s,summaryClassName:l,onToggle:p})=>{let{multipleOpen:d,openIds:u,setOpenIds:y}=(0,ko.useContext)(Hd),m=(0,ko.useRef)(null),g=(0,ko.useRef)(null),f=(0,ko.useRef)(null),b=(0,ko.useRef)(!1),S=(0,ko.useRef)(!1),C=u.includes(e);(0,ko.useEffect)(()=>{m.current&&C!==m.current.open&&(m.current.open=C)},[]);let v=(0,ko.useCallback)(()=>{if(b.current=!0,!m?.current||!g?.current)return;m.current.style.overflow="hidden";let B=`${m.current.offsetHeight}px`,M=`${g.current.offsetHeight}px`;f.current&&f.current.cancel(),f.current=m.current.animate?.({height:[B,M]},{duration:yb,easing:XM}),f.current?.finished.then(()=>D(!1)).catch(()=>{b.current=!1})},[]);(0,ko.useEffect)(()=>{C||m.current?.open&&v()},[C,v]);let k=(0,ko.useCallback)(()=>{if(S.current=!0,!m.current||!g.current)return;m.current.style.overflow="hidden";let B=`${m.current.offsetHeight}px`,M=`${g.current.offsetHeight+m.current.scrollHeight-g.current.offsetHeight}px`;f.current&&f.current.cancel(),f.current=m.current.animate?.({height:[B,M]},{duration:yb,easing:XM}),f.current?.finished.then(()=>D(!0)).catch(()=>{S.current=!1})},[]),I=(0,ko.useCallback)(()=>{m.current&&(m.current.style.height=`${m.current.offsetHeight}px`,m.current.open=!0,window.requestAnimationFrame(k))},[k]),A=(0,ko.useCallback)(B=>{y(d?B==="off"?u.filter(M=>M!==e):[...u,e]:B==="off"?[]:[e]),p?.(B==="on"),m.current&&(B==="on"?I():v())},[d,y,u,e,I,v,p]),D=B=>{m.current&&(m.current.open=B,m.current.style.height="",m.current.style.overflow="",S.current=!1,b.current=!1,f.current=null)};return i(ln,{id:t,detailsRef:m,summaryRef:g,summary:o,chevronProps:{className:zd,fill:r("--icon-color")},className:h(jM,s),onToggle:A,summaryProps:{dataset:a,className:h(YM,l)},transitionDurationMs:yb,open:C,children:n})};var JM=c`
  align-items: center;
  background-color: ${r("--banner-ai-bg-color")};
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  width: 100%;

  ${N} {
    padding: ${r("--spacing-xl")};
  }
`,ZM=c`
  display: flex;
  flex-direction: column;
  flex: 1 0 0;
  gap: ${r("--spacing-xxs")};
  justify-content: center;
  margin: 0px auto;
  max-width: ${dt}px;
  padding: ${r("--spacing-xl")} ${r("--spacing-xxxxl")};

  ${N} {
    padding: 0;
  }
`,eT=c`
  color: ${r("--banner-ai-fg-color")};
  ${ut}
`,tT=c`
  color: ${r("--banner-ai-fg-color")};
  ${qt}
`;var oT=({title:e,description:t})=>(Y("sdsm-ai-localization-banner"),!e&&!t?null:i("div",{className:h("sdsm-ai-localization-banner",JM),children:x("div",{className:ZM,children:[e&&i("div",{className:eT,children:e}),t&&i("div",{className:tT,children:t})]})}));var rT=T(w()),gb=e=>"changedTouches"in e&&"touches"in e,nT=e=>e.touches.length>1||e.changedTouches.length>1,EQ=e=>e?"current"in e?e.current:e:null;function cs(e,t,o){(0,rT.useEffect)(()=>{let n=window.scrollX,a=window.scrollY,s,l=u=>{if(!gb(u)||nT(u))return;let y=u.changedTouches[0];y&&(s=y.clientY)},p=u=>{if(o?.(u)||!u.cancelable||!(u.target instanceof HTMLElement))return;let y=EQ(e);if(!y||gb(u)&&nT(u))return;let m="down";if(u instanceof WheelEvent&&(m=u.deltaY>0?"down":"up"),gb(u)){let S=u.changedTouches[0];if(!S)return;m=s>S.clientY?"down":"up"}let g=u.target,f=!1,b=!1;for(;g&&g!==document.body;){let S=g.scrollHeight-g.offsetHeight,C=m==="up"&&g.scrollTop>0,v=m==="down"&&g.scrollTop<S;if(S>0&&(v||C)&&(b=!0),g===y){f=!0;break}g=g?.parentElement}f&&b||u.preventDefault()},d={passive:!1,capture:!1};return document.body.addEventListener("wheel",p,d),document.body.addEventListener("touchstart",l),document.body.addEventListener("touchmove",p,d),()=>{t||window.scrollTo(n,a),document.body.removeEventListener("wheel",p,d),document.body.removeEventListener("touchstart",l),document.body.removeEventListener("touchmove",p,d)}},[e,t,o])}var Ud=T(w());function Wd(e){let[t,o]=(0,Ud.useState)(!1);return(0,Ud.useEffect)(()=>{if(!e?.current)return;let n=new IntersectionObserver(([a])=>{o(a.isIntersecting)});return n.observe(e.current),()=>{n.disconnect()}},[e]),t}var wa=T(w());var gs=T(w());var _a=(e,t)=>o=>{[e,t].forEach(n=>{n&&(typeof n=="function"?n(o):n.current=o)})};var fT=T(w());var ir=-16,aT=c`
  height: auto;
  pointer-events: none;
  position: absolute;
  width: 60px;

  ${Xe} {
    width: 80px;
  }
`,iT=c`
  object-fit: contain;
  width: 100%;
`,sT=c`
  width: 80px;

  ${Xe} {
    width: 110px;
  }
`,lT=c`
  width: 80px;

  ${Xe} {
    width: 140px;
  }
`,pT=c`
  inset-inline-start: var(--sticker-position-offset, ${ir}px);
  top: var(--sticker-position-offset, ${ir}px);
`,cT=c`
  inset-inline-end: var(--sticker-position-offset, ${ir}px);
  top: var(--sticker-position-offset, ${ir}px);
`,dT=c`
  bottom: var(--sticker-position-offset, ${ir}px);
  inset-inline-start: var(--sticker-position-offset, ${ir}px);
`,uT=c`
  bottom: var(--sticker-position-offset, ${ir}px);
  inset-inline-end: var(--sticker-position-offset, ${ir}px);
`,yT=c`
  transform: rotate(-15deg);
`,mT=c`
  transform: rotate(15deg);
`,Qd=c`
  ${N} {
    display: none;
  }
`;var ip={TopStart:"Top-Start",TopEnd:"Top-End",BottomStart:"Bottom-Start",BottomEnd:"Bottom-End"},fb={Negative15Degrees:"-15 degrees",ZeroDegrees:"0 degrees",Positive15Degrees:"15 degrees"},sr={Regular:"regular",Medium:"medium",Large:"large"},qd=({className:e,imgSrcs:t,position:o=ip.TopStart,rotation:n=fb.ZeroDegrees,size:a=sr.Regular,insetPx:s=ir})=>i(et,{className:h(aT,{[sT]:a===sr.Medium,[lT]:a===sr.Large,[pT]:o===ip.TopStart,[cT]:o===ip.TopEnd,[dT]:o===ip.BottomStart,[uT]:o===ip.BottomEnd,[yT]:n===fb.Negative15Degrees,[mT]:n===fb.Positive15Degrees},e),style:{"--sticker-position-offset":`${s}px`},imgClassName:iT,imgSrcs:t,altText:""});var gT=c`
  display: inline-block; /* Ensure container always covers image so that stickers align correctly */
  position: relative;
  vertical-align: top; /* Ensure no additional space is added below image due to 'display: inline-block' */
`;var Vn=({altText:e,className:t,style:o,defaultSrc:n,imgClassName:a,imgSrcs:s,height:l,width:p,fetchPriority:d,dataset:u,isDraggable:y,handleSafariSourceSets:m,stickers:g=[]})=>{let f=!s?.sources?.length,b=(0,fT.useContext)(Zl);return x("span",{className:h(gT,t),style:o,children:[x("picture",{children:[s?.sources?.map((S,C)=>i("source",{srcSet:S.url,type:S.type,sizes:S.sizes,media:S.media},`${S.type}${C}desktop`)),i("img",{ref:m?Qk(s?.default??n,s?.defaultSrcSet):void 0,alt:e??"",className:a,sizes:s?.defaultSizes,height:l,width:p,src:f||!m?s?.default??n:void 0,srcSet:f||!m?s?.defaultSrcSet:void 0,loading:b?.lazy?"lazy":void 0,fetchpriorty:d,...ne(u),draggable:y})]}),g?.map((S,C)=>i(qd,{...S},C))]})};var Wr=e=>e?e.currentTime>0&&!e.paused&&!e.ended&&e.readyState>2:!1;var lr=T(w());var bT=T(w()),ds=(0,bT.createContext)({});var ST=c`
  display: block;
  height: 100%;
  position: relative;
  width: 100%;
`,Kd=c`
  width: 100%;
  height: 100%;
  display: block;
`,RQ=c`
  object-fit: cover;
`,FQ=c`
  object-fit: contain;
`,jd=e=>e?RQ:FQ;var yi=(0,lr.forwardRef)((e,t)=>{let{source:o,mobileSource:n,sourceType:a="video/mp4",mobileSourceType:s="video/mp4",posterSource:l,altText:p,className:d,style:u,muted:y=!0,autoPlay:m=!0,loop:g=!0,controls:f=!1,playsInline:b=!0,onPlay:S,onPause:C,captionsSource:v,isBackgroundVideo:k,onTimeUpdate:I,dataset:A}=e,D=(0,lr.useRef)(null),{getLowEntropyHints:B}=(0,lr.useContext)(Ze),M=B();(0,lr.useEffect)(()=>{let de=D.current?.querySelector("track");if(D.current&&v&&!de){let le=document.createElement("track");le.setAttribute("src",v),le.setAttribute("kind","captions"),le.setAttribute("srclang","en"),le.setAttribute("label","English"),D.current.appendChild(le)}},[v]);let{addOnTabChangeListener:_,removeOnTabChangeListener:P}=(0,lr.useContext)(ds);(0,lr.useEffect)(()=>{if(!D.current||y||m)return;let de=()=>{Wr(D.current||void 0)&&D.current?.pause()};return _?.(de),()=>P?.(de)},[_,P,D,y,m]);let $=jd(k),R=m?"auto":l?"none":"metadata",L=M.browsers.find(de=>de.brand==="Safari"),G=L&&R==="metadata"?`${o}#t=0.01`:o,Z=n&&L&&R==="metadata"?`${n}#t=0.01`:n,U=n?`${o}-${n}`:o;return x("video",{className:h("video",Kd,$,d),style:u,poster:l,autoPlay:m,loop:g,muted:y,controls:f,playsInline:b,onPlay:S,onPause:C,preload:R,"aria-describedby":p,ref:_a(D,t),crossOrigin:"anonymous",onTimeUpdate:I,...ne(A),children:[Z&&i("source",{src:Z,type:s,media:"(max-width: 768px)"}),i("source",{src:G,type:a})]},U)});yi.displayName="Video";var pr=T(w());var Qr=(0,pr.forwardRef)((e,t)=>{let{source:o,mobileSource:n,sourceType:a="video/mp4",mobileSourceType:s="video/mp4",posterSource:l,altText:p,className:d,style:u,muted:y=!0,autoPlay:m=!0,loop:g=!0,controls:f=!1,playsInline:b=!0,onPlay:S,onPause:C,captionsSource:v,isBackgroundVideo:k,onTimeUpdate:I,dataset:A,videoClassName:D,stickers:B=[]}=e,M=(0,pr.useRef)(null),{getLowEntropyHints:_}=(0,pr.useContext)(Ze),P=_();(0,pr.useEffect)(()=>{let re=M.current?.querySelector("track");if(M.current&&v&&!re){let te=document.createElement("track");te.setAttribute("src",v),te.setAttribute("kind","captions"),te.setAttribute("srclang","en"),te.setAttribute("label","English"),M.current.appendChild(te)}},[v]);let{addOnTabChangeListener:$,removeOnTabChangeListener:R}=(0,pr.useContext)(ds);(0,pr.useEffect)(()=>{if(!M.current||y||m)return;let re=()=>{Wr(M.current||void 0)&&M.current?.pause()};return $?.(re),()=>R?.(re)},[$,R,M,y,m]);let L=jd(k),G=m?"auto":l?"none":"metadata",Z=P.browsers.find(re=>re.brand==="Safari"),U=Z&&G==="metadata"?`${o}#t=0.01`:o,de=n&&Z&&G==="metadata"?`${n}#t=0.01`:n,le=n?`${o}-${n}`:o;return x("span",{className:h("video",ST,d),style:u,children:[x("video",{className:h(Kd,L,D),poster:l,autoPlay:m,loop:g,muted:y,controls:f,playsInline:b,onPlay:S,onPause:C,preload:G,"aria-describedby":p,ref:_a(M,t),crossOrigin:"anonymous",onTimeUpdate:I,...ne(A),children:[de&&i("source",{src:de,type:s,media:"(max-width: 768px)"}),i("source",{src:U,type:a})]},le),B?.map((re,te)=>i(qd,{...re},te))]})});Qr.displayName="VideoWithStickers";var sp=({children:e,className:t,maxHeight:o})=>{let n=c`
    ${o?`max-height: ${o}px;`:""}
    width: 100%;
    & > svg {
      /* Scaling the SVG */
      width: 100%;
    }
  `;return i("div",{className:h(n,t),children:x("svg",{viewBox:"0 0 654 366",width:"654",height:"366",fill:"none",xmlns:"http://www.w3.org/2000/svg","data-testid":"laptop-wrapper",children:[i("g",{filter:"url(#J)",fillRule:"evenodd",children:i("path",{d:`M95.626 1.127L104.459 1h444.227l8.834.127c9.637.157 17.141 7.735 
          17.096 17.253.045-.115.285 5.943.285 8.833v292.992c0 1.781-.092 4.779-.172 
          6.782-.05 1.237-.152 3.513-.238 4.224-1.023 8.479-8.201 14.964-16.971 
          14.923.086.045-5.974.285-8.834.285H104.459c-2.861 0-8.92-.24-8.833-.285
          -8.359.039-15.272-5.851-16.788-13.745-.208-1.083-.314-2.203-.309-3.351
          -.045.114-.285-5.944-.285-8.833V27.214c0-2.876.24-8.948.285-8.833-.045-9.518 
          7.591-17.299 17.097-17.253z`,fill:"#303030"})}),i("g",{filter:"url(#L)",fillRule:"evenodd",children:i("path",{d:`M572.337 27.499l-.285-8.833c.045-7.935-6.31-14.449-14.247-14.404
          -1.411-.051-6.09-.127-8.834-.127H104.459c-2.752 0-6.258.083-8.833.127
          -7.937-.045-14.292 6.469-14.247 14.404-.057.246-.285 6.117-.285 8.833V322.12c0 
          .889.037 2.314.088 3.582.059 1.457.223 3.895.304 4.478.768 5.534 5.499 9.421 
          11.29 9.321-.039.112 4.331.285 6.269.285h454.77c2.043 0 6.421-.173 6.554-.285 
          6.229.11 11.335-4.713 11.398-11.112-.06.036.112-4.348 0-6.269l.57-294.621z`,fill:"#272727"})}),x("g",{fillRule:"evenodd",children:[i("path",{d:`M574.988 216.885v103.069l-.144 6.217-.393 5.834c-1.491 7.885-8.427 
          13.848-16.758 13.848l-8.884.24H104.133c-2.82 0-8.879-.24-8.879-.24-8.499 0
          -15.286-6.207-16.53-14.328-.135-.879-.445-9.574-.445-11.552v-103.05l496.709
          -.038z`,fill:"url(#O)",fillOpacity:".03"}),i("path",{d:`M93.346 24.365h466.453c.355 0 .57.215.57.569v291.203a.52.52 0 0 1
          -.57.569H93.346a.52.52 0 0 1-.57-.569V24.934c0-.355.215-.569.57-.569z`,fill:"#111112"}),i("path",{d:`M272.029 350.802H100.508l-37.081-.284c-33.91.284-43.031-3.773-43.026
          -4.748v-1.425h252.054l107.667.096h252.054v1.424c.004.976-9.117 5.033-43.027 
          4.749-.622.019-37.081.284-37.081.284H380.546l-108.517-.096z`,fill:"#1c1b1b"})]}),i("path",{d:`M21.255 336.082H631.32c.532 0 .855.313.855.57v9.118c0 .256-.323.57
        -.855.57H21.255c-.532 0-.855-.314-.855-.57v-9.118c0-.257.322-.57.855-.57z`,fill:"#1d1c1c",fillRule:"evenodd"}),i("foreignObject",{x:"92",y:"24",width:"468",height:"293",requiredFeatures:"http://www.w3.org/TR/SVG11/feature#Extensibility",children:e}),x("defs",{children:[x("filter",{id:"J",x:"77.244",y:"0",width:"498.657",height:"347.42",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB",children:[i("feGaussianBlur",{stdDeviation:".5"}),i("feBlend",{in:"SourceGraphic",result:"C"}),i("feColorMatrix",{in:"SourceAlpha",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"D"}),i("feGaussianBlur",{stdDeviation:"1.5"}),i("feComposite",{in2:"D",operator:"arithmetic",k2:"-1",k3:"1"}),i("feBlend",{in2:"C"})]}),x("filter",{id:"L",x:"79.093",y:"2.134",width:"495.243",height:"339.652",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB",children:[i("feBlend",{in:"SourceGraphic",result:"C"}),i("feColorMatrix",{in:"SourceAlpha",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"D"}),i("feGaussianBlur",{stdDeviation:"2"}),i("feComposite",{in2:"D",operator:"arithmetic",k2:"-1",k3:"1"}),i("feBlend",{in2:"C",result:"E"}),i("feColorMatrix",{values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"}),i("feBlend",{in2:"E"})]}),x("linearGradient",{id:"O",x1:"111.017",y1:"227.897",x2:"111.017",y2:"340.072",gradientUnits:"userSpaceOnUse",children:[i("stop",{stopOpacity:".01"}),i("stop",{offset:"1"})]})]})]})})};sp.displayName="LaptopWrapper";var hT=c`
  display: block;
  object-fit: cover;
`,us=c`
  ${hT}
  border-width: ${r("--media-border-width")};
  border-radius: ${r("--media-border-radius")};
  border-color: ${r("--media-border-color")};
  border-style: solid;
  height: auto;
  margin: auto;
  max-width: 100%;
  overflow: hidden;
  width: auto;
`,ys=c`
  ${hT}
  height: 100%;
  width: 100%;
`,Yd=c`
  ${ys}
  object-fit: contain;
`,Xd=c`
  ${us}
  object-fit: contain;
`,Jd=ys,Zd=us,eu=c`
  ${N} {
    margin-top: 0;
  }
  ${Ht} {
    margin-top: 0;
  }
`,tu=c`
  position: fixed;
`,ou=c`
  width: 297px;
  height: 550px;
`,nu=c`
  border-radius: ${r("--media-border-radius")};
`,ms=c`
  box-shadow: ${r("--box-shadow-xl")};
  border-radius: ${r("--media-border-radius")};
`,ru=c`
  display: flex;
  justify-content: center;
`,CT=c`
  width: 100%;
  height: 100%;
`;var BQ=c`
  display: flex;
  justify-content: center;
`,$Q=c`
  background-image: url('https://images.ctfassets.net/kp51zybwznx4/5MBQ096OLy837zpHXtGsIa/0b35a1eadad459a767f935297483854c/iPhone.png');
  width: 250px;
  height: 530px;
  background-size: 100%;
  background-repeat: no-repeat;
  position: relative;
  margin-bottom: 20px;
  padding: 14px;
`,lp=({children:e})=>i("div",{className:h("phone-wrapper",BQ),"data-testid":"phone-wrapper",children:i("div",{className:$Q,children:e})});lp.displayName="PhoneWrapper";var bb="sdsm-media-wrapper",Ke=(0,gs.forwardRef)((e,t)=>{let{className:o,altText:n,imageSource:a,maxHeight:s,maxWidth:l,videoSource:p,mobileVideoSource:d,sourceType:u,mobileSourceType:y,wrap:m=xt.None,showVideoControls:g=!1,autoplay:f=!g,posterSource:b,onPlay:S,onPause:C,captionsSource:v,isBackgroundVideo:k,onTimeUpdate:I,imgSrcs:A,dataset:D,height:B,width:M,isDraggable:_}=e;Y("sdsm-media");let P=null,{getLowEntropyHints:$}=(0,gs.useContext)(Ze),R=(0,gs.useRef)(null),L=$(),Z=!!(L.platform==="macOS"&&L.browsers.find(le=>le.brand==="Safari"))&&m===xt.Phone,U=m===xt.Laptop||m===xt.Phone,de={maxHeight:s&&!U?`${s}px`:void 0,maxWidth:l&&!U?`${l}px`:void 0};if(a||A){let le=h({[ys]:U,[us]:!U,[nu]:m===xt.Phone,[ms]:m===xt.Shadow},o);A?P=i(et,{className:"sdsm-media",imgSrcs:A,altText:n,imgClassName:le,style:de,dataset:D,height:B,width:M,isDraggable:_}):a&&(P=i(et,{className:"sdsm-media",altText:n,imgClassName:le,style:de,defaultSrc:a,dataset:D,height:B,width:M,isDraggable:_}))}else if(p){let le=k?Jd:Yd,re=k?Zd:Xd,te=h({[eu]:m===xt.Phone,[le]:U,[ou]:m===xt.Phone&&Z,[re]:!U,[ms]:m===xt.Shadow},o);P=i(yi,{source:p,mobileSource:d,sourceType:u,mobileSourceType:y,altText:n,className:h("sdsm-media",te),style:de,autoPlay:f,playsInline:!g,loop:!g,muted:!g,controls:g,posterSource:b,onPlay:S,onPause:C,captionsSource:v,onTimeUpdate:I,isBackgroundVideo:k,dataset:D,ref:_a(R,t)},p),Z&&(P=i("div",{"data-testid":"sdsm-media-safari-wrapper",className:tu,children:P}))}else return null;return m===xt.Laptop?i(sp,{className:bb,maxHeight:s,children:P}):m===xt.Phone?i(lp,{className:bb,maxHeight:s,children:P}):i("div",{className:h(bb,ru),"data-testid":"no-device-wrapper",children:P})});Ke.displayName="Media";var bs=T(w());var fs="sdsm-media-wrapper",xn=(0,bs.forwardRef)((e,t)=>{let{className:o,mediaClassName:n,altText:a,imageSource:s,maxHeight:l,maxWidth:p,videoSource:d,mobileVideoSource:u,sourceType:y,mobileSourceType:m,wrap:g=xt.None,showVideoControls:f=!1,autoplay:b=!f,posterSource:S,onPlay:C,onPause:v,captionsSource:k,isBackgroundVideo:I,onTimeUpdate:A,imgSrcs:D,dataset:B,height:M,width:_,isDraggable:P,stickers:$}=e;Y("sdsm-media");let R=null,{getLowEntropyHints:L}=(0,bs.useContext)(Ze),G=(0,bs.useRef)(null),Z=L(),de=!!(Z.platform==="macOS"&&Z.browsers.find(te=>te.brand==="Safari"))&&g===xt.Phone,le=g===xt.Laptop||g===xt.Phone,re={maxHeight:l&&!le?`${l}px`:void 0,maxWidth:p&&!le?`${p}px`:void 0};if(s||D){let te=h({[ys]:le,[us]:!le,[nu]:g===xt.Phone,[ms]:g===xt.Shadow},n);D?R=i(Vn,{className:h("sdsm-media",o,{[CT]:le}),imgSrcs:D,altText:a,imgClassName:te,style:re,dataset:B,height:M,width:_,isDraggable:P,stickers:le?void 0:$}):s&&(R=i(Vn,{className:h("sdsm-media",o),altText:a,imgClassName:te,style:re,defaultSrc:s,dataset:B,height:M,width:_,isDraggable:P,stickers:le?void 0:$}))}else if(d){let te=I?Jd:Yd,ae=I?Zd:Xd,oe=h({[eu]:g===xt.Phone,[te]:le,[ou]:g===xt.Phone&&de,[ae]:!le,[ms]:g===xt.Shadow},n);R=i(Qr,{source:d,mobileSource:u,sourceType:y,mobileSourceType:m,altText:a,className:h("sdsm-media",o),videoClassName:oe,style:re,autoPlay:b,playsInline:!f,loop:!f,muted:!f,controls:f,posterSource:S,onPlay:C,onPause:v,captionsSource:k,onTimeUpdate:A,isBackgroundVideo:I,dataset:B,ref:_a(G,t),stickers:le?void 0:$},d),de&&(R=i("div",{"data-testid":"sdsm-media-safari-wrapper",className:tu,children:R}))}else return null;return g===xt.Laptop?i(sp,{className:fs,maxHeight:l,children:R}):g===xt.Phone?i(lp,{className:fs,maxHeight:l,children:R}):i("div",{className:h(fs,ru),"data-testid":"no-device-wrapper",children:R})});xn.displayName="MediaWithStickers";var cr=T(w());var hs=T(w());var xT=$r({min:dt}),vT=c`
  align-items: center;
  display: flex;
  gap: ${48}px;
  margin: 0 auto;
  max-width: ${dt}px;
  padding: 0 ${48}px ${64}px;
  width: 100%;
`,IT=c`
  flex-direction: row-reverse;
`,kT=c`
  max-width: 50%;
  width: 50%;

  ${xT} {
    flex: 1;
    max-width: none;
    width: auto;
  }
`,MT=c`
  max-width: 50%;
  width: 50%;

  ${xT} {
    /* This width value is specified in the designs. The accordion will fill the remaining horizontal space. */
    max-width: 416px;
    min-width: 416px;
    width: 416px;
  }
`,TT=c`
  margin-bottom: ${32}px;
  padding-inline-start: ${16}px;
  position: relative;

  &:last-child {
    margin-bottom: 0;
  }
`,AT=c`
  scroll-margin: 40px;
  overflow-y: hidden;
  overflow-x: auto;
`,_T=c`
  color: ${r("--animated-accordion-body-color")};
  font-size: ${r("--animated-accordion-body-desktop-font-size")};
  font-weight: ${r("--animated-accordion-body-desktop-font-weight")};
  letter-spacing: ${r("--animated-accordion-body-desktop-font-letter-spacing")};
  line-height: ${r("--animated-accordion-body-desktop-font-line-height")};

  /* Restrict height of content when not active to prevent initial flash
     of items appearing open without visibility due to functionality of
     the underlying 'DetailSummary' component from SDS-M.
  */
  max-height: 0;
`,wT=c`
  max-height: none;
  padding-top: ${16}px;
`,DT=c`
  align-items: center;
  cursor: pointer;
  display: flex;
  font-size: ${r("--animated-accordion-title-desktop-font-size")};
  font-weight: ${r("--animated-accordion-title-desktop-font-weight")};
  justify-content: space-between;
  letter-spacing: ${r("--animated-accordion-title-desktop-font-letter-spacing")};
  line-height: ${r("--animated-accordion-title-desktop-font-line-height")};
  margin: 0;
  user-select: none;
`,PT=c`
  background: ${r("--animated-accordion-progress-indicator-track-desktop-color")};
  border-radius: ${r("--animated-accordion-progress-indicator-desktop-border-radius")};
  height: 100%;
  inset-block-start: 0;
  inset-inline-start: 0;
  overflow: hidden;
  position: absolute;
  width: ${r("--animated-accordion-progress-indicator-desktop-width")};
`,NT=c`
  background: ${r("--animated-accordion-progress-indicator-bar-desktop-color")};
  width: 100%;
  height: 100%;
  transform-origin: center top;
  transform: scaleY(0);
`,ET=c`
  padding-top: 100%;
  position: relative;
  width: 100%;
`,RT=c`
  height: 100%;
  left: 50%;
  object-fit: contain;
  opacity: 0;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  transition: opacity 0.2s linear;
  width: 100%;
`,FT=c`
  opacity: 1;
`;var BT=({durationMs:e,isActive:t,isPaused:o,onAnimationComplete:n})=>{let a=(0,hs.useRef)(null),s=(0,hs.useRef)();return(0,hs.useEffect)(()=>{a.current&&(s.current=a.current.animate([{transform:"scaleY(0)"},{transform:"scaleY(1)"}],{duration:e,iterations:1,fill:"forwards"}),s.current.pause())},[]),(0,hs.useEffect)(()=>{s.current&&(t?o?s.current.pause():(s.current.play(),s.current.onfinish=()=>n?.()):(s.current.pause(),s.current.currentTime=0))},[o,t,n]),i("div",{className:PT,children:i("div",{ref:a,className:NT})})};var Sb={duration:400,easing:"ease-out"},$T=({isOpen:e,isPaused:t,progressIndicatorDurationMs:o,title:n,body:a,onToggle:s,onMouseOver:l,onMouseLeave:p,onAnimationComplete:d})=>{let u=(0,cr.useRef)(null),y=(0,cr.useRef)(null),m=(0,cr.useRef)(null),[g,f]=(0,cr.useState)(!1),[b,S]=(0,cr.useState)(!1),C=(0,cr.useCallback)(()=>{if(!u?.current||!y?.current)return;f(!0),u.current.style.overflow="hidden";let I=`${u.current.offsetHeight}px`,A=`${y.current.offsetHeight}px`;m.current&&m.current.cancel(),m.current=u.current.animate?.({height:[I,A]},Sb),m.current?.finished?.then(()=>k(!1)).catch(()=>f(!1))},[]),v=(0,cr.useCallback)(()=>{if(!u.current||!y.current)return;S(!0),u.current.style.height=`${u.current.offsetHeight}px`,u.current.style.overflow="hidden",u.current.open=!0;let I=`${u.current.offsetHeight}px`,A=`${u.current.scrollHeight}px`;m.current&&m.current.cancel(),m.current=u.current.animate?.({height:[I,A]},Sb),m.current?.finished.then(()=>k(!0)).catch(()=>S(!1))},[]),k=I=>{u.current&&(u.current.open=I,u.current.style.height="",u.current.style.overflow="",m.current=null,S(!1),f(!1))};return Br(()=>{u.current&&e!==u.current.open&&(u.current.open=e)},[]),Br(()=>{window.requestAnimationFrame(e?v:C)},[e,v,C]),x("div",{className:TT,onMouseOver:l,onFocus:l,onMouseLeave:p,onBlur:p,children:[i(BT,{durationMs:o,isActive:e,isPaused:t,onAnimationComplete:d}),i(ln,{disableScrollToOnOpen:!0,detailsRef:u,summaryRef:y,summary:n,showChevron:!1,className:AT,onToggle:s,summaryProps:{className:DT},transitionDurationMs:Sb.duration,open:e,children:i("div",{className:h(_T,{[wT]:e||b||g}),children:a})})]})};var LT=({items:e=[],mediaDirection:t,autoPlaySpeedMs:o,onItemSelect:n})=>{let a=e.length>1,s=(0,wa.useRef)(null),l=Wd(s),[p,d]=(0,wa.useState)(-1),[u,y]=(0,wa.useState)(!0),m=()=>{d(g=>g>=e.length-1?0:g+1)};return(0,wa.useEffect)(()=>{a&&y(!1),d(0)},[a,y,d]),(0,wa.useEffect)(()=>{a&&y(!l)},[l,a,y]),x("div",{className:h(vT,{[IT]:t==="Start"}),children:[i("div",{ref:s,className:kT,children:e.map((g,f)=>i($T,{isOpen:f===p,isPaused:u||f!==p,progressIndicatorDurationMs:o,title:g.title,body:g.body,onToggle:()=>{f===p||!a||(y(!1),d(f),n?.(f))},onMouseOver:()=>{f!==p||!a||y(!0)},onMouseLeave:()=>{f!==p||!a||y(!1)},onAnimationComplete:m},`${g.title}${f}`))}),i("div",{className:MT,children:i("div",{className:ET,children:e.map((g,f)=>i(Ke,{className:h(RT,{[FT]:f===p}),imgSrcs:g.imgSrcs,altText:g.imageAltText},`${g.title}${f}`))})})]})};var vn=T(w());var Cs=T(w());var hb="--item-min-height",Cb="32px",HT=c`
  text-align: start;
`,VT=c`
  text-align: center;
`,OT=c`
  text-align: end;
`,GT=c`
  display: none;
`,xb=c`
  animation: fade-in 1s;

  @keyframes fade-in {
    from {
      opacity: 0.4;
    }
    to {
      opacity: 1;
    }
  }
`,zT=c`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-l")};
  margin-block: ${r("--spacing-m")};
  min-height: var(${hb});

  &.dragging {
    a {
      pointer-events: none;
    }
  }
`,UT=c`
  aspect-ratio: 3/2;
  position: relative;
  width: 100%;
`,WT=c`
  height: 100%;
  left: 50%;
  object-fit: contain;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  transition: opacity 0.2s linear;
  width: 100%;
`,QT=c`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  gap: ${r("--spacing-xs")};
  justify-content: center;
  overflow: hidden;
`,qT=c`
  align-items: center;
  display: flex;
  justify-content: center;
`,KT=c`
  align-items: center;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-xs")};
  justify-content: center;
  padding: 0 ${r("--spacing-s")};
`,jT=c`
  background: ${r("--animated-accordion-progress-indicator-track-mobile-color")};
  border-radius: ${r("--animated-accordion-progress-indicator-mobile-border-radius")};
  height: ${r("--animated-accordion-progress-indicator-mobile-height")};
  inset-block-start: 0;
  inset-inline-start: 0;
  overflow: hidden;
  width: ${Cb};
`,YT=c`
  background: ${r("--animated-accordion-progress-indicator-bar-mobile-color")};
  border-radius: ${r("--animated-accordion-progress-indicator-mobile-border-radius")};
  height: 100%;
  transform-origin: center left;
  width: 100%;
`,XT=c`
  align-items: center;
  display: flex;
  gap: ${r("--spacing-xs")};
  justify-content: center;
  padding: ${r("--spacing-m")} ${r("--spacing-s")};
`,JT=c`
  align-items: center;
  background: ${r("--animated-accordion-progress-indicator-track-mobile-color")};
  border-radius: ${r("--animated-accordion-dot-border-radius")};
  display: flex;
  height: ${r("--animated-accordion-dot-height")};
  justify-content: flex-end;
  width: ${r("--animated-accordion-dot-width")};
`,ZT=c`
  align-items: center;
  background: ${r("--animated-accordion-nav-button-bg-color")};
  border-radius: ${r("--animated-accordion-nav-button-border-radius")};
  cursor: pointer;
  display: flex;
  gap: ${r("--spacing-xs")};
  height: ${r("--spacing-xxl")};
  justify-content: center;
  padding: ${r("--spacing-s")};
  width: ${r("--spacing-xxl")};

  &:hover {
    background: ${r("--animated-accordion-nav-button-hover-bg-color")};
  }
`,eA=c`
  align-items: flex-start;
  align-self: stretch;
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-m")};
`,tA=c`
  align-self: stretch;

  && {
    font-size: ${r("--animated-accordion-title-mobile-font-size")};
    font-weight: ${r("--animated-accordion-title-mobile-font-weight")};
    letter-spacing: ${r("--animated-accordion-title-mobile-font-letter-spacing")};
    line-height: ${r("--animated-accordion-title-mobile-font-line-height")};
    margin: 0;
    padding: 0;
  }
`,oA=c`
  align-self: stretch;
  color: ${r("--animated-accordion-body-color")};
  font-size: ${r("--animated-accordion-body-mobile-font-size")};
  font-weight: ${r("--animated-accordion-body-mobile-font-weight")};
  letter-spacing: ${r("--animated-accordion-body-mobile-font-letter-spacing")};
  line-height: ${r("--animated-accordion-body-mobile-font-line-height")};
  padding-bottom: auto;
`;var nA=({durationMs:e,isActive:t,isPaused:o,onAnimationComplete:n})=>{let a=(0,Cs.useRef)(null),s=(0,Cs.useRef)();return(0,Cs.useEffect)(()=>{a.current&&(s.current=a.current.animate([{translate:`-${Cb}`},{translate:"0"}],{duration:e,iterations:1,fill:"forwards"}),s.current.pause())},[]),(0,Cs.useEffect)(()=>{s.current&&(t?o?s.current.pause():(s.current.play(),s.current.onfinish=()=>n?.()):(s.current.pause(),s.current.currentTime=0))},[o,t,n]),i("div",{className:jT,children:i("div",{ref:a,className:YT})})};var rA=e=>{let{currentItemIndex:t,durationMs:o=7e3,isActive:n,isPaused:a,itemsCount:s,onAnimationComplete:l,onPause:p}=e;return x("div",{className:QT,children:[i("div",{className:qT,children:Array.from({length:s}).map((d,u)=>t===u?i("div",{className:KT,children:i(nA,{durationMs:o,isActive:n,isPaused:a,onAnimationComplete:l})},u):i("div",{className:XT,children:i("div",{className:JT})},u))}),i("button",{className:ZT,onClick:()=>p(),children:a?i(Wk,{}):i(Uk,{})})]})};var aA=e=>{let{items:t,textAlignment:o="Start",onItemSelect:n}=e,a=t.length>1,s=(0,vn.useRef)([]),[l,p]=(0,vn.useState)(-1),[d,u]=(0,vn.useState)(!0),[y,m]=(0,vn.useState)(0),[g,f]=(0,vn.useState)(!1),[b,S]=(0,vn.useState)(0),[C,v]=(0,vn.useState)(0),k=C>0,I=()=>{p($=>$>=t.length-1?0:$+1)};(0,vn.useEffect)(()=>{a&&u(!1),p(0)},[a]);let A=$=>{m($.touches[0]?.clientX),f(!0)},D=$=>{if(y===null||!g)return;let L=$.touches[0]?.clientX-y;S(L)},B=()=>{if(y===null)return;Math.abs(b)>50&&(b>0?_():M()),f(!1),S(0),m(null)},M=()=>{p($=>{let R=($+1)%t.length;return n?.(R),R})},_=()=>{p($=>{let R=$===0?t.length-1:$-1;return n?.(R),R})};(0,vn.useEffect)(()=>{if(!k&&a){let $=s.current.map(R=>R.clientHeight);v(Math.max(...$))}},[a,k,C]);let P={[hb]:`${C}px`};return i("div",{onTouchStart:A,onTouchMove:D,onTouchEnd:B,style:P,children:t?.map(($,R)=>x("div",{className:h(zT,{[HT]:o===ie.Start,[VT]:o===ie.Center,[OT]:o===ie.End,[GT]:a&&R!==l&&k}),ref:L=>{s.current[R]=L},onClick:()=>u(!d),children:[i("div",{className:h(UT,xb),children:i(Ke,{className:WT,imgSrcs:$.imgSrcs,altText:$.imageAltText})}),a&&i(rA,{currentItemIndex:R,isActive:R===l&&b===0,isPaused:d,itemsCount:t.length,onPause:()=>u(!d),onAnimationComplete:I}),x("div",{className:h(eA,xb),children:[i("h6",{className:tA,children:$.title}),i("section",{className:oA,children:$.body})]})]},R))})};var iA=e=>{Y("sdsm-animated-accordion");let o=Yo()===lt.Mobile,{mediaDirection:n="Start",autoPlaySpeed:a=10,textAlignmentMobile:s=ie.Start,items:l=[],onItemSelect:p}=e;return o?i(aA,{items:l,textAlignment:s,onItemSelect:p}):i(LT,{items:l,mediaDirection:n,autoPlaySpeedMs:a*1e3,onItemSelect:p})};var sA=T(w()),xs,LQ=()=>xs||(xs=new IntersectionObserver(e=>{for(let t of e){let o=t.target;t.isIntersecting&&o instanceof HTMLElement&&(o.style.animationPlayState="running",xs.unobserve(o))}return xs}),xs),HQ=e=>{let t=e.animationName,o=e.delay?`${e.delay}ms`:"",n=e.direction?`${e.direction}`:"normal",a=e.duration?`${e.duration}ms`:"1000ms",s="forwards",l=e.iterationCount??1,p="paused",d=e.timingFunction??"",u=e.transformOrigin??"";return{animation:`${a} ${d} ${o} ${l} ${n} ${s} ${p} ${t}`,transformOrigin:`${u}`}};function au(e,t){if((0,sA.useEffect)(()=>{if(!t)return;let o=LQ(),n=[],a=e.current;if(!a)return;if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){a.style.animationName="",a.style.opacity="1";return}return o.observe(a),n.push(a),()=>{o.unobserve(a)}},[t,e]),!!t)return HQ(t)}var lA=c`
  line-height: ${32}px;
  margin: ${8}px 0;
`,nle=c`
  display: block;
`;var pA=({author:e,date:t})=>!e&&!t?null:x("div",{className:lA,children:[e,e&&t&&i("br",{}),t]});var On=T(w());var vs=T(w());var Da=T(w());var vb="table-with-headers",pp="--column-count",cA=c`
  background-color: ${r("--table-bg-color")};
  border-radius: ${r("--border-radius-s")};
  margin-bottom: ${r("--spacing-m")};
  overflow-x: auto;

  /* Paragraph margins in table cells look like extra padding, so we remove them for tables */
  .${$n.p} {
    margin-bottom: 0;
    overflow-wrap: break-word;
  }
`,dA=c`
  /* Allow table to scroll horizontally on smaller viewpoints */
  border-collapse: collapse;
  display: grid;
  grid-template-columns: repeat(
    var(${pp}),
    minmax(${r("--table-cell-min-width")}, 1fr)
  );
  grid-row-gap: ${r("--table-desktop-row-gap")};
  min-width: ${r("--table-cell-min-width")};
  overflow-x: auto;
  width: 100%;
  padding: ${r("--spacing-m")} 0;

  div[role='cell'] {
    padding: ${r("--table-cell-desktop-padding")};

    &:first-child {
      padding-inline-start: ${r("--table-cell-desktop-inline-edge-padding")};
    }

    &:last-child {
      padding-inline-end: ${r("--table-cell-desktop-inline-edge-padding")};
    }
  }

  &.${vb} {
    padding: unset;
    grid-template-columns: repeat(
      var(${pp}),
      minmax(${r("--table-cell-min-width")}, 1fr)
    );

    div[role='cell'] {
      border-bottom: 1px solid ${r("--table-border-color")};
      padding: ${r("--spacing-m")};

      &:first-child {
        padding-inline-start: ${r("--table-cell-desktop-inline-edge-padding")};
      }

      &:last-child {
        padding-inline-end: ${r("--table-cell-desktop-inline-edge-padding")};
      }

      ${N} {
        &:first-child {
          padding-inline-start: ${r("--table-cell-mobile-inline-edge-padding")};
        }

        &:last-child {
          padding-inline-end: ${r("--table-cell-mobile-inline-edge-padding")};
        }
      }
    }
  }
`,uA=c`
  ${N} {
    overflow-x: scroll;
  }
`,yA=c`
  grid-template-columns:
    minmax(${r("--table-cell-min-width")}, ${r("--table-first-column-max-width")})
    repeat(calc(var(${pp}) - 1), minmax(${r("--table-cell-min-width")}, 1fr));

  /** mobile media query single column layout */
  div[role='cell'] {
    padding: ${r("--table-cell-desktop-padding")};

    &:first-child {
      padding-inline-start: ${r("--table-cell-desktop-inline-edge-padding")};
    }

    &:last-child {
      padding-inline-end: ${r("--table-cell-desktop-inline-edge-padding")};
    }
  }

  ${N} {
    grid-row-gap: ${r("--table-mobile-row-gap")};
    grid-auto-flow: row;
    grid-template-columns: minmax(0, 1fr);
    div[role='row'] {
      display: block;
    }
    div[role='cell'] {
      padding: ${r("--table-cell-mobile-padding")};
      padding-inline-end: ${r("--table-cell-mobile-inline-edge-padding")};
      padding-inline-start: ${r("--table-cell-mobile-inline-edge-padding")};

      &:first-child {
        padding-inline-start: ${r("--table-cell-mobile-inline-edge-padding")};
      }

      &:last-child {
        padding-inline-end: ${r("--table-cell-mobile-inline-edge-padding")};
      }
    }
  }
`,mA=c`
  background-color: ${r("--table-cell-body-bg-color")};
  color: ${r("--table-cell-fg-color")};
`,gA=c`
  background-color: ${r("--table-cell-header-bg-color")};
  border-bottom: 1px solid ${r("--table-border-color")};
  color: ${r("--table-header-fg-color")};
  font-weight: ${r("--table-header-font-weight")};
  padding: ${r("--spacing-m")};

  &:first-child {
    padding-inline-start: ${r("--table-cell-desktop-inline-edge-padding")};
  }

  &:last-child {
    padding-inline-end: ${r("--table-cell-desktop-inline-edge-padding")};
  }

  ${N} {
    &:first-child {
      padding-inline-start: ${r("--table-cell-mobile-inline-edge-padding")};
    }

    &:last-child {
      padding-inline-end: ${r("--table-cell-mobile-inline-edge-padding")};
    }
  }
`,fA=c`
  display: contents;
`;var iu=({children:e})=>i("div",{role:"cell",className:mA,children:e}),cp=({children:e})=>i("div",{role:"columnheader",className:gA,children:e}),su=({children:e})=>i("div",{role:"row",className:fA,children:e});var bA=({children:e,collapseMobileTable:t=!1})=>{Y("sdsm-primitive-table");let n=Da.Children.toArray(e).find(p=>(0,Da.isValidElement)(p)&&p.type===su),a=n?Da.Children.toArray(n.props.children).filter(p=>(0,Da.isValidElement)(p)&&(p.type===cp||p.type===iu)).length:0,s=n?Da.Children.toArray(n.props.children).some(p=>(0,Da.isValidElement)(p)&&p.type===cp):!1,l={[pp]:a};return i("article",{style:l,className:h(cA,"sdsm-primitive-table"),children:i("div",{"aria-label":"Table",role:"table",className:h("sdsm-primitive-table",dA,{[yA]:t&&!s,[vb]:s,[uA]:s&&a>=2||a>=2&&!t}),children:e})})},SA=({children:e})=>i(bA,{collapseMobileTable:!0,children:e}),Ib=bA;var hA=c`
  &.small {
    --size: 28px;
    --icon-size: 24px;
  }
  &.medium {
    --size: 32px;
    --icon-size: 24px;
  }
  &.large {
    --size: 40px;
    --icon-size: 24px;
  }
  &.extra_large {
    --size: 64px;
    --icon-size: 40px;
  }

  /* These are meant to be easily overridable via className prop. */
  width: var(--size);
  height: var(--size);

  cursor: pointer;
  transition: transform 0.2s linear;

  border-radius: 50%;
  box-shadow: ${r("--box-shadow-xs")};

  /* Center */
  display: flex;
  align-items: center;
  justify-content: center;

  --icon-color: ${r("--icon-button-fg-color")};
  background: ${r("--icon-button-bg-color")};
  border: ${r("--icon-button-border-width")} solid ${r("--icon-button-border-color")};

  :hover {
    background: ${r("--icon-button-hover-bg-color")};
    border: ${r("--icon-button-border-width")} solid ${r("--icon-button-hover-border-color")};
    transform: translate(0, -1px);
  }

  :active,
  .active {
    transform: translate(0, 1px);
  }

  :disabled,
  .disabled {
    cursor: not-allowed;
    transform: none;
    --icon-color: ${r("--icon-button-disabled-fg-color")};
    background: ${r("--icon-button-disabled-bg-color")};
    border: ${r("--icon-button-border-width")} solid ${r("--icon-button-disabled-border-color")};
  }

  > .icon {
    width: var(--icon-size);
    height: var(--icon-size);
  }
`;var Mo=(0,vs.forwardRef)((e,t)=>{let{url:o,iconName:n,className:a,iconClassName:s,onClick:l,disabled:p,size:d="medium",...u}=e;Y("sdsm-icon-button");let{Anchor:y}=(0,vs.useContext)(He),m=h("sdsm-icon-button",hA,d,{disabled:p},a),g=i(De,{name:n,size:24,fill:r("--icon-color"),className:h("icon",s)}),f=(0,vs.useCallback)(()=>{p||l?.()},[p,l]);return o?i(y,{href:o,ref:t,className:m,onClick:f,...u,children:g}):i("button",{ref:t,disabled:p,className:m,onClick:f,...u,children:g})});var VQ=400,CA=c`
  align-self: center;
  background-color: ${r("--autocomplete-bg-color")};
  border: ${r("--autocomplete-border-width")} solid ${r("--autocomplete-border-color")};
  border-radius: ${r("--border-radius-l")};
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  height: 52px;
  justify-content: center;
  margin: 0;
  position: relative;
  width: 100%;
  z-index: 20;

  :has(input:hover) {
    border-color: ${r("--autocomplete-hover-border-color")};
    box-shadow: ${r("--autocomplete-hover-box-shadow")};
  }

  :has(input:focus) {
    border-color: ${r("--autocomplete-active-border-color")};
    box-shadow: ${r("--autocomplete-active-box-shadow")};
  }
`,xA=c`
  border-bottom-left-radius: ${r("--border-radius-l")};
  border-bottom-right-radius: ${r("--border-radius-l")};
`,vA=c`
  margin-inline-start: auto;
  max-width: ${VQ}px;
`,IA=c`
  background-color: ${r("--autocomplete-bg-color")};
  border-style: none;
  box-sizing: border-box;
  color: ${r("--autocomplete-fg-color")};
  font-family: ${r("--font-family")};
  font-size: ${r("--autocomplete-mobile-font-size")};
  font-weight: ${r("--autocomplete-mobile-font-weight")};
  margin: ${r("--spacing-m")} 0;
  outline: none;
  padding: 0;
  vertical-align: middle;
  width: 100%;

  *[dir='rtl'] & {
    text-align: right;
  }

  ${H} {
    font-size: ${r("--autocomplete-desktop-font-size")};
    font-weight: ${r("--autocomplete-desktop-font-weight")};
  }
`,kA=e=>c`
    top: 41px;
    /** Because container is absolute positioned when adding a border 1px it was 1px inside of the parent container below fixed */
    left: -1px;
    width: calc(100% + 2px);
    position: absolute;
    list-style: none;
    margin-top: ${r("--spacing-xs")};
    max-height: 175px;
    overflow-y: auto;
    padding-left: 0;
    background: ${Lt.White};
    z-index: 20;
    border: ${r("--border-width-xs")} solid ${r("--palette-black-v150")};
    box-sizing: border-box;
    border-top: 0px;
    border-bottom: ${e?void 0:"0px"};
    border-bottom-right-radius: ${e?`${r("--spacing-s")};`:void 0};
    border-bottom-left-radius: ${e?`${r("--spacing-s")};`:void 0};
    webkit-scrollbar {
      width: 7px;
    }
    webkit-scrollbar-thumb {
      background-clip: padding-box;
      border-right: 2px ${Lt.White} solid;
      background-color: ${r("--palette-gray-v100")};
      border-radius: ${r("--border-radius-s")};
    }
    :before {
      content: '';
      background: ${r("--palette-gray-v100")};
      position: absolute;
      top: 0;
      left: ${r("--spacing-m")};
      height: 1px;
      width: calc(100% - ${r("--spacing-xl")};);
    }
  `,MA=kA(!0),TA=kA(!1),lu=c`
  cursor: pointer;
  padding: ${r("--spacing-s")} ${r("--spacing-xl")};
  margin: 0 ${r("--spacing-m")} 0 ${r("--spacing-m")};
  font-size: 18px;
  color: ${r("--palette-gray-v300")};
  line-height: 20px;
  border-radius: 6px;
  :hover {
    background: ${r("--palette-gray-v100")};
    color: ${r("--palette-black-v150")};
  }
`,AA=c`
  margin-block: ${r("--spacing-m")};
  margin-inline: ${r("--spacing-m")} ${r("--spacing-s")};
  min-width: 20px;
`,_A=c`
  background: transparent;
  border: none;
  color: ${r("--autocomplete-button-fg-color")};
  cursor: pointer;
  font-family: ${r("--font-family")};
  font-size: ${r("--action-mobile-font-size")};
  font-weight: ${r("--action-mobile-font-weight")};
  line-height: ${r("--action-mobile-font-line-height")};
  margin-block: auto;
  margin-inline: ${r("--spacing-s")} ${r("--spacing-m")};
  padding-inline: 0;
  white-space: nowrap;

  :hover,
  :focus {
    color: ${r("--autocomplete-button-fg-hover-color")};
  }

  ${H} {
    font-size: ${r("--action-desktop-font-size")};
    font-weight: ${r("--action-desktop-font-weight")};
    line-height: ${r("--action-desktop-font-line-height")};
    margin: ${r("--spacing-m")};
  }
`,wA=c`
  background: transparent;
  border: ${r("--border-width-xs")} solid ${r("--fg-color")};
  :hover {
    background: transparent;
  }

  /* Overrides for the icon button style */
  box-shadow: none;

  && {
    --icon-size: 16px;
    --icon-color: ${r("--fg-color")};
  }

  /* Overrides for the icon button hover styles */
  @media (hover: hover) {
    &:hover {
      --icon-color: ${r("--global-header-bg-color")};
      background: ${r("--fg-color")};
      border: ${r("--border-width-xs")} solid ${r("--fg-color")};
      transform: none;
    }
  }
`,DA=c`
  align-items: center;
  display: flex;
  height: 52px;

  svg {
    path {
      fill: ${r("--autocomplete-placeholder-color")};
    }
  }
`,PA=c`
  padding: ${r("--spacing-s")} ${r("--spacing-xxl")} ${r("--spacing-l")};
  font-size: ${r("--text-mobile-font-size")};
  line-height: 20px;
  color: ${r("--palette-blue-v200")};
  background: white;
  cursor: pointer;
  /** Because container is absolute positioned when adding a border 1px it was 1px inside of the parent container below fixed */
  left: -1px;
  width: calc(100% + 2px);
  position: absolute;
  top: 224px;
  border: ${r("--border-width-xs")} solid ${r("--palette-black-v150")};
  border-top: 0px;
  border-bottom-right-radius: ${r("--spacing-s")};
  border-bottom-left-radius: ${r("--spacing-s")};
  text-align: start;
  z-index: 20;

  ${H} {
    font-size: ${r("--text-desktop-font-size")};
  }
`;var OQ={background:`${r("--palette-gray-v100")}`,color:`${r("--palette-black-v150")}`};function GQ({term:e,onClick:t,setSelectedIndex:o,isActive:n,listItemStyles:a,resultAccessor:s,loadingAutocompleteTerms:l,loadingMessage:p}){let d=(0,On.useRef)(null);return(0,On.useEffect)(()=>{n&&d.current?.scrollIntoView({behavior:"smooth",block:"nearest",inline:"start"})},[n]),l?i("li",{className:lu,children:p??"Loading..."}):i("li",{className:h(lu,a),ref:d,style:n?OQ:{},onMouseLeave:()=>o(-1),onClick:u=>{u.stopPropagation(),t(e)},children:s?s(e):String(e)},typeof e=="string"?e:s?.(e))}function pu({onSelect:e,onChange:t,onKeyDown:o,onSeeResults:n,onCollapseChange:a,resultAccessor:s,autocompleteResults:l,loadingAutocompleteTerms:p,placeholder:d,cancelMessage:u,loadingMessage:y,seeResultsMessage:m,noResultsMessage:g,initialText:f,containerStyles:b,inputStyles:S,listItemStyles:C,collapsible:v,shortBar:k,disabled:I,hideSuggestions:A,hideCancelButton:D}){Y("sdsm-autocomplete");let[B,M]=(0,On.useState)(f??""),[_,P]=(0,On.useState)(!0),[$,R]=(0,On.useState)(A?!A:!1),[L,G]=(0,On.useState)(-1),Z=(0,On.useRef)(null);(0,On.useEffect)(()=>{_===!1&&Z.current?.focus()},[_]);let U=W=>{A||R(W)},de=W=>{W||U(!1),P(W),v&&a&&a(_)},le=W=>{t(W.target.value),M(W.target.value);let K=W.target.value.trimStart();U(K.length>0),K.length>0&&G(-1)},re=W=>{v&&de(!0),$&&(M(""),G(-1)),e(W)},te=()=>{de(!0),M(""),G(-1)},ae=()=>{v&&de(!0),$&&(M(""),G(-1)),n?.(B)},oe=W=>{let K=l.length;if(W.key==="Escape")U(!1);else if(W.key==="ArrowUp"){let F=Math.max(L-1,0)%K;G(F),W.preventDefault()}else if(W.key==="ArrowDown"){let F=Math.min(L+1,K-1)%K;G(F),W.preventDefault()}else if(W.key==="Enter"){if(l.length>0||A){if(L<0&&n)return ae();L<0?re(l[0]):re(l[L])}G(0)}o?.(W)},q=()=>i("div",{className:l.length===0||p?MA:TA,children:l.length>0?l.map((W,K)=>i(GQ,{term:W,onClick:re,index:K,isActive:L===K,setSelectedIndex:G,listItemStyles:C,resultAccessor:s,loadingAutocompleteTerms:p,loadingMessage:y},typeof W=="string"?W:s?.(W))):i("li",{className:lu,children:g??"No results returned."})});if(v&&_)return i(Mo,{size:"large",iconName:"search",disabled:I,className:wA,onClick:()=>de(!1)});let X=$&&!p&&m&&l.length>0;return x("div",{className:h("sdsm-autocomplete",CA,b,{[xA]:!$,[vA]:k}),onClick:()=>{U(B.length>0),Z.current?.focus()},children:[x("div",{className:DA,children:[i(De,{size:20,className:AA,name:"search"}),i("input",{className:h(IA,S),ref:Z,onChange:le,onKeyDown:oe,value:B,placeholder:d}),v&&!D&&i("button",{onClick:te,className:_A,children:u})]}),$?q():void 0,X?i("button",{onClick:ae,className:PA,children:`${m} "${B}"`}):void 0]})}var $A=T(w());var EA=c`
  padding: 16px 60px;
  font-size: ${r("--banner-font-size")};
  background-color: ${r("--banner-bg-color")};
  color: ${r("--banner-fg-color")};
  min-height: ${50}px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  line-height: ${r("--banner-font-line-height")};
  box-sizing: border-box;

  ${N} {
    padding: 16px 32px 16px 20px;
  }
`,RA=c`
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
`,FA=c`
  width: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  position: absolute;
  right: 0;

  ${N} {
    width: 44px;
  }
`,BA=c`
  background: none;
  border: none;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  /* 44 x 44 for a11y */
  width: 44px;
  height: 44px;

  /* search icon */
  .sds-icon-cross {
    fill: ${r("--banner-fg-color")};
  }
`;var LA=({motifScheme:e,backgroundColor:t,className:o,children:n,contentClassName:a,dataset:s})=>{Y("sdsm-banner");let[l,p]=(0,$A.useState)(!0);if(!l)return null;let d=e??Pe(t)??"sdsm-default";return x("div",{className:h("sdsm-banner",EA,o,d),...ne(s),children:[i("div",{className:h(RA,a),children:n}),i("div",{className:FA,children:i("button",{className:BA,onClick:()=>p(!1),children:i(zk,{size:24})})})]})};var Wb=T(w());var zQ=c`
  margin: auto;
  max-width: ${dt}px;
`,UQ=c`
  ${H} {
    max-width: ${Ck}px;
    width: 80%;
  }
`,WQ=c`
  max-width: ${xk}px;
`,qr=({children:e,className:t,isNarrow:o,widthStyle:n,...a})=>(Y("sdsm-block-boundary"),t=h("sdsm-block-boundary",zQ,{[UQ]:n==="reduced",[WQ]:o||n==="narrow"},t),i("div",{...a,className:t,children:e}));qr.displayName="BlockBoundary";var uu=T(w());var HA=T(w()),at=(0,HA.createContext)({});var cu=(e,t)=>c`
  & > * {
    margin-left: ${t/2}px;
    margin-right: ${t/2}px;
  }

  & > *:first-child {
    margin-left: ${e}px;
    margin-right: ${t/2}px;

    *[dir='rtl'] & {
      margin-right: ${e}px;
      margin-left: ${t/2}px;
    }
  }

  /* stylelint-disable-next-line no-descending-specificity */
  & > *:last-child {
    margin-left: ${t/2}px;
    margin-right: ${e}px;

    *[dir='rtl'] & {
      margin-right: ${t/2}px;
      margin-left: ${e}px;
    }
  }
`,VA=c`
  height: ${64}px;
  max-height: ${64}px;

  /* TODO: this doesnt really show well, and needs to work with subnav/banners. */
  /* box-shadow: ${r("--box-shadow-m")}; */

  color: ${r("--global-header-fg-color")};
  background-color: ${r("--global-header-bg-color")};

  /* Prevent the header from expanding the body to fit its contents. */
  max-width: 100vw;
  overflow-x: clip;
  overflow-y: revert;

  /* Stretch the header to the sides and ensure it's visible. */
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: ${Ee.NAVIGATOR};

  opacity: 1;
  &.hidden {
    opacity: 0;
    transform: translateY(-100%);
  }
  transition: opacity 250ms ease-in, transform 250ms ease-out;
`,kb=r("--spacing-xl"),Mb=r("--spacing-xxxl"),OA=c`
  ${cu(0,16)}
  /* we have less margins with items, but padding is larger */
  padding: 0 ${kb};

  ${Yl} {
    padding: 0 ${Mb};
  }
`,GA=c`
  ${VA}
  /* Prevent the header from expanding the body to fit its contents. */
  max-width: 100vw;
  overflow-x: clip;

  /* Stretch the header to the sides and ensure it's visible. */
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: ${Ee.NAVIGATOR};

  opacity: 1;
  &.hidden {
    opacity: 0;
    transform: translateY(-100%);
  }
  transition: opacity 250ms ease-in, transform 250ms ease-out;
`,zA=c`
  ${VA}
  display: flex;
  align-items: center;
  ${cu(20,16)}
  & > *:first-child,
  & > *:last-child {
    display: flex;
    flex-grow: 1;
    flex-basis: 100px;
  }

  & > *:first-child {
    justify-content: flex-start;
  }

  & > *:last-child {
    justify-content: flex-end;
  }
`,du=c`
  > svg {
    fill: ${r("--global-header-item-color")};
    transition: all 0.15s ease-out;
  }

  &&& {
    background: transparent;
    border: 0;
    box-shadow: none;
    padding: 0 7px; /* Must override the padding on button. */
  }

  &&&:hover {
    border-color: ${r("--global-header-item-hover-color")};

    /* Clearing out styles from the regular button. */
    box-shadow: none;
    transform: none;

    > svg {
      fill: ${r("--global-header-item-hover-color")};
    }
  }
`,UA=c`
  background-color: transparent;
  border: none;
  color: ${r("--fg-color")};
  padding: 4px 8px;
  cursor: pointer;
`,WA=c`
  border-bottom: 1px solid ${r("--global-header-border-color")};
`,QA=c`
  display: flex;
  align-items: center;

  ${cu(0,16)}
`,QQ=c`
  box-shadow: none;
  /* Hack to hide icons in CTAs. */
  i[class^='icon-'],
  img,
  svg {
    display: none;
  }
`,qA=c`
  & > *:not(:first-child) {
    margin-left: 16px;
    *[dir='rtl'] & {
      margin-left: unset;
      margin-right: 16px;
    }
  }

  /* NOTE: Triple specific selector to override button's double-specific styles. */
  & .${"sdsm-button"}.${"sdsm-button"}.${"sdsm-button"} {
    ${QQ}
    font-size: smaller;
    margin-right: 0;
    padding: 4px;
    width: inherit; /* buttons on mobile render full width by default which we don't want here */
    *[dir='rtl'] & {
      margin-right: unset;
      margin-left: 0;
    }
  }
`,dpe=c`
  width: 40px;
  height: 40px;
  border: ${r("--border-width-xs")} solid ${r("--neutral-v300")};
  border-radius: 50%;
  background-color: transparent;
`,KA=c`
  align-items: center;
  display: flex;
  height: ${64}px;
  margin: 0 auto;
  max-height: ${64}px;
  max-width: ${Qt}px;
  padding: 0 40px;
  ${cu(20,16)}

  /* used to make the header take up the full width of the container */
  /* this is needed when users click on the search icon */
  flex-grow: 1;

  /**
   * We are overriding the overflow from globalHeaderCss because of a bug
   * on Safari 16.2. Not sure why this works so this is a bandaid. Ideally we don't do this
   */
  overflow: visible;

  & > nav {
    flex-grow: 1;
    display: flex;
    justify-content: flex-end;
  }

  span {
    font-weight: ${r("--action-desktop-font-weight")};
    font-size: ${r("--action-desktop-font-size")};
    margin: 0 ${r("--spacing-xs")};

    ${N} {
      font-weight: ${r("--action-mobile-font-weight")};
      font-size: ${r("--action-mobile-font-size")};
    }
  }
`,upe=c`
  margin: -7.5px -5px;
`,jA=c`
  span.site-name {
    font-family: ${r("--global-header-site-name-font-family")};
    font-size: ${r("--global-header-site-name-font-size")};
  }
`,YA=c`
  background-color: ${r("--global-header-border-color")};
  bottom: 0;
  height: ${r("--border-width-xs")};
  left: 0;
  margin: auto;
  max-width: calc(${Qt}px - calc(${kb} * 2));
  position: absolute;
  right: 0;
  width: calc(100% - calc(${kb} * 2));

  ${Yl} {
    max-width: calc(${Qt}px - calc(${Mb} * 2));
    width: calc(100% - calc(${Mb} * 2));
  }
`,XA=c`
  position: relative;
`;var qQ=e=>{switch(e){case"left":return"flex-start";case"right":return"flex-end";case"center":return"center"}},Tb=({logo:e,siteName:t,className:o,cta:n,endChildrenClassName:a,localNavDesktop:s,toggleExpanded:l,showNavScreen:p,showGlobalLinks:d=!0,navItemAlignment:u="right",buttonAriaLabel:y,dataset:m,lessMargins:g,addBottomBorder:f,customIcon:b,headerClassName:S})=>i("header",{className:h(GA,jA,o,S),...ne(m),children:x("div",{className:XA,children:[x("div",{className:h(KA,g&&OA),children:[d&&p&&i(Mo,{size:"large",className:h(Hk,du),iconName:b||"dots",onClick:l,"data-testid":Lr.openButton,"aria-label":y}),e,i("span",{className:"site-name",children:t}),i("nav",{style:{justifyContent:qQ(u)},"data-testid":Lr.navItems,children:s}),!!n&&i("aside",{className:a??QA,"data-testid":Lr.endContents,children:n})]}),f&&i("div",{className:YA})]})});Tb.displayName="GlobalHeaderDesktop";var n_=T(w());var JA=c`
  background-color: transparent;
  cursor: pointer;
  display: grid;
  grid-template-columns: repeat(2, 12px);
  grid-template-rows: repeat(2, 12px);
  height: 24px;
  margin: 0;
  max-height: 24px;
  max-width: 24px;
  user-select: none;
  width: 24px;
  transition: transform ${450}ms ease-in-out;

  &.expanded {
    transform: rotate(-180deg);

    .dot {
      animation: dot-animation ${450}ms ease-out forwards;
    }
  }

  &.collapsed {
    transform: rotate(0deg);

    .dot {
      animation: dot-animation-reverse ${450}ms ease-in forwards;
    }
  }

  /* RTL overrides - placed after base rules to satisfy specificity ordering */
  [dir='rtl'] &.expanded {
    transform: rotate(180deg); /* Mirror: rotate clockwise instead of counter-clockwise */
  }

  [dir='rtl'] &.expanded .dot {
    animation: dot-animation-rtl ${450}ms ease-out forwards;
  }

  [dir='rtl'] &.collapsed .dot {
    animation: dot-animation-reverse-rtl ${450}ms ease-in forwards;
  }

  /** Animation for the dots when expanding */
  @keyframes dot-animation {
    0% {
      border-radius: 50%;
      transform: translateX(0) scale(1, 1);
    }
    15% {
      border-radius: 50%;
      transform: translateX(0) scale(1, 1);
    }
    100% {
      border-radius: 0%;
      transform: translateX(4px) scale(2, 0.35);
    }
  }

  @keyframes dot-animation-rtl {
    0% {
      border-radius: 50%;
      transform: translateX(0) scale(1, 1);
    }
    15% {
      border-radius: 50%;
      transform: translateX(0) scale(1, 1);
    }
    100% {
      border-radius: 0%;
      transform: translateX(-4px) scale(2, 0.35);
    }
  }

  /** Animation for the dots when collapsing */
  @keyframes dot-animation-reverse {
    0% {
      border-radius: 0%;
      transform: translateX(4px) scale(2, 0.35);
    }
    85% {
      border-radius: 50%;
      transform: translateX(0) scale(1, 1);
    }
    100% {
      border-radius: 50%;
      transform: translateX(0) scale(1, 1);
    }
  }

  @keyframes dot-animation-reverse-rtl {
    0% {
      border-radius: 0%;
      transform: translateX(-4px) scale(2, 0.35);
    }
    85% {
      border-radius: 50%;
      transform: translateX(0) scale(1, 1);
    }
    100% {
      border-radius: 50%;
      transform: translateX(0) scale(1, 1);
    }
  }
`,dp=c`
  align-items: center;
  display: flex;
  flex-grow: 0;
  flex-shrink: 0;
  justify-content: center;
`,up=c`
  background-color: ${r("--fg-color")};
  border-radius: 50%;
  height: 7px;
  width: 7px;
`,ZA=c`
  rotate: 45deg;

  [dir='rtl'] & {
    rotate: -45deg;
  }
`,e_=c`
  rotate: -45deg;

  [dir='rtl'] & {
    rotate: 45deg;
  }
`,t_=c`
  rotate: 135deg;

  [dir='rtl'] & {
    rotate: -135deg;
  }
`,o_=c`
  rotate: -135deg;

  [dir='rtl'] & {
    rotate: 135deg;
  }
`;var r_=()=>{let{screenState:e}=(0,n_.useContext)(at);return x("div",{className:h(JA,{expanded:e==="turning-on"||e==="on",collapsed:e==="turning-off"}),children:[i("div",{className:dp,children:i("div",{className:h("dot",up,ZA)})}),i("div",{className:dp,children:i("div",{className:h("dot",up,t_)})}),i("div",{className:dp,children:i("div",{className:h("dot",up,e_)})}),i("div",{className:dp,children:i("div",{className:h("dot",up,o_)})})]})};var Kr={navTopLevel:"sdsm-global-nav-screen",closeButton:"sdsm-global-nav-screen-close",navItems:"sdsm-global-nav-screen-items",navHighlights:"sdsm-global-nav-screen-highlights"};var Ab=({logo:e,cta:t,className:o,isExpanded:n,toggleExpanded:a,showNavScreen:s,endChildrenClassName:l,buttonAriaLabel:p,dataset:d,addBottomBorder:u})=>x("header",{className:h(zA,u&&WA,o),...ne(d),children:[s&&i("button",{onClick:a,className:UA,"data-testid":n?Kr.closeButton:Lr.openButton,"aria-label":p,children:i(r_,{})}),e,i("aside",{className:l??qA,"data-testid":Lr.endContents,children:t})]});Ab.displayName="GlobalHeaderMobile";var _b="home",wb=({motifScheme:e,backgroundColor:t,className:o,defaultGroupKey:n,children:a,displayed:s,onToggleExpanded:l,stayOpenInvariant:p,trackingSiteName:d,showNavScreen:u=!0,dataset:y,isUrlCurrent:m,buttonAriaLabel:g,...f})=>{Y("sdsm-header");let b=Yo(),{state:S,toggle:C}=Vd({transitionDurationMs:450,onToggle:(M,_)=>{l&&(M==="turning-on"&&l(!0),M==="off"&&l(!1)),document?.activeElement?.blur()}});(0,uu.useEffect)(()=>C("off"),[b,p]);let[v,k]=(0,uu.useState)(b===lt.Mobile?_b:n??""),I=s??!0,A=h("sdsm-header",e??Pe(t),I?null:"hidden",o);y?.testid||(y={...y,testid:Lr.headerTopLevel});let D=S!=="off",B=b===lt.Mobile?Ab:Tb;return x(at.Provider,{value:{mode:b,groupKey:v,setGroupKey:k,toggleExpanded:C,screenState:S,trackingSiteName:d,isUrlCurrent:m},children:[i(B,{...f,isExpanded:D,toggleExpanded:C,className:A,showNavScreen:u,buttonAriaLabel:g,dataset:y}),D&&u&&a]})};wb.displayName="GlobalHeader";var jr=T(w());var a_=c`
  display: flex;
  justify-content: space-between;

  & > .icon-external-link {
    color: ${r("--global-header-item-color")};
    font-size: 16px;
    vertical-align: middle;
    align-self: center;
  }

  & > a {
    position: relative;
  }

  & a.selected {
    color: ${r("--global-header-item-active-color")};
  }

  padding: 0;
`,i_=c`
  summary.selected {
    color: ${r("--global-header-item-active-color")};
  }
`,s_=c`
  &.icon-external-link {
    color: ${r("--global-header-item-color")};
    font-size: 14px;
    margin: 0 9px;
  }
`,yu=c`
  width: 20px;
  height: 20px;
  fill: ${r("--global-header-item-color")};

  summary.selected > & {
    fill: ${r("--global-header-item-active-color")};
  }
`,Db=c`
  && {
    && {
      color: ${r("--global-header-item-active-color")};
    }
  }
`;var Pb="--children-count",KQ=c`
  overflow: hidden;

  height: 0;
  opacity: 0;

  transition-property: opacity, height;
  transition-duration: ${300}ms;
  transition-timing-function: ease-in;

  details[data-state='on'] &,
  details[data-state='turning-on'] & {
    height: calc(var(${Jl}) * var(${Pb}));
    opacity: 1;

    transition-timing-function: ${ub};
  }
`,mu=c`
  list-style-type: none;
  padding: 0 0 0 16px;
  margin: 0;

  *[dir='rtl'] & {
    padding-left: initial;
    padding-right: 12px;
  }

  ${H} {
    ${KQ}
  }
`,l_=c`
  & > summary {
    color: ${r("--global-header-item-hover-color")};
  }
  &::before {
    visibility: visible;
  }
`,p_=c`
  & > summary {
    color: ${r("--global-header-item-active-color")};
  }

  &::before {
    visibility: visible;
    background-color: ${r("--global-header-indicator-active-color")};
  }
`,c_=c`
  transition: color 0.125s;
  white-space: nowrap;
  scroll-margin: ${ha};

  /* Hide the text that doesn't fit. */
  > summary {
    text-overflow: ellipsis;
    overflow: hidden;
  }

  &:hover,
  &:active,
  &:focus-within,
  [data-state='on'] > summary {
    color: ${r("--global-header-item-hover-color")};
  }

  /** Displays the knob on active and hover in desktop mode only */
  ${H} {
    /* Move the summary over so we can position the knob inside */
    left: ${qf};
    padding-left: ${ha};
    width: calc(${ha} + 100%);

    *[dir='rtl'] & {
      left: unset;
      padding-left: unset;
      right: ${qf};
      padding-right: ${ha};
    }

    &::before {
      content: ' ';
      background-color: ${r("--global-header-indicator-hover-color")};
      position: absolute;
      left: 0;
      top: 10px;
      width: 4px;
      height: 32px;
      border-start-end-radius: ${r("--action-indicator-border-radius")};
      border-end-end-radius: ${r("--action-indicator-border-radius")};
      visibility: hidden;
    }

    *[dir='rtl'] &::before {
      left: unset;
      right: 0;
    }

    &:focus-within::before,
    &:hover::before,
    &:active::before,
    details[data-state='on'] > &::before {
      visibility: visible;
    }
  }
`,d_=c`
  position: relative;
`;var Nb=({navGroupKey:e,title:t,mobileHighlight:o,isActive:n,children:a,onSummaryClick:s})=>{let{groupKey:l,setGroupKey:p,mode:d,screenState:u}=(0,jr.useContext)(at),[y,m]=(0,jr.useState)(l===e);(0,jr.useEffect)(()=>{let S=l===e;if(y===S)return;let C;return S&&u==="on"?C=setTimeout(m.bind(null,S),300):m(S),()=>{C&&clearTimeout(C)}},[l,e]);let g=i("ol",{className:mu,role:"menu",children:jr.Children.map(a,(S,C)=>i("li",{children:S},`list-item-${C}`))}),f=S=>{S==="on"&&p?.(e)},b=d===lt.Mobile;return x(ln,{forceOpenAttribute:b?void 0:!0,showChevron:d===lt.Mobile,onToggle:f,summaryOnClick:s?()=>s():void 0,open:b?void 0:y,summary:t,chevronProps:{className:yu},className:h(Ca,b?void 0:d_,c_,{[l_]:y,[p_]:n}),fadeInAnimation:b,transitionDurationMs:300,"data-testid":`group-${e}`,style:{[Pb]:jr.Children.count(a)},children:[g,b&&o]})};Nb.displayName="GlobalNavGroup";var b_=T(w());var ks="highlight-text",Eb="highlight-text-title",Rb="highlight-text-body",fu="highlight-media-mobile",bu="highlight-media-desktop",Pa="cta",y_=e=>c`
  box-sizing: border-box;

  /* Make the image/video cover the media space. These selectors are deep to account for any wrapper elements. */
  & > .${e} * {
    width: 100%;
    height: 100%;
  }
  & > .${e} img,
  & > .${e} video {
    object-fit: cover;
    border-radius: ${r("--border-radius-l")};
  }

  & > .${fu} img {
    width: 90%;
    margin: 0;
  }
`,m_=c`
  position: relative; /* For positioning the card */
  filter: drop-shadow(0px 0px 32px rgba(0, 0, 0, 0.12)); /* Faint highlight shadow */

  & > .${bu} {
    margin: 0;
    width: 100%;
    height: 100%;
  }

  ${y_(bu)}
`,jQ=c`
  box-sizing: border-box;
  color: ${r("--fg-color")};
  background-color: ${r("--bg-color")};

  padding: 0;
  border-radius: ${r("--border-radius-m")};
  box-shadow: ${r("--box-shadow-m")};
  border: ${r("--border-width-xs")} solid rgb(233, 234, 235);

  & > .${ks} {
    & > .${Eb} {
      color: ${r("--palette-black-v150")};

      font-weight: 500;
      font-size: 18px;
      line-height: 20px;
      white-space: nowrap;

      display: inline-block;

      max-width: 100%;

      overflow: hidden;
      text-overflow: ellipsis;

      /* The line height here is greater than in body, so we move it slightly so the top margin
         looks proportional to the card border. */
      position: relative;
      bottom: 1px;
    }

    & > .${Rb} {
      /* Default <p> sets margin to 1em which is larger than what we want. */
      margin-block-start: 2px;
      margin-block-end: 2px;

      font-size: 12px;
      line-height: 16px;
      font-weight: 400;

      color: ${r("--palette-black-v50")};

      /*
        Properties below work on Webkit AND Gecko. 96% browser support as of 2020-04. Note that vendor
        auto-prefixing does not work here, so '-webkit-' is required.
      */
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 3;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }
`,Fb=65,YQ=16,XQ=c`
  max-width: 500px;
  padding: 16px;

  *[dir='rtl'] & {
    right: unset;
    left: ${Fb}px;
  }

  .${Pa} {
    margin-left: 0;
  }

  *[dir='rtl'] & .${Pa} {
    margin-left: ${YQ}px;
    margin-right: 0;
  }
`,JQ=c`
  width: calc(100% - ${Fb*2}px);

  padding: 16px;

  &,
  & > .${Pa}, & > .${Pa} .${"sdsm-button"} {
    display: flex;
    flex-direction: column;
  }

  & > .${Pa} {
    margin-top: 0;
  }
`,u_=1040,g_=c`
  ${jQ}

  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;

  & > .${ks} {
    min-width: 0;
    max-width: 100%;
  }

  & > .${ks}, & > .${Pa} {
    margin: 0;
  }

  position: absolute;
  right: ${Fb}px;
  bottom: 30px;

  @media screen and (min-width: ${u_}px) {
    ${XQ}
  }

  @media screen and (max-width: ${u_}px) {
    ${JQ}
  }
`,bce=c`
  width: 100%;
  cursor: pointer;
  margin-top: 15px;
  margin-bottom: 50px;

  /**
   * NOTE: These values are important!
   * This first value is the height of the highlight.
   * The second is the height of the highlight description. The content is too tall
   * So we clip it after this size (1-line roughly)
   */
  display: grid;
  grid-template-rows: 40vw 20px;

  & > * {
    user-select: none;
  }

  & > .${ks} {
    font-weight: 400;
    font-size: 14px;
    line-height: 40px;
    margin: 0 12px;
  }

  & > .${fu} {
    border-radius: ${r("--border-radius-m")};
    margin: 0 20px 0 12px;
  }

  [dir='rtl'] & > .${fu} {
    margin: 0 12px 0 20px;
  }

  ${y_(fu)}
`,gu=10,f_=c`
  transition: transform ${500}ms ${db};
  transform: translateY(
    calc(((-100% + ${gu*5}px) * var(--selected-index) + ${gu*3}px))
  );
  height: 100%;

  margin: 0 32px 0 20px;

  *[dir='rtl'] & {
    margin: 0 20px 0 32px;
  }

  & > * {
    margin-top: 0;
    margin-bottom: ${gu*2}px;
    height: calc(100% - ${gu*7}px);
  }
`;var Bb=({background:e,callToAction:t,cardTitleV2:o,cardBodyV2:n,cardTitle:a,cardBody:s})=>x("section",{className:m_,children:[i("figure",{className:bu,children:e}),x("article",{className:h(Pe(Lt.White),g_),children:[x("figcaption",{className:ks,children:[i("label",{className:Eb,children:o??a}),i("p",{className:Rb,children:n??s})]}),i("div",{className:Pa,children:t})]})]});Bb.displayName="GlobalNavHighlightDesktop";var $b=e=>(0,b_.useContext)(at).mode===lt.Mobile?null:i(Bb,{...e});$b.displayName="GlobalNavHighlight";var Na=T(w());var S_=({className:e,highlights:t})=>{let o=(0,Na.useContext)(at),n=o.mode===lt.Mobile,[a,s]=(0,Na.useState)(0),l=Object.fromEntries([...t.entries()].filter(([d,u])=>!!u));if((0,Na.useEffect)(()=>{let u=Object.keys(l).indexOf(o.groupKey??"");u!==-1&&u!==a&&s(u)},[o.groupKey,l,a]),n)return null;let p=c`
    --selected-index: ${a};
  `;return i("section",{className:h(p,f_,e),children:Na.Children.toArray(Object.values(l))})};var gi=T(w());var Su=e=>{if(!e||!lb.test(e))return!1;try{return new URL(e).hostname!==window?.location.hostname}catch{return console.warn(`Unable to parse URL '${e}'. It is invalid.`),!1}};var h_={utm_source:"global_nav",utm_medium:"referral",utm_content:"global_nav_item",utm_campaign:"universal_navigation"},C_=({title:e,children:t,isSelected:o,dataset:n,onToggle:a})=>{let s=(0,gi.useCallback)(()=>{a?.(e)},[a,e]);return i(ln,{summary:e,summaryProps:{className:h({selected:o}),dataset:n},chevronProps:{className:yu},className:h(Ca,i_,{[Db]:o}),summaryOnClick:s,children:i("ol",{className:mu,children:gi.Children.map(t,l=>i("li",{children:l}))})})};C_.displayName="GlobalNavItemWithChildren";var Yr=({title:e,href:t,showExternalIcon:o,children:n,onClick:a,isSelected:s,dataset:l,addTrackingParams:p=!0,onToggle:d})=>{let{Anchor:u}=(0,gi.useContext)(He),{toggleExpanded:y,trackingSiteName:m}=(0,gi.useContext)(at);if(n&&(!Array.isArray(n)||n.length))return i(C_,{title:e,isSelected:s,dataset:l,onToggle:d,children:n});let g=m?{...h_,utm_source:mk(m)}:h_,f=$d(t,g),b=Su(t),S=C=>{a?.(C),!b&&!C.ctrlKey&&(y?.(),setTimeout(()=>window.scrollTo(0,0),500))};return x("div",{className:a_,...ne(l),children:[i(u,{className:h(Ca,{selected:s,[Db]:s}),href:b&&p?f:t,onClick:S,target:b?"_blank":"_self",rel:"noopener",children:e}),o&&b&&i(De,{className:s_,name:"external-link"})]})};Yr.displayName="GlobalNavItem";var __=T(w());var Lb=({backgroundColor:e,thumbColor:t,trackWidth:o})=>c`
  /* Firefox. See developer.mozilla.org/en-US/docs/Web/CSS/CSS_Scrollbars */
  scrollbar-width: ${o};
  scrollbar-color: ${t} ${e};

  /* Edge / Chrome / Safari. See css-tricks.com/custom-scrollbars-in-webkit/ */
  ::-webkit-scrollbar {
    width: ${o};
    background-color: ${e};
  }

  ::-webkit-scrollbar-thumb {
    background-color: ${t};
    border-radius: calc(${o} / 2);
    /* Can't control the width, so we add a border to introduce margin. */
    border: ${r("--border-width-s")} solid ${e};
  }

  ::-webkit-scrollbar-track {
    background-color: ${gk};
  }
`;var Ms=e=>`screen-state-${e}`,I_=c`
  background-color: ${r("--global-header-nav-screen-bg-color")};
  box-sizing: border-box;
  color: ${r("--global-header-nav-screen-fg-color")};
  /* Set font-family here or the var from the default motif is used */
  font-family: ${r("--font-family")};
  left: 0;
  position: fixed;
  top: 0;
  z-index: ${Ee.NAVIGATOR};

  & header {
    height: ${64}px;
    padding: 0 60px;
    display: flex;
    align-items: center;
    background-image: linear-gradient(
      0deg,
      transparent 0,
      ${r("--global-header-nav-screen-bg-color")} ${5}px
    );
    margin-bottom: -${5}px;
    z-index: ${Ee.NAVIGATOR_HEADER};

    &.sticky {
      position: sticky;
      top: 0;
    }
  }
`,gp=e=>`.${Ca} `.repeat(e),ZQ=c`
  & a {
    color: ${r("--global-header-item-color")};
    text-decoration: none;
    position: relative;

    &::after {
      left: 0;
      content: ' ';
      position: absolute;
      bottom: 5px;
      height: 0;
      width: 100%;
      border-bottom: 2px ${r("--global-header-item-hover-color")} solid;

      transition: ease-in-out;
      transition-duration: 100ms;
      opacity: 0;
    }
  }

  & a:hover,
  & a:focus {
    color: ${r("--global-header-item-hover-color")};
  }

  & ${gp(1)} {
    font-size: 26px;
    line-height: 54px;
    font-weight: 600;
    ${Jl}: 36px;
  }

  & ${gp(2)} {
    font-size: 18px;
    line-height: 36px;
    font-weight: 400;
    ${Jl}: 16px;
  }

  & ${gp(3)} {
    font-size: 16px;
    font-weight: 400;
    line-height: 40px;
  }
`,eq=c`
  & a {
    color: ${r("--global-header-item-color")};
    text-decoration: none;
  }
  & a:hover {
    color: ${r("--global-header-item-hover-color")};
  }

  .${Ca} {
    font-size: ${r("--p2-mobile-font-size")};
    font-weight: 500;
    line-height: 40px;
  }

  & ${gp(2)}, & ${gp(3)} {
    font-weight: 400;
  }
`,v_=400,Hb="highlight",tq="no-scroll",hu="left-nav",k_=c`
  ${I_}

  ${zM({duration:`${500}ms`})}
  &.${Ms("on")},
  &.${Ms("turning-on")} {
    ${UM({duration:`${500}ms`})}
  }

  box-sizing: border-box;
  height: 100vh;
  max-height: 100vh;
  max-width: 100vw;
  overflow: hidden;
  width: 100vw;
`,M_=c`
  height: 100%;
  margin: 0 auto;
  max-width: ${Qt}px;
  position: relative;
  width: 100%;

  & > .${hu} {
    height: 100%;
    width: ${v_}px;
    max-height: 100%;
    overflow-y: scroll;
    overflow-x: hidden;

    ${ZQ}

    /* Styling scrollbar */
    ${Lb({thumbColor:r("--global-header-item-color"),backgroundColor:r("--global-header-nav-screen-bg-color"),trackWidth:"10px"})}
  }

  & > .${hu}.${tq} {
    ${Lb({thumbColor:r("--global-header-nav-screen-bg-color"),backgroundColor:r("--global-header-nav-screen-bg-color"),trackWidth:"10px"})}
  }

  & .menu {
    padding: 0px 20px 0px ${ha};
    box-sizing: border-box;
  }

  *[dir='rtl'] & .menu {
    padding: 0px ${ha} 0px 20px;
  }

  & > .${Hb} {
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    width: calc(100% - ${v_}px);
    z-index: ${Ee.NAVIGATOR_HIGHLIGHT};

    *[dir='rtl'] & {
      right: unset;
      left: 0;
    }
  }

  & .close {
    position: relative;
  }
`,T_=c`
  ${I_}
  ${eq}

  ${OM({duration:`${500}ms`,curve:"ease-out"})}

  &.${Ms("turning-off")} {
    ${GM({duration:`${500}ms`,curve:"ease-out"})}
  }

  overflow: hidden scroll;
  display: flex;
  flex-direction: column;

  & > .${Cd} {
    padding: 20px;
    scroll-margin-top: 5px;
  }

  & > .${hd} {
    background-color: ${r("--global-header-nav-screen-global-links-bg-color")};
    color: ${r("--global-header-nav-screen-fg-color")};
    padding: 20px 20px 40px 20px;
    margin-bottom: -20px; /* Pushing background under the gradient in .highlight. */
    flex-grow: 1; /* Pushes the gray background to the bottom for long pages. */
  }

  & hr {
    border-color: ${r("--global-header-menu-col-divider-color")};
    border-style: inset;
    border-width: ${r("--border-width-xs")};
    margin-block-start: ${r("--spacing-m")};
    margin-block-end: ${r("--spacing-m")};
  }

  /* On mobile we show the header regardless, so we display the nav below it. */
  /* NOTE: Reducing so that at 75% zoom a sliver of background doesn't show. */
  top: ${64-.75}px;
  /* On mobile we need to subtract the header size. */
  max-height: calc(100vh - ${64}px);
  height: calc(100vh - ${64}px);
  /* stylelint-disable-next-line declaration-block-no-duplicate-properties */
  max-height: calc(100dvh - ${64}px);
  height: calc(100dvh - ${64}px);

  width: 100vw;
  max-width: 100vw;
`,A_=c`
  font-size: 14px;
  line-height: 40px;
  font-weight: 500;
  display: block;
`;var fp=T(w());var Vb=({className:e,onNavClose:t,highlight:o,globalNav:n,motifScheme:a,backgroundColor:s,screenState:l,dataset:p})=>{let d=(0,fp.useRef)(null),u=(0,fp.useRef)(null);return(0,fp.useEffect)(()=>{l==="on"&&u.current?.focus()},[l]),p?.testid||(p={...p,testid:Kr.navTopLevel}),cs(d.current),i("section",{className:h("sdsm-header",k_,a??Pe(s),e),...ne(p),children:x("div",{className:M_,children:[x("div",{ref:d,className:hu,children:[i("header",{className:"sticky",children:i(Mo,{size:"large",onClick:t,className:du,iconName:"close",ref:u,"data-testid":Kr.closeButton})}),i("nav",{className:"menu","data-testid":Kr.navItems,children:n})]}),i("aside",{className:Hb,"data-testid":Kr.navHighlights,children:o})]})})};Vb.displayName="GlobalNavScreenDesktop";var Cu=T(w());var Ob=({className:e,localNavMobile:t,localNavMobileFooter:o,globalNav:n,globalNavHeading:a,motifScheme:s,backgroundColor:l,showMobileGlobalLinks:p,dataset:d})=>{let u=(0,Cu.useRef)(null),{screenState:y}=(0,Cu.useContext)(at),m=y==="turning-off";cs(u.current,m);let g=()=>x("section",{className:Cd,children:[t,o&&x(pe,{children:[i("hr",{}),o]})]});return d?.testid||(d={...d,testid:Kr.navTopLevel}),x("nav",{ref:u,className:h("sdsm-header",T_,s??Pe(l),e),...ne(d),children:[(t||o)&&i(g,{}),p&&x("section",{className:h(hd,s??Pe(l)),children:[i("label",{className:A_,children:a}),n]})]})};Ob.displayName="GlobalNavScreenMobile";var Gb=e=>{let{screenState:t,mode:o}=(0,__.useContext)(at);return t==="off"?null:o===lt.Mobile?i(Ob,{...e,className:Ms(t),screenState:t}):i(Vb,{...e,className:Ms(t),screenState:t})};Gb.displayName="GlobalNavScreen";var w_=c`
  scroll-margin-top: var(--total-header-height);
`;var zb=c`
  inset: 0;
  /* Prevent overflowing elements from adding extra page width, e.g. background media stickers */
  overflow: hidden;
  position: absolute;
`,Ub=c`
  height: 100%;
  object-fit: cover;
  width: 100%;
`,D_=c`
  /** Relative color syntax decomposes the hex --curtain-color into r g b channels so opacity can be applied dynamically */
  background-color: rgb(from ${r("--curtain-color")} r g b / ${r("--curtain-opacity")});
  backdrop-filter: ${r("--curtain-backdrop-filter")};
  inset: 0;
  position: absolute;
  z-index: ${Ee.BLOCK_CURTAIN};
`,P_=c`
  background-color: ${r("--bg-color")};
`,N_=c`
  position: relative;
  width: 100%;
  background-image: ${r("--bg-image")};
  color: ${r("--fg-color")};

  /** Styles for the background image if it gets set. Legacy */
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
`,E_=c`
  margin-left: auto;
  margin-right: auto;
  width: 100%;
  padding: ${r("--block-boundary-desktop-padding")};
  position: relative;
  z-index: ${Ee.BLOCK_BOUNDARY};

  ${N} {
    padding: ${r("--block-boundary-mobile-padding")};
  }
`,R_=c`
  ${H} {
    padding-block: ${r("--block-boundary-dense-layout-desktop-padding")};
  }
`,F_=c`
  position: relative;
  margin-left: auto;
  margin-right: auto;
  width: 100%;
  max-width: 75%;
  padding: ${r("--block-header-desktop-padding")};

  ${N} {
    max-width: unset;
    padding: ${r("--block-header-mobile-padding")};
  }
`,B_=c`
  color: ${r("--block-eyebrow-color")};
  font-size: 14px;
  font-weight: 500;
  letter-spacing: -0.01em;
  line-height: 20px;
  margin: 0;
  margin-bottom: ${r("--spacing-xs")};
`,$_=c`
  /* Overriding h* tags requires double specificity */
  && {
    color: ${r("--block-title-color")};
    font-size: ${r("--block-title-desktop-font-size")};
    font-stretch: ${r("--block-title-desktop-font-stretch")};
    line-height: ${r("--block-title-desktop-font-line-height")};

    &:has(.${"sdsm-empahasized-text"}) {
      color: ${r("--block-title-de-emphasized-color")};
    }

    ${N} {
      font-size: ${r("--block-title-mobile-font-size")};
      padding: 0;
    }
  }
  margin: 0; /* Resets h* user stylesheet margin. */
`,L_=c`
  color: ${r("--block-subtitle-color")};
  /* Resets h* user stylesheet margin. */
  margin: 0;
  /* The margin between title/subtitle has to be on subtitle so that it collapses when there's only title. */
  margin-top: ${r("--spacing-m")};

  a {
    color: currentColor;
  }
`,H_=c`
  display: flex;
  padding: ${r("--spacing-m")} 0;

  > *:not(:last-child) {
    margin-right: ${r("--spacing-m")};
    margin-left: 0;
  }

  *[dir='rtl'] & > *:not(:last-child) {
    margin-right: 0;
    margin-left: ${r("--spacing-m")};
  }

  ${N} {
    padding: ${r("--spacing-m")};
    flex-direction: column;
    > *:not(:last-child) {
      margin-bottom: ${r("--spacing-m")};
      margin-right: 0;
    }
  }
`,xu=c`
  --column-span: 2;
  display: grid;
  position: relative;
  grid-row-gap: ${r("--spacing-xl")};
  grid-column-gap: ${r("--spacing-xl")};
  padding-left: ${r("--spacing-m")};
  padding-right: ${r("--spacing-m")};
  justify-content: center;

  /* We make every column span 2 in desktop mode so we can half-column align. */
  & > * {
    grid-column: span var(--column-span);
  }

  ${N} {
    grid-template-columns: minmax(0, 1fr);
    grid-row-gap: ${r("--spacing-m")};
    /* NOTE: grid-column-gap same as desktop */
    padding-left: 0;
    padding-right: 0;
    padding-inline: ${r("--spacing-m")};
  }
`,vu=c`
  grid-template-columns: repeat(var(--column-span), minmax(0, 1fr));
`,V_=c`
  ${H} {
    grid-row-gap: ${r("--block-content-dense-layout-desktop-grid-row-gap")};
  }
`,Iu=c`
  /* NOTE: We double the columns so we can do half-column adjustments */
  grid-template-columns: repeat(calc(2 * var(--column-span)), minmax(0, 1fr));

  /* In order to center a case where the last row only has 1 content,
   * We shift the start of the column.
   * Note that we don't do this if there's only 1 row.
   */
  ${H} {
    & > *:not(:first-child):nth-child(2n + 1):last-child {
      grid-column: var(--column-span) / span var(--column-span);
    }
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${uo} {
    grid-template-columns: repeat(var(--column-span), minmax(0, 1fr));

    /* Reset for cases where the screen-based media query is active but the container query is not */
    & > *:not(:first-child):nth-child(2n + 1):last-child {
      grid-column: span var(--column-span);
    }
  }
`,ku=c`
  /* Reduce grid column gap width by 8px on 3 column layout  */
  grid-row-gap: ${r("--spacing-l")};
  grid-column-gap: ${r("--spacing-l")};

  /* NOTE: We double the columns so we can do half-column adjustments */
  grid-template-columns: repeat(calc(3 * var(--column-span)), minmax(0, 1fr));

  /* The case where there are actually 3 columns. */
  ${bn} {
    /* Handle the case where the last child can be in 1st position */
    & > *:not(:first-child):last-child:nth-child(3n + 1) {
      grid-column: calc(1 + var(--column-span)) / span var(--column-span);
    }

    /* When there are 2 children on the last row, we shift over the first one to center both */
    & > *:not(:first-child):nth-child(3n + 1):nth-last-child(2) {
      grid-column: var(--column-span) / span var(--column-span);
    }
  }

  ${vo} {
    grid-template-columns: repeat(calc(2 * var(--column-span)), minmax(0, 1fr));

    ${H} {
      & > *:not(:first-child):nth-child(2n + 1):last-child {
        grid-column: var(--column-span) / span var(--column-span);
      }
    }
  }

  /** TODO: Figure out if we can remove this. */
  ${N} {
    grid-template-columns: repeat(var(--column-span), minmax(0, 1fr));
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${Tk} {
    /* Handle the case where the last child can be in 1st position */
    & > *:not(:first-child):last-child:nth-child(3n + 1) {
      grid-column: calc(1 + var(--column-span)) / span var(--column-span);
    }

    /* When there are 2 children on the last row, we shift over the first one to center both */
    & > *:not(:first-child):nth-child(3n + 1):nth-last-child(2) {
      grid-column: var(--column-span) / span var(--column-span);
    }
  }

  ${ji} {
    grid-template-columns: repeat(calc(2 * var(--column-span)), minmax(0, 1fr));

    /* Reset for cases where the screen-based media query is active but the container query is not */
    & > *:not(:first-child):last-child:nth-child(3n + 1) {
      grid-column: span var(--column-span);
    }

    /* Reset for cases where the screen-based media query is active but the container query is not */
    & > *:not(:first-child):nth-child(3n + 1):nth-last-child(2) {
      grid-column: span var(--column-span);
    }

    ${li} {
      /* Center the last child if the last row only has 1 child */
      & > *:not(:first-child):nth-child(2n + 1):last-child {
        grid-column: var(--column-span) / span var(--column-span);
      }
    }
  }

  ${uo} {
    grid-template-columns: repeat(var(--column-span), minmax(0, 1fr));

    /* Reset for cases where the screen-based media query is active but the container query is not */
    & > *:not(:first-child):nth-child(2n + 1):last-child {
      grid-column: span var(--column-span);
    }
  }
`,O_=c`
  /* Reduce grid column gap width by 8px on 4 column layout  */
  grid-row-gap: ${r("--spacing-l")};
  grid-column-gap: ${r("--spacing-l")};

  /* NOTE: We double the columns so we can do half-column adjustments */
  grid-template-columns: repeat(calc(4 * var(--column-span)), minmax(0, 1fr));

  ${Mk} {
    grid-template-columns: repeat(calc(3 * var(--column-span)), minmax(0, 1fr));
  }

  ${vo} {
    grid-template-columns: repeat(calc(2 * var(--column-span)), minmax(0, 1fr));

    ${H} {
      & > *:not(:first-child):nth-child(2n + 1):last-child {
        grid-column: var(--column-span) / span var(--column-span);
      }
    }
  }

  ${N} {
    grid-template-columns: repeat(var(--column-span), minmax(0, 1fr));
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${fd} {
    grid-template-columns: repeat(calc(3 * var(--column-span)), minmax(0, 1fr));
  }

  ${ji} {
    grid-template-columns: repeat(calc(2 * var(--column-span)), minmax(0, 1fr));

    ${li} {
      /* Center the last child if the last row only has 1 child */
      & > *:not(:first-child):nth-child(2n + 1):last-child {
        grid-column: var(--column-span) / span var(--column-span);
      }
    }
  }

  ${uo} {
    grid-template-columns: repeat(var(--column-span), minmax(0, 1fr));

    /* Reset for cases where the screen-based media query is active but the container query is not */
    & > *:not(:first-child):nth-child(2n + 1):last-child {
      grid-column: span var(--column-span);
    }
  }
`,G_=c`
  min-height: calc(100vh - ${64}px);
  display: flex;
  background-size: cover;
  flex-direction: column;
`;var ao=({showCurtain:e,backgroundVideoSource:t,backgroundPosterSource:o,mobileBackgroundVideoSource:n,backgroundImageSources:a,backgroundImageAltText:s,callsToAction:l,children:p,anchorId:d,maxColumns:u=4,motifScheme:y,backgroundColor:m,eyebrow:g,title:f,subtitle:b,titleAlignment:S=ie.Center,titleAlignmentMobile:C=ie.Start,widthStyle:v="full",fullHeight:k=!1,className:I,style:A,eyebrowDataset:D,titleDataset:B,subtitleDataset:M,preChildren:_,postChildren:P,backgroundMediaStickers:$,denseLayout:R=!1})=>{Y("sdsm-block");let L=!!g||!!f||!!b,G=Wb.Children.toArray(p).length,Z=Wb.Children.count(l);u=Math.max(1,Math.min(G,u));let U=u;v==="reduced"&&U===4&&(U=3),v==="narrow"&&U>=3&&(U=2);let de=$?.map(le=>({...le,size:sr.Large,insetPx:16,className:Qd}));return x("article",{id:d,className:h("sdsm-block",y??Pe(m),N_,w_,{[G_]:k,[P_]:!!y||!!m},I),style:A,children:[_,e&&i("div",{"data-testid":"sdsm-block-curtain",className:D_}),a&&i(Vn,{imgSrcs:a,altText:s,className:zb,imgClassName:Ub,fetchPriority:"auto",stickers:de}),t&&i(Qr,{mobileSource:n,source:t,className:zb,videoClassName:Ub,posterSource:o,isBackgroundVideo:!0,stickers:de}),i(Fd.Provider,{value:y??m,children:x(qr,{"data-testid":"sdsm-block-boundary",widthStyle:v,className:h(E_,{[R_]:R}),children:[L&&x("section",{"data-testid":"sdsm-block-title",className:h(F_,Ta[S],ar[C]),children:[g&&i("div",{className:B_,...ne(D),children:g}),f&&i("h2",{"data-testid":"sdsm-block-title",className:h($_),...ne(B),children:f}),b&&i("div",{"data-testid":"sdsm-block-subtitle",className:h(yo,L_),...ne(M),children:b})]}),p&&i("section",{"data-testid":"sdsm-block-children","data-max-columns":u,className:h(xu,{[vu]:U===1,[Iu]:U===2,[ku]:U===3,[O_]:U===4,[V_]:R&&U===1}),children:p}),Z>0&&i("section",{"data-testid":"sdsm-block-ctas",className:h(Ta[S],ar[C],H_),children:l})]})}),P]})};ao.displayName="Block";var Qb=`
  content: '';
  position: absolute;
  left: calc(-1 * ${r("--side-navigation-left-padding")});
  top: 0;
  height: 100%;
  width: ${r("--spacing-xxs")};
  background: ${r("--side-navigation-indicator-hover-color")};
  border-radius: 0 ${r("--action-indicator-border-radius")} ${r("--action-indicator-border-radius")} 0;
`,To=300,z_=c`
  background-color: ${r("--side-navigation-desktop-bar-bg-color")};
  z-index: ${Ee.SIDENAV};

  ${H} {
    border-inline-end-color: ${r("--side-navigation-desktop-border-color")};
    border-inline-end-style: solid;
    border-inline-end-width: ${r("--side-navigation-desktop-border-width")};
    flex: 0 0 ${To}px;

    & > * {
      position: sticky;
      top: ${64}px;
    }
  }

  ${N} {
    position: sticky;
    top: ${64}px;
    width: 100%;
    box-shadow: ${r("--box-shadow-m")};
  }
`,U_=c`
  ${N} {
    box-shadow: ${r("--box-shadow-xs")};
  }
`,W_=c`
  font-size: ${r("--action-desktop-font-size")};
  line-height: ${r("--action-desktop-font-line-height")};
  padding-block-start: ${r("--spacing-m")};
  padding-inline-start: ${r("--side-navigation-left-padding")};
  padding-inline-end: ${r("--side-navigation-right-padding")};

  ${N} {
    width: auto;
    font-size: ${r("--action-mobile-font-size")};
    line-height: ${r("--action-mobile-font-line-height")};
    background-color: ${r("--side-navigation-mobile-bg-color")};
    padding: ${r("--spacing-s")} ${r("--spacing-xl")};
  }

  & ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  & > ul > li {
    padding-block: ${r("--spacing-m")};
  }

  & > ul > li > ul > li {
    font-size: ${r("--action-desktop-font-size")};
    line-height: ${r("--action-desktop-font-line-height")};
    margin-top: ${r("--spacing-m")};
    margin-inline-start: ${r("--spacing-m")};
    position: relative;

    ${N} {
      font-size: ${r("--action-mobile-font-size")};
      line-height: ${r("--action-mobile-font-line-height")};
    }
  }
`,Q_=c`
  padding: 0;
  font-family: ${r("--font-family")};
  display: flex;
  color: ${r("--side-navigation-desktop-item-color")};
  text-decoration: none;
  font-weight: ${r("--action-desktop-font-weight")};
  background-color: transparent;
  border: 0;
  font-size: ${r("--action-desktop-font-size")};
  line-height: ${r("--action-desktop-font-line-height")};
  text-align: left;
  cursor: pointer;
  width: 100%;
  justify-content: space-between;
  align-items: center;
  min-height: 22px;
  position: relative;

  *[dir='rtl'] & {
    text-align: right;
  }

  :hover {
    color: ${r("--side-navigation-desktop-item-hover-color")};
    &::before {
      ${Qb}
    }
  }

  ${N} {
    font-size: ${r("--action-mobile-font-size")};
    line-height: ${r("--action-mobile-font-line-height")};
    justify-content: space-between;
    color: ${r("--side-navigation-mobile-item-color")};
  }
`,q_=c`
  color: ${r("--side-navigation-desktop-item-hover-color")};
  &::before {
    ${Qb}
  }
`,K_=c`
  color: ${r("--side-navigation-desktop-item-active-color")};

  &::before {
    ${Qb}
    background: ${r("--side-navigation-indicator-active-color")};

    ${N} {
      background: ${r("--side-navigation-indicator-active-color")};
    }
  }

  &:hover {
    color: ${r("--side-navigation-desktop-item-active-color")};
    &::before {
      background: ${r("--side-navigation-indicator-active-color")};
    }
  }

  ${N} {
    color: ${r("--side-navigation-mobile-item-active-color")};
  }
`,j_=c`
  a {
    color: ${r("--side-navigation-desktop-item-color")};
    display: block;
    text-decoration: none;
    font-size: ${r("--action-desktop-font-size")};
    line-height: 140%;

    *[dir='rtl'] & {
      &:before {
        right: calc(-1 * ${r("--spacing-m")});
        border-radius: ${r("--action-indicator-border-radius")} 0 0
          ${r("--action-indicator-border-radius")};
      }
    }

    &:hover {
      color: ${r("--side-navigation-desktop-item-hover-color")};
    }

    ${N} {
      color: ${r("--side-navigation-mobile-item-color")};
    }
  }
`,Y_=c`
  font-size: ${r("--action-desktop-font-size")};

  & svg:first-child {
    width: 22px;
    height: 22px;
    margin: -6px;
  }

  & svg:nth-child(2) {
    display: none;
  }

  & svg:nth-child(3) {
    display: none;
  }

  *[dir='rtl'] & {
    & svg:nth-child(2) {
      display: none;
    }

    & svg:nth-child(3) {
      display: none;
    }
  }
`,X_=c`
  position: relative;
  font-weight: ${r("--action-desktop-font-weight")};

  a,
  a:hover {
    color: ${r("--side-navigation-desktop-item-active-color")};

    ${N} {
      color: ${r("--side-navigation-mobile-item-active-color")};
    }
  }

  *[dir='rtl'] & {
    &:before {
      right: calc(-1 * ${r("--spacing-m")});
      border-radius: ${r("--action-indicator-border-radius")} 0 0
        ${r("--action-indicator-border-radius")};
    }
  }
`,J_=c`
  ${H} {
    display: none;
  }

  ${N} {
    background-color: ${r("--side-navigation-mobile-bar-bg-color")};
    color: ${r("--side-navigation-mobile-bar-fg-color")};
    border: 0;
    padding: 0;
    font: inherit;
    outline: inherit;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-inline: ${r("--spacing-xl")};
    height: 48px;
    margin: auto;

    & > span:first-child {
      font-family: ${r("--font-family")};
      font-size: ${r("--action-mobile-font-size")};
      line-height: ${r("--action-mobile-font-line-height")};
      font-weight: ${r("--action-desktop-font-weight")};
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
  }
`,Mu=c`
  fill: ${r("--side-navigation-desktop-item-color")};
  margin: -4px -12px;

  ${N} {
    fill: ${r("--side-navigation-mobile-item-color")};
  }
`,Z_=c`
  width: 22px;
  height: 22px;
  margin: -6px;
  fill: ${r("--side-navigation-mobile-toggler-icon-color")};
`;var e1=c`
  container-name: ${"sdsm-page"};
  container-type: inline-size;
`,t1=c`
  position: relative;
  width: 100%;
`,o1=c`
  ::before {
    background-color: ${r("--gutter-color")};
    content: '';
    height: 100vh;
    inset: 0;
    position: fixed;
    width: 100vw;
    z-index: -1;
  }
`,n1=c`
  background-color: ${r("--bg-color")};
`,r1=c`
  background-color: transparent;
`;var sue=c`
  background-attachment: fixed;
`,qb=c`
  position: absolute;
  object-fit: cover;
  height: 100%;
  width: 100%;
  z-index: -1;
`,Kb=c`
  object-fit: cover;
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  z-index: -1;
`,lue=c`
  display: flex;
  justify-content: center;

  background-color: ${fa};

  ${N} {
    flex-direction: column;
  }
`,pue=c`
  flex: 0 1 ${dt-To}px;
  min-width: 0px;

  ${N} {
    flex: none;
  }
`;var a1=c`
  height: ${r("--break-total-desktop-height")};
  ${N} {
    height: ${r("--break-total-mobile-height")};
  }
`,oq=c`
  height: ${r("--break-half-desktop-height")};
  ${N} {
    height: ${r("--break-half-mobile-height")};
  }
`,i1=c`
  pointer-events: none;
  position: relative;
  z-index: ${Ee.BREAK};
  ${a1}
`,Ea=c`
  width: 100%;
  height: calc(100% - 2 * ${r("--break-overlap-height")});
  position: relative;
  top: ${r("--break-overlap-height")};
`,s1=c`
  left: 50%;
  max-height: 100%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
`,l1=c`
  margin-top: calc(0px - ${r("--break-total-desktop-height")});

  ${N} {
    margin-top: calc(0px - ${r("--break-total-mobile-height")});
  }
`,p1=c`
  margin-bottom: calc(0px - ${r("--break-total-desktop-height")});

  ${N} {
    margin-bottom: calc(0px - ${r("--break-total-mobile-height")});
  }
`,c1=c`
  margin-top: calc(0px - ${r("--break-half-desktop-height")});

  ${N} {
    margin-top: calc(0px - ${r("--break-half-mobile-height")});
  }
`,d1=c`
  margin-bottom: calc(0px - ${r("--break-half-desktop-height")});

  ${N} {
    margin-bottom: calc(0px - ${r("--break-half-mobile-height")});
  }
`,u1=c`
  pointer-events: none;
  width: 100%;
`,y1=a1,m1=oq,g1=c`
  background-color: ${r("--bg-color")};
`;var f1=e=>{let{topColor:t,bottomColor:o,shadowColor:n,shadowOpacity:a=.2,...s}=e;return x("svg",{width:"1440",height:"96",viewBox:"0 0 1440 96",fill:"none",xmlns:"http://www.w3.org/2000/svg",preserveAspectRatio:"none",role:"presentation",...s,children:[i("defs",{children:x("filter",{id:"break-head-shadow",x:"0",y:"0",width:"100%",height:"96",children:[i("feGaussianBlur",{stdDeviation:"15"}),i("feComposite",{operator:"out",in2:"SourceGraphic"})]})}),i("path",{d:"M1440 0H0L-0.00390625 65C228.186 32.4746 470.064 21 720.555 21C971.045 21 1212.14 32.5811 1439.99 65L1440 0Z",fill:t}),i("path",{d:"M1439.99 43.9999L1440 75C896.804 75.3096 544.733 75 -0.00292327 75L-0.00463491 44C228.185 11.4751 470.065 8.66536e-05 720.555 6.42749e-05C971.044 4.18962e-05 1212.14 11.5812 1439.99 43.9999Z",fill:o,transform:"translate(0 21)"}),i("path",{d:"M1440 0H0L-0.00390625 65C228.186 32.4746 470.064 21 720.555 21C971.045 21 1212.14 32.5811 1439.99 65L1440 0Z",fill:n,opacity:a,filter:"url(#break-head-shadow)"})]})};var b1=e=>{let{topColor:t,bottomColor:o,shadowColor:n,shadowOpacity:a=.2,...s}=e;return x("svg",{width:"1440",height:"96",viewBox:"0 0 1440 96",fill:"none",xmlns:"http://www.w3.org/2000/svg",preserveAspectRatio:"none",role:"presentation",...s,children:[i("defs",{children:x("filter",{id:"break-headflipped-shadow",x:"0",y:"0",width:"100%",height:"96",children:[i("feGaussianBlur",{stdDeviation:"15"}),i("feComposite",{operator:"out",in2:"SourceGraphic"})]})}),i("path",{d:"M1440 0.000128746L4.27734e-06 9.68134e-08C228.19 32.5249 470.07 49.9999 720.56 49.9999C971.05 50 1212.15 32.4188 1440 0.000128746Z",fill:t}),i("path",{d:"M1440 96V0C1212.15 32.4189 971.051 50 720.561 50C470.07 50 228.189 32.5254 0 0V96H1440Z",fill:o}),i("path",{d:"M1440 0.000128746L4.27734e-06 9.68134e-08C228.19 32.5249 470.07 49.9999 720.56 49.9999C971.05 50 1212.15 32.4188 1440 0.000128746Z",fill:n,opacity:a,filter:"url(#break-headflipped-shadow)"})]})};var nq=c`
  align-items: center;
  background-color: ${r("--bg-color")};
  display: flex;
  height: 100%;
  padding: ${r("--spacing-l")} ${r("--spacing-xl")};
  width: 100%;

  ${H} {
    padding: ${r("--spacing-l")} ${r("--spacing-xl")};
  }
  ${Yl} {
    padding: ${r("--spacing-l")} ${r("--spacing-xxxl")};
  }
`,rq=c`
  background-color: ${r("--fg-color")};
  height: 1px;
  width: 100%;
`,S1=()=>i("div",{className:nq,children:i("div",{className:rq})});var h1=e=>{let{topColor:t,bottomColor:o,shadowColor:n,shadowOpacity:a=.2,...s}=e;return x("svg",{width:"1440",height:"96",viewBox:"0 0 1440 96",fill:"none",xmlns:"http://www.w3.org/2000/svg",preserveAspectRatio:"none",role:"presentation",...s,children:[i("defs",{children:x("filter",{id:"break-skirt-shadow",x:"0",y:"0",width:"100%",height:"96",children:[i("feGaussianBlur",{stdDeviation:"15"}),i("feComposite",{operator:"out",in2:"SourceGraphic"})]})}),i("path",{d:"M314.31 27.8046C510.98 21.076 546.9 47.315 818.11 47.9843C935 48.4325 1223.03 39.463 1440 0H0V41.5C27.99 42.3963 117.64 34.5331 314.31 27.8106V27.8046Z",fill:t}),i("path",{d:"M0 96H1440V0C1223.03 39.463 935 48.4325 818.11 47.9843C683.948 47.6532 607.363 41.065 540.415 35.3058C472.026 29.4227 413.692 24.4045 314.31 27.8046V27.8106C204.403 31.5674 127.919 35.6805 76.9403 38.4219C36.6967 40.5861 12.3481 41.8954 0 41.5V96Z",fill:o}),i("path",{d:"M314.31 27.8046C510.98 21.076 546.9 47.315 818.11 47.9843C935 48.4325 1223.03 39.463 1440 0H0V41.5C27.99 42.3963 117.64 34.5331 314.31 27.8106V27.8046Z",fill:n,opacity:a,filter:"url(#break-skirt-shadow)"})]})};var C1=e=>{let{topColor:t,bottomColor:o,shadowColor:n,shadowOpacity:a=.2,...s}=e;return x("svg",{width:"1440",height:"96",viewBox:"0 0 1440 96",fill:"none",xmlns:"http://www.w3.org/2000/svg",preserveAspectRatio:"none",role:"presentation",...s,children:[i("defs",{children:x("filter",{id:"break-skirt2-shadow",x:"0",y:"0",width:"100%",height:"96",children:[i("feGaussianBlur",{stdDeviation:"15"}),i("feComposite",{operator:"out",in2:"SourceGraphic"})]})}),i("path",{d:"M1440 0.0991211H0V50.1971C36.6091 43.6777 77.6641 37.7261 124.249 32.6745C310.648 12.4616 361 13.9746 528.797 31.5909C542.059 32.9831 555.219 35.2322 569.339 37.6453C599.237 42.755 633.435 48.5996 682 48.5996C731.565 48.3254 771.328 42.4257 813.924 36.1058C836.643 32.7351 860.166 29.2449 886.413 26.4248C944.864 20.7107 990.885 16.5365 1031.36 20.9347C1046.21 22.7434 1059.43 25.6192 1070.25 29.3933C1070.84 29.5968 1071.39 29.7913 1071.93 29.9783C1081.36 33.2595 1084.09 34.2084 1094.38 40.0996C1099.5 43.0274 1105.69 45.2946 1115.5 48.5996C1125.27 50.4244 1136.28 50.7567 1148.07 50.5944C1157.61 50.5266 1168.07 50.3572 1179.24 50.1765C1180.84 50.1505 1182.46 50.1243 1184.09 50.0982C1231.43 49.2382 1342.55 51.9494 1381.68 55.0925C1420.82 58.2357 1440 63.0996 1440 63.0996V0.0991211Z",fill:t}),i("path",{d:"M1440 79.2424V46.0986C1440 46.0986 1420.82 41.2347 1381.68 38.0915C1342.55 34.9484 1231.43 32.2372 1184.09 33.0972C1182.46 33.1233 1180.84 33.1495 1179.24 33.1755C1168.07 33.3562 1157.61 33.5256 1148.07 33.5935C1136.28 33.7557 1125.27 33.4234 1115.5 31.5986C1105.69 28.2936 1099.5 26.0264 1094.38 23.0986C1084.09 17.2074 1081.36 16.2586 1071.93 12.9773C1071.39 12.7904 1070.84 12.5958 1070.25 12.3924C1059.43 8.61827 1046.21 5.74244 1031.36 3.93377C990.885 -0.464426 944.864 3.70971 886.413 9.42386C860.166 12.244 836.643 15.7342 813.924 19.1048C771.328 25.4247 731.565 31.3244 682 31.5986C633.435 31.5986 599.237 25.754 569.339 20.6443C555.219 18.2313 542.059 15.9821 528.797 14.5899C361 -3.0264 310.648 -4.53937 124.249 15.6736C77.6641 20.7252 36.6091 26.6767 0 33.1961L4.37898e-05 79.2424H1440Z",fill:o,transform:"translate(0 17)"}),i("path",{d:"M1440 0.0991211H0V50.1971C36.6091 43.6777 77.6641 37.7261 124.249 32.6745C310.648 12.4616 361 13.9746 528.797 31.5909C542.059 32.9831 555.219 35.2322 569.339 37.6453C599.237 42.755 633.435 48.5996 682 48.5996C731.565 48.3254 771.328 42.4257 813.924 36.1058C836.643 32.7351 860.166 29.2449 886.413 26.4248C944.864 20.7107 990.885 16.5365 1031.36 20.9347C1046.21 22.7434 1059.43 25.6192 1070.25 29.3933C1070.84 29.5968 1071.39 29.7913 1071.93 29.9783C1081.36 33.2595 1084.09 34.2084 1094.38 40.0996C1099.5 43.0274 1105.69 45.2946 1115.5 48.5996C1125.27 50.4244 1136.28 50.7567 1148.07 50.5944C1157.61 50.5266 1168.07 50.3572 1179.24 50.1765C1180.84 50.1505 1182.46 50.1243 1184.09 50.0982C1231.43 49.2382 1342.55 51.9494 1381.68 55.0925C1420.82 58.2357 1440 63.0996 1440 63.0996V0.0991211Z",fill:n,opacity:a,filter:"url(#break-skirt2-shadow)"})]})};var x1=e=>{let{topColor:t,bottomColor:o,shadowColor:n,shadowOpacity:a=.2,...s}=e;return x("svg",{width:"1440",height:"96",viewBox:"0 0 1440 96",fill:"none",xmlns:"http://www.w3.org/2000/svg",preserveAspectRatio:"none",role:"presentation",...s,children:[i("defs",{children:x("filter",{id:"break-skirt3-shadow",x:"0",y:"0",width:"100%",height:"96",children:[i("feGaussianBlur",{stdDeviation:"15"}),i("feComposite",{operator:"out",in2:"SourceGraphic"})]})}),i("path",{d:"M0 0C34.849 14.3283 113.946 7.9634 169.366 14.5723C193.656 18.3155 229.541 28.3275 253.444 30.9529C320.056 36.6478 380.164 24.0008 446.021 28.8655C538.848 36.8216 612.91 60.1738 720.005 58.9539C827.081 60.1738 901.18 36.8253 993.979 28.8619C1059.84 23.9972 1119.94 36.6442 1186.56 30.9529C1210.32 28.3166 1246.29 18.3191 1270.63 14.5686C1326.17 7.96341 1405.17 14.3283 1440 0.00364149V0H0Z",fill:t}),i("path",{d:"M1440 96V0C1418.53 8.83496 1380.26 9.80273 1341.06 10.7939C1316.67 11.4102 1291.93 12.0361 1270.63 14.5684C1259.9 16.2227 1246.9 19.0908 1233.69 22.0078C1216.94 25.7051 1199.84 29.4795 1186.56 30.9531C1152.46 33.8662 1120.06 31.9736 1087.73 30.0859C1056.9 28.2852 1026.12 26.4873 993.979 28.8623C958.615 31.8965 925.967 37.165 893.176 42.457C839.916 51.0527 786.275 59.709 720.004 58.9541C653.738 59.709 600.121 51.0557 546.877 42.4639C514.072 37.1699 481.41 31.8984 446.021 28.8652C413.881 26.4912 383.107 28.2881 352.281 30.0879C319.943 31.9766 287.547 33.8682 253.443 30.9531C240.031 29.4795 222.848 25.6807 206.057 21.9688C192.922 19.0654 180.027 16.2148 169.367 14.5723C148.109 12.0371 123.369 11.4111 98.9785 10.7939C59.7793 9.80176 21.4824 8.83203 0 0V96H1440Z",fill:o}),i("path",{d:"M0 0C34.849 14.3283 113.946 7.9634 169.366 14.5723C193.656 18.3155 229.541 28.3275 253.444 30.9529C320.056 36.6478 380.164 24.0008 446.021 28.8655C538.848 36.8216 612.91 60.1738 720.005 58.9539C827.081 60.1738 901.18 36.8253 993.979 28.8619C1059.84 23.9972 1119.94 36.6442 1186.56 30.9529C1210.32 28.3166 1246.29 18.3191 1270.63 14.5686C1326.17 7.96341 1405.17 14.3283 1440 0.00364149V0H0Z",fill:n,opacity:a,filter:"url(#break-skirt3-shadow)"})]})};var jb=e=>{let{topColor:t,bottomColor:o,shadowColor:n,shadowOpacity:a=.2,...s}=e;return x("svg",{width:"1440",height:"96",viewBox:"0 0 1440 96",fill:"none",xmlns:"http://www.w3.org/2000/svg",preserveAspectRatio:"none",role:"presentation",...s,children:[i("defs",{children:x("filter",{id:"break-straight-shadow",x:"0",y:"0",width:"100%",height:"96",children:[i("feGaussianBlur",{stdDeviation:"15"}),i("feComposite",{operator:"out",in2:"SourceGraphic"})]})}),i("rect",{x:"0",y:"0",width:"100%",height:"48",fill:t}),i("rect",{x:"0",y:"0",width:"100%",height:"48",fill:o,transform:"translate(0 48)"}),i("rect",{x:"0",y:"0",width:"100%",height:"48",fill:n,opacity:a,filter:"url(#break-straight-shadow)"})]})};var bp=({template:e,isTopTransparent:t,isBottomTransparent:o,isOverlaid:n})=>{if(!e)return"none";if(e===tt.Line)return"topAndBottomHalfs";if(t&&o)return"none";let a=t&&!o,s=!t&&o;return n?e===tt.Straight?"topAndBottomHalfs":a?"top":s?"bottom":"topAndBottomHalfs":a?e===tt.Straight?"topHalf":"top":s?e===tt.Straight?"bottomHalf":"bottom":"none"};var Tu=({template:e,imgSrcs:t,topColor:o,bottomColor:n,isOverlaid:a})=>{if(Y("sdsm-break"),e==="None")return null;let s=!!t,l=!o,p=!n;if(l&&p)return null;let d=Bn(o),u=Bn(n),y=l?"transparent":Xl(d,"--bg-color")??"transparent",m=p?"transparent":Xl(u,"--bg-color")??"transparent",g=u==="sdsm-secondary"?r("--break-shadow-light-color"):r("--break-shadow-dark-color"),f=.2;d==="sdsm-secondary"&&u==="sdsm-secondary"&&(f=.4),d!=="sdsm-secondary"&&u==="sdsm-secondary"&&(f=.56);let b;if(s)b=i(jb,{className:Ea,topColor:y,bottomColor:m,shadowColor:g,shadowOpacity:f});else switch(e){case tt.Head:b=i(f1,{className:Ea,topColor:y,bottomColor:m,shadowColor:g,shadowOpacity:f});break;case tt.HeadFlipped:b=i(b1,{className:Ea,topColor:y,bottomColor:m,shadowColor:g,shadowOpacity:f});break;case tt.Line:b=i(S1,{});break;case tt.Skirt:b=i(h1,{className:Ea,topColor:y,bottomColor:m,shadowColor:g,shadowOpacity:f});break;case tt.Skirt2:b=i(C1,{className:Ea,topColor:y,bottomColor:m,shadowColor:g,shadowOpacity:f});break;case tt.Skirt3:b=i(x1,{className:Ea,topColor:y,bottomColor:m,shadowColor:g,shadowOpacity:f});break;case tt.Straight:b=i(jb,{className:Ea,topColor:y,bottomColor:m,shadowColor:g,shadowOpacity:f});break;default:break}if(!b)return null;let S=bp({template:s?tt.Straight:e,isTopTransparent:l,isBottomTransparent:p,isOverlaid:a});return x("div",{className:h("sdsm-break",d??"sdsm-default",i1,{[l1]:S==="top",[p1]:S==="bottom",[c1]:S==="topAndBottomHalfs"||S==="topHalf",[d1]:S==="topAndBottomHalfs"||S==="bottomHalf",[g1]:!l&&!p}),"data-testid":`break-${e?.toLowerCase()}`,children:[b,!!t&&i(Ke,{className:s1,imgSrcs:t,altText:""})]})};Tu.displayName="Break";var Sp=({type:e,location:t})=>{if(Y("sdsm-break"),!e||e==="none")return null;let o=t==="top"&&e==="bottom"||t==="bottom"&&e==="top",n=e==="topAndBottomHalfs"||t==="top"&&e==="bottomHalf"||t==="bottom"&&e==="topHalf";return!o&&!n?null:i("div",{className:h(u1,{[y1]:o,[m1]:n}),"data-testid":"break-spacer"})};Sp.displayName="BreakSpacer";var Bo=T(w());var Yb="editorial-gallery-card-media",Ra="editorial-gallery-card",Au=c`
  align-items: center;
  background-color: ${r("--bg-color")};
  display: flex;
  flex-direction: column;
  gap: 8px;
  position: relative;
  width: 100%;

  &:hover {
    & .${Yb} {
      opacity: 1;
      transform: scale(1);
      z-index: 2;

      ${Xe} {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.12);
      }
    }
  }

  &::before {
    transition: background-color 0.25s ease-out;
    background-color: transparent;
    content: '';
    inset: 0 calc(${r("--spacing-xxxl")} * -1);
    position: absolute;

    ${Xe} {
      width: calc(100% + 2 * ${r("--spacing-xxxl")});
    }
  }
`,_u=c`
  align-items: flex-start;
  align-self: stretch;
  color: ${r("--fg-color")};
  display: flex;
  justify-content: space-between;
  overflow: hidden;
  padding-block: ${r("--spacing-l")};
  /* Containing block for the stretched link ::after pseudo-element
     in stretchedLinkCss, allowing it to cover the full card area. */
  position: relative;

  ${H} {
    overflow: visible;
    padding-block: ${r("--spacing-xxl")};
  }
`,wu=c`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-l")};
  width: 100%;

  ${H} {
    flex-direction: row;
    gap: 72px;
  }
`,I1=c`
  align-items: flex-start;
  display: flex;
  flex-direction: row;
  flex-shrink: 0;
  justify-content: space-between;
  max-width: 100%;
  text-transform: uppercase;
  width: 100%;

  ${H} {
    flex-direction: column;
    max-width: 100px;
  }

  & > p {
    margin: 0;
  }
`,Du=c`
  display: flex;
  flex-direction: row-reverse;
  gap: ${r("--spacing-m")};
  width: 100%;

  ${H} {
    flex-direction: row;
    gap: 72px;
  }
`,Xb=c`
  font-size: ${r("--annotation-mobile-font-size")};
  font-weight: ${r("--annotation-mobile-font-weight")};
  letter-spacing: ${r("--annotation-mobile-font-letter-spacing")};
  line-height: ${r("--annotation-mobile-font-line-height")};
  margin: 0;
  margin-inline-start: auto;
  overflow-wrap: break-word;

  ${H} {
    font-size: ${r("--annotation-desktop-font-size")};
    font-weight: ${r("--annotation-desktop-font-weight")};
    letter-spacing: ${r("--annotation-desktop-font-letter-spacing")};
    line-height: ${r("--annotation-desktop-font-line-height")};
    margin-inline-start: 0;
  }
`,Pu=c`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  justify-content: center;
  position: relative;
  width: 96px;

  ${H} {
    width: 126px;
  }

  ${Xe} {
    width: 169px;
  }
`,k1=c`
  aspect-ratio: 9/16;
  background-color: ${r("--bg-color")};
  border-radius: ${r("--border-radius-l")};
  opacity: 1;
  overflow: hidden;
  pointer-events: none;
  position: relative;
  top: 0;
  user-select: none;

  ${H} {
    inset: 0;
    position: absolute;
    z-index: 1;
  }

  ${Xe} {
    transition: transform 0.25s ease-out;
    transform: scale(0.7);
  }
`,Nu=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-l")};
  width: 100%;

  ${H} {
    gap: ${r("--spacing-m")};
  }

  ${Xe} {
    flex-direction: row;
    justify-content: space-between;
  }
`,M1=c`
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  gap: 16px;

  ${H} {
    height: 115px;
    width: 100%;
  }

  ${Xe} {
    height: 151px;
    max-height: 151px;
    max-width: 480px;
  }
`,T1=c`
  ${ba}
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 4;
  display: -webkit-box;
  margin: 0px;
  overflow: hidden;
  text-overflow: ellipsis;
  width: 100%;

  ${H} {
    -webkit-line-clamp: 2;
  }
`,A1=c`
  ${ut}
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  display: none;
  margin: 0px;
  overflow: hidden;
  text-overflow: ellipsis;
  width: 100%;

  ${H} {
    display: -webkit-box;
  }
`,_1=c`
  display: flex;
  flex-grow: 0;
  height: fit-content;
  max-width: fit-content;

  & svg {
    flex-shrink: 0;
    height: 24px;
    width: 24px;
  }
`,w1=c`
  ${Xe} {
    &:hover {
      &::before {
        background-color: ${r("--neutral-v200")};
      }
      & .${Ra} {
        color: ${r("--neutral-v700")};
      }
    }
  }
`,D1=c`
  ${Xe} {
    &:hover {
      &::before {
        background: ${r("--palette-yellow-v100")};
      }
      & .${Ra} {
        color: ${r("--neutral-v700")};
      }
    }
  }
`,P1=c`
  ${Xe} {
    &:hover {
      &::before {
        background: linear-gradient(
          90deg,
          rgba(255, 252, 0, 1) 25%,
          rgba(217, 173, 224, 1) 75%,
          rgba(142, 102, 209, 1) 100%
        );
      }
      & .${Ra} {
        color: ${r("--neutral-v700")};
      }
    }
  }
`,N1=c`
  ${Xe} {
    &:hover {
      &::before {
        background: ${r("--neutral-v700")};
      }
      & .${Ra} {
        color: ${r("--neutral-v0")};
      }
    }
  }
`,E1=c`
  ${Xe} {
    &:hover {
      &::before {
        background: ${r("--editorial-gallery-card-hover-background-color")};
      }
    }
  }
`,R1=c`
  &::after {
    content: '';
    position: absolute;
    inset: 0;
    z-index: 1;
  }

  &:hover:not([disabled]) {
    transform: none;
  }

  &:active:not([disabled]) {
    transform: none;
  }
`,F1=c`
  background-color: ${r("--neutral-v200")};
`,aq=qo`
  0% {
    transform: translateX(-100%);
  }
  30% {
    transform: translateX(-100%);
  }
  100% {
    transform: translateX(100%);
  }
`,B1=c`
  border-radius: ${r("--border-radius-m")};
  overflow: hidden;
  position: relative;

  &::before {
    animation: ${aq} 2s infinite;
    background: linear-gradient(0.25turn, transparent, ${r("--bg-color")}, transparent);
    content: '';
    height: 100%;
    left: 0;
    opacity: 0.8;
    pointer-events: none;
    position: absolute;
    top: 0;
    transform: translateX(-100%);
    width: 100%;
  }

  @media (prefers-reduced-motion: reduce) {
    &::before {
      animation: none;
    }
  }
`,$1=c`
  display: none;
  flex-direction: column;
  justify-content: center;
  gap: 10px;
  width: 100%;
  padding-block-end: 4px;

  ${H} {
    display: flex;
    height: 52px;
  }
`,L1=c`
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 6px;
  height: 96px;
  width: 100%;
  padding-block: 2px;

  ${H} {
    height: 52px;
  }
`,H1=c`
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 100%;

  ${Xe} {
    height: 151px;
    max-height: 151px;
    max-width: 480px;
  }
`,V1=c`
  aspect-ratio: 9 / 16;
  border-radius: ${r("--border-radius-l")};
  flex-shrink: 0;
  position: absolute;
  width: 96px;

  ${H} {
    width: 126px;
  }

  ${Xe} {
    opacity: 0;
    width: 169px;
  }
`,O1=c`
  align-items: flex-start;
  display: flex;
  flex-direction: row;
  flex-shrink: 0;
  gap: 8px;
  justify-content: space-between;
  max-width: 100%;
  padding-block: 4px;
  text-transform: uppercase;
  width: 100%;

  ${H} {
    flex-direction: column;
    max-width: 100px;
  }
`,G1=c`
  height: 12px;
  width: 60px;
`,z1=c`
  height: 12px;
  width: 75px;
`,Jb=c`
  height: var(--skeleton-bar-height);
  width: var(--skeleton-bar-width);
`,U1=c`
  border-radius: 64px;
  height: 45px;
  width: 170px;

  ${H} {
    height: 50px;
  }
`,W1=c`
  background-color: ${r("--fg-color")};
  border-block: ${r("--border-width-xs")} solid ${r("--fg-color")};
  display: flex;
  flex-direction: column;
  gap: 1px;
  margin-top: ${r("--spacing-xxxl")};
`;var Zb={lens:"Lens Studio",snap:"Snap Inc.",snapchat:"Snapchat",spectacles:"Specs"},iq={lens:P1,snap:w1,snapchat:D1,spectacles:N1},eS=({date:e,dateTime:t,title:o,description:n,imgSrcs:a,videoSource:s,imgAltText:l,brand:p,isRtl:d=!1,link:u,ctaLabel:y="Read More",onClick:m,dataset:g,brandDataset:f,titleDataset:b,descriptionDataset:S,dateDataset:C,mediaDataset:v,className:k,...I})=>{Y("sdsm-editorial-gallery-card");let A=a||s;return i("div",{className:h(Au,p?iq[p]:E1,k),"data-testid":"editorial-gallery-card-container",...ne(g),...I,children:i("div",{className:h(Ra,_u),children:x("div",{className:wu,children:[x("div",{className:I1,children:[p?i("p",{className:Xb,...ne(f),children:Zb[p]}):null,e?i("time",{dateTime:Bd(t),className:Xb,...ne(C),children:e}):null]}),x("div",{className:Du,children:[A?i("div",{className:Pu,children:i(Ke,{imgSrcs:a,altText:l,videoSource:s,isBackgroundVideo:!0,className:h(Yb,k1),dataset:v})}):null,x("div",{className:Nu,children:[o||n?x("div",{className:M1,children:[o?i("h5",{className:T1,...ne(b),children:o}):null,n?i("p",{className:A1,...ne(S),children:n}):null]}):null,u?i(no,{type:rn.Secondary,iconName:d?"arrow-left":"arrow-right",className:h(_1,R1),link:u,onClick:m,children:y}):null]})]})]})})})};eS.displayName="EditorialGalleryCard";var sq=[{height:20,width:85},{height:20,width:60}],lq=[{height:12,width:90},{height:12,width:70}],tS=({className:e})=>{let t=h(F1,B1);return i("div",{className:h(Au,e),"data-testid":"skeleton-editorial-gallery-card-container","aria-hidden":"true",children:i("div",{className:h(Ra,_u),children:x("div",{className:wu,children:[x("div",{className:O1,children:[i("div",{className:h(t,G1)}),i("div",{className:h(t,z1)})]}),x("div",{className:Du,children:[i("div",{className:Pu,children:i("div",{className:h(t,V1)})}),x("div",{className:Nu,children:[x("div",{className:H1,children:[i("div",{className:L1,children:sq.map(({height:o,width:n},a)=>i("div",{className:h(t,Jb),style:{"--skeleton-bar-height":`${o}px`,"--skeleton-bar-width":`${n}%`}},`skeleton-title-${a}`))}),i("div",{className:$1,children:lq.map(({height:o,width:n},a)=>i("div",{className:h(t,Jb),style:{"--skeleton-bar-height":`${o}px`,"--skeleton-bar-width":`${n}%`}},`skeleton-desc-${a}`))})]}),i("div",{className:h(t,U1)})]})]})]})})})};tS.displayName="SkeletonEditorialGalleryCard";var oS="24px",fi=e=>c`
  -webkit-line-clamp: ${e};
  -webkit-box-orient: vertical;
  display: -webkit-box;
  overflow: hidden;
  text-overflow: ellipsis;
`,nS=c`
  border: ${r("--carousel-card-border-width")} solid ${r("--carousel-card-border-color")};
  border-radius: ${r("--carousel-card-border-radius")};
  box-shadow: ${r("--carousel-card-box-shadow")};
  cursor: grab;
  overflow: hidden;
  position: relative;
  transition: background-color 0.2s linear, border-color 0.2s linear, box-shadow 0.2s linear;
  user-select: none;

  &:hover svg {
    fill: ${r("--action-text-hover-color")};
  }

  :hover {
    border-color: ${r("--carousel-card-hover-border-color")};
    box-shadow: ${r("--carousel-card-hover-box-shadow")};
  }

  :hover .sdsm-carousel-card-text {
    background-color: ${r("--carousel-card-hover-bg-color")};
    border-color: ${r("--carousel-card-hover-border-color")};
  }
`,Q1=c`
  color: ${r("--carousel-card-fg-color")};
  cursor: pointer;
  display: block;
  text-decoration: none;
`,q1=c`
  aspect-ratio: 9 / 16;
  margin: calc(${r("--carousel-card-border-width")} * -1);
  /**
   * To help video controls extend full width
   * https://github.sc-corp.net/Snapchat/marketing-web/pull/2555#discussion_r5071157
  */
  position: relative;

  > picture {
    pointer-events: none;
  }

  /** To allow object-fit cover for the video element  */
  > div {
    height: 100%;
  }

  & img {
    aspect-ratio: 16 / 9;
  }
`,K1=c`
  aspect-ratio: 16 / 9;

  & img {
    aspect-ratio: 16 / 9;
  }
`,j1=c`
  aspect-ratio: 3 / 2;

  & img {
    aspect-ratio: 16 / 9;
  }
`,Y1=c`
  aspect-ratio: 1 / 1;

  & img {
    aspect-ratio: 16 / 9;
  }
`,X1=c`
  background-color: rgb(232, 232, 235);
  overflow: hidden;
  position: relative;

  &::before {
    animation: card-skeleton 2s infinite;
    background: linear-gradient(0.5turn, rgb(232, 232, 235), #fff, rgb(232, 232, 235));
    content: '';
    height: 100%;
    inset: 0;
    opacity: 0.8;
    pointer-events: none;
    position: absolute;
    transform: translateX(-100%);
  }

  @keyframes card-skeleton {
    0% {
      transform: translateY(-100%);
    }
    100% {
      transform: translateY(100%);
    }
  }
`,J1=c`
  align-items: center;
  display: flex;
  inset: 0;
  justify-content: center;
  position: absolute;
  transition: opacity 0.2s linear;

  :hover {
    opacity: 0;
  }

  ::before {
    background-color: ${r("--neutral-v700")};
    content: '';
    inset: 0;
    opacity: 0.4;
    position: absolute;
  }
`,Z1=c`
  max-height: 80%;
  max-width: 80%;
  z-index: 1;
`,ew=c`
  max-width: 100%;
  pointer-events: none;
`,tw=c`
  height: 32px;
  margin-bottom: ${r("--spacing-xs")};
  padding-block: ${r("--spacing-xxs")};
`,ow=c`
  max-height: 100%;
  pointer-events: none;
`,nw=c`
  width: ${r("--carousel-card-portrait-desktop-width")};

  ${N} {
    width: ${r("--carousel-card-portrait-mobile-width")};
  }
`,rw=c`
  width: ${r("--carousel-card-landscape-square-desktop-width")};

  ${N} {
    width: ${r("--carousel-card-landscape-square-mobile-width")};
  }

  ${$r({max:345})} {
    width: ${r("--carousel-card-landscape-square-small-mobile-width")};
  }
`,aw=c`
  ${H} {
    width: 100%;
  }
`,iw=c`
  width: 100%;
  /* TODO: explore making this bigger */
  max-width: 700px;
`,sw=c`
  position: relative;
  word-break: break-word;
`,lw=c`
  height: ${r("--carousel-card-desktop-text-height")};

  ${N} {
    height: ${r("--carousel-card-mobile-text-height")};
  }
`,pw=c`
  align-content: flex-start;
  background-color: ${r("--carousel-card-bg-color")};
  border: ${r("--carousel-card-border-width")} solid ${r("--carousel-card-border-color")};
  border-radius: ${r("--carousel-card-border-radius")};
  color: ${r("--carousel-card-fg-color")};
  display: grid;
  gap: 0 ${r("--spacing-m")};
  grid-template-columns: 1fr ${oS};
  margin: calc(${r("--carousel-card-border-width")} * -1);
  min-height: ${`calc(${r("--carousel-card-desktop-text-min-height")} + ${r("--spacing-l")})`};
  padding: ${r("--carousel-card-desktop-text-padding")};

  ${N} {
    padding: ${r("--carousel-card-mobile-text-padding")};
  }
`,cw=c`
  inset: auto 0 0 0;
  position: ${r("--carousel-card-text-position")};
`,dw=c`
  fill: ${r("--action-text-default-color")};
  grid-column: 2;
  height: ${oS};
  width: ${oS};

  [dir='rtl'] & {
    transform: rotate(180deg);
  }
`,hp=c`
  grid-column: span 2;
  margin: 0;
  text-align: ${r("--carousel-card-desktop-text-align")};

  ${N} {
    text-align: ${r("--carousel-card-mobile-text-align")};
  }

  svg + & {
    grid-column: span 1;
    grid-row: 1;
  }
`,uw=c`
  ${ba}
  ${fi(2)}
  letter-spacing: 0.5px;
  margin-block-end: ${r("--spacing-xxs")};
`,yw=c`
  ${fi(4)}
`,mw=c`
  ${Sa}
  ${fi(3)}
  letter-spacing: 0.25px;
  margin-block-end: ${r("--spacing-xs")};
`,gw=c`
  ${fi(5)}
`,fw=c`
  ${qt}
  ${fi(4)}

  a {
    color: ${r("--carousel-card-fg-color")};
  }
`,bw=c`
  ${fi(5)}
`,Sw=c`
  display: block;
  height: 100%;
  object-fit: cover;
  object-position: center;
  width: 100%;
`,hw=c`
  height: 100%;
  object-fit: cover;
  object-position: center;
  width: 100%;
`,Cw=c`
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
`,xw=c`
  border-top-left-radius: 0;
  border-top-right-radius: 0;
`,vw=c`
  color: ${r("--carousel-card-fg-color")};
  display: flex;
  font-size: ${r("--annotation-mobile-font-size")};
  font-weight: ${r("--annotation-mobile-font-weight")};
  gap: ${r("--spacing-l")};
  justify-content: space-between;
  letter-spacing: ${r("--annotation-mobile-font-letter-spacing")};
  line-height: ${r("--annotation-mobile-font-line-height")};
  margin-block-end: ${r("--spacing-xs")};
  text-transform: uppercase;

  ${H} {
    font-size: ${r("--annotation-desktop-font-size")};
    font-weight: ${r("--annotation-desktop-font-weight")};
    justify-content: flex-start;
    letter-spacing: ${r("--annotation-desktop-font-letter-spacing")};
    margin-block-end: ${r("--spacing-xs")};
    line-height: ${r("--annotation-desktop-font-line-height")};
  }
`,rS=c`
  ${fi(1)}
  max-width: 100px;
`,Iw=c`
  -webkit-box-orient: vertical;
  -webkit-line-clamp: ${r("--carousel-card-related-content-body-line-clamp")};
  display: -webkit-box;
  overflow: hidden;
  text-overflow: ellipsis;
`;var Gn=({aspectRatio:e,autoplay:t,body:o,captionsSource:n,imgAltText:a,imgSrcs:s,shouldLoad:l,onPlay:p,onPause:d,onTimeUpdate:u,openNewTab:y,posterSource:m,isVisible:g,showVideoControls:f,subtitle:b,title:S,url:C,videoSource:v,mobileVideoSource:k,onClick:I,isSingleView:A=!1,isResponsiveWidth:D=!1,hideLinkArrow:B,logoSrcs:M,logoAltText:_,className:P,date:$,brand:R,relatedContent:L=!1})=>{let[G,Z]=(0,Bo.useState)(),[U,de]=(0,Bo.useState)(!1),le=(0,Bo.useCallback)(j=>Z(j),[]),re=(0,Bo.useRef)(l),{Anchor:te}=(0,Bo.useContext)(He),ae=Rt(),oe=D&&!A&&!ae,q=!oe&&(!v||!f),X=!ae&&M,W=(0,Bo.useCallback)(j=>{C&&I&&I(C,j)},[C,I]);(0,Bo.useEffect)(()=>{l&&(re.current=!0)},[l]),(0,Bo.useEffect)(()=>{if(G&&G.tagName==="VIDEO"){let j=G;if(X){if(U){try{j.play()}catch{}j.tabIndex=0}else Wr(j)&&j.pause(),j.tabIndex=-1,f||(j.currentTime=0);return}if(!g)Wr(j)&&j.pause(),j.tabIndex=-1,f||(j.currentTime=0);else{if(!f)try{j.play()}catch{}j.tabIndex=0}}},[g,f,G,X,U]);let K=!!(S||b||o),F=(0,Bo.useMemo)(()=>{let j=h(v?hw:Sw,f&&K?Cw:null);return i(Ke,{showVideoControls:f,videoSource:v,mobileVideoSource:k,posterSource:m,onPlay:p,onPause:d,captionsSource:n,isBackgroundVideo:t,onTimeUpdate:u,altText:a,imgSrcs:s,className:j,ref:le,isDraggable:!1,autoplay:X?!1:void 0})},[v,f,m,p,d,n,t,u,le]),Q=x("div",{className:h(q1,{[j1]:e==="3:2"},{[Y1]:e==="1:1"},{[K1]:e==="16:9"},{[X1]:!g&&!re.current}),children:[(g||re.current)&&F,X&&i("div",{className:J1,onMouseEnter:()=>de(!0),onMouseLeave:()=>de(!1),children:i(et,{imgSrcs:M,altText:_,className:Z1,imgClassName:ew})})]}),z=i("div",{className:h(sw,{[lw]:q}),children:x("div",{className:h(pw,"sdsm-carousel-card-text",{[cw]:q,[xw]:f&&K}),children:[!!C&&!B&&i(De,{className:dw,name:"arrow-right"}),ae&&M&&i(et,{imgSrcs:M,altText:_,className:tw,imgClassName:ow}),(R||$)&&x("div",{className:h(hp,vw),children:[R?i("span",{className:rS,children:Zb[R]}):null,$?i("span",{className:rS,children:$}):null]}),S&&i("h5",{className:h(hp,uw,{[yw]:!b&&!o}),title:S,children:S}),b&&i("h6",{className:h(hp,mw,{[gw]:!S&&!o}),title:b,children:b}),o&&i("p",{className:h(hp,fw,{[Iw]:L,[bw]:!S&&!b}),title:o,children:o})]})}),Se={[rw]:e!=="9:16"&&!A,[iw]:e!=="9:16"&&A,[nw]:e==="9:16",[aw]:oe};return C?x(te,{href:C,...y?{target:"_blank",rel:"noopener"}:{},className:h(nS,Q1,Se,P),tabIndex:g?void 0:-1,onClick:W,draggable:"false","data-testid":"sdsm-carousel-card",children:[Q,K&&z]}):x("div",{className:h(nS,Se,P),"data-testid":"sdsm-carousel-card",children:[Q,K&&z]})};Gn.displayName="CarouselCardItem";var Eu=T(w());var kw="24px",pq=700,Mw=c`
  color: ${r("--carousel-card-fg-color")};
  cursor: pointer;
  text-decoration: none;

  display: flex;
  flex-direction: row-reverse;
  justify-content: space-between;
  ${N} {
    padding: ${r("--spacing-l")};
  }
`,aS=c`
  background: ${r("--carousel-card-bg-color")};
  border-radius: ${r("--carousel-card-border-radius")};
  box-shadow: 0 0 32px 0 rgba(0, 0, 0, 0.12);
  color: ${r("--carousel-card-fg-color")};
  cursor: grab;
  display: flex;
  flex-direction: column;
  max-width: ${pq}px;
  padding: ${r("--spacing-xl")};
  position: relative;
  user-select: none;
  width: 100%;

  ${N} {
    margin-inline: ${r("--spacing-xl")};
  }

  ${H} {
    padding: ${r("--spacing-xl")} ${r("--spacing-xxxl")};
  }
`,iS=c`
  margin: 0;
`,sS=c`
  ${qt}
  margin-block: ${r("--spacing-m")} 0;
`,Tw=c`
  fill: ${r("--action-text-default-color")};
  height: ${kw};
  width: ${kw};
  flex-shrink: 0;

  [dir='rtl'] & {
    transform: rotate(180deg);
    right: auto;
  }
`;var lS=({description:e,subText:t,url:o,openNewWTab:n,onClick:a,...s})=>{let{Anchor:l}=(0,Eu.useContext)(He),p=(0,Eu.useCallback)(d=>{o&&a&&a(o,d)},[o,a]);return o?x(l,{href:o,className:h(aS,Mw),...n?{target:"_blank",rel:"noreferrer"}:{},onClick:p,draggable:"false",...s,children:[i(De,{className:Tw,name:"arrow-right"}),x("div",{children:[e&&i("div",{className:iS,children:e}),t&&i("div",{className:sS,children:t})]})]}):x("div",{className:aS,...s,children:[e&&i("div",{className:iS,children:e}),t&&i("div",{className:sS,children:t})]})};lS.displayName="CarouselTextItem";function cq(e,t,o){return e===e&&(o!==void 0&&(e=e<=o?e:o),t!==void 0&&(e=e>=t?e:t)),e}var Aw=cq;Ok();function dq(e,t,o){return o===void 0&&(o=t,t=void 0),o!==void 0&&(o=Zi(o),o=o===o?o:0),t!==void 0&&(t=Zi(t),t=t===t?t:0),Aw(Zi(e),t,o)}var _w=dq;var uq=Math.max,yq=Math.min;function mq(e,t,o){return e>=yq(t,o)&&e<uq(t,o)}var ww=mq;Ok();function gq(e,t,o){return t=tb(t),o===void 0?(o=t,t=0):o=tb(o),e=Zi(e),ww(e,t,o)}var pS=gq;var Ue=T(w());var Ru=300,Dw=c`
  align-items: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-block-end: 20px;
  width: 100%;

  ${N} {
    overflow-x: hidden;
  }
`,Pw=c`
  max-height: 100%;
  overflow: hidden;
  width: 100%;

  ${N} {
    /* Tells the browser this element only consumes horizontal pan gestures so that a horizontal
       swipe never triggers vertical page scroll. Pinch-zoom is preserved for accessibility. */
    touch-action: pan-x pinch-zoom;
  }

  &.dragging {
    a {
      pointer-events: none;
    }
  }
`,Nw=c`
  mask-image: linear-gradient(to left, transparent, black 10%);
  html[dir='rtl'] & {
    mask-image: linear-gradient(to right, transparent, black 10%);
  }
`,Ew=c`
  ${H} {
    mask-image: none;
    html[dir='rtl'] & {
      mask-image: none;
    }
  }
`,Rw=c`
  justify-content: center;
`,Fw=c`
  gap: ${r("--carousel-card-mobile-grid-gap")};

  ${H} {
    gap: ${r("--carousel-card-desktop-grid-gap")};
  }
`,Bw=c`
  transform: translateX(-100%);

  html[dir='rtl'] & {
    transform: translateX(100%);
  }
`,$w=c`
  display: flex;
  margin-block: ${r("--spacing-xl")};
  transition: all ${Ru}ms linear;

  html[dir='rtl'] &,
  body[dir='rtl'] & {
    direction: rtl;
  }
`,Fu=c`
  opacity: 1;

  &.fadeOut {
    opacity: 0;
    pointer-events: none;
  }

  &.animate {
    transition: opacity ${Ru/2}ms ease;
  }
`,Bu=c`
  ${H} {
    max-width: calc(33.33% - ((2 * ${r("--carousel-card-desktop-grid-gap")}) / 3));
    min-width: calc(33.33% - ((2 * ${r("--carousel-card-desktop-grid-gap")}) / 3));
    width: calc(33.33% - ((2 * ${r("--carousel-card-desktop-grid-gap")}) / 3));
  }
`,$u=c`
  align-items: center;
  display: flex;
  flex-grow: 0;
  flex-shrink: 0;
  justify-content: center;
  width: 100%;
`,Lw=c`
  align-items: center;
  background-color: transparent;
  border: 0;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  height: 20px;
  width: 20px;
`,Hw=c`
  background-color: ${r("--carousel-inactive-dot-color")};
  transition: background-color 200ms;
  border-radius: 100px;
  height: 8px;
  width: 8px;

  ${H} {
    cursor: pointer;
  }
`,Vw=c`
  background-color: ${r("--carousel-active-dot-color")};
`,Ow=c`
  -ms-overflow-style: none;
  align-items: center;
  display: flex;
  flex-direction: row;
  height: 20px;
  margin-block-end: ${r("--spacing-xl")};
  padding-inline-start: 0;
  list-style: none;
  margin: 0 auto;
  scrollbar-width: none;

  html[dir='rtl'] & {
    direction: rtl;
  }

  > div:first-child {
    margin-inline-start: 0;
  }
`,Gw=c`
  padding-block-end: 0;
`,zw=c`
  display: flex;
  justify-content: center;
`;var cS=({currentIndex:e,length:t,onDotClick:o})=>i("nav",{className:zw,children:i("ul",{className:Ow,children:Array(t).fill(void 0).map((n,a)=>i("li",{"data-index":a,children:i("button",{onClick:()=>o(a),className:Lw,children:i("span",{className:h(Hw,{[Vw]:e===a})})})},a))})});cS.displayName="Dots";var Lu=T(w());var dS=e=>{if(!e)return null;let t=e,o=e;return t.touches?.[0]?.clientX??t.changedTouches?.[0]?.clientX??o.clientX??null},Uw=e=>e.type===dr?!0:e.type.displayName==="CarouselV3",Cp=(e,t)=>t?e:e*-1;var Ww=(e,t,o)=>{let n=Math.abs(t-e),a=o-n,s=e<t?1:-1;return(Math.abs(n)>Math.abs(a)?-a:n)*s},Qw=({dragStart:e,dragMove:t,dragEnd:o})=>{let a=Yo()===lt.Mobile,s=(0,Lu.useRef)(null),l=(0,Lu.useRef)(null),p=(0,Lu.useRef)(null);return{handleDragStart:g=>{let f=dS(g)??0;s.current=f,l.current=f,p.current=Date.now(),e?.(g)},handleDragMove:g=>{if(s.current===null)return;let f=dS(g);if(f==null)return;l.current=f;let b=s.current-f;t?.(b,g)},handleDragEnd:g=>{a||g?.stopPropagation();let f=s.current??0,b=s.current===null?0:dS(g)??l.current??0,S=f-b,C=p.current===null?0:Math.max(0,Date.now()-p.current);s.current=null,l.current=null,p.current=null,o?.(S,g,{durationMs:C})},resetDrag:()=>{s.current=null,l.current=null,p.current=null}}};var fq=300,bq=20,Sq=.3,hq=(e,t,o)=>{if(t<=0||Number.isNaN(t))return 0;let n=Math.abs(e),a=o>0?n/o:0;return o>0&&o<=fq&&n>=bq&&a>=Sq?Math.sign(e):Math.round(e/t)},dr=({children:e,isSingleView:t=!1,isRtl:o=!1,autoPlay:n=!0,autoPlaySpeed:a=3e3,enableOverflowDecoration:s=!1,isResponsiveWidth:l=!1,onSlideChange:p})=>{Y("sdsm-carousel");let d=(0,Ue.useRef)(null),[u,y]=(0,Ue.useState)(null),m=(0,Ue.useCallback)(J=>{y(J)},[]),g=(0,Ue.useRef)([]),f=(0,Ue.useRef)(),b=(0,Ue.useRef)(!1),[S,C]=(0,Ue.useState)(!1),v=Wd(d),[k,I]=(0,Ue.useState)(0),{isFocused:A}=FM(v),[D,B]=(0,Ue.useState)({width:0,gap:0}),M=Ue.Children.toArray(e),_=M.length,{width:P}=Sn(),$=Rt(),R=l&&!t&&!$,L=(0,Ue.useMemo)(()=>{let J=u?.clientWidth;if(!J)return 0;let ue=D.width+D.gap;return ue?t?1:Math.ceil(J/ue):0},[P,u,t,D.gap,D.width]),G=(0,Ue.useMemo)(()=>R?_>L:_>=L,[_,L,R]),Z=(0,Ue.useMemo)(()=>{if(!G)return 0;let J=Math.min(L*2-1,_);return t?1:Math.max(0,J)},[G,t,L,_]);(0,Ue.useEffect)(()=>{if(!u)return;let ue=u?.firstChild?.clientWidth,we=window.getComputedStyle(u).getPropertyValue("gap"),Be=Number.parseInt(we),Ce=Number.isNaN(Be)?0:Be;B({width:ue,gap:Ce})},[P,u,e,t,_]),(0,Ue.useEffect)(()=>{!t||!u?.children?.length||(g.current?.forEach(J=>clearTimeout(J)),g.current=Array.from(u.children).map((J,ue)=>{let _e=ue===Z+k;return setTimeout(()=>{J.classList.toggle("fadeOut",!_e)},_e?Ru/2:0)}))},[u?.children,k,t,Z]);let U=(0,Ue.useMemo)(()=>{let J=R?0:.5;return(k+Z)*D.width+(k+Z-J)*D.gap},[k,D,Z,R]),de=(0,Ue.useMemo)(()=>{if(!G)return!1;let J=u?.clientWidth??0,ue=D.width+D.gap;return(J+D.gap/2)%ue>D.gap},[u?.clientWidth,D.width,D.gap,G]),le=(0,Ue.useCallback)(J=>{b.current=!0,I(ue=>ue+(o?-J:J))},[o,I]);(0,Ue.useEffect)(()=>(G&&!f.current&&n&&!S&&v&&A&&(f.current=setInterval(()=>{le(1)},a)),()=>{clearInterval(f.current),f.current=void 0}),[f,S,v,A,le,n,a,G]);let re=(0,Ue.useCallback)(J=>{if(v){if(J.keyCode===37){le(-1),p?.((k-1+_)%_,"keyboard");return}J.keyCode===39&&(le(1),p?.((k+1)%_,"keyboard"))}},[v,le,p,k,_]),te=(0,Ue.useCallback)(J=>{if(J===k||P&&P<=jo)return;b.current=!0;let ue=Ww(k,J,_),_e=k+ue;I(_e),p?.(J,"dot")},[_,k,P,p]),ae=Qw({dragStart:()=>{},dragMove:(J,ue)=>{ue?.preventDefault(),d.current?.classList.add("dragging");let _e=U+Cp(J,!o);u.style.transform=`translateX(${Cp(_e,o)}px)`},dragEnd:(J,ue,_e)=>{d.current?.classList.remove("dragging");let we=t?D.width/2:D.width,Be=hq(J,we,_e?.durationMs??0);if(b.current=!0,Be===0||Number.isNaN(Be)){u.style.transform=`translateX(${Cp(U,o)}px)`;return}let Ce=_w(Be,-Z,Z);le(Ce),p?.((k+Ce+_)%_,"drag")}}),oe=(0,Ue.useCallback)(()=>C(!0),[C]),q=(0,Ue.useCallback)(()=>{ae.handleDragEnd(),C(!1)},[ae,C]),X=(0,Ue.useCallback)(()=>{ae.handleDragEnd()},[ae]),W=(0,Ue.useCallback)(()=>{let J=(k+_)%_;J!==k&&(b.current=!1,I(J))},[k,_]),K=J=>{u===J.target&&(ae.resetDrag(),W())},F=G&&!Vk()?{transform:`translateX(${Cp(U,o)}px)`,transition:b.current?void 0:"none"}:void 0,Q=G&&!!_,z=Z>0?M.slice(-Z):[],Se=M.slice(0,Z),j=J=>pS(J,k,k+L),fe=J=>pS(J,k-2,k+L+2);return x("div",{"data-testid":"sdsm-carousel",className:h(Dw,"sdsm-carousel",{"sdsm-carousel-single-view":t,"sdsm-carousel-multi-view":!t,"sdsm-carousel-overflow":de&&!t,[Gw]:Q}),onMouseEnter:G?oe:void 0,onMouseLeave:G?q:void 0,onMouseUp:G?X:void 0,onKeyUp:G?re:void 0,tabIndex:-1,children:[i("div",{className:h(Pw,{[Nw]:s&&de&&!t,[Ew]:R}),onTouchStart:G?ae.handleDragStart:void 0,onMouseDown:G?ae.handleDragStart:void 0,onTouchMove:G?ae.handleDragMove:void 0,onMouseMove:G?ae.handleDragMove:void 0,onTouchEnd:G?ae.handleDragEnd:void 0,onMouseUp:G?ae.handleDragEnd:void 0,ref:d,tabIndex:-1,children:x("div",{className:h($w,{[Rw]:!G,[Bw]:t,[Fw]:!t}),style:F,onTransitionEnd:K,ref:m,tabIndex:-1,children:[z.map((J,ue)=>i("div",{className:h(Fu,{[$u]:t,[Bu]:R,fadeOut:t,animate:b.current}),"aria-hidden":!0,children:(0,Ue.cloneElement)(J,{shouldLoad:fe(ue-z.length),isVisible:j(ue-z.length),isSingleView:t})},`initial-duplicated-${J.key||ue}`)),M.map((J,ue)=>i("div",{className:h(Fu,{[$u]:t,[Bu]:R,fadeOut:t&&ue!==k,animate:b.current}),children:(0,Ue.cloneElement)(J,{shouldLoad:fe(ue),isVisible:j(ue),isSingleView:t})},`carousel-item-${J.key||ue}`)),Se.map((J,ue)=>i("div",{className:h(Fu,{[$u]:t,[Bu]:R,fadeOut:t,animate:b.current}),"aria-hidden":!0,children:(0,Ue.cloneElement)(J,{shouldLoad:fe(ue+M.length),isVisible:j(ue+M.length),isSingleView:t})},`final-duplicated-${J.key||ue}`))]})}),Q&&i(cS,{currentIndex:k,length:_,onDotClick:te})]})};var qw=c`
  display: block;
  font-size: 15px;
  font-weight: 700;
  line-height: ${32}px;
`;var Kw=({title:e})=>i("span",{className:qw,children:e});var Ts=T(w());var jw=c`
  ${N} {
    display: none;
  }
`,Yw=c`
  ${H} {
    display: none;
  }
`;var uS="--list-icon-url",Xw=c`
  scroll-margin-top: var(--total-header-height);
`,Jw=c`
  background-color: ${r("--bg-color")};
  background-image: ${r("--bg-image")};
  color: ${r("--fg-color")};
  display: grid;
  /* we do only 1 column here because these are the default styles when there is only either Media or Text */
  grid-template-columns: 1fr;
  grid-template-rows: auto;
  width: 100%;
  gap: ${r("--spacing-xl")};
  border-color: ${r("--content-border-color")};
  border-width: ${r("--content-border-width")};
  border-style: solid;
  backdrop-filter: ${r("--content-backdrop-filter")};
  box-shadow: ${r("--content-box-shadow")};

  ${N} {
    grid-template-columns: 1fr;
    grid-template-rows: auto;
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${uo} {
    grid-template-columns: 1fr;
    grid-template-rows: auto;
  }
`,Zw=c`
  background-color: transparent;
  backdrop-filter: ${r("--content-backdrop-filter")};
`,eD={Normal:c`
    align-items: center;
    justify-items: stretch;
    justify-content: center;
  `,Dense:c`
    align-items: start;
    justify-items: stretch;
  `},tD={Normal:{Left:c`
      grid-template-columns: auto minmax(auto, 600px);
    `,Right:c`
      grid-template-columns: minmax(auto, 600px) auto;
    `,Top:c`
      gap: ${r("--content-desktop-grid-gap")};
      grid-template-rows: auto 1fr;
      align-items: start;
    `,Bottom:c`
      gap: ${r("--content-desktop-grid-gap")};
      grid-template-rows: 1fr auto;
      align-items: start;
    `},Dense:{Left:c`
      grid-template-columns: auto minmax(auto, 1fr);
    `,Right:c`
      grid-template-columns: minmax(auto, 1fr) auto;
    `,Top:"",Bottom:""}},oD={Normal:{Top:c`
      ${N} {
        gap: ${r("--content-mobile-grid-gap")};
        grid-template-rows: auto 1fr;
        align-items: start;
      }
    `,Bottom:c`
      ${N} {
        gap: ${r("--content-mobile-grid-gap")};
        grid-template-rows: 1fr auto;
        align-items: start;
      }
    `},Dense:{Top:"",Bottom:""}},nD=c`
  align-items: center;
  display: flex;
  justify-content: center;
`,rD={Right:c`
    order: 1;
  `,Bottom:c`
    order: 1;
  `},aD={Top:c`
    ${N} {
      order: 0;
    }
  `,Bottom:c`
    ${N} {
      order: 1;
    }
  `},iD={Normal:c`
    border-radius: ${r("--border-radius-l")};
    padding: ${r("--spacing-xl")};
    ${N} {
      padding-left: ${r("--spacing-m")};
      padding-right: ${r("--spacing-m")};
    }
  `,Dense:c`
    border-radius: ${r("--border-radius-l")};
    padding: ${r("--spacing-l")};
    ${N} {
      padding-left: ${r("--spacing-m")};
      padding-right: ${r("--spacing-m")};
    }
  `},sD={Normal:c`
    border-radius: ${r("--border-radius-l")};
    padding: ${r("--content-desktop-no-bg-padding")};
    ${N} {
      padding: ${r("--content-mobile-no-bg-padding")};
    }
  `,Dense:c`
    border-radius: ${r("--border-radius-l")};
  `},lD=c`
  /* This is needed to make the PrimitiveTable component not overflow. */
  max-width: 100%;
  /* https://weblog.west-wind.com/posts/2016/feb/15/flexbox-containers-pre-tags-and-managing-overflow */
  /* This is needed to make the Code component not overflow. The above blog post kind of explains it-ish... */
  min-width: 0;

  display: flex;
  flex-direction: column;
  gap: var(--spacing-m);
  height: 100%;
`,pD=c`
  ${H} {
    justify-self: stretch;
  }
`,cD=c`
  height: unset;
`,dD=c`
  & ul:not(:has(ul)) {
    list-style: none;
    /* Remove padding-left from primitive styles */
    padding-inline-start: 0;

    & li {
      position: relative;
      /*
        This is the size of the icon
        https://www.figma.com/design/MuetHWEuhUF7rJap6giyq5/%5BEXT%5D-SDS-M-Refresh-2024?node-id=465-20259&t=NPQoIP8Xk8WG9Sus-11
      */
      padding-inline-start: 24px;

      &::before {
        background-image: var(${uS});
        background-repeat: no-repeat;
        background-size: cover;
        content: '';
        height: 18px;
        inset-block-start: 4px;
        inset-inline-start: 3px;
        position: absolute;
        width: 18px;
      }
    }
  }

  /** Only top level of list items will have the bullet replaced by icon */
  & ul ul {
    list-style: initial;

    & li {
      padding-inline-start: initial;

      &::before {
        content: none;
      }
    }
  }
`,uD=c`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  gap: ${r("--spacing-m")};
  justify-content: space-between;
`,yD=c`
  ${ut}

  display: flex;
  flex-direction: column;

  .${"sdsm-button"} {
    margin-top: ${r("--spacing-s")};
  }

  /** 
   * Nested Hyperlink in content body text inherit font size, line height,
   * font weight, and font stretch to ensure consistent typography.
   * */
  & p .${"sdsm-hyperlink"} {
    font-size: inherit;
    line-height: inherit;
  }

  & ul {
    margin-block-end: ${r("--spacing-s")};

    /** Add margin bottom only to the top level list */
    & ul {
      margin-block-end: 0;
    }
  }
`,mD=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-xs")};
`,gD=c`
  /**
   * The title is rendered as an <h3> so that there's a hierarchy of Hero Title (H1),
   * Block Title (H2) and Content Title (H3). However, visually we want it to look like
   * like an H4 because users put in very long content titles.
   * So we force an H4 look over an H3 element.
   * Note the double specificity to override default h3 styles.
   * See https://jira.sc-corp.net/browse/WEBP-9117
   */
  && {
    ${bd}
  }
  color: ${r("--content-title-color")};
`,fD=c`
  color: ${r("--content-subtitle-color")};
`,ur={[ie.Left]:c`
    align-items: stretch;
    justify-content: flex-start;
    text-align: start;
  `,[ie.Start]:c`
    align-items: stretch;
    justify-content: flex-start;
    text-align: start;
  `,[ie.Center]:c`
    align-items: center;
    justify-content: center;
    text-align: center;
  `,[ie.End]:c`
    align-items: stretch;
    justify-content: flex-end;
    text-align: end;
  `,[ie.Right]:c`
    align-items: stretch;
    justify-content: flex-end;
    text-align: end;
  `},yS=c`
  width: 100%;
`,mS={[ie.Left]:c`
    ${H} {
      ${ur[ie.Left]}
    }
  `,[ie.Start]:c`
    ${H} {
      ${ur[ie.Start]}
    }
  `,[ie.Center]:c`
    ${H} {
      ${ur[ie.Center]}
    }
  `,[ie.End]:c`
    ${H} {
      ${ur[ie.End]}
    }
  `,[ie.Right]:c`
    ${H} {
      ${ur[ie.Right]}
    }
  `},gS={[ie.Left]:c`
    ${N} {
      ${ur[ie.Left]}
    }
  `,[ie.Start]:c`
    ${N} {
      ${ur[ie.Start]}
    }
  `,[ie.Center]:c`
    ${N} {
      ${ur[ie.Center]}
    }
  `,[ie.End]:c`
    ${N} {
      ${ur[ie.End]}
    }
  `,[ie.Right]:c`
    ${N} {
      ${ur[ie.Right]}
    }
  `},bD=c`
  margin-bottom: ${r("--spacing-m")};
  margin-top: auto;
`,SD=c`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: ${r("--spacing-m")};
`,hD=c`
  display: none;
`,fS="--border-color",CD=c`
  border-color: var(${fS});
  border-width: ${r("--content-decoration-border-width")};
`;var As=({className:e,body:t,bodyAlignment:o,bodyAlignmentMobile:n,callsToAction:a,displayOn:s="All",layout:l="Normal",mediaDirection:p="Top",mediaDirectionMobile:d="Top",subtitle:u,title:y,titleAlignment:m,titleAlignmentMobile:g,motifScheme:f,backgroundColor:b,borderColor:S,anchorId:C,animation:v,isRTL:k,bodyDataset:I,titleDataset:A,subtitleDataset:D,asset:B,style:M,listIconUrl:_})=>{Y("sdsm-content");let P=(0,Ts.useRef)(null),$=au(P,v),R=k?"rtl":void 0,L=(0,Ts.useContext)(Fd),G=f??b,Z=S?void 0:G,U=S?void 0:G||L,de=L===void 0!=(U===void 0)?!1:Bn(L)===Bn(U),le=!!(y||u),re=!!(a&&!Array.isArray(a)||Array.isArray(a)&&a.length),te=t||re,ae=!!(y||u||te),oe=!!B&&ae,q=Z?Pe(U):void 0,X=(0,Ts.useMemo)(()=>{if(!S)return M;let F=Bn(S),Q=Xl(F,"--bg-color"),z=Q?{[fS]:Q}:void 0;return{...M,...z}},[M,S]),W=!S&&de?sD[l]:iD[l],K=h("sdsm-content",q,Jw,W,{[jw]:s==="DesktopOnly",[Yw]:s==="MobileOnly",[hD]:s==="Neither",[eD[l]||""]:oe,[tD[l]?.[p]]:oe,[oD[l]?.[d]]:oe,[Zw]:!Z||de,[CD]:!!S},e);return x("section",{id:C,style:$?{...X,...$}:X,"data-testid":"sdsm-content",className:h(K,Xw),ref:P,dir:R,children:[!!B&&i("div",{"data-testid":"sdsm-content-media-container",className:h(nD,rD[p],aD[d]),children:i("div",{"data-testid":"sdsm-content-media","data-animation-id":"content-media",children:B})}),ae&&x("div",{"data-testid":"sdsm-content-header-and-body",className:h(lD,{[pD]:p==="Top"||p==="Bottom",[cD]:p==="Left"||p==="Right"}),children:[le&&i(Cq,{title:y,titleAlignment:m,titleAlignmentMobile:g,titleDataset:A,subtitle:u,subtitleDataset:D}),te&&i(xq,{body:t,bodyAlignment:o,bodyAlignmentMobile:n,bodyDataset:I,callsToAction:a,listIconUrl:_,hasCallsToAction:re})]})]})},Cq=({title:e,titleDataset:t,subtitle:o,subtitleDataset:n,titleAlignment:a=ie.Start,titleAlignmentMobile:s=ie.Start})=>{let l=h(yS,mS[a],gS[s]);return x("div",{"data-testid":"sdsm-content-header",className:h(mD,l),children:[e&&i("h3",{className:h(gD,l,"sdsm-content-title"),"data-testid":"sdsm-content-title","data-animation-id":"content-title",...ne(t),children:e}),o&&i("div",{className:h(yo,fD,"sdsm-content-subtitle"),"data-testid":"sdsm-content-subtitle","data-animation-id":"content-subtitle",...ne(n),children:o})]})},xq=({body:e,bodyDataset:t,callsToAction:o,listIconUrl:n,hasCallsToAction:a,bodyAlignment:s=ie.Start,bodyAlignmentMobile:l=ie.Start})=>{let p=h(yS,mS[s],gS[l]),d=n?{[uS]:`url("${n}")`}:void 0;return x("div",{"data-testid":"sdsm-content-body",style:d,className:h("sdsm-content-body",uD),children:[e&&i("div",{className:h(yD,p,{[dD]:!!n}),"data-testid":"sdsm-content-body-content","data-animation-id":"content-body",...ne(t),children:e}),a&&i("div",{"data-testid":"sdsm-content-cta",className:h(bD,"sdsm-content-cta"),children:i("div",{className:h(SD,p),"data-animation-id":"content-cta",children:o})})]})};var ID=T(w());var xD=c`
  background-color: ${r("--definition-bg-color")};
  border-radius: ${r("--border-radius-s")};
  border-bottom: 2px solid ${r("--definition-border-color")};
  cursor: pointer;
  margin: 0;
  padding: 0px 4px 2px 4px;
  /* Ensure element is scrolled to the center of the screen when scrolled into view here:
   * packages/web/src/Routes.tsx
   */
  scroll-margin-top: 50vh;
  transition: background-color 150ms ease-in-out, border-color 150ms ease-in-out;

  &:hover {
    background-color: ${r("--definition-hover-bg-color")};
    border-bottom: 2px solid ${r("--definition-hover-border-color")};
  }
`,vD=c`
  background-color: ${r("--definition-active-bg-color")};
  border-bottom: 2px solid ${r("--definition-hover-border-color")};

  &:hover {
    background-color: ${r("--definition-active-bg-color")};
    border-bottom: 2px solid ${r("--definition-hover-border-color")};
  }
`;var kD=(0,ID.forwardRef)(({anchorId:e,isActive:t,onClick:o,className:n,children:a},s)=>(Y("sdsm-definition"),i("span",{role:"button",tabIndex:0,id:e,ref:s,onClick:o,onKeyDown:p=>{["Enter"," "].includes(p.key)&&(p.preventDefault(),o?.())},className:h("sdsm-definition",xD,{[vD]:t},n),children:a})));var RD=T(ma());var xp=c`
  opacity: 1;
  pointer-events: auto;
  visibility: visible;
`,PD=c`
  box-sizing: border-box;
  opacity: 0;
  pointer-events: none;
  position: fixed;
  transition: transform 750ms cubic-bezier(0.8, 0, 0.2, 1),
    opacity 750ms cubic-bezier(0.8, 0, 0.2, 1), visibility 750ms cubic-bezier(0.8, 0, 0.2, 1);
  visibility: hidden;
  z-index: ${Ee.DIRECTIONAL_OVERLAY_PANEL};

  @media (prefers-reduced-motion: reduce) {
    transition: none;
  }
`,vq=c`
  ${H} {
    height: 100vh;
    left: 0;
    right: auto;
    top: 0;
    transform: translateX(calc(-100% - var(--directional-overlay-lateral-outset, 0px)));
    transform-origin: 0 50%;
    width: min(100vw, calc(var(--directional-overlay-desktop-size-pct) * 1vw));
  }
`,Iq=c`
  ${H} {
    height: 100vh;
    left: auto;
    right: 0;
    top: 0;
    transform: translateX(calc(100% + var(--directional-overlay-lateral-outset, 0px)));
    transform-origin: 100% 50%;
    width: min(100vw, calc(var(--directional-overlay-desktop-size-pct) * 1vw));
  }
`,kq=c`
  ${H} {
    bottom: auto;
    height: min(100vh, calc(var(--directional-overlay-desktop-size-pct) * 1vh));
    left: 0;
    overflow: auto;
    right: 0;
    top: 0;
    transform: translateY(calc(-100% - var(--directional-overlay-vertical-outset, 0px)));
    transform-origin: 50% 0;
    width: 100%;
  }
`,Mq=c`
  ${H} {
    bottom: 0;
    height: min(100vh, calc(var(--directional-overlay-desktop-size-pct) * 1vh));
    left: 0;
    overflow: auto;
    right: 0;
    top: auto;
    transform: translateY(calc(100% + var(--directional-overlay-vertical-outset, 0px)));
    transform-origin: 50% 100%;
    width: 100%;
  }
`,MD=c`
  ${H} {
    transform: translateX(0);
  }
`,TD=c`
  ${H} {
    transform: translateY(0);
  }
`,Tq=c`
  ${N} {
    height: 100vh;
    left: 0;
    right: auto;
    top: 0;
    transform: translateX(calc(-100% - var(--directional-overlay-lateral-outset, 0px)));
    transform-origin: 0 50%;
    width: min(100vw, calc(var(--directional-overlay-mobile-size-pct) * 1vw));
  }
`,Aq=c`
  ${N} {
    height: 100vh;
    left: auto;
    right: 0;
    top: 0;
    transform: translateX(calc(100% + var(--directional-overlay-lateral-outset, 0px)));
    transform-origin: 100% 50%;
    width: min(100vw, calc(var(--directional-overlay-mobile-size-pct) * 1vw));
  }
`,_q=c`
  ${N} {
    bottom: auto;
    height: min(100vh, calc(var(--directional-overlay-mobile-size-pct) * 1vh));
    left: 0;
    overflow: auto;
    right: 0;
    top: 0;
    transform: translateY(calc(-100% - var(--directional-overlay-vertical-outset, 0px)));
    transform-origin: 50% 0;
    width: 100%;
  }
`,wq=c`
  ${N} {
    bottom: 0;
    height: min(100vh, calc(var(--directional-overlay-mobile-size-pct) * 1vh));
    left: 0;
    overflow: auto;
    right: 0;
    top: auto;
    transform: translateY(calc(100% + var(--directional-overlay-vertical-outset, 0px)));
    transform-origin: 50% 100%;
    width: 100%;
  }
`,AD=c`
  ${N} {
    transform: translateX(0);
  }
`,_D=c`
  ${N} {
    transform: translateY(0);
  }
`,Dq=c`
  ${Ht} {
    height: 100vh;
    left: 0;
    right: auto;
    top: 0;
    transform: translateX(calc(-100% - var(--directional-overlay-lateral-outset, 0px)));
    transform-origin: 0 50%;
    width: min(100vw, calc(var(--directional-overlay-small-mobile-size-pct) * 1vw));
  }
`,Pq=c`
  ${Ht} {
    height: 100vh;
    left: auto;
    right: 0;
    top: 0;
    transform: translateX(calc(100% + var(--directional-overlay-lateral-outset, 0px)));
    transform-origin: 100% 50%;
    width: min(100vw, calc(var(--directional-overlay-small-mobile-size-pct) * 1vw));
  }
`,Nq=c`
  ${Ht} {
    bottom: auto;
    height: min(100vh, calc(var(--directional-overlay-small-mobile-size-pct) * 1vh));
    left: 0;
    overflow: auto;
    right: 0;
    top: 0;
    transform: translateY(calc(-100% - var(--directional-overlay-vertical-outset, 0px)));
    transform-origin: 50% 0;
    width: 100%;
  }
`,Eq=c`
  ${Ht} {
    bottom: 0;
    height: min(100vh, calc(var(--directional-overlay-small-mobile-size-pct) * 1vh));
    left: 0;
    overflow: auto;
    right: 0;
    top: auto;
    transform: translateY(calc(100% + var(--directional-overlay-vertical-outset, 0px)));
    transform-origin: 50% 100%;
    width: 100%;
  }
`,wD=c`
  ${Ht} {
    transform: translateX(0);
  }
`,DD=c`
  ${Ht} {
    transform: translateY(0);
  }
`,ND=c`
  background-color: ${r("--palette-plain-black")};
  height: 100vh;
  left: 0;
  opacity: 0;
  pointer-events: none;
  position: fixed;
  top: 0;
  transition: opacity 200ms ease-in-out, visibility 200ms ease-in-out,
    backdrop-filter 200ms ease-in-out;
  visibility: hidden;
  width: 100vw;
  z-index: ${Ee.DIRECTIONAL_OVERLAY_BACKDROP};

  @media (prefers-reduced-motion: reduce) {
    transition: none;
  }
`,ED=c`
  opacity: 0.3;
  pointer-events: auto;
  visibility: visible;
`,Hu={left:{desktop:vq,desktopOpen:MD,mobile:Tq,mobileOpen:AD,smallMobile:Dq,smallMobileOpen:wD},right:{desktop:Iq,desktopOpen:MD,mobile:Aq,mobileOpen:AD,smallMobile:Pq,smallMobileOpen:wD},top:{desktop:kq,desktopOpen:TD,mobile:_q,mobileOpen:_D,smallMobile:Nq,smallMobileOpen:DD},bottom:{desktop:Mq,desktopOpen:TD,mobile:wq,mobileOpen:_D,smallMobile:Eq,smallMobileOpen:DD}};var bS=({isOpen:e,children:t,desktopDirection:o,mobileDirection:n,smallMobileDirection:a,desktopSizePercent:s,mobileSizePercent:l=s,smallMobileSizePercent:p,onBackdropClick:d,showBackdrop:u=!0,backdropRef:y,portalRoot:m,backdropClassName:g,backdropOpenClassName:f,className:b,style:S,dataset:C,"data-testid":v,role:k,"aria-modal":I,"aria-label":A,"aria-labelledby":D,"aria-describedby":B})=>{let M=n??o,_=l??s,$={...S,"--directional-overlay-desktop-size-pct":s,"--directional-overlay-mobile-size-pct":_,"--directional-overlay-small-mobile-size-pct":p??_},R=re=>{(re.key==="Enter"||re.key===" ")&&(re.preventDefault(),d?.(re))},L=Hu[o],G=Hu[M],Z=a?Hu[a]:void 0,U=h(ND,e&&ED,g,e&&f),de=h(PD,L.desktop,G.mobile,Z?.smallMobile,e&&xp,e&&L.desktopOpen,e&&G.mobileOpen,e&&Z?.smallMobileOpen,b),le=x(pe,{children:[u&&i("div",{className:U,onClick:d,onKeyDown:R,ref:y,role:"presentation"}),i("aside",{...ne(C),"aria-describedby":B,"aria-label":A,"aria-labelledby":D,"aria-modal":I,className:de,"data-testid":v,role:k,style:$,children:t})]});return m?(0,RD.createPortal)(le,m):le};bS.displayName="DirectionalOverlay";var SS="toggleButtonsWrapper",hS="dropdownWrapper",CS="skeletonWrapper",FD=c`
  width: 100%;
`,Rq=c`
  display: flex;
  justify-content: center;
  padding-top: ${r("--spacing-xxxs")};
  flex-wrap: wrap;

  ${N} {
    justify-content: start;
    overflow-x: auto;
    flex-wrap: nowrap;
    ${PM}
  }

  *[dir='rtl'] & {
    flex-direction: row-reverse;
  }
`,Fq=c`
  margin-inline: 0;

  ${N} {
    &::before,
    &::after {
      content: '';
      flex: 0 0 ${r("--spacing-xl")};
    }
    margin-inline: calc(${r("--spacing-xl")} * -1);
  }
`,BD=c`
  ${Rq}
  ${Fq}
`,$D=c`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  width: 100%;

  & > div {
    margin: auto;

    & > div:not(:last-of-type):not(.${SS}) {
      margin-bottom: calc(${r("--spacing-xxl")} * 2);
    }
  }
`,xS="toggleButton-active",Bq=c`
  border-radius: 64px;
  cursor: pointer;
  font-weight: ${r("--action-desktop-font-weight")};
  line-height: ${r("--action-desktop-font-line-height")};
  text-decoration: none;
  transition: transform 150ms ease-in-out;
  white-space: nowrap;
  z-index: ${Ee.BUTTON};

  @media (hover: hover) {
    &:hover:not(:disabled) {
      box-shadow: ${r("--box-shadow-xl")};
      transform: translateY(-2px);
    }
  }

  &:active:not(:disabled) {
    box-shadow: ${r("--box-shadow-m")};
    transform: translateY(-1px);
  }

  ${N} {
    font-weight: ${r("--action-mobile-font-weight")};
    line-height: ${r("--action-mobile-font-line-height")};
  }
`,$q=c`
  margin-inline: ${r("--spacing-xs")};
  margin-bottom: ${r("--spacing-xl")};
  font-size: ${r("--action-desktop-font-size")};
  padding: ${r("--spacing-s")} ${r("--spacing-xl")};
  border: ${r("--border-width-xs")} solid ${r("--chart-toggle-buttons-border-color")};
  background-color: ${r("--chart-toggle-buttons-bg-color")};
  color: ${r("--chart-toggle-buttons-color")};

  ${N} {
    font-size: ${r("--action-mobile-font-size")};
  }

  &.${xS} {
    border: ${r("--border-width-xs")} solid ${r("--chart-toggle-buttons-active-border-color")};
    background-color: ${r("--chart-toggle-buttons-active-bg-color")};
    color: ${r("--chart-toggle-buttons-active-color")};
  }
`,LD=c`
  ${Bq}
  ${$q}
`,HD=c`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  position: relative;
  width: 100%;

  & > * {
    box-sizing: border-box;
    margin-left: ${r("--spacing-m")};
    margin-right: ${r("--spacing-m")};

    ${N} {
      margin-left: 0;
      margin-right: 0;
      width: 100%;
    }

    width: 100%;
  }
`,VD=c`
  align-items: flex-start;
  column-gap: ${r("--spacing-m")};
  display: flex;
  min-height: 70vh;
  row-gap: ${r("--spacing-xl")};

  ${N} {
    flex-direction: column;

    & > * {
      width: 100%;
    }

    /** Style buttons in dropdown component */
    button {
      width: 100%;
    }
  }

  ${H} {
    flex-wrap: wrap;

    & > *:not(.${hS}, .${CS}) {
      width: 100%;
    }
  }
`,OD=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-xs")};
  justify-content: end;

  label {
    font-size: ${r("--action-desktop-font-size")};
    font-weight: ${r("--action-desktop-font-weight")};

    ${N} {
      font-size: ${r("--action-mobile-font-size")};
      font-weight: ${r("--action-mobile-font-weight")};
    }
  }

  ${N} {
    width: 100%;
  }
`,GD=c`
  ${H} {
    margin-block-start: calc(24px + ${r("--spacing-xs")});
  }
`;var Lq="rgb(232, 232, 235)",zD=c`
  /** align with dropdown */
  margin-block-start: 17px;
`,UD=c`
  background-color: ${r("--dropdown-skeleton-animation-default-color")};
  border-radius: ${r("--border-radius-m")};
  height: 6px;
  margin-block-end: ${r("--spacing-xs")};
  width: 51px;
`,WD=c`
  align-items: center;
  background-color: ${r("--dropdown-menu-bg-color")};
  border: ${r("--dropdown-button-border-width")} solid ${r("--dropdown-button-border-color")};
  border-radius: ${r("--dropdown-button-border-radius")};
  box-shadow: ${r("--dropdown-button-shadow")};
  color: ${r("--fg-color")};
  display: flex;
  gap: 6px;
  justify-content: space-between;
  min-width: 160px;
  padding: ${r("--spacing-s")} ${r("--spacing-m")};
`,vS=c`
  background-color: ${r("--dropdown-skeleton-animation-default-color")};
  border-radius: ${r("--border-radius-m")};
  height: 12px;

  &:nth-child(1) {
    flex: 0 0 48px;
  }

  &:nth-child(2) {
    flex: 1 1 100%;
  }

  ${H} {
    &:nth-child(1) {
      flex: 0 0 28px;
    }
  }
`,Vu=c`
  overflow: hidden;
  position: relative;

  &::before {
    animation: dropdown-skeleton 2s infinite;
    background: linear-gradient(
      0.25turn,
      transparent,
      ${r("--dropdown-skeleton-animation-color")},
      transparent
    );
    content: '';
    height: 100%;
    left: 0;
    opacity: 0.8;
    pointer-events: none;
    position: absolute;
    top: 0;
    transform: translateX(-100%);
    width: 100%;
  }

  @keyframes dropdown-skeleton {
    0% {
      transform: translateX(-100%);
    }
    30% {
      transform: translateX(-100%);
    }
    100% {
      transform: translateX(100%);
    }
  }
`,QD=c`
  flex: 0 0 20px;
`,qD=c`
  fill: ${Lq};
  position: relative;
  top: 1px;
  transform: rotate(0deg);
  transition: transform 250ms;
`;var KD=()=>x("aside",{className:h("sdsm-dropdown-skeleton",CS,zD),children:[i("div",{className:h(UD,Vu)}),x("div",{className:h(WD),children:[i("div",{className:h(vS,Vu)}),i("div",{className:h(vS,Vu)}),i("div",{className:QD,children:i(De,{size:20,className:qD,name:"chevron-down"})})]})]});var jD=c`
  color: ${r("--emphasized-text-color")};
  font-style: normal;
`;var YD=({text:e})=>(Y("sdsm-empahasized-text"),e?i("em",{className:h("sdsm-empahasized-text",jD),children:e}):null);var o2=T(w());var XD=c`
  ${N} {
    display: none;
  }

  ${H} {
    display: block;
  }
`,JD=c`
  border: none;
  background-color: inherit;
  color: ${r("--fg-color")};
  cursor: pointer;
  align-items: center;
  display: flex;
  padding-block: ${16}px;
  margin-inline-end: ${32}px;
`,ZD=c`
  ${N} {
    position: relative;
  }

  ${H} {
    display: none;
  }
`,e2=c`
  ${N} {
    width: 100%;
  }
`,IS=c`
  cursor: pointer;
  font-family: inherit;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;

  *[dir='rtl'] & {
    text-align: right;
  }

  ${N} {
    background: none;
    border: none;
    padding-block: ${8}px;
    padding-inline-end: ${32}px;
    /* stylelint-disable-next-line property-no-vendor-prefix */
    -webkit-appearance: none;
    appearance: none;
    width: 100%;
  }
`,kS=c`
  font-size: ${r("--h6-desktop-font-size")};
  font-weight: ${r("--h6-desktop-font-weight")};
  line-height: 120%;

  ${N} {
    ${Ur.M400};
    line-height: 28px;
  }
`,t2=c`
  color: ${r("--fg-color")};
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  margin-inline-end: ${8}px;
  width: 100%;
`,MS=c`
  font-size: 16px;
  pointer-events: none;

  svg {
    fill: ${r("--fg-color")};
  }

  ${H} {
    margin-block-start: 3px;
    margin-inline-start: 9px;

    *[dir='rtl'] & {
      margin-right: ${8}px;
    }
  }

  ${N} {
    position: absolute;
    right: 4px;
    top: 50%;
    transform: translateY(-50%);

    *[dir='rtl'] & {
      left: 4px;
      right: auto;
    }
  }
`;var Ou="all",TS=({title:e,onChange:t,isStandalone:o=!0,value:n,allItemTitle:a,items:s,dataset:l})=>{Y("sdsm-filter-dropdown-menu");let p=(0,o2.useMemo)(()=>[{title:a,id:Ou,onClick:()=>t?.(void 0)},...s.map(({title:m,id:g})=>({title:m,id:g,onClick:()=>t?.(g)}))],[a,s,t]),d=y=>{y.target.value===Ou?t?.(void 0):t?.(y.target.value)},u=y=>x("button",{onClick:y.onClick,"data-testid":"sds-dropdown-menu",className:JD,role:"combobox","aria-expanded":y.isExpanded,"aria-haspopup":"listbox","aria-label":y.ariaLabel,...ne(l),children:[i("div",{"data-testid":"sds-dropdown-menu-title",className:h(IS,kS),children:y.children}),i("div",{className:MS,children:i(De,{size:24,name:y.isExpanded?"chevron-up":"chevron-down"})})]});return x(pe,{children:[i("div",{"data-testid":"sds-dropdown-menu-container",className:h("sdsm-filter-dropdown-menu",XD),children:i(es,{placeholderText:e,selectedItemId:n,items:p,ariaLabel:e,buttonComponent:u})}),x("div",{"data-testid":"sds-dropdown-menu-container-mobile",className:ZD,...ne(l),children:[i("select",{"data-testid":"sds-dropdown-menu-mobile",className:h(e2,IS,{[kS]:o,[t2]:!o}),value:n,onChange:d,"aria-label":e,children:p.map(({title:y,id:m})=>i("option",{value:m,children:y},m))}),i("div",{className:MS,children:i(De,{name:"chevron-down"})})]})]})};TS.displayName="FilterDropdownMenu";var Ao=T(w());var Gu=T(w());var n2=({links:e,isUrlCurrent:t,focusSection:o,isRTL:n})=>{let a=(0,Gu.useRef)([]),{Anchor:s}=(0,Gu.useContext)(He),l=u=>y=>{if(y.key==="ArrowDown"){let m=a.current[u+1];m&&m.focus()}if(y.key==="ArrowUp"){let m=a.current[u-1];m&&m.focus()}y.key===(n()?"ArrowRight":"ArrowLeft")&&o()},p=u=>()=>{Su(u)&&requestAnimationFrame(()=>window.scrollTo(0,0))},d=(u,y)=>{let m={ref:f=>{a.current[y]=f},onKeyDown:l(y),onClick:p(u.url),role:"menuitem"},g=t?.(u.url)?"page":void 0;return i(s,{href:u.url,target:u.inNewTab?"_blank":void 0,rel:u.inNewTab?"noopener":void 0,...m,"aria-current":g,children:u.title})};return i(pe,{children:e.map((u,y)=>{let m=t?.(u.url);return i("li",{className:h(j_,{[X_]:m}),...ne(u.dataset),children:d(u,y)},y)})})};var AS=(0,Ao.memo)(({className:e,items:t,isUrlCurrent:o,dataset:n,motifScheme:a,backgroundColor:s,motifSchemeMobile:l,mobileBackgroundColor:p,onSectionClick:d})=>{Y("sdsm-side-navigation");let u=(0,Ao.useContext)(Ze),{formatMessage:y}=(0,Ao.useContext)(qe),{width:m}=Sn(),g=md(u),f=(0,Ao.useRef)(null),b=(0,Ao.useRef)([]),S=t.findIndex(R=>R.links.find(L=>o?.(L.url))),[C,v]=(0,Ao.useState)(S),[k,I]=(0,Ao.useState)(!g);(0,Ao.useEffect)(()=>{v(S)},[o]);let A=()=>!!f?.current?.closest('[dir="rtl"]'),D=R=>L=>{L.preventDefault();let G=R!==C;v(G?R:null),d?.(t[R]?.title??"unknown",G,t[R]?.id)},B=R=>L=>{if(L.key==="ArrowDown"){let G=b.current[R+1];G&&G.focus()}if(L.key==="ArrowUp"){let G=b.current[R-1];G&&G.focus()}L.key==="ArrowRight"&&v(A()?null:R),L.key==="ArrowLeft"&&v(A()?R:null)},M=R=>{let L=b.current[R];L&&L.focus()},_=()=>{I(!k)},P=(0,Ao.useMemo)(()=>m&&m<=jo,[m]);(0,Ao.useEffect)(()=>{I(!P)},[P]);let $=y({id:"secondaryNavigationLabel",defaultMessage:"Secondary Navigation"});return x("section",{"data-testid":"sdsm-side-navigation",className:h("sdsm-side-navigation",P?l??Pe(p):a??Pe(s),z_,{[U_]:!k},e),children:[x("button",{type:"button","data-testid":"sdsm-side-navigation-mobile-toggle","aria-label":t[S]?.title??$,className:J_,onClick:_,children:[i("span",{children:t[S]?.title??$}),i(De,{className:Z_,name:k?"chevron-up":"chevron-down"})]}),i("nav",{"data-testid":"sdsm-side-navigation-links","aria-label":$,ref:f,className:W_,style:{display:k?"block":"none"},...ne(n),children:i("ul",{role:"menubar","aria-label":$,children:t.map((R,L)=>{let G=R.links.some(Z=>o?.(Z.url));return x("li",{children:[x("button",{ref:Z=>{b.current[L]=Z},type:"button",onKeyDown:B(L),onClick:D(L),role:"menuitem","aria-haspopup":t[L].links.length>0,"aria-expanded":C===L,className:h(Q_,{[q_]:C===L,[K_]:G}),tabIndex:0,"aria-label":R.title,children:[i("span",{...ne(R.dataset),children:R.title}),x("span",{className:Y_,children:[i(De,{className:Mu,name:C===L?"chevron-up":"chevron-down",size:18}),i(De,{className:Mu,name:C===L?"chevron-up":"chevron-down",size:18}),i(De,{className:Mu,name:C===L?"chevron-up":"chevron-down",size:18})]})]}),i("ul",{role:"menu","aria-label":R.title,style:{display:C===L?"block":"none"},children:i(n2,{links:R.links,isUrlCurrent:o,focusSection:()=>M(L),isRTL:A})})]},L)})})})]})});AS.displayName="SideNavigation";var r2=c`
  color: ${r("--footer-bar-fg-color")};
  background-color: ${r("--footer-bar-bg-color")};
  border-top: 1px solid ${r("--footer-bar-divider-border-color")};
  display: flex;
  justify-content: center;
`,a2=c`
  display: flex;
  justify-content: center;
  max-width: ${Qt}px;
  width: 100%;
`,i2=c`
  @media screen and (min-width: ${dt+1}px) {
    padding-inline-start: ${To}px;
  }
`,lfe=c`
  max-width: unset;
`,s2=c`
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  max-width: ${dt}px;
  padding-block: ${r("--spacing-xl")};
  position: relative;
  white-space: nowrap;
  width: 100%;

  ${H} {
    padding-block: ${r("--spacing-s")};
    padding-inline: ${r("--spacing-xl")};
  }

  ${vo} {
    gap: 27px;
    padding-block: ${r("--spacing-l")};
    padding-inline: ${r("--spacing-xxxxl")};
  }

  ${bn} {
    flex-direction: row;
    gap: 0;
    padding-inline: ${r("--spacing-xxxxl")};

    div {
      width: auto;
    }
  }

  ${N} {
    gap: 0;
    padding-inline: ${r("--spacing-xl")};
  }
`;var _S=({children:e,backgroundColor:t,hasSideNav:o})=>i("div",{"data-testid":"footer-bar",className:h(Rk,Pe(t),r2),children:i("div",{className:h(Ek,a2,{[i2]:o}),children:i("div",{className:h(Nk,s2),children:e})})});var I2=T(w());var l2=T(w()),Fa=(0,l2.createContext)({});var p2=c`
  border-top-color: ${r("--footer-border-color")};
  border-top-style: solid;
  border-top-width: 1px;
  color: ${r("--footer-fg-color")};
  background-color: ${r("--footer-bg-color")};
  display: flex;
  justify-content: center;
`,c2=c`
  display: flex;
  justify-content: center;
  max-width: ${Qt}px;
  width: 100%;
`,d2=c`
  @media screen and (min-width: ${dt+1}px) {
    padding-inline-start: ${To}px;
  }
`,bi=c`
  box-sizing: border-box;
  display: flex;
  flex-wrap: wrap;
  gap: ${r("--spacing-m")};
  max-width: ${dt}px;
  padding-block: ${r("--spacing-xl")};
  padding-inline: ${r("--spacing-l")};
  width: 100%;

  ${vo} {
    padding-inline: ${r("--spacing-xxxxl")};
  }

  ${bn} {
    padding-inline: ${r("--spacing-xxxxl")};
  }
`,u2=c`
  justify-content: space-between;
`,y2=c`
  box-sizing: border-box;
`,m2=c`
  align-items: center;
  border-top: 1px solid ${r("--footer-divider-border-color")};
  color: ${r("--footer-fg-color")};
  background-color: ${r("--footer-bg-color")};
  display: block;
  padding-block: ${r("--spacing-xl")} ${r("--spacing-xl")};
  padding-inline: ${r("--spacing-xl")};
`,g2=c`
  > div {
    width: 100%;
  }
`,f2=c`
  > div {
    width: calc((100% - ${r("--spacing-m")}) / 2);
  }
`,b2=c`
  > div {
    width: calc((100% - (${r("--spacing-m")} * 2)) / 3);
  }
`,S2=c`
  > div {
    width: calc((100% - (${r("--spacing-m")} * 3)) / 4);
  }
`,h2=c`
  > div {
    width: calc((100% - (${r("--spacing-m")} * 4)) / 5);
  }

  ${bn} {
    > div {
      width: calc((100% - (${r("--spacing-m")} * 5)) / 6);
    }
  }
`;var C2=({hasSideNav:e,children:t})=>{let o=h(bi),n=Array.isArray(t)?t.filter(a=>!!a).length:1;switch(n){case 1:o=h(bi,g2);break;case 2:o=h(bi,f2);break;case 3:o=h(bi,b2);break;case 4:o=h(bi,S2);break;default:o=h(bi,h2);break}return n<=6&&(o=h(o,u2)),i("article",{"data-testid":"footer-columns-desktop",className:h(Fk,p2),children:i("div",{className:h(Bk,c2,{[d2]:e}),children:i("div",{className:o,children:t})})})};var x2=T(w());var v2=({children:e,backgroundColor:t})=>{let[o,n]=(0,x2.useState)();return i(Fa.Provider,{value:{mode:lt.Mobile,expandedItem:o,setExpandedItem:n},children:i("div",{"data-testid":"footer-columns-mobile",className:h(Pe(t),m2,y2),children:e})})};var k2=({children:e,...t})=>{let{mode:o}=(0,I2.useContext)(Fa);return o===lt.Mobile?i(v2,{...t,children:e}):i(C2,{...t,children:e})};var vp=T(w());var M2=c`
  font-weight: ${r("--footer-bar-header-font-weight")};
  text-transform: ${r("--footer-bar-header-mobile-font-text-transform")};
  padding-inline-end: ${r("--spacing-xl")};
  word-break: break-word;

  ${H} {
    padding-inline-end: 0;
    text-transform: ${r("--footer-bar-header-desktop-font-text-transform")};
  }
`,T2=c`
  ${H} {
    margin-block-end: ${r("--spacing-xs")};
  }
`,A2=c`
  border-bottom: 1px solid ${r("--footer-border-color")};
  font-size: ${r("--footer-desktop-font-size")};
  line-height: 16px;
  padding-block: ${r("--spacing-m")};
  padding-inline: 0 ${r("--spacing-m")};
  color: ${r("--fg-color")};

  &:first-child {
    padding-block-start: ${r("--spacing-s")};
  }

  &:last-child {
    border-bottom: 0;
  }

  ${H} {
    border-bottom: 0;
    padding-bottom: ${r("--spacing-xxs")};
    padding-inline: 0;
    padding-top: 0;

    &:first-child {
      padding-block-start: 0;
    }
  }

  ${N} {
    font-size: ${r("--footer-mobile-font-size")};
    font-weight: ${r("--action-mobile-font-weight")};
  }
`,wS=c`
  display: flex;
  flex-direction: column;
  list-style-type: none;
  margin: 0;
  padding-block: ${r("--spacing-s")} 0;
  padding-inline: 0;
  width: 100%;

  ${H} {
    padding: 0;
  }
`,zu=c`
  a {
    margin-inline: 0;
    white-space: unset;
  }

  li {
    margin: 0;
  }

  align-items: flex-start;
  border: 0;
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-m")};
  padding-block: ${r("--spacing-s")};

  ${H} {
    align-items: center;
    flex-direction: row;
    gap: ${r("--spacing-l")};
    padding-block: 0;

    &:first-child {
      padding-block-start: 0;
    }
  }

  ${bn} {
    &:first-child {
      margin-inline-start: 0;
    }

    &:last-child {
      margin-inline-end: 0;
    }
  }
`;var _2=({id:e,children:t,title:o,orientation:n="Vertical",isFooterBar:a,onToggle:s})=>{let{mode:l}=(0,vp.useContext)(Fa),p=h(A2,{[zu]:n==="Horizontal"}),d=h(M2,{[T2]:n==="Vertical"}),u=(0,vp.useMemo)(()=>o?typeof o!="string"?o:i("div",{className:d,children:i("span",{children:o})}):null,[o,d]),y=(0,vp.useMemo)(()=>t?i("ul",{className:h(wS,{[zu]:n==="Horizontal"}),children:t}):null,[t,n]);return a&&l===lt.Mobile?i("ul",{className:h(wS,{[zu]:n==="Horizontal"}),children:t}):l===lt.Mobile?i(ln,{showChevron:!!o,summary:o,summaryProps:{className:d},className:p,fadeInAnimation:!0,transitionDurationMs:300,disableScrollToOnOpen:a,summaryOnClick:()=>{s?.(e,typeof o=="string"?o:"unknown")},children:y}):x("div",{"data-testid":"footer-group",className:p,children:[u,y]})};var P2=T(w());var w2=c`
  margin: ${r("--spacing-s")} 0;

  ${H} {
    margin: ${r("--spacing-xxs")} 0;
  }
`,D2=c`
  color: ${r("--action-text-default-color")};
  /* Set font-family here or the var from the default motif is used */
  font-family: ${r("--font-family")};
  font-size: ${r("--footer-desktop-font-size")};
  font-weight: ${r("--action-desktop-font-weight")};
  text-decoration: none;
  white-space: pre-wrap;

  @media (hover: hover) {
    &:hover {
      color: ${r("--action-text-hover-color")};
      text-decoration: underline;
      text-decoration-thickness: ${r("--spacing-xxxs")};
      text-underline-offset: ${r("--spacing-xxxs")};
    }
  }

  ${H} {
    margin: 0;
    margin-inline-end: ${r("--spacing-s")};
  }
`;var N2=({id:e,url:t,title:o,onClick:n})=>{let{Anchor:a}=(0,P2.useContext)(He);return i("li",{"data-testid":"footer-item",id:e,className:w2,children:i(a,{href:t,onClick:n,className:D2,children:o})})};var E2=c`
  color: ${r("--footer-fg-color")};
  background-color: ${r("--footer-bg-color")};
  border-top-color: ${r("--footer-divider-border-color")};
  border-top-style: solid;
  border-top-width: 2px;
  display: flex;
  justify-content: center;
  width: 100%;
`,R2=c`
  display: flex;
  justify-content: center;
  max-width: ${Qt}px;
  width: 100%;
`,F2=c`
  @media screen and (min-width: ${dt+1}px) {
    padding-inline-start: ${To}px;
  }
`,B2=c`
  align-items: center;
  color: ${r("--fg-color")};
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  gap: ${r("--spacing-l")};
  max-width: ${dt}px;
  padding-block: ${r("--spacing-m")};
  padding-inline: ${r("--spacing-xl")};
  position: relative;
  width: 100%;

  ${H} {
    flex-direction: row;
    justify-content: center;
    padding-block: ${r("--spacing-m")};
    padding-inline: ${r("--spacing-xxxxl")};
  }
`,$2=c`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: ${r("--spacing-s")};
`;var L2=({title:e,hasSideNav:t,children:o})=>i("section",{"data-testid":"footer-social",className:h($k,E2),children:i("div",{className:h(Lk,R2,{[F2]:t}),children:x("div",{className:B2,children:[e&&i("h5",{children:e}),i("div",{className:$2,children:o})]})})});var Uu=({children:e,motifScheme:t,backgroundColor:o,className:n})=>{let a=Yo();return Y("sdsm-footer"),i(Fa.Provider,{value:{mode:a},children:i("footer",{"data-testid":"footer-v2",className:h("sdsm-footer",t??Pe(o),n),children:e})})};var H2=c`
  box-sizing: border-box;
  display: flex;
  gap: 0.25em;
  margin: 0 auto ${r("--spacing-m")};
  max-width: ${dt}px;
  padding: 0 ${r("--spacing-xl")};
  ${qt}

  ${N} {
    padding: 0 ${r("--spacing-m")};
  }

  p {
    margin-bottom: 0;
  }

  a {
    ${qt}

    ${H} {
      font-weight: ${r("--hyperlink-desktop-font-weight")};
    }

    ${N} {
      font-weight: ${r("--hyperlink-mobile-font-weight")};
    }
  }
`,V2=c`
  font-size: 10px;
  line-height: 18px;
`;var DS=({index:e,children:t})=>(Y("sdsm-footnote"),x("div",{"data-testid":"sdsm-footnote",className:h("sdsm-footnote",H2),children:[i("span",{className:V2,children:x(np,{children:[e," "]})}),i("span",{children:t})]}));DS.displayName="Footnote";var Ba=T(w());var O2=c`
  background-color: ${r("--footnote-bg-color")};
  border-top: 1px solid ${r("--footnote-border-color")};
`,G2=c`
  color: ${r("--footnote-fg-color")};
  margin: 0px auto;
  max-width: ${dt}px;
  padding: 0 ${r("--spacing-xl")};

  ${N} {
    padding: 0 ${r("--spacing-m")};
  }
`,z2=c`
  display: none;

  @media print {
    display: block;
    padding-block: ${r("--spacing-l")};
  }
`,U2=c`
  padding-bottom: 0;

  @media print {
    display: none;
  }
`,PS=c`
  color: ${r("--footnote-title-color")};
  font-size: ${r("--h6-desktop-font-size")};
  font-weight: 500;
  height: 92px;
  line-height: 28px;
  margin: 0 auto;
  max-width: ${dt}px;
  padding-inline-start: ${r("--spacing-xl")};

  ${N} {
    padding: 0 ${r("--spacing-m")};
  }

  & > svg {
    background-color: transparent;
    border-radius: 100%;
    height: 32px;
    padding: 6px;
    transition: background-color 0.2s linear;
    width: 32px;
  }

  &:hover {
    & > svg {
      background-color: ${r("--footnote-hover-icon-bg-color")};
    }
  }
`,W2=c`
  padding-bottom: ${r("--spacing-m")};
`;var Q2="White",Hq=300,Vq={className:zd,fill:r("--icon-color")},Oq={className:PS},NS=({title:e,isOpenInitially:t,children:o,className:n})=>{let[a,s]=(0,Ba.useState)(t),l=(0,Ba.useRef)(null),p=(0,Ba.useCallback)(()=>{s(d=>!d)},[]);return Ba.Children.count(o)===0?null:i("footer",{"data-testid":"sdsm-footnotes",className:h(O2,n),children:x("div",{className:G2,children:[x("div",{className:z2,children:[i("h2",{className:PS,children:e}),o]}),i(ln,{summary:e,detailsRef:l,chevronProps:Vq,className:U2,summaryProps:Oq,onToggle:p,fadeInAnimation:!0,transitionDurationMs:Hq,open:a,children:i("div",{className:W2,children:o})})]})})};NS.displayName="FootnoteBlock";var zn=T(w());var Y2=T(w());var q2={Email:new RegExp('^$|^(([^<>()[\\]\\.,;:\\s@"]+(\\.[^<>()[\\]\\.,;:\\s@"]+)*)|(".+"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]{1,24}\\.)+[a-zA-Z]{2,}))$'),Name:/^(?!\s*$).+/,"Email (English only)":/^[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i};function K2(e){if(e.error)return!1;for(let t of Object.keys(e.fields))if(e.fields[t]&&e.fields[t].hasError)return!1;return!0}var ES=(e,t)=>e.required&&(Array.isArray(t)&&t.length===0||!Array.isArray(t)&&(String(t).trim()===""||!t))?!0:!e.validation||!q2[e.validation]||typeof t!="string"?!1:!q2[e.validation].test(t),Wu={type:"initial",fields:{},formBody:{}};function j2(e,t){switch(e=Fo(e),t.type){case"registerField":{let o=tr(e.fields[t.name]??{},t.field);e.fields[t.name]=o,e.formBody[t.name]=t.field.initialValue,e.type!=="initial"&&(o.hasError=ES(o,t.field.initialValue));break}case"changeFieldValue":{e.lastChangedFieldName=t.name,e.formBody=Fo(e.formBody),e.formBody[t.name]=t.value,e.fields[t.name]||(e.fields[t.name]={});let o=e.fields[t.name];o.hasError=ES(o,t.value),e.type=K2(e)?"ready":"invalid",e.error=void 0;break}case"invalidateField":{e.fields[t.name].hasError=!0,e.type="invalid";break}case"submitTrigger":{for(let o of Object.keys(e.fields)){let n=e.fields[o];n&&(n.hasError=ES(n,e.formBody[o]))}e.type=K2(e)?"submitting":"invalid";break}case"submitFailure":{e.type="submitFailure",e.errorStatusCode=t.errorStatusCode,e.error=t.error;break}case"submitSuccess":{e.type="submitSuccess",e.formBody={};for(let o of Object.keys(e.fields)){let n=e.fields[o];n.hasError=!1,e.formBody[o]=n.shouldResetToInitial?n.initialValue:void 0}e.error=void 0;break}default:throw new Error(`Unhandled action type for ${JSON.stringify(t)}`)}return e}var mo=(0,Y2.createContext)({state:Wu,dispatch:xo});var yP=T(w());var X2=c`
  display: flex;
  align-items: center;
  flex-direction: column;
  width: 100% !important;
  max-width: 650px;
  margin: auto;
  /* extra margin for button shadow */
  margin-bottom: ${r("--spacing-m")};
`,J2=c`
  display: flex;
  align-items: flex-start;
  column-gap: ${r("--form-grid-gap")};
  width: 100%;

  /* Add extra top spacing if there is a label */
  &:not(:first-child) label {
    margin-top: ${r("--spacing-m")};
  }

  ${N} {
    flex-direction: column;
  }
`,Z2=c`
  margin-bottom: ${r("--spacing-xs")};
`,RS=c`
  ${ut}
  color: ${r("--form-input-placeholder-color")};
  margin-top: ${r("--spacing-xs")};
`,Ip=c`
  ${RS}

  color: ${r("--form-input-error-color")};
`,eP=c`
  width: 100%;
  text-align: center;
  margin-top: ${r("--spacing-m")};
`,tP=c`
  display: block;
  text-align: start;
  border: ${r("--form-input-border-width")} solid ${r("--form-input-border-color")};
  border-radius: ${r("--spacing-m")};
  background-color: ${r("--form-input-bg-color")};
  box-shadow: ${r("--form-input-box-shadow")};
  color: ${r("--form-input-error-color")};
  margin-top: ${r("--spacing-s")};
  padding: ${r("--spacing-m")};
  word-wrap: break-word;
`,oP=c`
  justify-content: center;

  margin-top: ${r("--spacing-xl")};
  margin-bottom: ${r("--spacing-xl")};

  ${N} {
    width: 100%;
    max-width: 350px;
    margin-top: ${r("--spacing-m")};
    margin-bottom: ${r("--spacing-m")};
  }
`,nP=c`
  display: flex;
  flex-direction: column;
  width: 100%;
  margin-bottom: ${r("--spacing-m")};

  *[dir='rtl'] & > select {
    background-position: left ${r("--spacing-l")} top 50%;
  }
`,Xr=c`
  border: ${r("--form-input-border-width")} solid ${r("--form-input-error-color")};

  &:hover {
    border: ${r("--form-input-border-width")} solid ${r("--form-input-error-color")};
  }
`,FS=c`
  cursor: not-allowed;
  opacity: 0.8;
`,_s=c`
  background-color: ${r("--form-input-bg-color")};
  border: ${r("--form-input-border-width")} solid ${r("--form-input-border-color")};
  border-radius: ${r("--form-input-border-radius")};
  box-shadow: ${r("--form-input-box-shadow")};
  box-sizing: border-box;
  color: ${r("--form-input-fg-color")};
  font-family: ${r("--font-family")};
  height: 52px;
  padding: ${r("--form-input-padding")};
  width: 100%;

  &[readonly] {
    ${FS}
  }

  &:active,
  &:focus {
    border-color: ${r("--form-input-active-border-color")};
    box-shadow: ${r("--form-input-active-box-shadow")};
  }

  &:focus-visible {
    outline: ${r("--form-input-border-width")} solid ${r("--form-input-active-border-color")};
    outline-offset: -2px;
  }

  &:hover {
    border-color: ${r("--form-input-hover-border-color")};
    box-shadow: ${r("--form-input-hover-box-shadow")};
  }

  &[type='number']::-webkit-inner-spin-button {
    opacity: 1;
  }

  &[type='date']::-webkit-calendar-picker-indicator {
    filter: invert(50%);
  }

  ${H} {
    font-size: ${r("--form-input-desktop-font-size")};
    line-height: ${r("--form-input-desktop-font-line-height")};
    font-weight: ${r("--form-input-desktop-font-weight")};
    font-stretch: ${r("--form-input-desktop-font-stretch")};
  }

  ${N} {
    font-size: ${r("--form-input-mobile-font-size")};
    line-height: ${r("--form-input-mobile-font-line-height")};
    font-weight: ${r("--form-input-mobile-font-weight")};
    font-stretch: ${r("--form-input-mobile-font-stretch")};
  }
`,Gq="M4.95801 10.8631C4.43001 10.8631 3.91701 10.6511 3.54301 10.2771L0.293006 7.02713C-0.0979941 6.63613 -0.0979941 6.00413 0.293006 5.61313C0.684006 5.22213 1.31601 5.22213 1.70701 5.61313L4.95701 8.86313L12.253 0.655126C12.619 0.242126 13.251 0.205126 13.664 0.572126C14.077 0.940126 14.114 1.57113 13.747 1.98513L6.45201 10.1921C6.08701 10.6021 5.56301 10.8461 5.01601 10.8621C4.99601 10.8631 4.97701 10.8631 4.95801 10.8631Z",rP=c`
  appearance: none;
  background-color: ${r("--form-input-bg-color")};
  border: ${r("--form-input-border-width")} solid ${r("--form-input-border-color")};
  border-radius: ${r("--form-input-checkbox-border-radius")};
  display: grid;
  font: inherit;
  height: 20px;
  margin: 0;
  place-content: center;
  width: 20px;

  &::before {
    box-shadow: inset 1em 1em ${r("--palette-plain-white")};
    clip-path: path('${Gq}');
    content: '';
    height: 20px;
    margin: 8px 0px 0px 6px;
    transform: scale(0);
    width: 20px;
  }

  &:checked::before {
    transform: scale(1);
  }

  &:checked {
    background-color: ${r("--form-input-active-border-color")};
    border-width: ${r("--border-width-none")};
    box-shadow: ${r("--form-input-active-box-shadow")};
  }

  &:focus-visible {
    outline: ${r("--form-input-border-width")} solid ${r("--form-input-active-border-color")};
    outline-offset: -2px;
  }

  &:not(:checked):hover {
    border-color: ${r("--form-input-hover-border-color")};
    box-shadow: ${r("--form-input-hover-box-shadow")};
  }

  &[required]:not(:checked)::before {
    border-color: ${r("--form-input-error-color")};
  }

  &[readonly] {
    ${FS}
  }
`,aP=c`
  && {
    align-items: center;
    display: flex;
    gap: ${r("--spacing-s")};

    label {
      align-items: center;
      display: flex;
      justify-content: center;
      margin-top: 0;

      a {
        &,
        &:hover,
        &:visited {
          /* TODO: See if this should be hyperlink color or its own */
          color: ${r("--fg-color")};
          /* Ensure hyperlinks are displayed in the same font size and weight as the label */
          font-size: inherit;
          font-weight: inherit;
        }
      }

      /* Remove margin from the paragraph inside the label */
      p {
        margin: 0;
      }
    }
  }
`,iP=c`
  appearance: none;
  ${_s}
  font-family: ${r("--font-family")};
  height: 133px;
  padding: ${r("--form-input-padding")};
  resize: vertical;
  /* Add custom resizer icon as background */
  background-image: url("data:image/svg+xml,%3Csvg height='9' viewBox='0 0 9 9' width='9' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M5 8L8 5M1 8L8 1' stroke='rgba(133, 141, 148, 1)'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: bottom 4px right 4px;

  &::-webkit-resizer {
    display: none;
  }

  &[readonly] {
    ${FS}
  }

  /* Change custom resizer icon position according to RTL */
  *[dir='rtl'] & {
    background-image: url("data:image/svg+xml,%3Csvg height='9' viewBox='0 0 9 9' transform='scale(-1 1)' width='9' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M5 8L8 5M1 8L8 1' stroke='rgba(133, 141, 148, 1)'/%3E%3C/svg%3E");
    background-position: bottom 4px left 4px;
  }
`,sP=c`
  ${_s}
  appearance: none;
  height: auto;

  &:-ms-expand {
    display: none;
  }

  &:has(option:disabled:checked) {
    color: ${r("--form-input-placeholder-color")};
  }
`,Qu=c`
  position: relative;

  i {
    margin-left: 10px;
    width: 10px;
    cursor: pointer;

    svg {
      fill: ${r("--palette-gray-v300")};
    }
  }
`,Jr=c`
  input::-webkit-input-placeholder,
  textarea::-webkit-input-placeholder,
  input:-moz-placeholder,
  textarea:-moz-placeholder,
  input::-moz-placeholder,
  textarea::-moz-placeholder,
  input:-ms-input-placeholder,
  textarea:-ms-input-placeholder,
  input::-ms-input-placeholder,
  textarea::-ms-input-placeholder,
  input::placeholder,
  textarea::placeholder,
  ::placeholder {
    color: ${r("--form-input-placeholder-color")};
  }
`,lP=c`
  pointer-events: none;
  position: absolute;
  right: ${r("--spacing-l")};
  top: calc(50% - 5px);
  width: 20px;
  height: 20px;
  margin: -4px;
  fill: ${r("--form-input-fg-color")};

  html[dir='rtl'] & {
    right: unset;
    left: ${r("--spacing-l")};
  }
`,pP=c`
  pointer-events: none;
  position: absolute;
  right: ${r("--spacing-l")};
  top: calc(50% - 5px);
  width: 20px;
  height: 20px;
  margin: -4px;
  fill: ${r("--multi-select-fg-color")};

  html[dir='rtl'] & {
    right: unset;
    left: ${r("--spacing-l")};
  }
`,cP=c`
  ${_s}
  height: auto;
  padding: 0;

  /** applies styles to multi select wrapper when displaying options */
  &:has(.displayBlock) {
    border-color: ${r("--form-input-active-border-color")};
    box-shadow: ${r("--form-input-active-box-shadow")};
  }

  .searchWrapper {
    color: ${r("--multi-select-fg-color")};

    .chip {
      background: ${r("--multi-select-chip-bg-color")};
      color: ${r("--form-input-fg-color")};

      svg {
        fill: ${r("--form-input-fg-color")};
      }
    }
  }

  .optionListContainer .option {
    color: ${r("--multi-select-option-fg-color")};

    &.selected,
    &.highlight,
    &:hover {
      background: ${r("--multi-select-chip-bg-color")};
      color: ${r("--multi-select-option-fg-color")};
    }

    input[type='checkbox'] {
      &:checked {
        accent-color: ${r("--multi-select-option-fg-color")};
      }
    }
  }
`,dP=c`
  & p:last-of-type {
    display: inline-block;
  }

  &::after {
    color: ${r("--form-input-error-color")};
    content: '*';
  }
`,uP=c`
  ${qk}
  ${qt}
  color: ${r("--form-description-fg-color")};
  font-style: italic;
  font-weight: ${r("--action-desktop-font-weight")};
  text-align: start;
  width: 100%;
`;var mP=({renderErrorMessage:e,on400ResponseMessage:t,on500ResponseMessage:o,onInvalidClientSideSubmissionMessage:n,renderErrorDetails:a})=>{let{state:s}=(0,yP.useContext)(mo),{errorStatusCode:l,error:p,type:d}=s;if(d==="invalid")return i("div",{className:Ip,children:n});if(!p)return null;let u;l===void 0?u=null:e?u=e?.(l):u=l===400?t:o;let y=JSON.stringify({name:p.name,message:p.message,callStack:p.stack},null,2);return x(pe,{children:[i("div",{className:Ip,children:u}),a&&x("div",{className:eP,children:[i("h6",{children:"Error Object"}),i("code",{className:tP,children:y})]})]})};var gP=T(w());var fP=({formRequiredFieldsMessage:e})=>{let{state:t}=(0,gP.useContext)(mo);return!Object.values(t?.fields??{}).some(n=>n.required)||!e?null:i("p",{className:uP,children:e})};var BS=({className:e,children:t,endpoint:o,submitText:n,submitSuccessText:a,submitTextDataset:s,onSubmitSuccess:l,onSubmitFailure:p,onFormBodyChange:d,formChildrenRenderer:u,extraParams:y,extraParamsAsync:m,on400ResponseMessage:g,on500ResponseMessage:f,renderErrorMessage:b,onInvalidClientSideSubmissionMessage:S,formRequiredFieldsMessage:C,renderErrorDetails:v=!1})=>{Y("sdsm-form");let[k,I]=(0,zn.useReducer)(j2,Io(Wu)),A=(0,zn.useMemo)(()=>({state:k,dispatch:I}),[k,I]);(0,zn.useEffect)(()=>{d?.(Io(k.formBody),k.lastChangedFieldName,k.type==="initial",k.type==="submitting"||k.type==="submitSuccess"||k.type==="submitFailure")},[d,k.formBody,k.lastChangedFieldName,k.type]);let D=(0,zn.useCallback)(R=>{R?.preventDefault(),I({type:"submitTrigger"})},[]);(0,zn.useEffect)(()=>{if(k.type!=="submitting")return;async function R(){let L=await m?.().catch(()=>({}))??{},G=tr({},k.formBody,y,L);try{let Z=await fetch(o,{method:"POST",body:JSON.stringify(G),headers:{"Content-Type":"application/json"}});if(I({type:"submitTrigger"}),Z.ok)I({type:"submitSuccess"}),l?.(Z,G);else{let U=await Z.text(),de=new Error(`Form submit failed. Server Response: ${Z.status} ${Z.statusText}.\r
 ${U}`);I({type:"submitFailure",errorStatusCode:Z.status,error:de}),p?.(de,G,Z)}}catch(Z){let U=Ft(Z);I({type:"submitFailure",error:U}),p?.(U,G)}}R()},[o,y,m,p,l,k.formBody,k.type]);let B=k.type==="submitting"||k.type==="submitSuccess"||Object.values(k.fields).some(R=>R.hasError)||jl(k.fields),M=k.type==="submitting",_=k.type==="submitSuccess",P=k.type==="submitSuccess"?a:n,$;return u?$=(0,zn.createElement)(u,{handleSubmit:D,disabled:B,loading:M,submitSuccess:_}):$=x(pe,{children:[t,i(no,{nativeButtonType:"submit",onClick:D,type:rn.Primary,size:"Large",disabled:B,loading:M,className:oP,buttonTextDataset:s,children:P})]}),i(mo.Provider,{value:A,children:x("form",{className:h("sdsm-form",X2,Jr,e),noValidate:!0,children:[i(fP,{formRequiredFieldsMessage:C}),$,i(mP,{renderErrorMessage:b,on400ResponseMessage:g,on500ResponseMessage:f,onInvalidClientSideSubmissionMessage:S,renderErrorDetails:v})]})})};var qu=({children:e,...t})=>i("div",{className:h("sdsm-form-row",J2),...t,children:e});var Zr=T(w());var $a=({type:e,name:t,label:o,helpText:n,error:a,hasError:s,children:l,dataset:p,labelDataset:d,helpTextDataset:u,errorDataset:y,required:m=!1})=>e==="Hidden"?i(pe,{children:l}):x("div",{className:h("sdsm-form-field",h(nP)),...ne(p),children:[o&&e!=="Checkbox"&&i("label",{htmlFor:t,className:h(Sa,Z2,{[dP]:m}),...ne(d),children:o}),l,(n&&!s||n&&s&&!a)&&i("p",{className:RS,...ne(u),children:n}),s&&a&&i("div",{id:`${t}-error`,className:Ip,...ne(y),children:a})]});function yr(e){return e?Array.isArray(e)?e.join(","):String(e):""}function bP(e){return typeof e=="boolean"?e:typeof e=="string"?e==="true":Array.isArray(e)?e.length>0:!1}function ws(e,t){return e&&t?`${e}*`:e}var Ku=(0,Zr.memo)(e=>{let{name:t,validation:o,required:n=!1,placeholder:a="",initialValue:s,type:l="Text",label:p,richLabel:d,labelDataset:u,richLabelDataset:y,readOnly:m,shouldResetToInitial:g,maxLength:f,minValue:b,maxValue:S,...C}=e,{state:v,dispatch:k}=(0,Zr.useContext)(mo),I=v.fields[t],A=v.formBody[t],D=Vt(C,"dataset","helpText","helpTextDataset","errorDataset","contentfulDescriptionDataset");(0,Zr.useEffect)(()=>{k({type:"registerField",name:t,field:{initialValue:s,validation:o,required:n,shouldResetToInitial:l==="Hidden"||g}})},[k,s,t,n,o,l,g]);let B=(0,Zr.useCallback)($=>{let R=$.target,G=R.type==="checkbox"?R.checked:R.value;k({type:"changeFieldValue",name:t,value:G})},[k,t]),M=(0,Zr.useCallback)(()=>{k({type:"invalidateField",name:t})},[k,t]),_=ws(a,n&&!d&&!p&&!I?.hasError),P=()=>l==="Textarea"?i("textarea",{name:t,placeholder:_,value:yr(A),className:h(iP,Jr,{[Xr]:I?.hasError}),required:n,onInvalid:M,readOnly:m,onChange:B,onBlur:B,maxLength:f??600,"aria-describedby":I?.hasError?`${t}-error`:void 0,"aria-invalid":I?.hasError??!1,...D}):l==="Checkbox"?x("div",{className:aP,children:[i("input",{type:"checkbox",name:t,id:t,onInvalid:M,placeholder:a,checked:bP(A),className:h(rP,Jr,{[Xr]:I?.hasError}),required:n,onChange:B,onBlur:B,readOnly:m,"aria-describedby":I?.hasError?`${t}-error`:void 0,"aria-invalid":I?.hasError??!1,...D}),i("label",{htmlFor:t,...ne(d?y:u),children:d??p})]}):l==="Number"||l==="Date"?i("input",{type:l,name:t,placeholder:_,value:yr(A),className:h(_s,Jr,{[Xr]:I?.hasError}),required:n,readOnly:m,onChange:B,onInvalid:M,onBlur:B,min:b,max:S,"aria-describedby":I?.hasError?`${t}-error`:void 0,"aria-invalid":I?.hasError??!1,...D}):i("input",{type:l==="Hidden"?"hidden":"text",name:t,placeholder:_,value:yr(A),className:h(_s,Jr,{[Xr]:I?.hasError}),required:n,readOnly:m,onChange:B,onInvalid:M,onBlur:B,maxLength:f,"aria-describedby":I?.hasError?`${t}-error`:void 0,"aria-invalid":I?.hasError??!1,...D});return i($a,{...e,label:d??p,hasError:I?.hasError??!1,type:l??"Hidden",children:P()})});Ku.displayName="Input";var Ds=T(w());var _P=T(vP()),pn=T(w()),wP=T(ma());var IP=c`
  position: relative;

  i {
    margin-left: 10px;
    width: 10px;
    cursor: pointer;
  }
`,kP=c`
  height: auto;
  padding: 0;

  .displayNone {
    display: none;
  }

  .searchWrapper {
    padding: 0 ${r("--spacing-xxl")} 0 ${r("--spacing-xs")};
    border: 0;
    min-height: 50px;
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    color: ${r("--multi-select-fg-color")};

    input {
      color: inherit;
      font-size: inherit;
      cursor: default;
      min-width: 0px;
      padding-left: ${r("--spacing-xs")};
      flex: 1 1 0%;
    }

    .chip {
      background: ${r("--multi-select-chip-bg-color")};
      color: ${r("--multi-select-fg-color")};
      font-size: inherit;
      padding: ${r("--spacing-xs")};
      margin: 5px;
      cursor: default;

      svg {
        fill: ${r("--multi-select-fg-color")};
      }
    }

    .icon_down_dir {
      right: -60px;
    }
  }

  .optionListContainer {
    background: ${r("--multi-select-bg-color")};
    border-radius: 0 0 ${r("--border-radius-s")} ${r("--border-radius-s")};
    box-shadow: ${r("--box-shadow-l")};
    list-style-type: none;
    padding-left: ${r("--spacing-xs")};
    padding-right: ${r("--spacing-xs")};
    z-index: 51;

    .optionContainer {
      border: none;

      &::-webkit-scrollbar {
        width: 7px;
      }

      &::-webkit-scrollbar-thumb {
        border-radius: 4px;
        background-color: rgba(0, 0, 0, 0.5);
        box-shadow: 0 0 1px rgba(255, 255, 255, 0.5);
      }
    }

    .option {
      display: flex;
      align-items: center;
      margin-top: ${r("--spacing-xs")};
      margin-bottom: ${r("--spacing-xs")};
      padding-left: ${r("--spacing-m")};
      padding-right: ${r("--spacing-m")};
      border-radius: 5px;
      color: ${r("--multi-select-option-fg-color")};

      &.selected,
      &.highlight,
      &:hover {
        background: ${r("--multi-select-chip-bg-color")};
        color: ${r("--multi-select-option-fg-color")};
      }

      input[type='checkbox'] {
        height: 17px;
        width: 17px;

        &:checked {
          accent-color: ${r("--multi-select-option-fg-color")};
        }
      }
    }
  }
`,MP=c`
  appearance: none;
  background: none;
  border: none;
  padding: 0;
  cursor: pointer;
  position: absolute;
  right: 16px;
  top: 19px;
  width: 20px;
  height: 20px;
  margin: -4px;

  svg {
    width: 100%;
    height: 100%;
    fill: ${r("--multi-select-fg-color")};
  }

  html[dir='rtl'] & {
    right: unset;
    left: 16px;
  }
`,TP=c`
  margin: -7px;

  svg {
    fill: ${r("--multi-select-fg-color")};
  }
`,AP=c`
  cursor: pointer;
  white-space: nowrap;
`;var Yu=({options:e,selectedValues:t,displayValue:o="name",placeholder:n,showCheckbox:a,hidePlaceholder:s=!0,avoidHighlightFirstOption:l=!0,onSelect:p,onRemove:d,onKeyPressFn:u,dropdownClassName:y,wrapperClassName:m,arrowClassName:g,maxVisibleChips:f})=>{Y("sdsm-multi-select");let b=(0,pn.useRef)(null),[S,C]=(0,pn.useState)(null),v=(0,pn.useMemo)(()=>i(De,{name:"cross",className:TP}),[]);(0,pn.useLayoutEffect)(()=>{C(b.current?.querySelector(".searchWrapper")??null)},[]);let k=t?.length??0,I=f!=null&&k>f,A=I?k-f:0,D=(0,pn.useMemo)(()=>{if(I)return c`
      .searchWrapper .chip:nth-child(n + ${f+1}):not([data-overflow]) {
        display: none;
      }
      .searchWrapper input {
        order: 1;
      }
    `},[I,f]),B=(0,pn.useCallback)(P=>{P.preventDefault()},[]),M=(0,pn.useCallback)(()=>{let P=b.current?.querySelector(".searchWrapper input");P&&(document.activeElement===P?P.blur():P.focus())},[]),_=(0,pn.useCallback)(P=>{P.preventDefault()},[]);return x("div",{ref:b,className:h("sdsm-multi-select",IP,m),children:[i(_P.default,{options:e,selectedValues:t,displayValue:o,placeholder:n,showCheckbox:a,hidePlaceholder:s,avoidHighlightFirstOption:l,onSelect:p,onRemove:d,onKeyPressFn:u,className:h(kP,y,D),customCloseIcon:v}),I&&S&&(0,wP.createPortal)(x("span",{className:h("chip",AP),"data-overflow":!0,onMouseDown:_,children:["+",A," more"]}),S),i("button",{type:"button","aria-label":"Toggle dropdown",className:h(MP,g),onMouseDown:B,onClick:M,children:i(De,{name:"chevron-down"})})]})};Yu.displayName="MultiSelect";var Uq=[],Xu=(0,Ds.memo)(e=>{let{name:t,placeholder:o,showCheckbox:n,options:a,required:s=!1,initialValues:l=Uq}=e,{state:p,dispatch:d}=(0,Ds.useContext)(mo),u=p.formBody[t],y=p.fields[t];(0,Ds.useEffect)(()=>{d({type:"registerField",name:t,field:{initialValue:l,required:s}})},[l,d,t,s]);let m=b=>{d({type:"changeFieldValue",name:t,value:b})},g=b=>{b.preventDefault(),b.stopPropagation()},f=b=>{d({type:"changeFieldValue",name:t,value:b})};return i($a,{...e,hasError:y?.hasError,type:"MultiSelect",children:i(Yu,{options:a,selectedValues:u,showCheckbox:n,onSelect:m,onRemove:f,hidePlaceholder:!0,avoidHighlightFirstOption:!0,placeholder:ws(o,!!e.required&&!e.label&&!e.richLabel&&!y?.hasError),displayValue:"name",dropdownClassName:h(cP,Jr,{[Xr]:y?.hasError}),wrapperClassName:Qu,arrowClassName:pP,onKeyPressFn:g})})});Xu.displayName="MultiSelectDropdown";var La=T(w());var Mp=(0,La.memo)(e=>{let{name:t,placeholder:o,children:n,required:a=!1,initialValue:s="",allValues:l=[],shouldResetToInitial:p,fieldDataset:d,...u}=e,y={required:a,...Vt(u,"helpText","helpTextDataset","errorDataset","labelDataset","fieldDataset")},{state:m,dispatch:g}=(0,La.useContext)(mo),f=l.includes(yr(s))?s:"",b=m.fields[t],S=m.formBody[t];(0,La.useEffect)(()=>{g({type:"registerField",name:t,field:{required:a,initialValue:f,shouldResetToInitial:p}})},[g,t,a,f,p]);let C=k=>{g({type:"changeFieldValue",name:t,value:k.target.value})},v=(0,La.useCallback)(()=>{g({type:"invalidateField",name:t})},[g,t]);return i($a,{hasError:b?.hasError,...Vt(e,"dataset"),dataset:d,type:"Select",children:x("div",{className:h(Qu),children:[x("select",{value:yr(S),name:t,className:h(sP,{[Xr]:b?.hasError}),onChange:C,onBlur:C,onInvalid:v,"aria-describedby":b?.hasError?`${t}-error`:void 0,"aria-invalid":b?.hasError??!1,...y,children:[o&&i("option",{value:"",disabled:!0,children:ws(o,a&&!e.label&&!e.richLabel&&!b?.hasError)}),n]}),i(De,{name:"chevron-down",className:lP})]})})});Mp.displayName="Select";var Ju=T(w());var DP=c`
  ${N} {
    display: none;
  }

  ${H} {
    display: block;
  }
`,PP=c`
  ${N} {
    display: block;
  }

  ${H} {
    display: none;
  }
`,Tp=c`
  background: none;
  border: none;
  color: ${r("--fg-color")};
  cursor: pointer;
  padding: 0;
  /* stylelint-disable-next-line property-no-vendor-prefix */
  -webkit-appearance: none;
  appearance: none;
`,HS=c`
  display: flex;
  width: 100%;

  ${H} {
    align-items: center;
    flex-wrap: wrap;
    padding-bottom: 50px;
  }

  ${N} {
    flex-direction: column;
    justify-content: flex-end;
    margin-block: ${r("--spacing-m")};
  }
`,NP=c`
  align-items: center;
  display: flex;
  justify-content: space-between;
  padding-block: ${r("--spacing-m")};
`,VS=c`
  font-size: ${r("--action-desktop-font-size")};
  line-height: ${r("--action-desktop-font-line-height")};

  ${N} {
    font-size: ${r("--action-mobile-font-size")};
    line-height: ${r("--action-mobile-font-line-height")};
  }
`,EP=c`
  font-family: inherit;
  font-weight: ${r("--action-desktop-font-weight")};

  ${N} {
    font-weight: ${r("--action-mobile-font-weight")};
  }
`,RP=c`
  font-weight: ${r("--p1-desktop-font-weight")};

  ${N} {
    font-weight: ${r("--p1-mobile-font-weight")};
  }
`,FP=c`
  align-items: center;
  display: flex;
`,OS=c`
  font-family: inherit;
  font-size: ${r("--action-mobile-font-size")};
  font-weight: ${r("--action-mobile-font-weight")};
  line-height: ${r("--action-mobile-font-line-height")};
  margin-inline-end: ${r("--spacing-m")};

  ${H} {
    padding-block: ${r("--spacing-m")};
    font-size: ${r("--action-desktop-font-size")};
    font-weight: ${r("--action-desktop-font-weight")};
    line-height: ${r("--action-desktop-font-line-height")};
  }
`,BP=c`
  align-items: center;
  display: flex;
  width: ${r("--spacing-l")};
`,$P=c`
  fill: ${r("--fg-color")};
  height: auto;
  transform: rotate(0deg);
  transform-origin: center;
  transition: transform 100ms cubic-bezier(0.4, 0, 0.2, 1);
  width: 100%;
`,LP=c`
  transform: rotate(-180deg);
`;var Ap=({searchMenus:e=[],selectedFilters:t,onChangeFilter:o,mobileFiltersToggleLabel:n,onClearFilters:a,clearButtonLabel:s,mobileFiltersWrapperTextDataset:l,clearFiltersCtaCopyDataset:p})=>{Y("sdsm-gallery");let[d,u]=(0,Ju.useState)(!1),y=()=>u(!d),m=(0,Ju.useMemo)(()=>Object.keys(t).length,[t]);if(e.length===0)return null;let f=e.map(({title:S,id:C,allItemTitle:v,items:k,dataset:I})=>({title:S,id:C,allItemTitle:v,items:k,dataset:I,value:t[C]?t[C]:Ou,onChange:A=>o(C,A)})).map(S=>i(TS,{...S,isStandalone:e.length===1},S.id)),b=n??(e.length>1?"Filters":"Filter");return x("section",{className:"sdsm-gallery",children:[i("aside",{className:DP,children:x("div",{className:HS,children:[f,!!m&&i("button",{"data-testid":"clear-btn-desktop",type:"button",className:h(Tp,OS),onClick:a,...ne(p),children:s??"Clear"})]})}),x("aside",{className:PP,children:[e.length>1&&x("div",{className:NP,"data-testid":"dropdowns-mobile-wrapper",children:[x("div",{children:[i("button",{type:"button",className:h(Tp,VS,EP),onClick:y,...ne(l),children:b}),!!m&&i("span",{"data-testid":"selected-filters-counter-mobile",className:h(VS,RP),children:` (${m})`})]}),x("div",{className:FP,children:[!!m&&i("button",{"data-testid":"clear-btn-mobile",type:"button",className:h(Tp,OS),onClick:a,...ne(p),children:s??"Clear"}),i("button",{type:"button",className:h(Tp,BP),onClick:y,children:i(De,{name:"bars-triangle",className:h($P,{[LP]:d})})})]})]}),(d||e.length===1)&&i("div",{className:HS,children:f})]})]})};Ap.displayName="GalleryFiltersV2";var HP=c`
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;
  gap: ${r("--spacing-m")};
  margin-bottom: ${r("--spacing-m")};
  margin-inline: auto;

  /*
  We are keeping the media queries in addition to the container queries in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${Xe} {
    gap: ${r("--spacing-l")};
    margin-bottom: ${r("--spacing-l")};
  }

  ${fd} {
    gap: ${r("--spacing-m")};
  }

  ${Wf} {
    gap: ${r("--spacing-l")};
    margin-bottom: ${r("--spacing-l")};
  }

  > * {
    width: 100%;

    /*
    We are keeping the media queries in addition to the container queries in case:
    - this component is ever rendered without a wrapping SDS-M Page component
    - the browser does not support container queries (smart TVs, etc.)
    */
    ${H} {
      /* 
      Width calculation assumes 2 cards per line
      {50% of parent width} - { gap size / 2 }
      */
      width: calc(50% - ${r("--spacing-m")} / 2);
    }

    ${Xe} {
      /* 
      Width calculation assumes 2 cards per line
      {50% of parent width} - { gap size / 2 }
      */
      width: calc(50% - ${r("--spacing-l")} / 2);
    }

    ${uo} {
      width: 100%;
    }

    ${li} {
      /* 
      Width calculation assumes 2 cards per line
      {50% of parent width} - { gap size / 2 }
      */
      width: calc(50% - ${r("--spacing-m")} / 2);
    }

    ${Wf} {
      /* 
      Width calculation assumes 2 cards per line
      {50% of parent width} - { gap size / 2 }
      */
      width: calc(50% - ${r("--spacing-l")} / 2);
    }
  }
`;var Ha=({children:e})=>(Y("sdsm-gallery"),i("div",{"data-testid":"sdsm-gallery-grid",className:h("sdsm-gallery",HP),children:e}));Ha.displayName="GalleryGridV2";var Wq=1,Qq=2;function qq(e,t,o,n){var a=o.length,s=a,l=!n;if(e==null)return!s;for(e=Object(e);a--;){var p=o[a];if(l&&p[2]?p[1]!==e[p[0]]:!(p[0]in e))return!1}for(;++a<s;){p=o[a];var d=p[0],u=e[d],y=p[1];if(l&&p[2]){if(u===void 0&&!(d in e))return!1}else{var m=new qI;if(n)var g=n(u,y,d,e,t,m);if(!(g===void 0?Id(y,u,Wq|Qq,n,m):g))return!1}}return!0}var VP=qq;OI();function Kq(e){return e===e&&!ql(e)}var Zu=Kq;function jq(e){for(var t=ld(e),o=t.length;o--;){var n=t[o],a=e[n];t[o]=[n,a,Zu(a)]}return t}var OP=jq;function Yq(e,t){return function(o){return o==null?!1:o[e]===t&&(t!==void 0||e in Object(o))}}var ey=Yq;function Xq(e){var t=OP(e);return t.length==1&&t[0][2]?ey(t[0][0],t[0][1]):function(o){return o===e||VP(o,e,t)}}var GP=Xq;function Jq(e,t,o){var n=e==null?void 0:os(e,t);return n===void 0?o:n}var _p=Jq;function Zq(e,t){return e!=null&&t in Object(e)}var zP=Zq;function eK(e,t,o){t=ts(t,e);for(var n=-1,a=t.length,s=!1;++n<a;){var l=xa(t[n]);if(!(s=e!=null&&o(e,l)))break;e=e[l]}return s||++n!=a?s:(a=e==null?0:e.length,!!a&&zI(a)&&sd(l,a)&&(Qo(e)||WI(e)))}var UP=eK;function tK(e,t){return e!=null&&UP(e,t,zP)}var ty=tK;var oK=1,nK=2;function rK(e,t){return vd(e)&&Zu(t)?ey(xa(e),t):function(o){var n=_p(o,e);return n===void 0&&n===t?ty(o,e):Id(t,n,oK|nK)}}var WP=rK;function aK(e){return function(t){return t?.[e]}}var oy=aK;function iK(e){return function(t){return os(t,e)}}var QP=iK;function sK(e){return vd(e)?oy(xa(e)):QP(e)}var qP=sK;function lK(e){return typeof e=="function"?e:e==null?id:typeof e=="object"?Qo(e)?WP(e[0],e[1]):GP(e):qP(e)}var Jo=lK;function pK(e,t){return function(o,n){if(o==null)return o;if(!ya(o))return e(o,n);for(var a=o.length,s=t?a:-1,l=Object(o);(t?s--:++s<a)&&n(l[s],s,l)!==!1;);return o}}var KP=pK;var cK=KP(kd),Va=cK;function dK(e,t){var o=-1,n=ya(e)?Array(e.length):[];return Va(e,function(a,s,l){n[++o]=t(a,s,l)}),n}var jP=dK;function uK(e,t){var o=Qo(e)?gd:jP;return o(e,Jo(t,3))}var ny=uK;var yK={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"',"&#39;":"'"},mK=fk(yK),YP=mK;var XP=/&(?:amp|lt|gt|quot|#39);/g,gK=RegExp(XP.source);function fK(e){return e=bk(e),e&&gK.test(e)?e.replace(XP,YP):e}var mr=fK;var cn=T(w()),Ge=T(s0()),cN=T(ZP()),QS=T(tN()),dN=T(nN());function Ot(){return Ot=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var o=arguments[t];for(var n in o)Object.prototype.hasOwnProperty.call(o,n)&&(e[n]=o[n])}return e},Ot.apply(this,arguments)}function YS(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e,qS(e,t)}function qS(e,t){return qS=Object.setPrototypeOf||function(o,n){return o.__proto__=n,o},qS(e,t)}function rN(e,t){if(e==null)return{};var o,n,a={},s=Object.keys(e);for(n=0;n<s.length;n++)t.indexOf(o=s[n])>=0||(a[o]=e[o]);return a}var Ne={BASE:"base",BODY:"body",HEAD:"head",HTML:"html",LINK:"link",META:"meta",NOSCRIPT:"noscript",SCRIPT:"script",STYLE:"style",TITLE:"title",FRAGMENT:"Symbol(react.fragment)"},vK={rel:["amphtml","canonical","alternate"]},IK={type:["application/ld+json"]},kK={charset:"",name:["robots","description"],property:["og:type","og:title","og:url","og:image","og:image:alt","og:description","twitter:url","twitter:title","twitter:description","twitter:image","twitter:image:alt","twitter:card","twitter:site"]},aN=Object.keys(Ne).map(function(e){return Ne[e]}),sy={accesskey:"accessKey",charset:"charSet",class:"className",contenteditable:"contentEditable",contextmenu:"contextMenu","http-equiv":"httpEquiv",itemprop:"itemProp",tabindex:"tabIndex"},MK=Object.keys(sy).reduce(function(e,t){return e[sy[t]]=t,e},{}),Ns=function(e,t){for(var o=e.length-1;o>=0;o-=1){var n=e[o];if(Object.prototype.hasOwnProperty.call(n,t))return n[t]}return null},TK=function(e){var t=Ns(e,Ne.TITLE),o=Ns(e,"titleTemplate");if(Array.isArray(t)&&(t=t.join("")),o&&t)return o.replace(/%s/g,function(){return t});var n=Ns(e,"defaultTitle");return t||n||void 0},AK=function(e){return Ns(e,"onChangeClientState")||function(){}},GS=function(e,t){return t.filter(function(o){return o[e]!==void 0}).map(function(o){return o[e]}).reduce(function(o,n){return Ot({},o,n)},{})},_K=function(e,t){return t.filter(function(o){return o[Ne.BASE]!==void 0}).map(function(o){return o[Ne.BASE]}).reverse().reduce(function(o,n){if(!o.length)for(var a=Object.keys(n),s=0;s<a.length;s+=1){var l=a[s].toLowerCase();if(e.indexOf(l)!==-1&&n[l])return o.concat(n)}return o},[])},wp=function(e,t,o){var n={};return o.filter(function(a){return!!Array.isArray(a[e])||(a[e]!==void 0&&console&&typeof console.warn=="function"&&console.warn("Helmet: "+e+' should be of type "Array". Instead found type "'+typeof a[e]+'"'),!1)}).map(function(a){return a[e]}).reverse().reduce(function(a,s){var l={};s.filter(function(m){for(var g,f=Object.keys(m),b=0;b<f.length;b+=1){var S=f[b],C=S.toLowerCase();t.indexOf(C)===-1||g==="rel"&&m[g].toLowerCase()==="canonical"||C==="rel"&&m[C].toLowerCase()==="stylesheet"||(g=C),t.indexOf(S)===-1||S!=="innerHTML"&&S!=="cssText"&&S!=="itemprop"||(g=S)}if(!g||!m[g])return!1;var v=m[g].toLowerCase();return n[g]||(n[g]={}),l[g]||(l[g]={}),!n[g][v]&&(l[g][v]=!0,!0)}).reverse().forEach(function(m){return a.push(m)});for(var p=Object.keys(l),d=0;d<p.length;d+=1){var u=p[d],y=Ot({},n[u],l[u]);n[u]=y}return a},[]).reverse()},wK=function(e,t){if(Array.isArray(e)&&e.length){for(var o=0;o<e.length;o+=1)if(e[o][t])return!0}return!1},uN=function(e){return Array.isArray(e)?e.join(""):e},zS=function(e,t){return Array.isArray(e)?e.reduce(function(o,n){return(function(a,s){for(var l=Object.keys(a),p=0;p<l.length;p+=1)if(s[l[p]]&&s[l[p]].includes(a[l[p]]))return!0;return!1})(n,t)?o.priority.push(n):o.default.push(n),o},{priority:[],default:[]}):{default:e}},iN=function(e,t){var o;return Ot({},e,((o={})[t]=void 0,o))},DK=[Ne.NOSCRIPT,Ne.SCRIPT,Ne.STYLE],US=function(e,t){return t===void 0&&(t=!0),t===!1?String(e):String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#x27;")},sN=function(e){return Object.keys(e).reduce(function(t,o){var n=e[o]!==void 0?o+'="'+e[o]+'"':""+o;return t?t+" "+n:n},"")},lN=function(e,t){return t===void 0&&(t={}),Object.keys(e).reduce(function(o,n){return o[sy[n]||n]=e[n],o},t)},iy=function(e,t){return t.map(function(o,n){var a,s=((a={key:n})["data-rh"]=!0,a);return Object.keys(o).forEach(function(l){var p=sy[l]||l;p==="innerHTML"||p==="cssText"?s.dangerouslySetInnerHTML={__html:o.innerHTML||o.cssText}:s[p]=o[l]}),cn.default.createElement(e,s)})},In=function(e,t,o){switch(e){case Ne.TITLE:return{toComponent:function(){return a=t.titleAttributes,(s={key:n=t.title})["data-rh"]=!0,l=lN(a,s),[cn.default.createElement(Ne.TITLE,l,n)];var n,a,s,l},toString:function(){return(function(n,a,s,l){var p=sN(s),d=uN(a);return p?"<"+n+' data-rh="true" '+p+">"+US(d,l)+"</"+n+">":"<"+n+' data-rh="true">'+US(d,l)+"</"+n+">"})(e,t.title,t.titleAttributes,o)}};case"bodyAttributes":case"htmlAttributes":return{toComponent:function(){return lN(t)},toString:function(){return sN(t)}};default:return{toComponent:function(){return iy(e,t)},toString:function(){return(function(n,a,s){return a.reduce(function(l,p){var d=Object.keys(p).filter(function(m){return!(m==="innerHTML"||m==="cssText")}).reduce(function(m,g){var f=p[g]===void 0?g:g+'="'+US(p[g],s)+'"';return m?m+" "+f:f},""),u=p.innerHTML||p.cssText||"",y=DK.indexOf(n)===-1;return l+"<"+n+' data-rh="true" '+d+(y?"/>":">"+u+"</"+n+">")},"")})(e,t,o)}}}},KS=function(e){var t=e.baseTag,o=e.bodyAttributes,n=e.encode,a=e.htmlAttributes,s=e.noscriptTags,l=e.styleTags,p=e.title,d=p===void 0?"":p,u=e.titleAttributes,y=e.linkTags,m=e.metaTags,g=e.scriptTags,f={toComponent:function(){},toString:function(){return""}};if(e.prioritizeSeoTags){var b=(function(S){var C=S.linkTags,v=S.scriptTags,k=S.encode,I=zS(S.metaTags,kK),A=zS(C,vK),D=zS(v,IK);return{priorityMethods:{toComponent:function(){return[].concat(iy(Ne.META,I.priority),iy(Ne.LINK,A.priority),iy(Ne.SCRIPT,D.priority))},toString:function(){return In(Ne.META,I.priority,k)+" "+In(Ne.LINK,A.priority,k)+" "+In(Ne.SCRIPT,D.priority,k)}},metaTags:I.default,linkTags:A.default,scriptTags:D.default}})(e);f=b.priorityMethods,y=b.linkTags,m=b.metaTags,g=b.scriptTags}return{priority:f,base:In(Ne.BASE,t,n),bodyAttributes:In("bodyAttributes",o,n),htmlAttributes:In("htmlAttributes",a,n),link:In(Ne.LINK,y,n),meta:In(Ne.META,m,n),noscript:In(Ne.NOSCRIPT,s,n),script:In(Ne.SCRIPT,g,n),style:In(Ne.STYLE,l,n),title:In(Ne.TITLE,{title:d,titleAttributes:u},n)}},ay=[],jS=function(e,t){var o=this;t===void 0&&(t=typeof document<"u"),this.instances=[],this.value={setHelmet:function(n){o.context.helmet=n},helmetInstances:{get:function(){return o.canUseDOM?ay:o.instances},add:function(n){(o.canUseDOM?ay:o.instances).push(n)},remove:function(n){var a=(o.canUseDOM?ay:o.instances).indexOf(n);(o.canUseDOM?ay:o.instances).splice(a,1)}}},this.context=e,this.canUseDOM=t,t||(e.helmet=KS({baseTag:[],bodyAttributes:{},encodeSpecialCharacters:!0,htmlAttributes:{},linkTags:[],metaTags:[],noscriptTags:[],scriptTags:[],styleTags:[],title:"",titleAttributes:{}}))},yN=cn.default.createContext({}),PK=Ge.default.shape({setHelmet:Ge.default.func,helmetInstances:Ge.default.shape({get:Ge.default.func,add:Ge.default.func,remove:Ge.default.func})}),NK=typeof document<"u",Si=(function(e){function t(o){var n;return(n=e.call(this,o)||this).helmetData=new jS(n.props.context,t.canUseDOM),n}return YS(t,e),t.prototype.render=function(){return cn.default.createElement(yN.Provider,{value:this.helmetData.value},this.props.children)},t})(cn.Component);Si.canUseDOM=NK,Si.propTypes={context:Ge.default.shape({helmet:Ge.default.shape()}),children:Ge.default.node.isRequired},Si.defaultProps={context:{}},Si.displayName="HelmetProvider";var Ps=function(e,t){var o,n=document.head||document.querySelector(Ne.HEAD),a=n.querySelectorAll(e+"[data-rh]"),s=[].slice.call(a),l=[];return t&&t.length&&t.forEach(function(p){var d=document.createElement(e);for(var u in p)Object.prototype.hasOwnProperty.call(p,u)&&(u==="innerHTML"?d.innerHTML=p.innerHTML:u==="cssText"?d.styleSheet?d.styleSheet.cssText=p.cssText:d.appendChild(document.createTextNode(p.cssText)):d.setAttribute(u,p[u]===void 0?"":p[u]));d.setAttribute("data-rh","true"),s.some(function(y,m){return o=m,d.isEqualNode(y)})?s.splice(o,1):l.push(d)}),s.forEach(function(p){return p.parentNode.removeChild(p)}),l.forEach(function(p){return n.appendChild(p)}),{oldTags:s,newTags:l}},WS=function(e,t){var o=document.getElementsByTagName(e)[0];if(o){for(var n=o.getAttribute("data-rh"),a=n?n.split(","):[],s=[].concat(a),l=Object.keys(t),p=0;p<l.length;p+=1){var d=l[p],u=t[d]||"";o.getAttribute(d)!==u&&o.setAttribute(d,u),a.indexOf(d)===-1&&a.push(d);var y=s.indexOf(d);y!==-1&&s.splice(y,1)}for(var m=s.length-1;m>=0;m-=1)o.removeAttribute(s[m]);a.length===s.length?o.removeAttribute("data-rh"):o.getAttribute("data-rh")!==l.join(",")&&o.setAttribute("data-rh",l.join(","))}},pN=function(e,t){var o=e.baseTag,n=e.htmlAttributes,a=e.linkTags,s=e.metaTags,l=e.noscriptTags,p=e.onChangeClientState,d=e.scriptTags,u=e.styleTags,y=e.title,m=e.titleAttributes;WS(Ne.BODY,e.bodyAttributes),WS(Ne.HTML,n),(function(S,C){S!==void 0&&document.title!==S&&(document.title=uN(S)),WS(Ne.TITLE,C)})(y,m);var g={baseTag:Ps(Ne.BASE,o),linkTags:Ps(Ne.LINK,a),metaTags:Ps(Ne.META,s),noscriptTags:Ps(Ne.NOSCRIPT,l),scriptTags:Ps(Ne.SCRIPT,d),styleTags:Ps(Ne.STYLE,u)},f={},b={};Object.keys(g).forEach(function(S){var C=g[S],v=C.newTags,k=C.oldTags;v.length&&(f[S]=v),k.length&&(b[S]=g[S].oldTags)}),t&&t(),p(e,f,b)},Dp=null,ly=(function(e){function t(){for(var n,a=arguments.length,s=new Array(a),l=0;l<a;l++)s[l]=arguments[l];return(n=e.call.apply(e,[this].concat(s))||this).rendered=!1,n}YS(t,e);var o=t.prototype;return o.shouldComponentUpdate=function(n){return!(0,dN.default)(n,this.props)},o.componentDidUpdate=function(){this.emitChange()},o.componentWillUnmount=function(){this.props.context.helmetInstances.remove(this),this.emitChange()},o.emitChange=function(){var n,a,s=this.props.context,l=s.setHelmet,p=null,d=(n=s.helmetInstances.get().map(function(u){var y=Ot({},u.props);return delete y.context,y}),{baseTag:_K(["href"],n),bodyAttributes:GS("bodyAttributes",n),defer:Ns(n,"defer"),encode:Ns(n,"encodeSpecialCharacters"),htmlAttributes:GS("htmlAttributes",n),linkTags:wp(Ne.LINK,["rel","href"],n),metaTags:wp(Ne.META,["name","charset","http-equiv","property","itemprop"],n),noscriptTags:wp(Ne.NOSCRIPT,["innerHTML"],n),onChangeClientState:AK(n),scriptTags:wp(Ne.SCRIPT,["src","innerHTML"],n),styleTags:wp(Ne.STYLE,["cssText"],n),title:TK(n),titleAttributes:GS("titleAttributes",n),prioritizeSeoTags:wK(n,"prioritizeSeoTags")});Si.canUseDOM?(a=d,Dp&&cancelAnimationFrame(Dp),a.defer?Dp=requestAnimationFrame(function(){pN(a,function(){Dp=null})}):(pN(a),Dp=null)):KS&&(p=KS(d)),l(p)},o.init=function(){this.rendered||(this.rendered=!0,this.props.context.helmetInstances.add(this),this.emitChange())},o.render=function(){return this.init(),null},t})(cn.Component);ly.propTypes={context:PK.isRequired},ly.displayName="HelmetDispatcher";var EK=["children"],RK=["children"],Mt=(function(e){function t(){return e.apply(this,arguments)||this}YS(t,e);var o=t.prototype;return o.shouldComponentUpdate=function(n){return!(0,cN.default)(iN(this.props,"helmetData"),iN(n,"helmetData"))},o.mapNestedChildrenToProps=function(n,a){if(!a)return null;switch(n.type){case Ne.SCRIPT:case Ne.NOSCRIPT:return{innerHTML:a};case Ne.STYLE:return{cssText:a};default:throw new Error("<"+n.type+" /> elements are self-closing and can not contain children. Refer to our API for more information.")}},o.flattenArrayTypeChildren=function(n){var a,s=n.child,l=n.arrayTypeChildren;return Ot({},l,((a={})[s.type]=[].concat(l[s.type]||[],[Ot({},n.newChildProps,this.mapNestedChildrenToProps(s,n.nestedChildren))]),a))},o.mapObjectTypeChildren=function(n){var a,s,l=n.child,p=n.newProps,d=n.newChildProps,u=n.nestedChildren;switch(l.type){case Ne.TITLE:return Ot({},p,((a={})[l.type]=u,a.titleAttributes=Ot({},d),a));case Ne.BODY:return Ot({},p,{bodyAttributes:Ot({},d)});case Ne.HTML:return Ot({},p,{htmlAttributes:Ot({},d)});default:return Ot({},p,((s={})[l.type]=Ot({},d),s))}},o.mapArrayTypeChildrenToProps=function(n,a){var s=Ot({},a);return Object.keys(n).forEach(function(l){var p;s=Ot({},s,((p={})[l]=n[l],p))}),s},o.warnOnInvalidChildren=function(n,a){return(0,QS.default)(aN.some(function(s){return n.type===s}),typeof n.type=="function"?"You may be attempting to nest <Helmet> components within each other, which is not allowed. Refer to our API for more information.":"Only elements types "+aN.join(", ")+" are allowed. Helmet does not support rendering <"+n.type+"> elements. Refer to our API for more information."),(0,QS.default)(!a||typeof a=="string"||Array.isArray(a)&&!a.some(function(s){return typeof s!="string"}),"Helmet expects a string as a child of <"+n.type+">. Did you forget to wrap your children in braces? ( <"+n.type+">{``}</"+n.type+"> ) Refer to our API for more information."),!0},o.mapChildrenToProps=function(n,a){var s=this,l={};return cn.default.Children.forEach(n,function(p){if(p&&p.props){var d=p.props,u=d.children,y=rN(d,EK),m=Object.keys(y).reduce(function(f,b){return f[MK[b]||b]=y[b],f},{}),g=p.type;switch(typeof g=="symbol"?g=g.toString():s.warnOnInvalidChildren(p,u),g){case Ne.FRAGMENT:a=s.mapChildrenToProps(u,a);break;case Ne.LINK:case Ne.META:case Ne.NOSCRIPT:case Ne.SCRIPT:case Ne.STYLE:l=s.flattenArrayTypeChildren({child:p,arrayTypeChildren:l,newChildProps:m,nestedChildren:u});break;default:a=s.mapObjectTypeChildren({child:p,newProps:a,newChildProps:m,nestedChildren:u})}}}),this.mapArrayTypeChildrenToProps(l,a)},o.render=function(){var n=this.props,a=n.children,s=rN(n,RK),l=Ot({},s),p=s.helmetData;return a&&(l=this.mapChildrenToProps(a,l)),!p||p instanceof jS||(p=new jS(p.context,p.instances)),p?cn.default.createElement(ly,Ot({},l,{context:p.value,helmetData:void 0})):cn.default.createElement(yN.Consumer,null,function(d){return cn.default.createElement(ly,Ot({},l,{context:d}))})},t})(cn.Component);Mt.propTypes={base:Ge.default.object,bodyAttributes:Ge.default.object,children:Ge.default.oneOfType([Ge.default.arrayOf(Ge.default.node),Ge.default.node]),defaultTitle:Ge.default.string,defer:Ge.default.bool,encodeSpecialCharacters:Ge.default.bool,htmlAttributes:Ge.default.object,link:Ge.default.arrayOf(Ge.default.object),meta:Ge.default.arrayOf(Ge.default.object),noscript:Ge.default.arrayOf(Ge.default.object),onChangeClientState:Ge.default.func,script:Ge.default.arrayOf(Ge.default.object),style:Ge.default.arrayOf(Ge.default.object),title:Ge.default.string,titleAttributes:Ge.default.object,titleTemplate:Ge.default.string,prioritizeSeoTags:Ge.default.bool,helmetData:Ge.default.object},Mt.defaultProps={defer:!0,encodeSpecialCharacters:!0,prioritizeSeoTags:!1},Mt.displayName="Helmet";var hi=({title:e,ogTitle:t,description:o,keywords:n,ogImage:a,ogVideo:s,noIndex:l,noFollow:p,customMetas:d})=>{let u;l&&p?u="noindex, nofollow":l?u="noindex":p&&(u="nofollow");let y=t||e;return x(Mt,{children:[!!e&&i("title",{children:mr(e)}),!!y&&i("meta",{property:"og:title",content:mr(y)}),!!o&&i("meta",{name:"description",content:mr(o)}),!!o&&i("meta",{property:"og:description",content:mr(o)}),!!n&&i("meta",{name:"keywords",content:mr(n.join(","))}),!!a&&i("meta",{property:"og:image",content:a}),!!a&&i("meta",{property:"og:image:secure_url",content:a}),!!s&&i("meta",{property:"og:video",content:s}),!!s&&i("meta",{property:"og:video:secure_url",content:s}),!!u&&i("meta",{name:"robots",content:u}),!!d&&ny(d,m=>i("meta",{name:m.name,content:m.content},m.name))]})};hi.displayName="Header";var KE=T(w());var Es=T(w());var XS=c`
  overflow: hidden;
`,JS=c`
  align-items: center;
  color: ${r("--breadcrumbs-item-color")};
  display: flex;
  font-size: ${r("--annotation-mobile-font-size")};
  font-weight: ${r("--annotation-mobile-font-weight")};
  gap: ${r("--spacing-xxs")};
  letter-spacing: ${r("--annotation-mobile-font-letter-spacing")};
  line-height: ${r("--annotation-mobile-font-line-height")};
  overflow: hidden;
  padding: ${r("--spacing-xs")} ${r("--spacing-xxs")};

  ${H} {
    font-size: ${r("--annotation-desktop-font-size")};
    font-weight: ${r("--annotation-desktop-font-weight")};
    letter-spacing: ${r("--annotation-desktop-font-letter-spacing")};
    line-height: ${r("--annotation-desktop-font-line-height")};
  }
`,mN=c`
  text-decoration: none;

  @media (hover: hover) {
    :hover {
      color: ${r("--breadcrumbs-item-hover-color")};
      text-decoration: ${r("--breadcrumbs-item-hover-font-text-decoration")};
    }
  }
`,gN=c`
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`,fN=c`
  color: ${r("--breadcrumbs-item-active-color")};
`,bN=c`
  ${qt}
  background-color: ${r("--neutral-v625")};
  border-radius: 4px;
  color: ${r("--neutral-v0")};
  left: 50%;
  opacity: 0;
  padding: ${r("--spacing-xs")} 21px;
  position: absolute;
  top: 120%;
  transform: translateX(-50%);
  transition: opacity 200ms, visibility 200ms;
  white-space: nowrap;
  pointer-events: none;
  visibility: hidden;

  ${`.${XS}[data-truncated="true"]`}:hover & {
    opacity: 1;
    pointer-events: auto;
    visibility: visible;
  }

  &::before {
    border-bottom: 12px solid ${r("--neutral-v625")};
    border-left: 12px solid transparent;
    border-right: 12px solid transparent;
    bottom: 100%;
    content: '';
    height: 0;
    left: 50%;
    position: absolute;
    transform: translateX(-50%);
    width: 0;
  }
`,SN=c`
  fill: ${r("--breadcrumbs-item-color")};
  margin-inline-start: calc(${r("--spacing-xxs")} * -1);

  [dir='rtl'] & {
    transform: scaleX(-1);
  }

  ${H} {
    display: none;
  }
`;var ZS=({breadcrumbText:e,slug:t,isCurrent:o,showBackIcon:n})=>{let{Anchor:a}=(0,Es.useContext)(He),s=(0,Es.useRef)(null),[l,p]=(0,Es.useState)(!1),d=()=>{if(!s.current)return;let{offsetWidth:m,scrollWidth:g}=s.current;p(g>m)},u=i("span",{ref:s,className:gN,children:e}),y=t&&!o?x(a,{href:t,className:h(JS,mN),children:[n&&i(De,{name:"chevron-left",size:24,className:SN}),u]}):i("span",{className:h(JS,{[fN]:o}),children:u});return x("span",{className:XS,"data-truncated":l,onMouseEnter:d,children:[y,i("span",{role:"tooltip",className:bN,children:e})]})};ZS.displayName="BreadcrumbItem";var hN=c`
  inset-block: 0 auto;
  inset-inline: 0;
  position: absolute;
  /** Allow tooltip to show on top the Hero text */
  z-index: 10;
`,CN=c`
  background: linear-gradient(to bottom, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0));
`,xN=c`
  background: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0));
`,vN=c`
  align-items: center;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(0, auto));
  justify-content: start;
  list-style: none;
  padding-block: ${r("--spacing-xs")};
  /**
   * Hardcoded calc(28px - var('--spacing-xxs')) to align the element with the first element on the header and to make
   * the dependency on the breadcrumb padding explicit.
   * Find the design in the jira ticket: https://jira.sc-corp.net/browse/WEBP-11085
   */
  padding-inline: calc(28px - ${r("--spacing-xxs")}) ${r("--spacing-xxs")};

  ${H} {
    padding-block: ${r("--spacing-m")};
    /**
     * Hardcoded calc(60px - var('--spacing-xxs')) to align the element with the first element on the header and to make
     * the dependency on the breadcrumb padding explicit.
     * Find the design in the jira ticket: https://jira.sc-corp.net/browse/WEBP-11085
     */
    padding-inline: calc(60px - ${r("--spacing-xxs")}) ${r("--spacing-l")};
    max-width: 50%;
  }
`,IN=c`
  display: flex;
  position: relative;

  ${N} {
    display: none;
  }
`,kN=c`
  ${N} {
    display: flex;
  }
`,MN=c`
  &:not(:last-of-type)::after {
    color: ${r("--breadcrumbs-item-color")};
    content: '/';
    font-size: ${r("--annotation-mobile-font-size")};
    font-weight: ${r("--annotation-mobile-font-weight")};
    letter-spacing: ${r("--annotation-mobile-font-letter-spacing")};
    line-height: ${r("--annotation-mobile-font-line-height")};
    padding: ${r("--spacing-xs")};

    ${H} {
      font-size: ${r("--annotation-desktop-font-size")};
      font-weight: ${r("--annotation-desktop-font-weight")};
      letter-spacing: ${r("--annotation-desktop-font-letter-spacing")};
      line-height: ${r("--annotation-desktop-font-line-height")};
    }

    ${N} {
      display: none;
    }
  }
`,TN=c`
  color: ${r("--breadcrumbs-item-color")};
  flex-shrink: 0;
  height: 16px;
  margin: ${r("--spacing-xs")} ${r("--spacing-xxs")};
  width: 16px;

  [dir='rtl'] & {
    transform: scaleX(-1);
  }

  ${N} {
    display: none;
  }
`;var eh=({motifScheme:e,breadcrumbsItems:t,showBgGradient:o,SeparatorIcon:n})=>{if(Y("sdsm-breadcrumbs"),!t.length)return null;let a=t.length-1;return i("nav",{"aria-label":"breadcrumbs",className:h("sdsm-breadcrumbs",hN),children:i("ol",{className:h(vN,{[xN]:o&&e!=="sdsm-secondary",[CN]:o&&e==="sdsm-secondary"}),children:t.map((s,l)=>{let p=l===a,d=l===a-1,u=!!n&&l<a;return x("li",{className:h(IN,{[kN]:d,[MN]:!n}),children:[i(ZS,{...s,isCurrent:p,showBackIcon:d}),u&&n&&i(n,{"aria-hidden":!0,className:TN,focusable:!1})]},s.breadcrumbText)})})})};eh.displayName="Breadcrumbs";var my=T(w());var gr=T(VU()),kn=T(w()),oh=T(OU()),Oa=T(RN()),YK=Object.defineProperty,XK=Object.defineProperties,JK=Object.getOwnPropertyDescriptors,dy=Object.getOwnPropertySymbols,BN=Object.prototype.hasOwnProperty,$N=Object.prototype.propertyIsEnumerable,FN=(e,t,o)=>t in e?YK(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o,dn=(e,t)=>{for(var o in t||(t={}))BN.call(t,o)&&FN(e,o,t[o]);if(dy)for(var o of dy(t))$N.call(t,o)&&FN(e,o,t[o]);return e},uy=(e,t)=>XK(e,JK(t)),yy=(e,t)=>{var o={};for(var n in e)BN.call(e,n)&&t.indexOf(n)<0&&(o[n]=e[n]);if(e!=null&&dy)for(var n of dy(e))t.indexOf(n)<0&&$N.call(e,n)&&(o[n]=e[n]);return o};function _t(e){return o=>{var n=o,{bgStyle:a={},borderRadius:s=0,iconFillColor:l="white",round:p=!1,size:d=64}=n,u=yy(n,["bgStyle","borderRadius","iconFillColor","round","size"]);return(0,gr.jsxs)("svg",uy(dn({viewBox:"0 0 64 64",width:d,height:d},u),{children:[p?(0,gr.jsx)("circle",{cx:"32",cy:"32",r:"32",fill:e.color,style:a}):(0,gr.jsx)("rect",{width:"64",height:"64",rx:s,ry:s,fill:e.color,style:a}),(0,gr.jsx)("path",{d:e.path,fill:l})]}))}}var $xe=_t({color:"#7f7f7f",networkName:"email",path:"M17,22v20h30V22H17z M41.1,25L32,32.1L22.9,25H41.1z M20,39V26.6l12,9.3l12-9.3V39H20z"});function yt(e){let t=Object.entries(e).filter(([,o])=>o!=null).map(([o,n])=>`${encodeURIComponent(o)}=${encodeURIComponent(String(n))}`);return t.length>0?`?${t.join("&")}`:""}var ZK=e=>!!e&&(typeof e=="object"||typeof e=="function")&&typeof e.then=="function",ej=(e,t)=>({left:window.outerWidth/2+(window.screenX||window.screenLeft||0)-e/2,top:window.outerHeight/2+(window.screenY||window.screenTop||0)-t/2}),tj=(e,t)=>({top:(window.screen.height-t)/2,left:(window.screen.width-e)/2});function oj(e,t,o){var n=t,{height:a,width:s}=n,l=yy(n,["height","width"]);let p=dn({height:a,width:s,location:"no",toolbar:"no",status:"no",directories:"no",menubar:"no",scrollbars:"yes",resizable:"no",centerscreen:"yes",chrome:"yes"},l),d=window.open(e,"",Object.keys(p).map(u=>`${u}=${p[u]}`).join(", "));if(o){let u=window.setInterval(()=>{try{(d===null||d.closed)&&(window.clearInterval(u),o(d))}catch(y){console.error(y)}},1e3)}return d}function nj(e){var t=e,{beforeOnClick:o,children:n,className:a,disabled:s,disabledStyle:l={opacity:.6},forwardedRef:p,htmlTitle:d,networkLink:u,networkName:y,onClick:m,onShareWindowClose:g,openShareDialogOnClick:f=!0,opts:b,resetButtonStyle:S=!0,style:C,url:v,windowHeight:k=400,windowPosition:I="windowCenter",windowWidth:A=550}=t,D=yy(t,["beforeOnClick","children","className","disabled","disabledStyle","forwardedRef","htmlTitle","networkLink","networkName","onClick","onShareWindowClose","openShareDialogOnClick","opts","resetButtonStyle","style","url","windowHeight","windowPosition","windowWidth"]);let B=async P=>{let $=u(v,b);if(!s){if(P.preventDefault(),o){let R=o();ZK(R)&&await R}if(f){let R=dn({height:k,width:A},I==="windowCenter"?ej(A,k):tj(A,k));oj($,R,g)}m&&m(P,$)}},M=(0,oh.default)("react-share__ShareButton",{"react-share__ShareButton--disabled":!!s,disabled:!!s},a),_=dn(dn(S?{backgroundColor:"transparent",border:"none",padding:0,font:"inherit",color:"inherit",cursor:"pointer"}:{},C),s&&l);return(0,gr.jsx)("button",uy(dn({},D),{className:M,onClick:B,ref:p,style:_,title:d,children:n}))}function Bt(e,t,o,n){function a(s,l){let p=o(s),d=dn({},s);return Object.keys(p).forEach(y=>{delete d[y]}),(0,gr.jsx)(nj,uy(dn(dn({},n),d),{forwardedRef:l,networkName:e,networkLink:t,opts:o(s)}))}return a.displayName=`ShareButton-${e}`,(0,kn.forwardRef)(a)}function rj(e,{subject:t,body:o,separator:n}){return"mailto:"+yt({subject:t,body:o?o+n+e:e})}var Lxe=Bt("email",rj,e=>({subject:e.subject,body:e.body,separator:e.separator||" "}),{openShareDialogOnClick:!1,onClick:(e,t)=>{window.location.href=t}});var Hxe=_t({color:"#0965FE",networkName:"facebook",path:"M34.1,47V33.3h4.6l0.7-5.3h-5.3v-3.4c0-1.5,0.4-2.6,2.6-2.6l2.8,0v-4.8c-0.5-0.1-2.2-0.2-4.1-0.2 c-4.1,0-6.9,2.5-6.9,7V28H24v5.3h4.6V47H34.1z"});var Vxe=_t({color:"#0A7CFF",networkName:"facebookmessenger",path:"M 53.066406 21.871094 C 52.667969 21.339844 51.941406 21.179688 51.359375 21.496094 L 37.492188 29.058594 L 28.867188 21.660156 C 28.339844 21.207031 27.550781 21.238281 27.054688 21.730469 L 11.058594 37.726562 C 10.539062 38.25 10.542969 39.09375 11.0625 39.613281 C 11.480469 40.027344 12.121094 40.121094 12.640625 39.839844 L 26.503906 32.28125 L 35.136719 39.679688 C 35.667969 40.132812 36.457031 40.101562 36.949219 39.609375 L 52.949219 23.613281 C 53.414062 23.140625 53.464844 22.398438 53.066406 21.871094 Z M 53.066406 21.871094"});function aj(e,{appId:t,redirectUri:o,to:n}){return"https://www.facebook.com/dialog/send"+yt({link:e,redirect_uri:o||e,app_id:t,to:n})}var Oxe=Bt("facebookmessenger",aj,e=>({appId:e.appId,redirectUri:e.redirectUri,to:e.to}),{windowWidth:1e3,windowHeight:820});var th=class extends Error{constructor(t){super(t),this.name="AssertionError"}};function At(e,t){if(!e)throw new th(t)}function ij(e,{hashtag:t}){return At(e,"facebook.url"),"https://www.facebook.com/sharer/sharer.php"+yt({u:e,hashtag:t})}var Gxe=Bt("facebook",ij,e=>({hashtag:e.hashtag}),{windowWidth:550,windowHeight:400});function sj(){let e=(0,kn.useRef)(!1);return(0,kn.useEffect)(()=>(e.current=!0,()=>{e.current=!1}),[]),(0,kn.useCallback)(()=>e.current,[])}function lj(e){var t=e,{children:o=g=>g,className:n,getCount:a,url:s}=t,l=yy(t,["children","className","getCount","url"]);let p=sj(),[d,u]=(0,kn.useState)(void 0),[y,m]=(0,kn.useState)(!1);return(0,kn.useEffect)(()=>{m(!0),a(s,g=>{p()&&(u(g),m(!1))})},[s]),(0,gr.jsx)("span",uy(dn({className:(0,oh.default)("react-share__ShareCount",n)},l),{children:!y&&d!==void 0&&o(d)}))}function xi(e){let t=o=>(0,gr.jsx)(lj,dn({getCount:e},o));return t.displayName=`ShareCount(${e.name})`,t}function pj(e,t){let o=`https://graph.facebook.com/?id=${e}&fields=og_object{engagement}`;(0,Oa.default)(o,(n,a)=>{t(!n&&a&&a.og_object&&a.og_object.engagement?a.og_object.engagement.count:void 0)})}var zxe=xi(pj),Uxe=_t({color:"#009ad9",networkName:"hatena",path:"M 36.164062 33.554688 C 34.988281 32.234375 33.347656 31.5 31.253906 31.34375 C 33.125 30.835938 34.476562 30.09375 35.335938 29.09375 C 36.191406 28.09375 36.609375 26.78125 36.609375 25.101562 C 36.628906 23.875 36.332031 22.660156 35.75 21.578125 C 35.160156 20.558594 34.292969 19.71875 33.253906 19.160156 C 32.304688 18.640625 31.175781 18.265625 29.847656 18.042969 C 28.523438 17.824219 26.195312 17.730469 22.867188 17.730469 L 14.769531 17.730469 L 14.769531 47.269531 L 23.113281 47.269531 C 26.46875 47.269531 28.886719 47.15625 30.367188 46.929688 C 31.851562 46.695312 33.085938 46.304688 34.085938 45.773438 C 35.289062 45.148438 36.28125 44.179688 36.933594 42.992188 C 37.597656 41.796875 37.933594 40.402344 37.933594 38.816406 C 37.933594 36.621094 37.347656 34.867188 36.164062 33.554688 Z M 22.257812 24.269531 L 23.984375 24.269531 C 25.988281 24.269531 27.332031 24.496094 28.015625 24.945312 C 28.703125 25.402344 29.042969 26.183594 29.042969 27.285156 C 29.042969 28.390625 28.664062 29.105469 27.9375 29.550781 C 27.210938 29.992188 25.84375 30.199219 23.855469 30.199219 L 22.257812 30.199219 Z M 29.121094 41.210938 C 28.328125 41.691406 26.976562 41.925781 25.078125 41.925781 L 22.257812 41.925781 L 22.257812 35.488281 L 25.195312 35.488281 C 27.144531 35.488281 28.496094 35.738281 29.210938 36.230469 C 29.925781 36.726562 30.304688 37.582031 30.304688 38.832031 C 30.304688 40.078125 29.914062 40.742188 29.105469 41.222656 Z M 29.121094 41.210938 M 46.488281 39.792969 C 44.421875 39.792969 42.742188 41.46875 42.742188 43.535156 C 42.742188 45.605469 44.421875 47.28125 46.488281 47.28125 C 48.554688 47.28125 50.230469 45.605469 50.230469 43.535156 C 50.230469 41.46875 48.554688 39.792969 46.488281 39.792969 Z M 46.488281 39.792969 M 43.238281 17.730469 L 49.738281 17.730469 L 49.738281 37.429688 L 43.238281 37.429688 Z M 43.238281 17.730469 "});function cj(e,{title:t}){return At(e,"hatena.url"),`http://b.hatena.ne.jp/add?mode=confirm&url=${e}&title=${t}`}var Wxe=Bt("hatena",cj,e=>({title:e.title}),{windowWidth:660,windowHeight:460,windowPosition:"windowCenter"});function dj(e,t){(0,Oa.default)("https://bookmark.hatenaapis.com/count/entry"+yt({url:e}),(n,a)=>{t(a??void 0)})}var Qxe=xi(dj),qxe=_t({color:"#1F1F1F",networkName:"instapaper",path:"M35.688 43.012c0 2.425.361 2.785 3.912 3.056V48H24.401v-1.932c3.555-.27 3.912-.63 3.912-3.056V20.944c0-2.379-.36-2.785-3.912-3.056V16H39.6v1.888c-3.55.27-3.912.675-3.912 3.056v22.068h.001z"});function uj(e,{title:t,description:o}){return At(e,"instapaper.url"),"http://www.instapaper.com/hello2"+yt({url:e,title:t,description:o})}var Kxe=Bt("instapaper",uj,e=>({title:e.title,description:e.description}),{windowWidth:500,windowHeight:500,windowPosition:"windowCenter"});var jxe=_t({color:"#00b800",networkName:"line",path:"M52.62 30.138c0 3.693-1.432 7.019-4.42 10.296h.001c-4.326 4.979-14 11.044-16.201 11.972-2.2.927-1.876-.591-1.786-1.112l.294-1.765c.069-.527.142-1.343-.066-1.865-.232-.574-1.146-.872-1.817-1.016-9.909-1.31-17.245-8.238-17.245-16.51 0-9.226 9.251-16.733 20.62-16.733 11.37 0 20.62 7.507 20.62 16.733zM27.81 25.68h-1.446a.402.402 0 0 0-.402.401v8.985c0 .221.18.4.402.4h1.446a.401.401 0 0 0 .402-.4v-8.985a.402.402 0 0 0-.402-.401zm9.956 0H36.32a.402.402 0 0 0-.402.401v5.338L31.8 25.858a.39.39 0 0 0-.031-.04l-.002-.003-.024-.025-.008-.007a.313.313 0 0 0-.032-.026.255.255 0 0 1-.021-.014l-.012-.007-.021-.012-.013-.006-.023-.01-.013-.005-.024-.008-.014-.003-.023-.005-.017-.002-.021-.003-.021-.002h-1.46a.402.402 0 0 0-.402.401v8.985c0 .221.18.4.402.4h1.446a.401.401 0 0 0 .402-.4v-5.337l4.123 5.568c.028.04.063.072.101.099l.004.003a.236.236 0 0 0 .025.015l.012.006.019.01a.154.154 0 0 1 .019.008l.012.004.028.01.005.001a.442.442 0 0 0 .104.013h1.446a.4.4 0 0 0 .401-.4v-8.985a.402.402 0 0 0-.401-.401zm-13.442 7.537h-3.93v-7.136a.401.401 0 0 0-.401-.401h-1.447a.4.4 0 0 0-.401.401v8.984a.392.392 0 0 0 .123.29c.072.068.17.111.278.111h5.778a.4.4 0 0 0 .401-.401v-1.447a.401.401 0 0 0-.401-.401zm21.429-5.287c.222 0 .401-.18.401-.402v-1.446a.401.401 0 0 0-.401-.402h-5.778a.398.398 0 0 0-.279.113l-.005.004-.006.008a.397.397 0 0 0-.111.276v8.984c0 .108.043.206.112.278l.005.006a.401.401 0 0 0 .284.117h5.778a.4.4 0 0 0 .401-.401v-1.447a.401.401 0 0 0-.401-.401h-3.93v-1.519h3.93c.222 0 .401-.18.401-.402V29.85a.401.401 0 0 0-.401-.402h-3.93V27.93h3.93z"});function yj(e,{title:t}){return At(e,"line.url"),"https://social-plugins.line.me/lineit/share"+yt({url:e,text:t})}var Yxe=Bt("line",yj,e=>({title:e.title}),{windowWidth:500,windowHeight:500});var mj=_t({color:"#0077B5",networkName:"linkedin",path:"M20.4,44h5.4V26.6h-5.4V44z M23.1,18c-1.7,0-3.1,1.4-3.1,3.1c0,1.7,1.4,3.1,3.1,3.1 c1.7,0,3.1-1.4,3.1-3.1C26.2,19.4,24.8,18,23.1,18z M39.5,26.2c-2.6,0-4.4,1.4-5.1,2.8h-0.1v-2.4h-5.2V44h5.4v-8.6 c0-2.3,0.4-4.5,3.2-4.5c2.8,0,2.8,2.6,2.8,4.6V44H46v-9.5C46,29.8,45,26.2,39.5,26.2z"}),LN=mj;function gj(e,{title:t,summary:o,source:n}){return At(e,"linkedin.url"),"https://linkedin.com/shareArticle"+yt({url:e,mini:"true",title:t,summary:o,source:n})}var fj=Bt("linkedin",gj,({title:e,summary:t,source:o})=>({title:e,summary:t,source:o}),{windowWidth:750,windowHeight:600}),HN=fj,Xxe=_t({color:"#21A5D8",networkName:"livejournal",path:"M18.3407821,28.1764706 L21.9441341,31.789916 L33.0055865,42.882353 C33.0055865,42.882353 33.0893855,42.9663866 33.0893855,42.9663866 L46.6648046,47 C46.6648046,47 46.6648046,47 46.7486034,47 C46.8324022,47 46.8324022,47 46.9162012,46.9159664 C47,46.8319327 47,46.8319327 47,46.7478991 L42.9776536,33.1344537 C42.9776536,33.1344537 42.9776536,33.1344537 42.8938548,33.0504202 L31.1620111,21.3697479 L31.1620111,21.3697479 L28.1452514,18.2605042 C27.3072626,17.4201681 26.5530726,17 25.7150838,17 C24.2905028,17 23.0335195,18.3445378 21.5251397,19.8571429 C21.273743,20.1092437 20.9385475,20.4453781 20.6871508,20.697479 C20.3519553,21.0336134 20.1005586,21.2857143 19.849162,21.5378151 C18.3407821,22.9663866 17.0837989,24.2268908 17,25.7394958 C17.0837989,26.4957983 17.5027933,27.3361345 18.3407821,28.1764706 Z M39.9012319,39.6134454 C39.7336341,39.4453781 39.4822374,37.6806724 40.2364275,36.8403362 C40.9906174,36.0840337 41.6610084,36 42.1638017,36 C42.3313995,36 42.4989973,36 42.5827961,36 L44.8453659,43.5630253 L43.5883828,44.8235295 L36.0464833,42.5546218 C35.9626843,42.2184874 35.8788855,41.2100841 36.8844722,40.2016807 C37.2196676,39.8655463 37.8900587,39.6134454 38.5604498,39.6134454 C39.147042,39.6134454 39.5660364,39.7815126 39.5660364,39.7815126 C39.6498353,39.8655463 39.8174331,39.8655463 39.8174331,39.7815126 C39.9850307,39.7815126 39.9850307,39.697479 39.9012319,39.6134454 Z"});function bj(e,{title:t,description:o}){return At(e,"livejournal.url"),"https://www.livejournal.com/update.bml"+yt({subject:t,event:o})}var Jxe=Bt("livejournal",bj,e=>({title:e.title,description:e.description}),{windowWidth:660,windowHeight:460});var Zxe=_t({color:"#168DE2",networkName:"mailru",path:"M39.7107745,17 C41.6619755,17 43.3204965,18.732852 43.3204965,21.0072202 C43.3204965,23.2815885 41.7595357,25.0144404 39.7107745,25.0144404 C37.7595732,25.0144404 36.1010522,23.2815885 36.1010522,21.0072202 C36.1010522,18.732852 37.7595732,17 39.7107745,17 Z M24.3938451,17 C26.3450463,17 28.0035672,18.732852 28.0035672,21.0072202 C28.0035672,23.2815885 26.4426063,25.0144404 24.3938451,25.0144404 C22.4426439,25.0144404 20.7841229,23.2815885 20.7841229,21.0072202 C20.7841229,18.732852 22.4426439,17 24.3938451,17 Z M51.9057817,43.4259928 C51.7106617,44.0758123 51.4179815,44.6173285 50.9301812,44.9422383 C50.637501,45.1588448 50.2472607,45.267148 49.8570205,45.267148 C49.07654,45.267148 48.3936197,44.833935 48.0033795,44.0758123 L46.2472985,40.7184115 L45.759498,41.2599278 C42.5400162,44.9422383 37.466893,47 32.0035297,47 C26.5401664,47 21.5646034,44.9422383 18.2475614,41.2599278 L17.7597611,40.7184115 L16.00368,44.0758123 C15.6134398,44.833935 14.9305194,45.267148 14.1500389,45.267148 C13.7597986,45.267148 13.3695584,45.1588448 13.0768782,44.9422383 C12.0037176,44.2924187 11.7110374,42.7761733 12.2963978,41.5848375 L16.7841605,33.0288807 C17.1744007,32.270758 17.8573211,31.8375453 18.6378016,31.8375453 C19.0280418,31.8375453 19.4182821,31.9458485 19.7109623,32.1624548 C20.7841229,32.8122743 21.0768031,34.3285197 20.4914427,35.5198555 L20.1012025,36.2779783 L20.2963226,36.602888 C22.4426439,39.9602888 27.0279667,42.234657 31.9059697,42.234657 C36.7839727,42.234657 41.3692955,40.068592 43.5156167,36.602888 L43.7107367,36.2779783 L43.3204965,35.6281587 C43.0278165,35.0866425 42.9302562,34.436823 43.1253765,33.7870035 C43.3204965,33.137184 43.6131767,32.5956678 44.100977,32.270758 C44.3936572,32.0541515 44.7838975,31.9458485 45.1741377,31.9458485 C45.9546182,31.9458485 46.6375385,32.3790613 47.0277787,33.137184 L51.5155415,41.6931408 C52.003342,42.234657 52.100902,42.8844765 51.9057817,43.4259928 Z"});function Sj(e,{title:t,description:o,imageUrl:n}){return At(e,"mailru.url"),"https://connect.mail.ru/share"+yt({url:e,title:t,description:o,image_url:n})}var eve=Bt("mailru",Sj,e=>({title:e.title,description:e.description,imageUrl:e.imageUrl}),{windowWidth:660,windowHeight:460});var tve=_t({color:"#F97400",networkName:"ok",path:"M39,30c-1,0-3,2-7,2s-6-2-7-2c-1.1,0-2,0.9-2,2c0,1,0.6,1.5,1,1.7c1.2,0.7,5,2.3,5,2.3l-4.3,5.4   c0,0-0.8,0.9-0.8,1.6c0,1.1,0.9,2,2,2c1,0,1.5-0.7,1.5-0.7S32,39,32,39c0,0,4.5,5.3,4.5,5.3S37,45,38,45c1.1,0,2-0.9,2-2   c0-0.6-0.8-1.6-0.8-1.6L35,36c0,0,3.8-1.6,5-2.3c0.4-0.3,1-0.7,1-1.7C41,30.9,40.1,30,39,30z M32,15c-3.9,0-7,3.1-7,7s3.1,7,7,7c3.9,0,7-3.1,7-7S35.9,15,32,15z M32,25.5   c-1.9,0-3.5-1.6-3.5-3.5c0-1.9,1.6-3.5,3.5-3.5c1.9,0,3.5,1.6,3.5,3.5C35.5,23.9,33.9,22.5,35,22.5z "});function hj(e,{title:t,description:o,image:n}){return At(e,"ok.url"),"https://connect.ok.ru/offer"+yt({url:e,title:t,description:o,imageUrl:n})}var ove=Bt("ok",hj,e=>({title:e.title,description:e.description,image:e.image}),{windowWidth:588,windowHeight:480,windowPosition:"screenCenter"});function Cj(e,t){window.OK||(window.OK={Share:{count:function(s,l){var p,d;(d=(p=window.OK.callbacks)[s])==null||d.call(p,l)}},callbacks:[]});let o="https://connect.ok.ru/dk",n=window.OK.callbacks.length;return window.ODKL={updateCount(a,s){var l,p;let d=a===""?0:parseInt(a.replace("react-share-",""),10);(p=(l=window.OK.callbacks)[d])==null||p.call(l,s===""?void 0:parseInt(s,10))}},window.OK.callbacks.push(t),(0,Oa.default)(o+yt({"st.cmd":"extLike",uid:`react-share-${n}`,ref:e}))}var nve=xi(Cj),rve=_t({color:"#E60023",networkName:"pinterest",path:"M32,16c-8.8,0-16,7.2-16,16c0,6.6,3.9,12.2,9.6,14.7c0-1.1,0-2.5,0.3-3.7 c0.3-1.3,2.1-8.7,2.1-8.7s-0.5-1-0.5-2.5c0-2.4,1.4-4.1,3.1-4.1c1.5,0,2.2,1.1,2.2,2.4c0,1.5-0.9,3.7-1.4,5.7 c-0.4,1.7,0.9,3.1,2.5,3.1c3,0,5.1-3.9,5.1-8.5c0-3.5-2.4-6.1-6.7-6.1c-4.9,0-7.9,3.6-7.9,7.7c0,1.4,0.4,2.4,1.1,3.1 c0.3,0.3,0.3,0.5,0.2,0.9c-0.1,0.3-0.3,1-0.3,1.3c-0.1,0.4-0.4,0.6-0.8,0.4c-2.2-0.9-3.3-3.4-3.3-6.1c0-4.5,3.8-10,11.4-10 c6.1,0,10.1,4.4,10.1,9.2c0,6.3-3.5,11-8.6,11c-1.7,0-3.4-0.9-3.9-2c0,0-0.9,3.7-1.1,4.4c-0.3,1.2-1,2.5-1.6,3.4 c1.4,0.4,3,0.7,4.5,0.7c8.8,0,16-7.2,16-16C48,23.2,40.8,16,32,16z"});function xj(e,{media:t,description:o,pinId:n}){return n?`https://pinterest.com/pin/${n}/repin/x/`:(At(e,"pinterest.url"),At(t,"pinterest.media"),"https://pinterest.com/pin/create/button/"+yt({url:e,media:t,description:o}))}var ave=Bt("pinterest",xj,e=>({media:e.media,description:e.description,pinId:e.pinId}),{windowWidth:1e3,windowHeight:730});function vj(e,t){(0,Oa.default)("https://api.pinterest.com/v1/urls/count.json"+yt({url:e}),(n,a)=>{t(a?a.count:void 0)})}var ive=xi(vj),sve=_t({color:"#EF3F56",networkName:"pocket",path:"M41.084 29.065l-7.528 7.882a2.104 2.104 0 0 1-1.521.666 2.106 2.106 0 0 1-1.522-.666l-7.528-7.882c-.876-.914-.902-2.43-.065-3.384.84-.955 2.228-.987 3.1-.072l6.015 6.286 6.022-6.286c.88-.918 2.263-.883 3.102.071.841.938.82 2.465-.06 3.383l-.015.002zm6.777-10.976C47.463 16.84 46.361 16 45.14 16H18.905c-1.2 0-2.289.82-2.716 2.044-.125.363-.189.743-.189 1.125v10.539l.112 2.096c.464 4.766 2.73 8.933 6.243 11.838.06.053.125.102.19.153l.04.033c1.882 1.499 3.986 2.514 6.259 3.014a14.662 14.662 0 0 0 6.13.052c.118-.042.235-.065.353-.087.03 0 .065-.022.098-.042a15.395 15.395 0 0 0 6.011-2.945l.039-.045.18-.153c3.502-2.902 5.765-7.072 6.248-11.852L48 29.674v-10.52c0-.366-.041-.728-.161-1.08l.022.015z"});function Ij(e,{title:t}){return At(e,"pocket.url"),"https://getpocket.com/save"+yt({url:e,title:t})}var lve=Bt("pocket",Ij,e=>({title:e.title}),{windowWidth:500,windowHeight:500});var pve=_t({color:"#FF5700",networkName:"reddit",path:"M 53.34375 32 C 53.277344 30.160156 52.136719 28.53125 50.429688 27.839844 C 48.722656 27.148438 46.769531 27.523438 45.441406 28.800781 C 41.800781 26.324219 37.519531 24.957031 33.121094 24.863281 L 35.199219 14.878906 L 42.046875 16.320312 C 42.214844 17.882812 43.496094 19.09375 45.066406 19.171875 C 46.636719 19.253906 48.03125 18.183594 48.359375 16.644531 C 48.6875 15.105469 47.847656 13.558594 46.382812 12.992188 C 44.914062 12.425781 43.253906 13.007812 42.464844 14.367188 L 34.625 12.800781 C 34.363281 12.742188 34.09375 12.792969 33.871094 12.9375 C 33.648438 13.082031 33.492188 13.308594 33.441406 13.566406 L 31.070312 24.671875 C 26.617188 24.738281 22.277344 26.105469 18.59375 28.609375 C 17.242188 27.339844 15.273438 26.988281 13.570312 27.707031 C 11.863281 28.429688 10.746094 30.089844 10.71875 31.941406 C 10.691406 33.789062 11.757812 35.484375 13.441406 36.257812 C 13.402344 36.726562 13.402344 37.195312 13.441406 37.664062 C 13.441406 44.832031 21.792969 50.65625 32.097656 50.65625 C 42.398438 50.65625 50.753906 44.832031 50.753906 37.664062 C 50.789062 37.195312 50.789062 36.726562 50.753906 36.257812 C 52.363281 35.453125 53.371094 33.800781 53.34375 32 Z M 21.34375 35.199219 C 21.34375 33.433594 22.777344 32 24.542969 32 C 26.3125 32 27.742188 33.433594 27.742188 35.199219 C 27.742188 36.96875 26.3125 38.398438 24.542969 38.398438 C 22.777344 38.398438 21.34375 36.96875 21.34375 35.199219 Z M 39.9375 44 C 37.664062 45.710938 34.871094 46.582031 32.03125 46.464844 C 29.191406 46.582031 26.398438 45.710938 24.128906 44 C 23.847656 43.65625 23.871094 43.15625 24.183594 42.839844 C 24.5 42.527344 25 42.503906 25.34375 42.785156 C 27.269531 44.195312 29.617188 44.90625 32 44.800781 C 34.386719 44.929688 36.746094 44.242188 38.6875 42.847656 C 39.042969 42.503906 39.605469 42.511719 39.953125 42.863281 C 40.296875 43.21875 40.289062 43.785156 39.9375 44.128906 Z M 39.359375 38.527344 C 37.59375 38.527344 36.160156 37.09375 36.160156 35.328125 C 36.160156 33.5625 37.59375 32.128906 39.359375 32.128906 C 41.128906 32.128906 42.558594 33.5625 42.558594 35.328125 C 42.59375 36.203125 42.269531 37.054688 41.65625 37.6875 C 41.046875 38.316406 40.203125 38.664062 39.328125 38.65625 Z M 39.359375 38.527344"});function kj(e,{title:t}){return At(e,"reddit.url"),"https://www.reddit.com/submit"+yt({url:e,title:t})}var cve=Bt("reddit",kj,e=>({title:e.title}),{windowWidth:660,windowHeight:460,windowPosition:"windowCenter"});function Mj(e,{title:t}){return At(e,"gab.url"),"https://gab.com/compose"+yt({url:e,text:t})}var dve=Bt("gab",Mj,e=>({title:e.title}),{windowWidth:660,windowHeight:640,windowPosition:"windowCenter"});var uve=_t({color:"#00d178",networkName:"gab",path:"m17.0506,23.97457l5.18518,0l0,14.23933c0,6.82699 -3.72695,10.09328 -9.33471,10.09328c-2.55969,0 -4.82842,-0.87286 -6.22084,-2.0713l2.07477,-3.88283c1.19844,0.81051 2.33108,1.29543 3.85511,1.29543c2.75366,0 4.44049,-1.97432 4.44049,-4.82149l0,-0.87286c-1.16728,1.39242 -2.81947,2.0713 -4.63446,2.0713c-4.44048,0 -7.81068,-3.68885 -7.81068,-8.28521c0,-4.59289 3.37019,-8.28174 7.81068,-8.28174c1.81499,0 3.46718,0.67888 4.63446,2.0713l0,-1.55521zm-3.62997,11.39217c1.97777,0 3.62997,-1.6522 3.62997,-3.62652c0,-1.97432 -1.6522,-3.62305 -3.62997,-3.62305c-1.97778,0 -3.62997,1.64873 -3.62997,3.62305c0,1.97432 1.65219,3.62652 3.62997,3.62652zm25.7077,4.13913l-5.18518,0l0,-1.29197c-1.00448,1.13264 -2.3969,1.81152 -4.21188,1.81152c-3.62997,0 -5.63893,-2.52504 -5.63893,-5.4034c0,-4.27076 5.251,-5.85715 9.78846,-4.49937c-0.09698,-1.39241 -0.9733,-2.39343 -2.78829,-2.39343c-1.26426,0 -2.72248,0.48492 -3.62997,1.00102l-1.5552,-3.72003c1.19844,-0.77587 3.40136,-1.55174 5.96452,-1.55174c3.78931,0 7.25648,2.13365 7.25648,7.95962l0,8.08777zm-5.18518,-6.14809c-2.42806,-0.77587 -4.66563,-0.3533 -4.66563,1.36124c0,1.00101 0.84168,1.6799 1.84616,1.6799c1.20191,0 2.56315,-0.96984 2.81947,-3.04115zm13.00626,-17.66495l0,9.83695c1.16727,-1.39242 2.81946,-2.0713 4.63445,-2.0713c4.44048,0 7.81068,3.68885 7.81068,8.28174c0,4.59636 -3.37019,8.28521 -7.81068,8.28521c-1.81499,0 -3.46718,-0.67888 -4.63445,-2.0713l0,1.55174l-5.18519,0l0,-23.81304l5.18519,0zm3.62997,19.67391c1.97777,0 3.62997,-1.6522 3.62997,-3.62652c0,-1.97432 -1.6522,-3.62305 -3.62997,-3.62305c-1.97778,0 -3.62997,1.64873 -3.62997,3.62305c0,1.97432 1.65219,3.62652 3.62997,3.62652zm0,0"});function Tj(e,t){let o=`https://www.reddit.com/api/info.json?limit=1&url=${e}`;(0,Oa.default)(o,{param:"jsonp"},(n,a)=>{t(!n&&a&&a.data&&a.data.children.length>0&&a.data.children[0].data.score?a.data.children[0].data.score:void 0)})}var yve=xi(Tj),mve=_t({color:"#25A3E3",networkName:"telegram",path:"m45.90873,15.44335c-0.6901,-0.0281 -1.37668,0.14048 -1.96142,0.41265c-0.84989,0.32661 -8.63939,3.33986 -16.5237,6.39174c-3.9685,1.53296 -7.93349,3.06593 -10.98537,4.24067c-3.05012,1.1765 -5.34694,2.05098 -5.4681,2.09312c-0.80775,0.28096 -1.89996,0.63566 -2.82712,1.72788c-0.23354,0.27218 -0.46884,0.62161 -0.58825,1.10275c-0.11941,0.48114 -0.06673,1.09222 0.16682,1.5716c0.46533,0.96052 1.25376,1.35737 2.18443,1.71383c3.09051,0.99037 6.28638,1.93508 8.93263,2.8236c0.97632,3.44171 1.91401,6.89571 2.84116,10.34268c0.30554,0.69185 0.97105,0.94823 1.65764,0.95525l-0.00351,0.03512c0,0 0.53908,0.05268 1.06412,-0.07375c0.52679,-0.12292 1.18879,-0.42846 1.79109,-0.99212c0.662,-0.62161 2.45836,-2.38812 3.47683,-3.38552l7.6736,5.66477l0.06146,0.03512c0,0 0.84989,0.59703 2.09312,0.68132c0.62161,0.04214 1.4399,-0.07726 2.14229,-0.59176c0.70766,-0.51626 1.1765,-1.34683 1.396,-2.29506c0.65673,-2.86224 5.00979,-23.57745 5.75257,-27.00686l-0.02107,0.08077c0.51977,-1.93157 0.32837,-3.70159 -0.87096,-4.74991c-0.60054,-0.52152 -1.2924,-0.7498 -1.98425,-0.77965l0,0.00176zm-0.2072,3.29069c0.04741,0.0439 0.0439,0.0439 0.00351,0.04741c-0.01229,-0.00351 0.14048,0.2072 -0.15804,1.32576l-0.01229,0.04214l-0.00878,0.03863c-0.75858,3.50668 -5.15554,24.40802 -5.74203,26.96472c-0.08077,0.34417 -0.11414,0.31959 -0.09482,0.29852c-0.1756,-0.02634 -0.50045,-0.16506 -0.52679,-0.1756l-13.13468,-9.70175c4.4988,-4.33199 9.09945,-8.25307 13.744,-12.43229c0.8218,-0.41265 0.68483,-1.68573 -0.29852,-1.70681c-1.04305,0.24584 -1.92279,0.99564 -2.8798,1.47502c-5.49971,3.2626 -11.11882,6.13186 -16.55882,9.49279c-2.792,-0.97105 -5.57873,-1.77704 -8.15298,-2.57601c2.2336,-0.89555 4.00889,-1.55579 5.75608,-2.23009c3.05188,-1.1765 7.01687,-2.7042 10.98537,-4.24067c7.94051,-3.06944 15.92667,-6.16346 16.62028,-6.43037l0.05619,-0.02283l0.05268,-0.02283c0.19316,-0.0878 0.30378,-0.09658 0.35471,-0.10009c0,0 -0.01756,-0.05795 -0.00351,-0.04566l-0.00176,0zm-20.91715,22.0638l2.16687,1.60145c-0.93418,0.91311 -1.81743,1.77353 -2.45485,2.38812l0.28798,-3.98957"});function Aj(e,{title:t}){return At(e,"telegram.url"),"https://telegram.me/share/url"+yt({url:e,text:t})}var gve=Bt("telegram",Aj,e=>({title:e.title}),{windowWidth:550,windowHeight:400});var fve=_t({color:"#34526f",networkName:"tumblr",path:"M39.2,41c-0.6,0.3-1.6,0.5-2.4,0.5c-2.4,0.1-2.9-1.7-2.9-3v-9.3h6v-4.5h-6V17c0,0-4.3,0-4.4,0 c-0.1,0-0.2,0.1-0.2,0.2c-0.3,2.3-1.4,6.4-5.9,8.1v3.9h3V39c0,3.4,2.5,8.1,9,8c2.2,0,4.7-1,5.2-1.8L39.2,41z"});function _j(e,{title:t,caption:o,tags:n,posttype:a}){return At(e,"tumblr.url"),"https://www.tumblr.com/widgets/share/tool"+yt({canonicalUrl:e,title:t,caption:o,tags:n,posttype:a})}var bve=Bt("tumblr",_j,e=>({title:e.title,tags:(e.tags||[]).join(","),caption:e.caption,posttype:e.posttype||"link"}),{windowWidth:660,windowHeight:460});function wj(e,t){return(0,Oa.default)("https://api.tumblr.com/v2/share/stats"+yt({url:e}),(n,a)=>{t(!n&&a&&a.response?a.response.note_count:void 0)})}var Sve=xi(wj),Dj=_t({color:"#00aced",networkName:"twitter",path:"M48,22.1c-1.2,0.5-2.4,0.9-3.8,1c1.4-0.8,2.4-2.1,2.9-3.6c-1.3,0.8-2.7,1.3-4.2,1.6 C41.7,19.8,40,19,38.2,19c-3.6,0-6.6,2.9-6.6,6.6c0,0.5,0.1,1,0.2,1.5c-5.5-0.3-10.3-2.9-13.5-6.9c-0.6,1-0.9,2.1-0.9,3.3 c0,2.3,1.2,4.3,2.9,5.5c-1.1,0-2.1-0.3-3-0.8c0,0,0,0.1,0,0.1c0,3.2,2.3,5.8,5.3,6.4c-0.6,0.1-1.1,0.2-1.7,0.2c-0.4,0-0.8,0-1.2-0.1 c0.8,2.6,3.3,4.5,6.1,4.6c-2.2,1.8-5.1,2.8-8.2,2.8c-0.5,0-1.1,0-1.6-0.1c2.9,1.9,6.4,2.9,10.1,2.9c12.1,0,18.7-10,18.7-18.7 c0-0.3,0-0.6,0-0.8C46,24.5,47.1,23.4,48,22.1z"}),VN=Dj;function Pj(e,{title:t,via:o,hashtags:n=[],related:a=[]}){return At(e,"twitter.url"),At(Array.isArray(n),"twitter.hashtags is not an array"),At(Array.isArray(a),"twitter.related is not an array"),"https://twitter.com/intent/tweet"+yt({url:e,text:t,via:o,hashtags:n.length>0?n.join(","):void 0,related:a.length>0?a.join(","):void 0})}var Nj=Bt("twitter",Pj,e=>({hashtags:e.hashtags,title:e.title,via:e.via,related:e.related}),{windowWidth:550,windowHeight:400}),ON=Nj,hve=_t({color:"#7360f2",networkName:"viber",path:"m31.0,12.3c9.0,0.2 16.4,6.2 18.0,15.2c0.2,1.5 0.3,3.0 0.4,4.6a1.0,1.0 0 0 1 -0.8,1.2l-0.1,0a1.1,1.1 0 0 1 -1.0,-1.2l0,0c-0.0,-1.2 -0.1,-2.5 -0.3,-3.8a16.1,16.1 0 0 0 -13.0,-13.5c-1.0,-0.1 -2.0,-0.2 -3.0,-0.3c-0.6,-0.0 -1.4,-0.1 -1.6,-0.8a1.1,1.1 0 0 1 0.9,-1.2l0.6,0l0.0,-0.0zm10.6,39.2a19.9,19.9 0 0 1 -2.1,-0.6c-6.9,-2.9 -13.2,-6.6 -18.3,-12.2a47.5,47.5 0 0 1 -7.0,-10.7c-0.8,-1.8 -1.6,-3.7 -2.4,-5.6c-0.6,-1.7 0.3,-3.4 1.4,-4.7a11.3,11.3 0 0 1 3.7,-2.8a2.4,2.4 0 0 1 3.0,0.7a39.0,39.0 0 0 1 4.7,6.5a3.1,3.1 0 0 1 -0.8,4.2c-0.3,0.2 -0.6,0.5 -1.0,0.8a3.3,3.3 0 0 0 -0.7,0.7a2.1,2.1 0 0 0 -0.1,1.9c1.7,4.9 4.7,8.7 9.7,10.8a5.0,5.0 0 0 0 2.5,0.6c1.5,-0.1 2.0,-1.8 3.1,-2.7a2.9,2.9 0 0 1 3.5,-0.1c1.1,0.7 2.2,1.4 3.3,2.2a37.8,37.8 0 0 1 3.1,2.4a2.4,2.4 0 0 1 0.7,3.0a10.4,10.4 0 0 1 -4.4,4.8a10.8,10.8 0 0 1 -1.9,0.6c-0.7,-0.2 0.6,-0.2 0,0l0.0,0l0,-0.0zm3.1,-21.4a4.2,4.2 0 0 1 -0.0,0.6a1.0,1.0 0 0 1 -1.9,0.1a2.7,2.7 0 0 1 -0.1,-0.8a10.9,10.9 0 0 0 -1.4,-5.5a10.2,10.2 0 0 0 -4.2,-4.0a12.3,12.3 0 0 0 -3.4,-1.0c-0.5,-0.0 -1.0,-0.1 -1.5,-0.2a0.9,0.9 0 0 1 -0.9,-1.0l0,-0.1a0.9,0.9 0 0 1 0.9,-0.9l0.1,0a14.1,14.1 0 0 1 5.9,1.5a11.9,11.9 0 0 1 6.5,9.3c0,0.1 0.0,0.3 0.0,0.5c0,0.4 0.0,0.9 0.0,1.5l0,0l0.0,0.0zm-5.6,-0.2a1.1,1.1 0 0 1 -1.2,-0.9l0,-0.1a11.3,11.3 0 0 0 -0.2,-1.4a4.0,4.0 0 0 0 -1.5,-2.3a3.9,3.9 0 0 0 -1.2,-0.5c-0.5,-0.1 -1.1,-0.1 -1.6,-0.2a1.0,1.0 0 0 1 -0.8,-1.1l0,0l0,0a1.0,1.0 0 0 1 1.1,-0.8c3.4,0.2 6.0,2.0 6.3,6.2a2.8,2.8 0 0 1 0,0.8a0.8,0.8 0 0 1 -0.8,0.7l0,0l0.0,-0.0z"});function Ej(e,{title:t,separator:o}){return At(e,"viber.url"),"viber://forward"+yt({text:t?t+o+e:e})}var Cve=Bt("viber",Ej,e=>({title:e.title,separator:e.separator||" "}),{windowWidth:660,windowHeight:460});var xve=_t({color:"#4C75A3",networkName:"vk",path:"M44.94,44.84h-0.2c-2.17-.36-3.66-1.92-4.92-3.37C39.1,40.66,38,38.81,36.7,39c-1.85.3-.93,3.52-1.71,4.9-0.62,1.11-3.29.91-5.12,0.71-5.79-.62-8.75-3.77-11.35-7.14A64.13,64.13,0,0,1,11.6,26a10.59,10.59,0,0,1-1.51-4.49C11,20.7,12.56,21,14.11,21c1.31,0,3.36-.29,4.32.2C19,21.46,19.57,23,20,24a37.18,37.18,0,0,0,3.31,5.82c0.56,0.81,1.41,2.35,2.41,2.14s1.06-2.63,1.1-4.18c0-1.77,0-4-.5-4.9S25,22,24.15,21.47c0.73-1.49,2.72-1.63,5.12-1.63,2,0,4.84-.23,5.62,1.12s0.25,3.85.2,5.71c-0.06,2.09-.41,4.25,1,5.21,1.09-.12,1.68-1.2,2.31-2A28,28,0,0,0,41.72,24c0.44-1,.91-2.65,1.71-3,1.21-.47,3.15-0.1,4.92-0.1,1.46,0,4.05-.41,4.52.61,0.39,0.85-.75,3-1.1,3.57a61.88,61.88,0,0,1-4.12,5.61c-0.58.78-1.78,2-1.71,3.27,0.05,0.94,1,1.67,1.71,2.35a33.12,33.12,0,0,1,3.92,4.18c0.47,0.62,1.5,2,1.4,2.76C52.66,45.81,46.88,44.24,44.94,44.84Z"});function Rj(e,{title:t,image:o,noParse:n,noVkLinks:a}){return At(e,"vk.url"),"https://vk.com/share.php"+yt({url:e,title:t,image:o,noparse:n?1:0,no_vk_links:a?1:0})}var vve=Bt("vk",Rj,e=>({title:e.title,image:e.image,noParse:e.noParse,noVkLinks:e.noVkLinks}),{windowWidth:660,windowHeight:460});function Fj(e,t){window.VK||(window.VK={}),window.VK.Share={count:(a,s)=>{var l,p;return(p=(l=window.VK.callbacks)==null?void 0:l[a])==null?void 0:p.call(l,s)}},window.VK.callbacks=[];let o="https://vk.com/share.php",n=window.VK.callbacks.length;return window.VK.callbacks.push(t),(0,Oa.default)(o+yt({act:"count",index:n,url:e}))}var Ive=xi(Fj),kve=_t({color:"#DF2029",networkName:"weibo",path:"M40.9756152,15.0217119 C40.5000732,15.0546301 39.9999314,15.1204666 39.5325878,15.2192213 C38.6634928,15.4085016 38.0977589,16.2643757 38.2863368,17.1284787 C38.4667163,18.0008129 39.3194143,18.5686519 40.1885094,18.3793715 C42.8613908,17.8115326 45.7720411,18.6427174 47.7316073,20.8153207 C49.6911735,22.996153 50.2077122,25.975254 49.3714112,28.5840234 C49.1008441,29.4316684 49.5763861,30.3533789 50.4208857,30.6249537 C51.2653852,30.8965286 52.1754769,30.4192153 52.4542425,29.5715703 C53.6349013,25.9011885 52.9133876,21.7699494 50.1585171,18.7085538 C48.0923641,16.4042776 45.2063093,15.1533848 42.3530505,15.0217119 C41.8775084,14.9970227 41.4511594,14.9887937 40.9756152,15.0217119 Z M27.9227762,19.8277737 C24.9957268,20.140498 20.863421,22.4365431 17.2312548,26.0822378 C13.2711279,30.0571148 11,34.2871065 11,37.9328012 C11,44.9032373 19.8713401,49.125 28.5786978,49.125 C39.9917329,49.125 47.600423,42.4261409 47.600423,37.1427636 C47.600423,33.9496952 44.9603397,32.1638816 42.549827,31.4149913 C41.9594976,31.2339421 41.5167516,31.1434164 41.8283133,30.3616079 C42.5006339,28.66632 42.6236176,27.1932286 41.8939054,26.1480742 C40.5328692,24.1894405 36.7203236,24.2881952 32.448635,26.0822378 C32.448635,26.0822378 31.1203949,26.6912261 31.4647526,25.6213825 C32.1206742,23.4981576 32.0304845,21.712342 31.0056075,20.6836478 C30.2840938,19.9512176 29.2510184,19.6878718 27.9227762,19.8277737 Z M42.0906819,20.6836478 C41.6233383,20.6589586 41.1723917,20.716566 40.7132466,20.8153207 C39.9671353,20.9716828 39.4997917,21.7781784 39.6637721,22.5270687 C39.8277525,23.275959 40.5574647,23.7450433 41.303576,23.5804521 C42.1972686,23.3911718 43.2057485,23.6380596 43.8616701,24.3704897 C44.5175916,25.1029198 44.6733735,26.0657797 44.3864073,26.9381118 C44.1486363,27.6705419 44.5093932,28.4770397 45.2391054,28.7156963 C45.9688176,28.9461239 46.780521,28.5922524 47.0100936,27.8598223 C47.584026,26.0740087 47.2396661,24.0248493 45.8950269,22.5270687 C44.886547,21.4078489 43.4845162,20.7494842 42.0906819,20.6836478 Z M29.496988,29.9665891 C35.3100922,30.1723275 39.9917329,33.0691319 40.3852858,37.0769272 C40.8362324,41.6607904 35.5970585,45.9319315 28.6442899,46.6232144 C21.6915214,47.3144973 15.6488446,44.154347 15.197898,39.5787128 C14.7469514,34.9948495 20.059916,30.7237084 27.004486,30.0324256 C27.8735831,29.950131 28.6688875,29.9336709 29.496988,29.9665891 Z M25.5614586,34.3776322 C23.183744,34.5916017 20.9372116,35.9577073 19.9205332,37.9328012 C18.5348994,40.6238672 19.9041362,43.6029661 23.0689567,44.582284 C26.340366,45.5945202 30.1857056,44.0638213 31.5303448,41.1587879 C32.8503864,38.3195909 31.1613894,35.3734082 27.9227762,34.5751416 C27.1438688,34.3776322 26.356763,34.3035667 25.5614586,34.3776322 Z M24.052839,38.7228388 C24.3316067,38.7310678 24.5857748,38.8215935 24.8399449,38.9203482 C25.8648218,39.3400561 26.1845841,40.4428158 25.5614586,41.4221338 C24.9219361,42.3932227 23.5690963,42.8623069 22.5442194,42.4096807 C21.5357395,41.9652856 21.2487754,40.8542948 21.8882979,39.9078951 C22.3638421,39.2001542 23.2247386,38.7146097 24.052839,38.7228388 Z"});function Bj(e,{title:t,image:o}){return At(e,"weibo.url"),"http://service.weibo.com/share/share.php"+yt({url:e,title:t,pic:o})}var Mve=Bt("weibo",Bj,e=>({title:e.title,image:e.image}),{windowWidth:660,windowHeight:550,windowPosition:"screenCenter"});var Tve=_t({color:"#25D366",networkName:"whatsapp",path:"m42.32286,33.93287c-0.5178,-0.2589 -3.04726,-1.49644 -3.52105,-1.66732c-0.4712,-0.17346 -0.81554,-0.2589 -1.15987,0.2589c-0.34175,0.51004 -1.33075,1.66474 -1.63108,2.00648c-0.30032,0.33658 -0.60064,0.36247 -1.11327,0.12945c-0.5178,-0.2589 -2.17994,-0.80259 -4.14759,-2.56312c-1.53269,-1.37217 -2.56312,-3.05503 -2.86603,-3.57283c-0.30033,-0.5178 -0.03366,-0.80259 0.22524,-1.06149c0.23301,-0.23301 0.5178,-0.59547 0.7767,-0.90616c0.25372,-0.31068 0.33657,-0.5178 0.51262,-0.85437c0.17088,-0.36246 0.08544,-0.64725 -0.04402,-0.90615c-0.12945,-0.2589 -1.15987,-2.79613 -1.58964,-3.80584c-0.41424,-1.00971 -0.84142,-0.88027 -1.15987,-0.88027c-0.29773,-0.02588 -0.64208,-0.02588 -0.98382,-0.02588c-0.34693,0 -0.90616,0.12945 -1.37736,0.62136c-0.4712,0.5178 -1.80194,1.76053 -1.80194,4.27186c0,2.51134 1.84596,4.945 2.10227,5.30747c0.2589,0.33657 3.63497,5.51458 8.80262,7.74113c1.23237,0.5178 2.1903,0.82848 2.94111,1.08738c1.23237,0.38836 2.35599,0.33657 3.24402,0.20712c0.99159,-0.15534 3.04985,-1.24272 3.47963,-2.45956c0.44013,-1.21683 0.44013,-2.22654 0.31068,-2.45955c-0.12945,-0.23301 -0.46601,-0.36247 -0.98382,-0.59548m-9.40068,12.84407l-0.02589,0c-3.05503,0 -6.08417,-0.82849 -8.72495,-2.38189l-0.62136,-0.37023l-6.47252,1.68286l1.73463,-6.29129l-0.41424,-0.64725c-1.70875,-2.71846 -2.6149,-5.85116 -2.6149,-9.07706c0,-9.39809 7.68934,-17.06155 17.15993,-17.06155c4.58253,0 8.88029,1.78642 12.11655,5.02268c3.23625,3.21036 5.02267,7.50812 5.02267,12.06476c-0.0078,9.3981 -7.69712,17.06155 -17.14699,17.06155m14.58906,-31.58846c-3.93529,-3.80584 -9.1133,-5.95471 -14.62789,-5.95471c-11.36055,0 -20.60848,9.2065 -20.61625,20.52564c0,3.61684 0.94757,7.14565 2.75211,10.26282l-2.92557,10.63564l10.93337,-2.85309c3.0136,1.63108 6.4052,2.4958 9.85634,2.49839l0.01037,0c11.36574,0 20.61884,-9.2091 20.62403,-20.53082c0,-5.48093 -2.14111,-10.64081 -6.03239,-14.51915"});function $j(){return/(android|iphone|ipad|mobile)/i.test(navigator.userAgent)}function Lj(e,{title:t,separator:o}){return At(e,"whatsapp.url"),"https://"+($j()?"api":"web")+".whatsapp.com/send"+yt({text:t?t+o+e:e})}var Ave=Bt("whatsapp",Lj,e=>({title:e.title,separator:e.separator||" "}),{windowWidth:550,windowHeight:400});var _ve=_t({color:"#4326c4",networkName:"workplace",path:"M34.019,10.292c0.21,0.017,0.423,0.034,0.636,0.049 c3.657,0.262,6.976,1.464,9.929,3.635c3.331,2.448,5.635,5.65,6.914,9.584c0.699,2.152,0.983,4.365,0.885,6.623 c-0.136,3.171-1.008,6.13-2.619,8.867c-0.442,0.75-0.908,1.492-1.495,2.141c-0.588,0.651-1.29,1.141-2.146,1.383 c-1.496,0.426-3.247-0.283-3.961-1.642c-0.26-0.494-0.442-1.028-0.654-1.548c-1.156-2.838-2.311-5.679-3.465-8.519 c-0.017-0.042-0.037-0.082-0.065-0.145c-0.101,0.245-0.192,0.472-0.284,0.698c-1.237,3.051-2.475,6.103-3.711,9.155 c-0.466,1.153-1.351,1.815-2.538,2.045c-1.391,0.267-2.577-0.154-3.496-1.247c-0.174-0.209-0.31-0.464-0.415-0.717 c-2.128-5.22-4.248-10.442-6.37-15.665c-0.012-0.029-0.021-0.059-0.036-0.104c0.054-0.003,0.103-0.006,0.15-0.006 c1.498-0.001,2.997,0,4.495-0.004c0.12-0.001,0.176,0.03,0.222,0.146c1.557,3.846,3.117,7.691,4.679,11.536 c0.018,0.046,0.039,0.091,0.067,0.159c0.273-0.673,0.536-1.32,0.797-1.968c1.064-2.627,2.137-5.25,3.19-7.883 c0.482-1.208,1.376-1.917,2.621-2.135c1.454-0.255,2.644,0.257,3.522,1.449c0.133,0.18,0.229,0.393,0.313,0.603 c1.425,3.495,2.848,6.991,4.269,10.488c0.02,0.047,0.04,0.093,0.073,0.172c0.196-0.327,0.385-0.625,0.559-0.935 c0.783-1.397,1.323-2.886,1.614-4.461c0.242-1.312,0.304-2.634,0.187-3.962c-0.242-2.721-1.16-5.192-2.792-7.38 c-2.193-2.939-5.086-4.824-8.673-5.625c-1.553-0.346-3.124-0.405-4.705-0.257c-3.162,0.298-6.036,1.366-8.585,3.258 c-3.414,2.534-5.638,5.871-6.623,10.016c-0.417,1.76-0.546,3.547-0.384,5.348c0.417,4.601,2.359,8.444,5.804,11.517 c2.325,2.073,5.037,3.393,8.094,3.989c1.617,0.317,3.247,0.395,4.889,0.242c1-0.094,1.982-0.268,2.952-0.529 c0.04-0.01,0.081-0.018,0.128-0.028c0,1.526,0,3.047,0,4.586c-0.402,0.074-0.805,0.154-1.21,0.221 c-0.861,0.14-1.728,0.231-2.601,0.258c-0.035,0.002-0.071,0.013-0.108,0.021c-0.493,0-0.983,0-1.476,0 c-0.049-0.007-0.1-0.018-0.149-0.022c-0.315-0.019-0.629-0.033-0.945-0.058c-1.362-0.105-2.702-0.346-4.017-0.716 c-3.254-0.914-6.145-2.495-8.66-4.752c-2.195-1.971-3.926-4.29-5.176-6.963c-1.152-2.466-1.822-5.057-1.993-7.774 c-0.014-0.226-0.033-0.451-0.05-0.676c0-0.502,0-1.003,0-1.504c0.008-0.049,0.02-0.099,0.022-0.148 c0.036-1.025,0.152-2.043,0.338-3.052c0.481-2.616,1.409-5.066,2.8-7.331c2.226-3.625,5.25-6.386,9.074-8.254 c2.536-1.24,5.217-1.947,8.037-2.126c0.23-0.015,0.461-0.034,0.691-0.051C33.052,10.292,33.535,10.292,34.019,10.292z"});function Hj(e,{quote:t,hashtag:o}){return At(e,"workplace.url"),"https://work.facebook.com/sharer.php"+yt({u:e,quote:t,hashtag:o})}var wve=Bt("workplace",Hj,e=>({quote:e.quote,hashtag:e.hashtag}),{windowWidth:550,windowHeight:400});var Dve=_t({color:"#000000",networkName:"X",path:"M 41.116 18.375 h 4.962 l -10.8405 12.39 l 12.753 16.86 H 38.005 l -7.821 -10.2255 L 21.235 47.625 H 16.27 l 11.595 -13.2525 L 15.631 18.375 H 25.87 l 7.0695 9.3465 z m -1.7415 26.28 h 2.7495 L 24.376 21.189 H 21.4255 z"});var nh=({title:e,...t})=>{Y("sdsm-social");let[o,n]=(0,my.useState)("");return Y("sdsm-social"),(0,my.useEffect)(()=>{n(window.location.origin+window.location.pathname)},[]),x("article",{...t,className:h("sdsm-social",t.className),"data-testid":"sdsm-social",children:[i(HN,{title:e,url:o,children:i(LN,{size:32,round:!0})}),i(ON,{title:e,url:o,children:i(VN,{size:32,round:!0})})]})};nh.displayName="Social";var rh=256,GN=714,zN=1014,UN="860px",WN=375,gy="--hero-curtain-opacity",QN=c`
  align-items: start;
`,qN=c`
  align-items: end;
`,KN=c`
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-block: ${r("--spacing-xl")};
  padding-inline: ${r("--spacing-xl")};
  z-index: ${Ee.HERO_TEXT};

  ${N} {
    padding-inline: 0;
    width: 100%;
  }
`,ah=c`
  & .${"sdsm-topic"} {
    &:hover {
      background-color: rgba(0, 0, 0, calc(var(${gy}, 0) + 0.2));
    }
  }
`,jN=c`
  overflow: hidden;
  max-height: 100%;
`,YN=c`
  background-color: ${r("--bg-color")};
  background-image: ${r("--bg-image")};
  position: relative;
  width: 100%;
  --hero-text-color-curtain-title-color: ${r("--hero-title-color")};
  --hero-text-color-curtain-subtitle-color: ${r("--hero-subtitle-color")};

  &[data-curtain='true'] {
    --hero-text-color-curtain-title-color: ${r("--hero-text-color-curtain-active")};
    --hero-text-color-curtain-subtitle-color: ${r("--hero-text-color-curtain-active")};

    & .${"sdsm-topic"} {
      border-color: ${r("--hero-text-color-curtain-active")};
      color: ${r("--hero-text-color-curtain-active")};
    }

    ${ah}
  }

  ${N} {
    min-height: ${rh}px;

    & > video {
      min-height: ${rh}px;
    }
  }
`,XN=c`
  align-items: center;
  display: grid;
  grid-auto-columns: minmax(0, 100%) 40%;
  grid-auto-flow: column;
  grid-gap: ${r("--spacing-xl")};
  min-height: ${GN}px;
  padding: ${r("--hero-content-desktop-padding")};

  ${N} {
    grid-auto-flow: row;
    padding: ${r("--hero-content-mobile-padding")};
    min-height: ${rh}px;
    max-width: 100vw;
  }

  ${Ht} {
    padding-bottom: ${r("--spacing-xl")};
  }
`,JN=c`
  ${N} {
    padding-block-start: ${r("--spacing-xxl")};
  }

  ${H} {
    padding-block-start: ${r("--spacing-xxxxl")};
  }
`,ZN=c`
  min-height: 0px;
`,eE=c`
  /** Relative color syntax decomposes the hex --curtain-color into r g b channels so opacity can be applied dynamically */
  background-color: rgb(from ${r("--curtain-color")} r g b / var(${gy}, 0));
  backdrop-filter: ${r("--curtain-backdrop-filter")};
  inset: 0;
  position: absolute;
  z-index: ${Ee.HERO_CURTAIN};
`,tE=c`
  color: var(--hero-text-color-curtain-title-color);
`,oE=c`
  /**
   * using var instead of m function because this is not a motif variable.
   * It is a custom css var defined in heroCss.
   */
  color: var(--hero-text-color-curtain-title-color);
  font-size: ${r("--annotation-desktop-font-size")};
  line-height: ${r("--annotation-desktop-font-line-height")};
  font-weight: ${r("--annotation-desktop-font-weight")};
  letter-spacing: ${r("--annotation-desktop-font-letter-spacing")};
  margin-block-end: ${r("--spacing-m")};

  ${N} {
    font-size: ${r("--annotation-mobile-font-size")};
    line-height: ${r("--annotation-mobile-font-line-height")};
    font-weight: ${r("--annotation-mobile-font-weight")};
    letter-spacing: ${r("--annotation-mobile-font-letter-spacing")};
  }
`,ih=c`
  /**
 * using var instead of m function because this is not a motif variable.
 * It is a custom css var defined in heroCss.
 */
  color: var(--hero-text-color-curtain-title-color);
  margin-block: 0 ${r("--spacing-m")};

  &:has(.${"sdsm-empahasized-text"}) {
    color: ${r("--hero-title-de-emphasized-color")};
  }

  ${N} {
    margin-block: 0 ${r("--spacing-xs")};
  }
`,nE=c`
  ${ih}
  /**
   * Ensure Hero Split title uses compact desktop font size
   */
  && {
    ${H} {
      && {
        font-size: ${r("--h1-desktop-font-size-compact")};
        line-height: ${r("--h1-desktop-font-line-height-compact")};
      }
    }
  }
`,rE=c`
  && {
    font-size: ${r("--hero-title-increased-font-size")};
    line-height: ${r("--hero-title-increased-font-line-height")};
  }
`,aE=c`
  ${yo}
  color: var(--hero-text-color-curtain-subtitle-color);
  margin-block-end: ${r("--spacing-m")};
  max-width: ${UN};

  ${N} {
    margin-block-end: ${r("--spacing-xs")};
  }

  /** Overriding margin added from renderRichTextWithElementsNoHeadings*/
  & p {
    margin: 0;
  }
`,iE=c`
  display: flex;
  flex-wrap: wrap;
  gap: ${r("--spacing-s")};
  margin-top: ${r("--spacing-xs")};
`,sE=c`
  ${ut}
  color: var(--hero-text-color-curtain-subtitle-color);
  margin-block-end: ${r("--spacing-m")};
  max-width: ${UN};

  ${N} {
    margin-block-end: ${r("--spacing-xs")};
  }
  /** Overriding margin added from renderRichTextWithElementsNoHeadings */
  & p {
    margin-bottom: 0;
  }

  /**
   * If the body has multiple paragraphs, we need to add a top margin.
   * Do not add a margin bottom to avoid extra white space by adding the paragraph and parent margins.
   */
  & p + p {
    margin-block-start: ${r("--spacing-s")};
  }
`,lE=c`
  display: flex;
  gap: ${r("--spacing-m")};
  margin-block-start: ${r("--spacing-m")};

  ${N} {
    flex-direction: column;
  }

  ${Ht} {
    width: 100%;
  }
`,pE=c`
  ${ut}
  color: var(--hero-text-color-curtain-subtitle-color);
  margin-block-start: ${r("--spacing-xl")};

  ${N} {
    margin-block-start: ${r("--spacing-l")};
    text-align: center;
  }
`,cE=c`
  position: absolute;
  bottom: calc(${r("--break-total-desktop-height")} + ${r("--spacing-xl")});
  left: ${r("--spacing-xl")};
  z-index: ${Ee.HERO_CURTAIN};

  button {
    margin-right: ${r("--spacing-s")};
  }

  ${N} {
    bottom: calc(${r("--break-total-mobile-height")} + ${r("--spacing-m")});
    left: ${r("--spacing-xl")};
  }
`,sh=c`
  ${H} {
    height: calc(100vh - ${64}px);
    max-height: 1600px;
    min-height: ${GN}px;
  }
`,lh=c`
  height: 100%;
  left: 0;
  /* Prevent overflowing elements from adding extra page width, e.g. background media stickers */
  overflow: hidden;
  position: absolute;
  top: 0;
  width: 100%;
`,ph=c`
  height: 100%;
  object-fit: cover;
  width: 100%;
`,dE=c`
  ${N} {
    max-width: 100%;
    overflow-x: auto;
  }
`,uE=c`
  z-index: ${Ee.HERO_BOUNDARY};
`,yE=c`
  bottom: ${r("--spacing-xl")};
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  z-index: ${Ee.HERO_TEXT};
`,mE=c`
  background: ${r("--hero-scroll-button-bg-color")};
  border: none;
  box-shadow: none;
  transition: background 0.2s linear;

  svg {
    fill: ${r("--hero-scroll-button-fg-color")};
  }

  &:hover {
    background: ${r("--hero-scroll-button-hover-bg-color")};
    border: none;
    transform: none;

    svg {
      fill: ${r("--hero-scroll-button-hover-fg-color")};
    }
  }

  [data-curtain='true'] & {
    background: ${r("--hero-scroll-button-curtain-active-bg-color")};

    svg {
      fill: ${r("--hero-scroll-button-curtain-active-fg-color")};
    }

    &:hover {
      background: ${r("--hero-scroll-button-curtain-active-hover-bg-color")};

      svg {
        fill: ${r("--hero-scroll-button-curtain-active-hover-fg-color")};
      }
    }
  }
`,gE=c`
  align-items: stretch;
  display: flex;
  justify-content: space-between;

  ${N} {
    flex-direction: column;
    flex-direction: column-reverse;
  }
`,fE=c`
  flex-direction: row-reverse;
`,fy=c`
  width: 50%;
  ${N} {
    width: 100%;
  }
`,ch=c`
  height: inherit;
  position: relative;

  ${N} {
    height: ${WN}px;
  }
`,dh=c`
  ${N} {
    max-height: ${WN}px;
  }
`;var bE=84,SE=c`
  ${ut}
  ${N} {
    margin-block-end: ${r("--spacing-xs")};
    display: flex;
    flex-direction: column;
    width: 100%;
  }

  ${H} {
    display: none;
  }
`,hE=c`
  ${ut}
  ${N} {
    display: none;
  }

  ${H} {
    margin-block-end: ${r("--spacing-m")};
    display: flex;
    align-items: center;
  }
`,uh=c`
  border-radius: ${r("--spacing-xs")};
  width: ${bE}px;
  height: ${bE}px;
  object-fit: contain;

  ${N} {
    margin-bottom: ${r("--spacing-m")};
  }

  ${H} {
    margin-inline: 0 ${r("--spacing-m")};

    *[dir='rtl'] & {
      margin-inline: ${r("--spacing-m")} 0;
    }
  }
`;function CE(e){return e?typeof e.getFullYear=="function":!1}var xE=e=>e.toLocaleDateString(void 0,{year:"numeric",month:"long",day:"numeric"}),vE=e=>e.toLocaleDateString(void 0,{year:"numeric",month:"numeric",day:"2-digit"});var yh=({content:e,iconSrcs:t,iconAltText:o,textAlignMobile:n,headerDataset:a,className:s})=>{if(!e&&!t)return null;let l=CE(e),p=l?vE(e):e,d=l?xE(e):e,u=t&&i("div",{className:uh,children:i(et,{imgSrcs:t,imgClassName:uh,altText:o})});return x(pe,{children:[x("div",{"data-testid":"sdsm-hero-header",className:h(hE,s),...ne(a),children:[u,d]}),x("div",{className:h(ar[n??ie.Start],SE,s),...ne(a),children:[u,p]})]})};yh.displayName="HeroHeader";var qE=T(w());var IE=225,kE=180,ME=20,Pp=c`
  color: ${r("--summary-card-fg-color")};
  background-color: ${r("--summary-card-bg-color")};
  border: ${r("--summary-card-border-width")} solid ${r("--summary-card-border-color")};
  border-radius: ${r("--summary-card-border-radius")};
  display: flex;
  box-shadow: ${r("--summary-card-box-shadow")};
  flex-direction: row;
  height: ${kE}px;
  transition: background-color 0.2s linear, border-color 0.2s linear, box-shadow 0.2s linear;
  will-change: filter;

  ${H} {
    height: ${IE}px;
  }

  :hover {
    background-color: ${r("--summary-card-hover-bg-color")};
    border-color: ${r("--summary-card-hover-border-color")};
    box-shadow: ${r("--summary-card-hover-box-shadow")};
  }
`,by=c`
  display: flex;
  flex-direction: row;
  width: 100%;
`,Sy=c`
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  height: 100%;
  min-width: 101px;
  width: 101px;

  video {
    border-radius: 0;
    height: ${kE}px;
    width: 100%;

    ${H} {
      height: ${IE}px;
    }
  }

  ${Xe} {
    min-width: 126px;
    width: 126px;
  }

  ${kk} {
    min-width: 134px;
    width: 134px;
  }
`,TE=c`
  /* stylelint-disable-next-line value-no-vendor-prefix */
  display: -webkit-box;
  -webkit-box-orient: vertical;
  font-weight: 500;
  margin-bottom: ${r("--spacing-xxs")};
  overflow: hidden;
  word-break: break-word;
  color: ${r("--summary-card-title-color")};

  ${Xe} {
    margin-bottom: ${r("--spacing-xs")};
  }
`,AE=c`
  /* NOTE(dvazbynd): margin-block-start should match line-height of summaryCardDateCss */
  margin-block-start: ${ME}px;
`,_E=c`
  -webkit-line-clamp: 4;
  font-size: 18px;
  line-height: 26px;

  ${H} {
    font-size: 24px;
    line-height: 34px;
  }
`,wE=c`
  -webkit-line-clamp: 5;
  font-size: 14px;
  line-height: 20px;

  ${H} {
    -webkit-line-clamp: 4;
    font-size: 20px;
    line-height: 30px;
  }
`,DE=c`
  -webkit-line-clamp: 3;
  font-size: 18px;
  line-height: 26px;

  ${H} {
    -webkit-line-clamp: 4;
    font-size: 20px;
    line-height: 30px;
  }
`,PE=c`
  -webkit-line-clamp: 3;
  font-size: 18px;
  line-height: 26px;

  ${H} {
    -webkit-line-clamp: 3;
    font-size: 20px;
    line-height: 30px;
  }
`,NE=c`
  -webkit-line-clamp: 3;
  font-size: 14px;
  line-height: 20px;

  ${H} {
    font-size: 20px;
    line-height: 30px;
  }
`,mh=c`
  font-size: 12px;
  font-weight: 500;
  line-height: ${ME}px;
  margin-bottom: ${r("--spacing-xxs")};

  ${Xe} {
    font-size: 14px;
    margin-bottom: ${r("--spacing-xs")};
  }
`,hy=c`
  color: ${r("--summary-card-fg-color")};
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  padding: ${r("--spacing-m")};

  ${H} {
    padding: ${r("--spacing-l")};
  }
`,EE=c`
  justify-content: space-between;
`,RE=c`
  -webkit-box-orient: vertical;
  color: ${r("--summary-card-description-color")};
  /* stylelint-disable-next-line value-no-vendor-prefix */
  display: -webkit-box;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  overflow: hidden;
  pointer-events: none;
  word-break: break-word;

  b,
  strong,
  > * b,
  > * strong {
    font-weight: normal;
  }

  i,
  > * i {
    font-style: normal;
  }

  a,
  u,
  > * a,
  > * u {
    text-decoration: none;
    color: inherit;
  }

  ${H} {
    font-size: 16px;
    line-height: 26px;
  }

  > *:not(:first-child) {
    display: none;
  }
`,FE=c`
  -webkit-line-clamp: 3;

  ${H} {
    -webkit-line-clamp: 2;
  }
`,BE=c`
  -webkit-line-clamp: 2;
`,$E=c`
  display: block;
  height: 100%;
  width: 100%;
`,LE=c`
  /* Due to stickers overlapping the image, we cannot have 'overflow: hidden' on the container or they
  * get clipped. Therefore, we need to set the border radius on the image as well.
  *
  * As the image is inside the outer card container, which has the border applied, the radius needs to
  * be smaller in order to match the curve of the container, so remove the border width from the radius.
  * 
  * NOTE: Ensure that '--summary-card-border-width' has 'px' unit as it is required for 'calc()', which
  * will not work with '0'.
  */
  border-end-end-radius: calc(
    ${r("--summary-card-border-radius")} - ${r("--summary-card-border-width")}
  );
  border-start-end-radius: calc(
    ${r("--summary-card-border-radius")} - ${r("--summary-card-border-width")}
  );
  height: 100%;
  object-fit: cover;
  object-position: center;
  width: 100%;
`,HE=c`
  text-decoration: none;
`,gh=c`
  background-color: rgb(232, 232, 235);
`,VE=c`
  gap: 10px;
`,OE=c`
  border-radius: ${r("--border-radius-m")};
`,fh=c`
  position: relative;
  overflow: hidden;

  &::before {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    transform: translateX(-100%);
    content: '';
    background: linear-gradient(0.25turn, transparent, #fff, transparent);
    pointer-events: none;
    opacity: 0.8;
    animation: summary-card-skeleton 2s infinite;
  }

  @keyframes summary-card-skeleton {
    0% {
      transform: translateX(-100%);
    }
    30% {
      transform: translateX(-100%);
    }
    100% {
      transform: translateX(100%);
    }
  }
`;var Vj=[{height:8,items:[20]},{height:12,items:[40,17,25]},{height:12,items:[25,55]},{height:8,items:[36,19,27]},{height:8,items:[15,46,25]},{height:8,items:[22,39]}],vi=({className:e})=>{let t=h(Pp,e),o=h(hy,EE),n=h(Sy,gh),a=h(OE,gh,fh),s=h(by,VE);return x("div",{className:t,"data-testid":"skeleton-summary-card-container",children:[i("div",{className:o,children:Vj.map(({height:l,items:p},d)=>i("div",{style:{height:l},className:s,children:p.map((u,y)=>i("div",{className:a,style:{height:l,width:`${u}%`}},`skeleton-line-${d}-${y}`))},`skeleton-line-${d}`))}),i("div",{className:h(n,fh)})]})};vi.displayName="SkeletonSummaryCard";var GE=T(w());var Np=({date:e,dateTime:t,className:o,title:n,description:a,onClick:s,link:l,imgSrcs:p,imgAltText:d,showMedia:u,showDescription:y,showDate:m,dataset:g,dateDataset:f,titleDataset:b,descriptionDataset:S,mediaDataset:C,eyebrowText:v,stickers:k})=>{Y("sdsm-summary-card");let{Anchor:I}=(0,GE.useContext)(He),A=h("sdsm-summary-card",{[Pp]:!l,[by]:!!l},o),D=h(HE,{[Pp]:!!l},o),B=h(TE,{[NE]:y&&u,[_E]:!y&&!u,[PE]:y&&!u&&m,[DE]:!y&&!u&&!m,[wE]:!y&&u,[AE]:!e&&m}),M=h(RE,{[FE]:u,[BE]:!u}),_=x("div",{className:A,"data-testid":"summary-card-container",...ne(g),children:[x("div",{className:hy,children:[v?i("span",{className:mh,children:v}):m&&e?i("time",{dateTime:Bd(t),className:mh,...ne(f),children:e}):null,n?i("div",{className:B,...ne(b),children:n}):null,y&&a?i("div",{className:M,...ne(S),children:a}):null]}),u?i("div",{className:Sy,children:p?i(Vn,{altText:d,imgSrcs:p,className:$E,imgClassName:LE,dataset:C,stickers:k}):null}):null]});return l?i(I,{href:l,className:D,onClick:s,children:_}):_};Np.displayName="SummaryCard";var zE=e=>{let t=e;if(t?.type===Np||t?.type===vi)return!0;let o=e.type;return o.displayName==="SummaryCard"||o.displayName==="SkeletonSummaryCard"};var UE=c`
  /* Setting height so that we reserve the space for the video/carousel. */
  max-height: 650px;

  /* Limiting the width to at least allow for 1 tile. */
  min-width: 274px;
  max-width: 100%;

  /* Matches the padding on the Hero Text container. */
  padding-inline: ${r("--spacing-xxl")};

  /* TODO: Fix this for the case where VIDEOS overflow */
  overflow: visible;

  ${N} {
    height: unset;
  }

  /* Limits the height of the video wrapper. Without this max-height is ignored */
  * {
    max-height: 650px;
  }
`,WE=c`
  padding-inline: 0;
`,QE=c`
  max-height: 350px;

  /* Limits the height of the video wrapper. Without this max-height is ignored */
  * {
    max-height: 350px;
  }
`;var bh=({className:e,foregroundMedia:t,imgSrcs:o,wrapMedia:n,showMediaMobile:a,size:s})=>{let l=Rt();if(n=t?.props?.wrap??n,l&&!a)return null;let p;return t?(p=t,Uw(t)&&(p=(0,qE.cloneElement)(t,{isSingleView:!0}))):p=i(Ke,{imgSrcs:o,wrap:n}),i("aside",{"data-testid":"sdsm-hero-media",className:h(UE,e,{[QE]:s==="Compact"},{[WE]:t?zE(t):!1}),children:p})};bh.displayName="HeroMedia";var Ii={FullScreen:"Full screen",Start:"50% start",End:"50% end"},Sh=(0,KE.forwardRef)((e,t)=>{Y("sdsm-hero");let{backgroundVideoSource:o,backgroundPosterSource:n,mobileBackgroundVideoSource:a,body:s,callsToAction:l,fitWindow:p=!1,foregroundMedia:d,curtainOpacityPercentage:u,headerImgSrcs:y,headerImgAltText:m,eyebrow:g,title:f,motifScheme:b,backgroundColor:S,header:C,bgImgSrcs:v,bgImgAltText:k,imgSrcs:I,textAlign:A,textAlignMobile:D,verticalTextAlign:B=Xo.Middle,shareable:M=!1,className:_,footer:P,anchorId:$,eyebrowDataset:R,titleDataset:L,bodyDataset:G,headerDataset:Z,postChildren:U,showMediaMobile:de,wrapMedia:le,size:re,subTitle:te,subTitleDataset:ae,showScrollButton:oe,onScrollDownButtonClick:q,backgroundMediaLayout:X=Ii.FullScreen,breadcrumbs:W,breadcrumbsPropsOverride:K,topics:F,backgroundMediaStickers:Q,increaseTitleFontSize:z=!1}=e,Se=!!(d||I),{width:j}=Sn(),fe=Rt(),J=b??Pe(S)??"sdsm-secondary",ue=!!j&&j>jo&&j<zN,_e=!jl(v)||!jl(o),we=re==="Compact",Be=u;Ct(Be)&&(Be=_e?75:0);let Ce=X===Ii.Start||X===Ii.End,We,Pt=Q?.map(ke=>({...ke,size:Ce?sr.Medium:sr.Large,insetPx:16,className:Qd}));v?We=i(Vn,{imgSrcs:v,altText:k,className:h(lh,{[fy]:Ce,[ch]:Ce,[dh]:Ce}),imgClassName:ph,fetchPriority:"high",stickers:Pt}):o&&(We=i("div",{className:h({[fy]:Ce,[ch]:Ce}),children:i(Qr,{mobileSource:a,className:h(lh,{[dh]:Ce}),videoClassName:ph,source:o,posterSource:n,isBackgroundVideo:!0,stickers:Pt})}));let $e=ar[D??ie.Start],Ro=Se?ie.Start:ie.Center,eo=Ta[A??Ro],Ie=h({[QN]:B===Xo.Top,[qN]:B===Xo.Bottom}),me=!!Be&&!Ce;return x("section",{ref:t,className:h("sdsm-hero",J,YN,{[sh]:p,[gE]:Ce,[fE]:X===Ii.End,[ah]:_e},_),id:$,"data-curtain":me,children:[We,me&&i("div",{"data-testid":"sdsm-hero-curtain",className:eE,style:{[gy]:Be/100}}),!!W?.length&&i(eh,{motifScheme:J,breadcrumbsItems:W,showBgGradient:X===Ii.Start,...K}),x(qr,{"data-testid":"sdsm-hero-block-content",className:h(XN,Ie,{[JN]:!!W?.length},{[sh]:p},{[ZN]:we,[fy]:Ce}),children:[x("div",{"data-testid":"sdsm-hero-text",className:h($e,eo,KN,{[jN]:p}),children:[(C||y)&&i(yh,{content:C,iconSrcs:y,iconAltText:m,textAlignMobile:D,headerDataset:Z,className:tE}),g&&i("div",{className:oE,...ne(R),children:g}),f&&i("div",{className:dE,children:i("h1",{className:h({[ih]:!Ce&&!Se,[nE]:Ce||Se,[rE]:z&&!Ce&&!Se},eo,$e),...ne(L),children:f})}),te&&i("div",{className:aE,...ne(ae),children:te}),s&&i("div",{className:h($e,eo,sE),...ne(G),children:s}),F&&i("div",{className:h(iE,eo),children:F}),l&&i("div",{className:h($e,lE),children:l}),P&&i("footer",{className:pE,children:P})]}),Se&&!ue&&!Ce&&i(bh,{className:uE,foregroundMedia:d,imgSrcs:I,wrapMedia:le,showMediaMobile:de,size:re}),p&&oe&&!fe&&i("div",{className:yE,children:i(Mo,{size:"small",iconName:"chevron-down",className:mE,onClick:q})})]}),M&&i(nh,{className:cE,title:f?.toString()??""}),U]})});Sh.displayName="Hero";var Cy=T(w());var jE=c`
  cursor: pointer;

  /** TODO: Troubleshoot this w/ designers. */
  text-decoration: underline;

  color: ${r("--hyperlink-color")};
  :hover {
    color: ${r("--hyperlink-hover-color")};
    border-bottom: 0;
  }

  ${N} {
    font-size: ${r("--hyperlink-mobile-font-size")};
    font-weight: ${r("--hyperlink-mobile-font-weight")};
    letter-spacing: ${r("--hyperlink-mobile-font-letter-spacing")};
    line-height: ${r("--hyperlink-mobile-font-line-height")};
  }

  ${H} {
    font-size: ${r("--hyperlink-desktop-font-size")};
    font-weight: ${r("--hyperlink-desktop-font-weight")};
    letter-spacing: ${r("--hyperlink-desktop-font-letter-spacing")};
    line-height: ${r("--hyperlink-desktop-font-line-height")};
  }
`;var hh=(0,Cy.memo)(({children:e,link:t,target:o,onClick:n,className:a})=>{Y("sdsm-hyperlink");let{Anchor:s}=(0,Cy.useContext)(He);return i(s,{href:t,target:o,className:h("sdsm-hyperlink",jE,a),onClick:n,children:e})});hh.displayName="Hyperlink";var YE=T(w());var Oj=c`
  background: none;
  border: none;
  cursor: pointer;
  outline: inherit;
`,$s=({height:e,imgSrcs:t,url:o,width:n,onClick:a,altText:s,pictureClassName:l,className:p})=>{Y("sdsm-image-button");let{Anchor:d}=(0,YE.useContext)(He);return o?i(d,{href:o,className:h("sdsm-image-button",p),onClick:a,children:i(et,{className:l,altText:s,height:e,width:n,imgSrcs:t})}):i("button",{className:h("sdsm-image-button",Oj,p),onClick:a,children:i(et,{className:l,altText:s,height:e,width:n,imgSrcs:t})})};var ea=T(w());var XE=c`
  background-color: ${r("--bg-color")};
`,JE=c`
  padding: ${r("--spacing-xxxl")} ${r("--spacing-l")};

  ${H} {
    padding-inline: ${r("--spacing-xxxxl")};
  }
`,ZE=c`
  display: grid;
  gap: ${r("--spacing-xl")};
  grid-template-columns: 1fr;

  ${H} {
    grid-template-areas: 'text text text text text . cards cards cards cards cards cards';
    grid-template-columns: repeat(12, 1fr);
  }
`,eR=c`
  ${H} {
    grid-template-areas: 'cards cards cards cards cards cards . text text text text text';
  }
`,tR=c`
  grid-column: span 1;

  ${H} {
    align-items: center;
    display: flex;
    grid-area: text;
    height: calc(100vh - ${64}px);
    position: sticky;
    top: ${64}px;
  }
`,oR=c`
  ${H} {
    flex-direction: row-reverse;
  }
`,nR=c`
  display: none;
  list-style: none;

  > li {
    line-height: 0;
  }

  ${H} {
    display: flex;
    flex-direction: column;
    flex: 0 0 20%;
    gap: ${r("--spacing-m")};
  }
`,rR=c`
  ${H} {
    align-items: flex-end;
  }
`,aR=r("--neutral-v700"),iR=r("--primary-v100"),sR=e=>c`
  background-color: transparent;
  height: 24px;
  transition: height 0.3s ease-in-out, background-color 0.3s ease-in-out;
  width: 14px;

  &::before {
    background-color: rgba(133, 141, 148, 0.5);
    border-radius: ${r("--border-radius-s")};
    content: '';
    display: block;
    height: 100%;
    width: 4px;
  }

  @media (hover: hover) {
    cursor: pointer;

    &:hover {
      height: 56px;
    }

    &:hover::before {
      background-color: ${e==="sdsm-secondary"?iR:aR};
    }
  }
`,lR=e=>c`
  height: 56px;

  &::before {
    background-color: ${e==="sdsm-secondary"?iR:aR};
  }
`,pR=c`
  color: ${r("--fg-color")};

  ${N} {
    display: flex;
    flex-direction: column;
    flex: 0 0 80%;
    gap: ${r("--spacing-m")};
    padding: ${r("--spacing-m")};
  }

  ${H} {
    align-self: center;
    flex: 1;
    padding-block: 134px;
  }
`,cR=c`
  ${N} {
    text-align: start;
  }
`,dR=c`
  ${N} {
    text-align: center;
  }
`,uR=c`
  ${N} {
    text-align: end;
  }
`,yR=c`
  grid-column: span 1;
  list-style: none;

  ${N} {
    display: flex;
    flex-direction: column;
    gap: ${r("--spacing-m")};
  }

  ${H} {
    grid-area: cards;
  }
`,mR=c`
  align-items: center;
  display: flex;
  justify-content: center;

  > div {
    cursor: initial;
  }

  ${N} {
    transform: scale(0.7);
    transition: transform 50ms linear;
    will-change: transform;
  }

  ${H} {
    padding-block: 134px;
    scroll-margin-top: ${64}px;

    /* Override the Carousel Card width. Value defined by the design team. */
    > div {
      width: 320px;
    }
  }
`,gR=c`
  /**
   * using var instead of m function because this is not a motif variable.
   * It is a custom css var defined in heroCss.
   */
  color: ${r("--fg-color")};
  font-size: ${r("--annotation-desktop-font-size")};
  font-weight: ${r("--annotation-desktop-font-weight")};
  letter-spacing: ${r("--annotation-desktop-font-letter-spacing")};
  line-height: ${r("--annotation-desktop-font-line-height")};

  ${N} {
    font-size: ${r("--annotation-mobile-font-size")};
    font-weight: ${r("--annotation-mobile-font-weight")};
    letter-spacing: ${r("--annotation-mobile-font-letter-spacing")};
    line-height: ${r("--annotation-mobile-font-line-height")};
  }
`,fR=c`
  ${wk}
  margin-block-start: ${r("--spacing-xs")};
`,bR=c`
  ${yo}

  ${H} {
    margin-block-start: ${r("--spacing-m")};
  }
`;var xy=T(w()),SR=({cardRefs:e,childCount:t,options:o})=>{let{threshold:n=.5,isEnabled:a}=o,[s,l]=(0,xy.useState)(0);return(0,xy.useEffect)(()=>{if(!a){l(0);return}let p=e.current.slice(0,t);if(p.length===0)return;let d=new Map,u=g=>{for(let k of g)d.set(k.target,k.intersectionRatio);let f=-1,b=0,S=-1,C=0;for(let k=0;k<p.length;k++){let I=p[k];if(!I)continue;let A=d.get(I)??0;A>=n&&A>C&&(C=A,S=k),A>b&&(b=A,f=k)}let v=S!==-1?S:f;v!==-1&&l(v)},y=[0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1],m=new IntersectionObserver(u,{threshold:y});for(let g of p)g&&m.observe(g);return()=>{m.disconnect()}},[e,t,n,a]),s};Kf();var Ep=T(w());var hR=({childCount:e,elementRefs:t,isEnabled:o})=>{let n=(0,Ep.useRef)(new Set),a=(0,Ep.useRef)(!1);(0,Ep.useEffect)(()=>{let s=t.current.slice(0,e);if(!o){for(let m of s)m&&(m.style.transform="scale(1)");return}let l=()=>{let m=window.innerHeight/2+64;for(let g of n.current){let f=s[g];if(!f)continue;let b=f.getBoundingClientRect(),S=b.top+b.height/2,C=Math.abs(m-S),k=Math.max(0,C-30),I=Math.min(1,k/m),D=1-I*I*.3;f.style.transform=`scale(${D})`}},p=()=>{a.current||(window.requestAnimationFrame(()=>{l(),a.current=!1}),a.current=!0)},d=m=>{for(let g of m){let f=g.target,b=s.indexOf(f);if(b===-1)return;g.isIntersecting?n.current.add(b):n.current.delete(b)}},u=new IntersectionObserver(d,{rootMargin:"20px",threshold:0});for(let m of s)m&&u.observe(m);let y=pi(l,200,{trailing:!0});return window.addEventListener("scroll",p,{passive:!0}),window.addEventListener("resize",y),l(),()=>{window.removeEventListener("scroll",p),window.removeEventListener("resize",y),u.disconnect(),n.current.clear()}},[t,e,o])};var Ch=e=>{let{anchor:t,motifScheme:o,backgroundColor:n,children:a,eyebrow:s,text:l,textAlignmentMobile:p=ie.Center,tilesDirection:d=ie.End,title:u}=e;Y("sdsm-carousel");let y=(0,ea.useRef)([]),m=(0,ea.useRef)(null),g=ea.Children.count(a),f=Rt(),b=(0,ea.useId)(),S=o??Pe(n)??"sdsm-secondary",C=(k,I)=>{y.current[I]=k};hR({elementRefs:y,childCount:g,isEnabled:f});let v=SR({cardRefs:y,childCount:g,options:{isEnabled:!f,threshold:.8}});return i("section",{"aria-labelledby":b,className:h(XE,S),id:t,ref:m,children:i(qr,{className:JE,children:x("div",{className:h(ZE,{[eR]:d===ie.Start}),children:[x("section",{className:h(tR,{[oR]:d===ie.Start}),children:[i("ul",{className:h(nR,{[rR]:d===ie.Start}),children:ea.Children.map(a,(k,I)=>i("li",{children:i("button",{type:"button","aria-label":`Go to item ${I+1}`,onClick:()=>{y.current[I]?.scrollIntoView({behavior:"smooth"})},className:h(sR(S),{[lR(S)]:v===I}),"aria-current":v===I?"true":"false"})},I))}),x("div",{className:h(pR,{[cR]:p===ie.Start,[dR]:p===ie.Center,[uR]:p===ie.End}),children:[s&&i("div",{className:gR,children:s}),i("h2",{id:b,className:fR,children:u}),l&&i("div",{className:bR,children:l})]})]}),i("ul",{className:yR,children:ea.Children.map(a,(k,I)=>i("li",{className:mR,ref:A=>C(A,I),children:k},I))})]})})})};Ch.displayName="ImmersiveScrollBlock";var CR=c`
  width: 100%;
  margin-top: ${r("--spacing-xs")};
  padding: 0 0 ${r("--spacing-m")};
`,xR=c`
  font-size: 2rem;
  font-weight: 600;
  line-height: 2.5rem;
  margin-bottom: 0;

  :hover {
    text-decoration: underline;
  }

  a {
    /* TODO: See if this should be hyperlink color or its own */
    color: ${r("--fg-color")};
    text-decoration: none;
  }
`;var vR=({anchorId:e,title:t,items:o,cta:n,motifScheme:a,backgroundColor:s,scrollSnap:l,className:p,preChildren:d,postChildren:u})=>{let y=i(pe,{children:o.map((m,g)=>x("article",{"data-testid":"latest-post-item",className:CR,children:[m.category&&i(Kw,{title:m.category}),i("div",{className:xR,children:m.title}),(m.author||m.date)&&i(pA,{author:m.author,date:m.date}),i("hr",{})]},g))});return i(ao,{title:t,titleAlignment:ie.Center,anchorId:e,className:p,fullHeight:l,motifScheme:a,backgroundColor:s,maxColumns:1,preChildren:d,postChildren:u,children:i(As,{body:y,callsToAction:n?[n]:void 0})})};var Gj=c`
  @keyframes loader-animation {
    0% {
      left: -60%;
    }
    50% {
      left: 60%;
    }
    100% {
      left: -60%;
    }
  }
`,zj=c`
  position: absolute;
  height: 3.75px;
  width: 100%;
  overflow: hidden;
`,Uj=c`
  position: relative;
  height: 5px;
  z-index: ${Ee.LOADING_BAR};
  width: 75%;
  margin: 0;
  background: linear-gradient(
    90deg,
    transparent 0%,
    ${r("--loading-bar-left-color")} 14%,
    ${r("--loading-bar-right-color")} 86%,
    transparent 100%
  );

  animation-name: loader-animation;
  animation-duration: 2s;
  animation-iteration-count: infinite;
  animation-timing-function: ease-in-out;
`,IR=({className:e})=>(Y("sdsm-loading-bar"),i("div",{className:h("sdsm-loading-bar",zj,Gj,e),children:i("hr",{className:Uj})}));var DR=T(w());var kR=c`
  fill: ${r("--logo-stroke-color")};
`,MR=c`
  fill: ${r("--logo-fill-color")};
`,TR=c`
  fill: ${r("--logo-stroke-color")};
  fill-rule: evenodd;
`;var AR=({className:e,width:t,height:o})=>(Y("sdsm-logo"),i("svg",{version:"1.1",xmlns:"http://www.w3.org/2000/svg",x:"0px",y:"0px",viewBox:"0 0 500 500",className:h("sdsm-logo",e),width:t,height:o,children:i("g",{id:"Layer_1",children:x("g",{children:[i("g",{children:i("path",{className:MR,d:`M484.6,369.3c-2-6.8-11.9-11.6-11.9-11.6l0,0c-0.9-0.5-1.7-0.9-2.4-1.3c-16.4-7.9-30.8-17.4-43.1-28.2
				c-9.8-8.7-18.2-18.2-25-28.4c-8.2-12.4-12.1-22.8-13.8-28.4c-0.9-3.7-0.8-5.1,0-7c0.6-1.6,2.5-3.1,3.4-3.8
				c5.5-3.9,14.4-9.7,19.9-13.2c4.7-3.1,8.8-5.7,11.2-7.4c7.7-5.4,12.9-10.8,16-16.7c4-7.6,4.5-16,1.4-24.3
				c-4.2-11.1-14.6-17.8-27.8-17.8c-2.9,0-6,0.3-9,1c-7.6,1.6-14.8,4.3-20.8,6.7c-0.4,0.2-0.9-0.2-0.9-0.6
				c0.6-14.9,1.3-34.9-0.3-53.9c-1.5-17.2-5-31.7-10.8-44.3c-5.8-12.7-13.4-22.1-19.3-28.9c-5.7-6.5-15.5-16-30.5-24.5
				c-21-12-45-18.1-71.1-18.1c-26.1,0-50,6.1-71.1,18.1c-15.8,9-25.9,19.2-30.5,24.5c-5.9,6.8-13.5,16.2-19.3,28.9
				c-5.8,12.6-9.3,27.1-10.8,44.3c-1.6,19.1-1,37.5-0.3,53.9c0,0.5-0.5,0.8-0.9,0.6c-6-2.3-13.2-5-20.7-6.7c-3-0.7-6-1-9-1
				c-13.2,0-23.6,6.7-27.8,17.8c-3.1,8.3-2.7,16.7,1.4,24.3c3.1,5.9,8.4,11.4,16,16.7c2.4,1.7,6.4,4.3,11.2,7.4
				c5.3,3.5,14,9.1,19.5,13c0.7,0.5,3,2.3,3.8,4.1c0.8,2,0.9,3.4-0.1,7.3c-1.7,5.7-5.6,15.9-13.7,28.1c-6.8,10.2-15.2,19.7-25,28.4
				C60.5,339,46,348.5,29.7,356.5c-0.8,0.4-1.7,0.8-2.7,1.4l0,0c0,0-9.8,5-11.6,11.4c-2.7,9.5,4.5,18.4,11.9,23.2
				c12.1,7.8,26.9,12,35.4,14.3c2.4,0.6,4.5,1.2,6.5,1.8c1.2,0.4,4.3,1.6,5.6,3.3c1.7,2.1,1.9,4.8,2.5,7.8v0c0.9,5,3,11.2,9.2,15.5
				c6.8,4.7,15.5,5,26.4,5.5c11.5,0.4,25.8,1,42.1,6.4c7.6,2.5,14.4,6.7,22.4,11.6c16.6,10.2,37.2,22.9,72.5,22.9
				c35.3,0,56.1-12.8,72.8-23c7.9-4.8,14.7-9,22.1-11.5c16.3-5.4,30.6-5.9,42.1-6.4c11-0.4,19.6-0.7,26.4-5.5
				c6.6-4.6,8.6-11.4,9.4-16.6c0.5-2.5,0.8-4.8,2.3-6.7c1.2-1.6,4.1-2.7,5.4-3.2c2-0.6,4.2-1.2,6.7-1.9c8.6-2.3,19.3-5,32.3-12.4
				C485.2,385.6,486.3,374.7,484.6,369.3z`})}),i("path",{className:kR,d:`M498.2,364c-3.5-9.5-10.1-14.5-17.6-18.7c-1.4-0.8-2.7-1.5-3.8-2c-2.2-1.2-4.5-2.3-6.8-3.5
			c-23.5-12.5-41.8-28.2-54.6-46.8c-4.3-6.3-7.3-12-9.4-16.6c-1.1-3.1-1-4.9-0.3-6.5c0.6-1.2,2.2-2.5,3-3.1c4-2.7,8.2-5.4,11-7.2
			c5-3.3,9-5.8,11.6-7.6c9.6-6.7,16.4-13.9,20.6-21.9c5.9-11.3,6.7-24.2,2.1-36.3c-6.4-16.8-22.3-27.3-41.5-27.3
			c-4,0-8,0.4-12.1,1.3c-1.1,0.2-2.1,0.5-3.1,0.7c0.2-11.4-0.1-23.6-1.1-35.6c-3.6-42-18.3-64-33.7-81.6c-6.4-7.3-17.5-18-34.2-27.6
			C305.1,10.6,278.8,3.9,250,3.9c-28.7,0-55,6.7-78.3,20c-16.8,9.6-27.9,20.3-34.3,27.6c-15.3,17.5-30,39.6-33.7,81.6
			c-1,11.9-1.3,24.1-1.1,35.6c-1-0.3-2.1-0.5-3.1-0.7c-4-0.9-8.1-1.3-12.1-1.3c-19.3,0-35.2,10.4-41.5,27.3
			c-4.6,12.1-3.8,25,2.1,36.3c4.2,8,11,15.2,20.6,21.9c2.6,1.8,6.6,4.4,11.6,7.6c2.7,1.8,6.7,4.3,10.6,6.9c0.6,0.4,2.7,1.9,3.4,3.4
			c0.8,1.7,0.8,3.5-0.4,6.8c-2.1,4.6-5,10.1-9.2,16.3c-12.4,18.2-30.3,33.6-53,46c-12,6.4-24.6,10.6-29.9,25
			c-4,10.9-1.4,23.2,8.8,33.6l0,0c3.3,3.6,7.5,6.8,12.8,9.7c12.4,6.9,23,10.2,31.3,12.5c1.5,0.4,4.8,1.5,6.3,2.8
			c3.7,3.2,3.2,8.1,8.1,15.2c3,4.4,6.4,7.4,9.2,9.4c10.3,7.1,21.9,7.6,34.2,8c11.1,0.4,23.7,0.9,38.1,5.7c6,2,12.1,5.8,19.3,10.2
			c17.2,10.6,40.8,25,80.2,25c39.4,0,63.1-14.5,80.5-25.2c7.1-4.4,13.3-8.1,19-10c14.4-4.7,27-5.2,38.1-5.7
			c12.3-0.5,23.9-0.9,34.2-8c3.2-2.2,7.3-5.9,10.5-11.5c3.5-6,3.4-10.2,6.8-13.2c1.4-1.2,4.3-2.2,5.9-2.7
			c8.4-2.3,19.1-5.7,31.7-12.6c5.6-3.1,10-6.5,13.4-10.3c0,0,0.1-0.1,0.1-0.1C499.7,386.6,502.1,374.6,498.2,364z M463.2,382.8
			c-21.4,11.8-35.6,10.5-46.6,17.7c-9.4,6-3.8,19.1-10.7,23.8c-8.4,5.8-33.2-0.4-65.1,10.2c-26.4,8.7-43.2,33.8-90.7,33.8
			c-47.6,0-64-25-90.7-33.8c-32-10.6-56.8-4.4-65.1-10.2c-6.8-4.7-1.3-17.7-10.7-23.8c-11-7.1-25.3-5.9-46.6-17.7
			c-13.6-7.5-5.9-12.2-1.4-14.4c77.4-37.5,89.8-95.4,90.3-99.7c0.7-5.2,1.4-9.3-4.3-14.6c-5.5-5.1-30.1-20.3-36.9-25
			c-11.3-7.9-16.2-15.7-12.6-25.4c2.5-6.7,8.8-9.2,15.4-9.2c2,0,4.1,0.2,6.1,0.7c12.4,2.7,24.4,8.9,31.3,10.6c1,0.2,1.8,0.3,2.6,0.3
			c3.7,0,5-1.9,4.8-6.1c-0.8-13.5-2.7-39.9-0.6-64.5c2.9-33.9,13.9-50.7,26.9-65.6c6.2-7.1,35.5-38.1,91.6-38.1
			c56.2,0,85.3,30.9,91.6,38.1c13,14.9,23.9,31.7,26.9,65.6c2.1,24.6,0.3,51-0.6,64.5c-0.3,4.5,1.1,6.1,4.8,6.1
			c0.8,0,1.6-0.1,2.6-0.3c6.9-1.7,19-7.9,31.3-10.6c2-0.4,4.1-0.7,6.1-0.7c6.6,0,12.8,2.5,15.4,9.2c3.7,9.7-1.3,17.5-12.6,25.4
			c-6.8,4.7-31.3,19.9-36.9,25c-5.7,5.3-5,9.4-4.3,14.6c0.6,4.4,12.9,62.2,90.3,99.7C469.1,370.6,476.8,375.3,463.2,382.8z`})]})})}));var _R=({className:e})=>(Y("sdsm-logo"),i("svg",{className:h("sdsm-logo",e,TR),width:"89",height:"22",viewBox:"0 0 89 22",xmlns:"http://www.w3.org/2000/svg",children:x("g",{children:[i("path",{d:"M.261 15.794C.247 14.39.126 12.767.003 11.526a.513.513 0 0 1 .433-.559l.02-.003a.518.518 0 0 1 .58.38 5.99 5.99 0 0 0 .742 1.767c.308.484 1.386 2.155 3.65 2.155 1.65 0 2.86-1.166 2.86-2.64 0-1.362-1.1-1.912-3.255-2.726-.637-.264-1.297-.505-1.935-.791C2.218 8.69.15 7.723.15 5.039.15 2.05 2.548.29 5.605.29c.742 0 1.798.104 2.856.59.234.107.51.024.648-.192l.175-.276a.515.515 0 0 1 .422-.24.519.519 0 0 1 .53.48 55.8 55.8 0 0 0 .418 3.743.518.518 0 1 1-.994.255c-.276-.729-.432-1.07-.735-1.524-.725-.989-1.693-1.67-2.902-1.67-1.562 0-2.485 1.274-2.485 2.308 0 1.187 1.055 1.693 1.517 1.913.946.462 1.935.77 2.925 1.166 1.583.616 3.76 1.562 3.76 4.465 0 2.858-2.287 5.255-5.915 5.255-1.803 0-2.978-.57-3.66-1.003a.514.514 0 0 0-.714.17l-.195.322a.518.518 0 0 1-.402.246l-.037.003a.514.514 0 0 1-.556-.507M12.223 15.668c0-.219.157-.405.371-.441.332-.055.734-.198.795-.62.066-.507.066-1.826.066-2.156 0-.77-.022-2.023-.022-2.793 0-1.104-.37-1.407-.89-1.554a.445.445 0 0 1-.32-.429v-.052c0-.219.158-.403.373-.44 1.095-.192 2.751-.66 3.62-.96a.446.446 0 0 1 .57.283c.018.058.035.113.05.17a.447.447 0 0 0 .66.26c.83-.482 1.617-.84 2.776-.84.836 0 1.672.22 2.354.703 1.071.744 1.25 1.88 1.34 3.083v1.931c0 .33-.043 2.045-.043 2.42 0 .556.151.895.878 1.03a.442.442 0 0 1 .353.439.446.446 0 0 1-.475.446c-.623-.042-1.564-.069-3.11-.069-.872 0-1.353.024-1.8.063a.447.447 0 0 1-.487-.445v-.094c0-.201.135-.379.33-.43.643-.174.723-.481.704-1.82l-.044-3.431c-.022-1.055-.066-2.265-1.496-2.265-.595 0-1.056.218-1.5.553a.451.451 0 0 0-.184.374c.035 1.102.035 4.23.035 5.208 0 1.009.175 1.288.712 1.43.192.05.322.23.322.429v.058a.447.447 0 0 1-.475.447c-.747-.047-1.707-.077-3.506-.077-.692 0-1.094.022-1.469.058a.446.446 0 0 1-.488-.446v-.023zM31.379 12.006a.447.447 0 0 0-.56-.43c-.742.188-1.727.621-1.727 1.777 0 .594.308 1.253 1.144 1.253.426 0 .68-.129.947-.305a.444.444 0 0 0 .196-.37v-1.925zm5.082 2.544a.447.447 0 0 1 .041.66c-1.057 1.07-2.105 1.288-2.682 1.288a2.85 2.85 0 0 1-1.649-.55 2.385 2.385 0 0 1-.408-.42.44.44 0 0 0-.594-.102c-.605.393-1.854 1.093-3.242 1.093-2.024 0-2.507-1.363-2.507-2.176 0-2.513 3.867-3.564 5.618-3.878a.444.444 0 0 0 .364-.436c.002-.68.003-1.48-.089-1.756-.264-.77-1.143-.77-1.253-.77-.726 0-1.122.44-1.254.924-.066.286-.066.594-.132.88-.176.747-.792 1.033-1.341 1.033-.682 0-1.32-.44-1.32-1.253 0-1.628 3.013-2.948 5.74-2.948 1.891 0 3.276.616 3.276 2.442l-.043 4.904c-.022.374-.045 1.23.527 1.23.142 0 .276-.074.402-.172a.443.443 0 0 1 .546.007z"}),i("path",{d:"M42.65 15.002c1.627 0 2.22-2.265 2.22-3.76 0-1.584-.66-3.695-2.286-3.695-1.474 0-1.474 1.518-1.474 1.979 0 .506.023 2.969.023 3.519 0 .704 0 1.957 1.517 1.957zM37.482 9.79c.04-1.68-.2-2.076-.95-2.283a.425.425 0 0 1-.304-.412v-.11a.42.42 0 0 1 .372-.419c1.485-.159 3.056-.564 3.829-.774a.417.417 0 0 1 .52.32c.023.102.046.227.074.384a.421.421 0 0 0 .636.288c.863-.553 1.714-.842 2.794-.842 2.661 0 4.31 2.287 4.31 4.706 0 3.32-2.353 5.63-5.101 5.63-.843 0-1.457-.215-1.882-.444a.422.422 0 0 0-.625.368v2.538c0 .851.052 1.507.962 1.661a.416.416 0 0 1 .335.414.422.422 0 0 1-.432.422 150.558 150.558 0 0 0-3.262-.055c-.827 0-1.362.015-2.066.045a.422.422 0 0 1-.442-.42v-.055c0-.204.142-.387.344-.421.818-.14.888-.59.888-1.217.022-.418.022-1.715.022-2.199l-.022-7.125zM60.272 16.146c-.893-.066-1.477-.066-3.816-.066-1.28 0-1.791.015-2.54.068a.502.502 0 0 1-.11-.996c1.233-.173 1.286-.618 1.286-3.405V4.754c-.022-1.671-.043-2.177-.198-2.485-.166-.39-.427-.482-1.099-.594a.5.5 0 0 1-.418-.493c0-.308.232-.533.514-.525 1.236.033 2.473.05 3.708.05 1.24 0 2.035-.027 2.717-.05a.5.5 0 0 1 .082.997c-1.303.163-1.303.558-1.303 3.474l.022 6.817c.044 2.31.066 2.442.33 2.793.188.222.483.339.935.4a.5.5 0 0 1 .428.495.504.504 0 0 1-.538.513zM60.97 15.668c0-.219.157-.405.371-.441.332-.055.734-.198.795-.62.066-.507.066-1.826.066-2.156 0-.77-.022-2.023-.022-2.793 0-1.104-.37-1.407-.89-1.554a.445.445 0 0 1-.32-.429v-.052c0-.219.157-.403.373-.44 1.095-.192 2.75-.66 3.62-.96a.446.446 0 0 1 .57.283c.018.058.035.113.05.17a.447.447 0 0 0 .659.26c.83-.482 1.617-.84 2.777-.84.835 0 1.671.22 2.353.703 1.072.744 1.252 1.88 1.34 3.083.002.012.002.024.002.036v1.895c0 .33-.044 2.045-.044 2.42 0 .556.15.895.878 1.03a.442.442 0 0 1 .353.439.446.446 0 0 1-.476.446c-.622-.042-1.564-.069-3.109-.069-.873 0-1.353.024-1.8.063a.447.447 0 0 1-.487-.445v-.094c0-.201.135-.379.33-.43.643-.174.723-.481.704-1.82l-.044-3.431c-.023-1.055-.066-2.265-1.496-2.265-.595 0-1.057.218-1.501.553a.451.451 0 0 0-.183.374c.035 1.102.035 4.23.035 5.208 0 1.009.174 1.288.712 1.43.192.05.322.23.322.429v.058a.447.447 0 0 1-.475.447c-.747-.047-1.707-.077-3.506-.077-.692 0-1.094.022-1.469.058a.446.446 0 0 1-.488-.446v-.023zM83.847 13.754c.276.2.314.604.072.844a6.543 6.543 0 0 1-4.557 1.9c-3.145 0-5.454-2.178-5.454-5.169 0-3.144 2.683-5.167 5.96-5.167 2.155 0 4.2.945 4.2 2.529 0 .747-.637 1.385-1.385 1.385-.33 0-.726-.154-.968-.396-.198-.176-.242-.286-.66-1.231-.198-.418-.638-1.166-1.319-1.166-1.276 0-1.628 2.177-1.628 3.255 0 2.485 1.408 4.156 2.947 4.156.818 0 1.495-.376 2.096-.904a.558.558 0 0 1 .696-.036M86.884 12.539c1.078 0 2 .858 2 2.001 0 1.122-.922 1.98-1.978 1.98a1.96 1.96 0 0 1-1.98-1.936c0-1.363 1.056-2.045 1.958-2.045"})]})}));var Wj=c`
  text-decoration: none;
  display: flex;
  padding-top: 0;
  padding-bottom: 0;
  cursor: pointer;
`,wR=c`
  max-width: 100%;
  /* Prevents large logo images from exceeding header height */
  max-height: calc(${64}px - ${r("--spacing-m")});

  ${N} {
    max-width: 100%;
  }
  display: block;
`,Qj=c`
  margin-left: ${r("--spacing-m")};

  *[dir='rtl'] & {
    margin-right: ${r("--spacing-m")};
    margin-left: 0;
  }

  ${Dk}
`,ki=({imgSrcs:e,imageSource:t,label:o,url:n="/",onClick:a,innerLogoClassName:s,className:l,openInNewTab:p,logoType:d="Ghost",ariaLabel:u})=>{let{Anchor:y}=(0,DR.useContext)(He),m;return e?m=i(et,{altText:"logo",imgClassName:wR,imgSrcs:e}):t?m=i(et,{altText:"logo",imgClassName:wR,defaultSrc:t}):d==="SnapInc"?m=i(_R,{className:s}):m=i(AR,{className:s,width:32,height:32}),x(y,{href:n,onClick:a,className:h(l,Wj),"aria-label":u,...p?{target:"_blank",rel:"noopener"}:{},children:[m,o&&i("span",{className:Qj,children:o})]})};ki.displayName="Logo";var vy=T(w()),BR=T(ma());var PR={[Xo.Top]:c`
    left: 50%;
    top: 0;
    transform: translateX(-50%);
  `,[Xo.Bottom]:c`
    left: 50%;
    bottom: 0;
    transform: translateX(-50%);
  `,[Xo.Middle]:c`
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  `},NR=c`
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  box-shadow: none;
  z-index: ${Ee.MODAL};
  overflow: hidden;
  background: ${r("--modal-bg-color")};
  backdrop-filter: blur(4px);

  /* ==========================================================================================================
  Specific fix to address errant behavior in Safari browser when in fullscreen mode.
    Bug Behavior: certain CSS transforms (like blur) will cause the browser to stop honoring z-index values.
      Since this style is only applied when in full-screen mode, there should be no issues with
      removing the background blur since it should be hidden by the fullscreen content.
    Use Case: Rendering a Video player inside of the SDS-M Modal component.
  ========================================================================================================== */
  :-webkit-full-screen-ancestor:not(iframe) {
    /* NOTE: Safari needs the prefix. See https://caniuse.com/css-backdrop-filter */
    /* stylelint-disable-next-line property-no-vendor-prefix */
    -webkit-backdrop-filter: unset;
  }
`,ER=c`
  position: fixed;
`,RR="sdsm-modal-blocking",FR=c`
  --close-button-size: 40px;

  ${N} {
    right: 0;
    --close-button-size: 32px;
  }

  /* Render over video content. */
  z-index: ${Ee.MODAL+1};

  *[dir='rtl'] {
    left: -80px;
  }

  position: absolute;
  right: calc(0px - calc(var(--close-button-size) + ${r("--spacing-s")}));
  top: calc(0px - calc(var(--close-button-size) + ${r("--spacing-s")}));
`;var Iy=({className:e,contentClassName:t,isBlocking:o=!1,verticalAlignment:n=Xo.Middle,onClose:a,isDisplayed:s=!1,portalRoot:l,style:p,dataset:d,children:u,disableBackgroundScroll:y,shouldAllowScrollEvent:m})=>{Y("sdsm-modal");let[g,f]=(0,vy.useState)(null),b=Rt(),S=(0,vy.useCallback)(v=>f(v),[f]);cs(o||y?g:null,void 0,m);let C=i("section",{className:h("sdsm-modal",NR,{[RR]:o},e),style:p,...ne(d),children:x("div",{className:h(ER,"sdsm-modal-content",PR[n],t),ref:S,children:[u,!o&&i(Mo,{size:b?"medium":"large",className:FR,iconName:"cross",onClick:a})]})});return l?s?(0,BR.createPortal)(C,l):null:s?C:null};var $o=T(w());var Rp=T(w());var $R=c`
  display: flex;
  justify-content: center;
  padding: ${r("--spacing-m")} 0;
  margin-bottom: ${r("--spacing-xxxxl")};
`,LR=(e,t)=>c`
  display: grid;
  grid-auto-flow: dense;
  transition: filter 0.2s;
  grid-template-columns: repeat(${Math.max(1,e??4)}, 1fr);

  ${N} {
    grid-template-columns: repeat(${Math.max(1,t??e??2)}, 1fr);
    padding: 0 8px;
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${uo} {
    grid-template-columns: repeat(${Math.max(1,t??e??2)}, 1fr);
  }
`,HR=c`
  position: relative;
  border-radius: ${r("--border-radius-xl")};
  overflow: hidden;
  z-index: 0;

  &:before {
    content: '';
    display: block;
    height: 0;
  }

  @media (hover: hover) {
    transition: box-shadow 0.2s;

    div[data-poster] {
      transition: opacity 0.2s;
    }

    &:hover {
      box-shadow: ${r("--box-shadow-xl")};

      div[data-poster] {
        opacity: 0;
      }
    }
  }
`,VR=c`
  min-height: 100%;
`,OR=c`
  position: absolute;
  inset: 0;
  z-index: 1;
  display: flex;
  align-content: center;
  flex-direction: row;
  align-items: flex-end;
  justify-content: flex-start;
  padding: ${r("--spacing-xl")};
  font-size: 16px;

  [data-playing='true'] > & {
    opacity: 0;
  }

  [data-overlay='true'] > & {
    background: linear-gradient(180deg, rgba(0, 0, 0, 0) 42.19%, rgba(0, 0, 0, 0.9) 100%);
  }

  [data-overlay='false'] > & {
    font-weight: 700;
    font-size: 24px;
    line-height: 38px;
  }

  ${N} {
    padding: ${r("--spacing-m")};
  }
`,GR=c`
  flex: 1 1 auto;
  width: 100%;
  color: ${r("--mosaic-title-color")};
`,zR=c`
  display: inline-block;
  color: ${r("--mosaic-highlight-color")};
  white-space: nowrap;

  &:after {
    /* NOTE: Emotion has a rule that there has to be a space at the end here. */
    content: '\\00a0 ';
  }
`,UR=c`
  margin-inline-start: auto;
  flex: 0 0 auto;
  color: ${r("--mosaic-duration-color")};
`,WR=c`
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`,QR=c`
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;

  [data-playing='true'] > & {
    opacity: 0;
  }
`,qR=(e,t,o,n)=>c`
  cursor: pointer;
  position: relative;
  padding: calc(${r("--mosaic-grid-gap")} / 2);
  grid-row: span ${Math.max(1,e??1)};
  grid-column: span ${Math.max(1,t??1)};

  ${N} {
    padding: ${r("--spacing-xs")};
    grid-row: span ${Math.max(1,o??e??1)};
    grid-column: span ${Math.max(1,n??t??1)};
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${uo} {
    grid-row: span ${Math.max(1,o??e??1)};
    grid-column: span ${Math.max(1,n??t??1)};
  }
`,KR=c`
  position: absolute;
  inset: 0;
`,jR=c`
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: opacity 0.2s;
`,YR=c`
  /* This is set such that the 40px close button fits in the middle. */
  --lightbox-horizontal-padding: 80px;
  --lightbox-vertical-padding: 80px;

  ${N} {
    --lightbox-horizontal-padding: 24px;
    --lightbox-vertical-padding: 80px;
  }

  width: calc(100vw - calc(2 * var(--lightbox-horizontal-padding)));
  width: calc(100dvw - calc(2 * var(--lightbox-horizontal-padding)));
  height: calc(100vh - calc(2 * var(--lightbox-vertical-padding)));
  height: calc(100dvh - calc(2 * var(--lightbox-vertical-padding)));
`,XR=c`
  height: calc(100% + var(--lightbox-vertical-padding));
  display: grid;
  grid-template-rows: calc(100% - 100px) auto;
  align-items: center;

  margin: 0;
  margin-bottom: calc(0px - var(--lightbox-vertical-padding));

  z-index: ${Ee.MOSAIC_LIGHTBOX};
  inset: ${64}px 0 0;
  transition: opacity 0.2s;

  &[data-active='false'] {
    opacity: 0;
    pointer-events: none;
  }
`,JR=c`
  display: flex;
  flex-direction: row;
  align-items: center;
`,ZR=c`
  color: ${r("--fg-color")};
  width: 100%;
  padding: ${r("--spacing-l")};
  text-align: center;
`,e3=c`
  border-radius: ${r("--border-radius-l")};
  overflow: hidden;
  max-width: 100%;
  max-height: 100%;
  width: auto;
  height: auto;
`,t3=c`
  margin: 5px 0;
  transform: rotate(270deg);
  [dir='rtl'] & {
    transform: rotate(90deg);
  }
`,o3=c`
  margin: 5px -1px 5px 1px;
  transform: rotate(270deg);
  [dir='rtl'] & {
    transform: rotate(90deg);
  }
`;var xh=(0,Rp.memo)(({filters:e,currentFilter:t,onSelectFilter:o})=>{let n=(0,Rp.useCallback)(s=>()=>{o(t===s?"":s)},[t,o]),a=(0,Rp.useCallback)(s=>l=>{l.key==="Enter"&&o(t===s?"":s),l.key==="Escape"&&o("")},[t,o]);return i("div",{className:h($R),children:e.map(({id:s,icon:l,text:p},d)=>i("div",{"aria-pressed":t===s,onKeyPress:a(s),role:"button",tabIndex:0,children:l&&i(l0,{icon:l,onClick:n(s),selected:t===s,id:s,index:d,text:p})},`${s}-${d}`))})});xh.displayName="MosaicFilters";var n3=T(w());var r3=({tile:e,handleKeyPress:t,goNext:o,goPrevious:n,close:a,className:s})=>((0,n3.useEffect)(()=>{e?.onOpen&&e.onOpen()},[e]),!e||!e.video?null:i(Iy,{contentClassName:YR,isBlocking:!1,isDisplayed:!!e,disableBackgroundScroll:!0,onClose:a,children:x("figure",{"data-testid":"sdsm-mosaic-lightbox",className:h(XR,s),children:[i(Ke,{loop:!0,className:e3,...e.video,showVideoControls:!0,autoplay:!0}),x("div",{"data-testid":"sdsm-mosaic-lightbox-controls",className:JR,children:[i(Mo,{iconName:"chevron-up",iconClassName:t3,onClick:n,onKeyDown:t}),i("figcaption",{className:ZR,children:e.title}),i(Mo,{iconName:"chevron-down",iconClassName:o3,onClick:o,onKeyDown:t})]})]},`${e.video.source}-${e.title}-${e.highlight}`)}));var ta=T(w());var a3=({columns:e=1,rows:t=1,mobileColumns:o=e,mobileRows:n=t,cover:a=!0,poster:s,preview:l,showOverlay:p,highlight:d,title:u,duration:y,onEnter:m,onLeave:g})=>{let f=(0,ta.useRef)(null),[b,S]=(0,ta.useState)(!1),C=t/e,v=n/o,k=c`
    &:before {
      padding-bottom: ${C*100}%;
    }
    ${N} {
      &:before {
        padding-bottom: ${v*100}%;
      }
    }
  `,I=(0,ta.useCallback)(async()=>{m?.();let D=f.current?.querySelector("video");D&&(await D.play(),S(!0))},[f,m]),A=(0,ta.useCallback)(()=>{g?.();let D=f.current?.querySelector("video");D&&(Wr(D)&&D.pause(),D.currentTime=0,S(!1))},[f,g]);return(0,ta.useEffect)(()=>{let D=f.current;return D?.addEventListener("mouseenter",I),D?.addEventListener("mouseleave",A),()=>{D?.removeEventListener("mouseenter",I),D?.removeEventListener("mouseleave",A)}},[f,I,A]),x("div",{ref:f,className:h(k,HR,a?VR:void 0),"data-playing":b,"data-overlay":!!p,children:[l&&i(Ke,{className:WR,isBackgroundVideo:!0,autoPlay:!1,...l}),s&&i("div",{className:KR,"data-poster":!0,children:i("img",{alt:u??d??"",src:s.src,srcSet:s.srcSet,className:jR})}),x("div",{className:OR,children:[(u||d)&&x("div",{className:GR,children:[d&&i("div",{className:zR,children:d}),u]}),y&&i("div",{className:UR,children:y}),i("div",{className:QR,children:i(De,{name:"play-filled"})})]})]})};var vh=(0,$o.memo)(({tiles:e,columns:t,mobileColumns:o,filters:n,className:a,lightboxClassName:s})=>{Y("sdsm-mosaic");let[l,p]=(0,$o.useState)(),[d,u]=(0,$o.useState)(""),[y,m]=(0,$o.useState)(!1),g=(0,$o.useCallback)(I=>{m(!!I?.closest('[dir="rtl"]'))},[]),f=(0,$o.useRef)([]),b=(0,$o.useCallback)(()=>{if(l===void 0)return;let I=(l+1)%e.length;p(I)},[l,e.length]),S=(0,$o.useCallback)(()=>{if(l===void 0)return;let I=(l-1+e.length)%e.length;p(I)},[l,e.length]),C=()=>{p(void 0)},v=(0,$o.useCallback)(I=>A=>{if(I!==void 0){if(A.key===(y?"ArrowLeft":"ArrowRight")){let D=(I+1)%e.length;l!==void 0&&p(D),f.current[D]?.focus()}if(A.key===(y?"ArrowRight":"ArrowLeft")){let D=(I-1+e.length)%e.length;l!==void 0&&p(D),f.current[D]?.focus()}A.key==="Enter"&&l===void 0&&p(I),A.key==="Escape"&&l!==void 0&&p(void 0)}},[l,y,e.length]),k=(0,$o.useMemo)(()=>d?e.filter(I=>I.filters?.includes(d)):e,[d,e]);return x("div",{className:h("sdsm-mosaic",a),children:[i(r3,{className:s,tile:l!==void 0?e[l]:void 0,handleKeyPress:v(l),goNext:b,goPrevious:S,close:C}),n?.length?i(xh,{filters:n,onSelectFilter:u,currentFilter:d}):void 0,i("div",{ref:g,className:h(LR(t,o)),"data-active":l!==void 0,children:k.map((I,A)=>i("div",{className:h(qR(I.rows,I.columns,I.mobileRows,I.mobileColumns)),"aria-pressed":l===A,role:"button",tabIndex:0,onClick:()=>p(A),onKeyDown:v(A),ref:D=>{f.current[A]=D},children:i(a3,{...I})},`${A}-${I.poster?.src}`))})]})});vh.displayName="Mosaic";var qj=864,Kj=120,jj=369,Yj=225,i3=c`
  display: flex;
  gap: ${r("--spacing-xl")};
  justify-content: center;
  margin-block: 0;
  padding: ${r("--spacing-xl")} ${r("--spacing-xxxxl")};
  width: 100%;

  ${Xe} {
    align-items: center;
  }

  ${N} {
    padding: ${r("--spacing-xl")};
  }
`,s3=c`
  background-color: ${r("--bg-color")};
  color: ${r("--fg-color")};
  display: flex;
`,l3=c`
  max-width: ${qj}px;
  width: 100%;
`,p3=c`
  flex-direction: row-reverse;
`,c3=c`
  min-height: calc(100vh - ${64}px);
`,d3=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-xxxl")};
  width: 60%;

  /** Dynamic padding for nonmobile devices such that content inside the block could be centered
   * Have to use dyanmic padding (should be a one-off case) instead of fixed padding
   * due to the media inside was complicatedly implemented (animated carousel, video were using fixed padding)
   * Ticket: https://jira.sc-corp.net/browse/WEBP-13033
   */
  padding-inline-start: 6%;

  ${$r({max:1366})} {
    padding-inline-start: 3%;
  }

  ${N} {
    gap: ${r("--spacing-xl")};
    width: 100%;
    padding-inline-start: 0;
  }
`,u3=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-l")};
  overflow-wrap: break-word;

  ${ut}
`,y3=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-xs")};
`,m3=c`
  display: grid;
  gap: ${r("--spacing-l")};
  grid-template-columns: repeat(2, 1fr);
  overflow-wrap: anywhere;

  ${Xe} {
    display: flex;
  }
`,Ls=c`
  box-sizing: border-box;
  display: flex;
  flex: 1 0 0;

  ${Sd}

  ${N} {
    flex-direction: column;
    gap: ${r("--spacing-xxs")};
  }
`,ky=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-xs")};
`,g3=c`
  display: flex;
  flex-shrink: 0;
  margin: 3px;
  pointer-events: none;
  user-select: none;
`,f3=c`
  height: 18px;
  width: 18px;
`,b3=c`
  fill: ${r("--fg-color")};
  flex-shrink: 0;
  margin: 3px;
`,S3=c`
  flex-direction: column;
`,h3=c`
  max-width: ${Kj}px;
`,C3=c`
  aspect-ratio: 1 / 1;
`,x3=c`
  display: flex;
  flex-wrap: wrap;
  gap: ${r("--spacing-m")};
`,v3=c`
  align-items: flex-start;
  display: flex;
  justify-content: center;
  padding-inline: 20px;
  width: 40%;

  ${Xe} {
    align-items: center;
  }

  ${N} {
    width: 100%;
  }
`,I3=c`
  display: block;
  object-fit: cover;
  object-position: center;
  width: 100%;

  > picture {
    pointer-events: none;
  }
`,Ih=c`
  aspect-ratio: 9 / 16;
  width: ${jj}px;

  & img {
    aspect-ratio: 9 / 16;
  }
`,kh=c`
  ${N} {
    aspect-ratio: 9 / 16;
    width: ${Yj}px;

    & img {
      aspect-ratio: 9 / 16;
    }
  }
`,Mh=c`
  aspect-ratio: 16 / 9;

  & img {
    aspect-ratio: 16 / 9;
  }
`,k3=c`
  ${N} {
    ${Mh}
  }
`,Th=c`
  aspect-ratio: 3 / 2;

  & img {
    aspect-ratio: 3 / 2;
  }
`,M3=c`
  ${N} {
    ${Th}
  }
`,Ah=c`
  aspect-ratio: 1 / 1;

  & img {
    aspect-ratio: 1 / 1;
  }
`,T3=c`
  ${N} {
    ${Ah}
  }
`;var A3=e=>{let{title:t,imgSrcs:o}=e;return x("div",{className:h(Ls,ky),children:[i("div",{className:h3,children:i(Ke,{className:C3,imgSrcs:o})}),t&&i("h6",{className:Sa,children:t})]})};var _3=e=>{let t=Rt(),{anchor:o,motifScheme:n,backgroundColor:a,title:s,subtitle:l,body:p,children:d,mediaSources:u=[],desktopMediaAspectRatio:y="9:16",mobileMediaAspectRatio:m="9:16",mediaDirection:g=ie.End,autoplayCarousel:f,callsToAction:b,fullHeight:S,className:C,style:v,stickers:k,isRtl:I=!1}=e,A=u?.length||0,D=()=>A>0?i("section",{className:v3,children:A>1?i(dr,{autoPlay:f,isSingleView:!0,isRtl:I,children:u.map((B,M)=>B&&i(Gn,{aspectRatio:t?m:y,imgSrcs:B?.sources,imgAltText:B?.altText,className:h({[Ih]:!t&&y==="9:16",[kh]:t&&m==="9:16"}),...B},`${B.type}-${M}`))}):A>0?i(xn,{mediaClassName:h(I3,{[Ih]:y==="9:16",[kh]:m==="9:16",[Mh]:y==="16:9",[Th]:y==="3:2",[Ah]:y==="1:1",[k3]:m==="16:9",[M3]:m==="3:2",[T3]:m==="1:1"}),imgSrcs:u[0]?.sources,altText:u[0]?.altText,...u[0],stickers:k}):null}):null;return i("article",{id:o,className:h("sdsm-multi-value-prop-block",n??Bn(a),s3,{[c3]:S},C),style:v,children:x(qr,{className:h(i3,{[p3]:!t&&g===ie.Start&&!I}),children:[x("section",{className:h(d3,{[l3]:A===0}),children:[x("div",{className:u3,children:[x("div",{className:y3,children:[i("h3",{className:Ji,children:s}),l&&i("p",{className:yo,children:l})]}),t&&i(D,{}),p&&p]}),d&&i("div",{className:m3,children:d}),b&&i("div",{className:x3,children:b})]}),!t&&i(D,{})]})})};var w3=({stat:e,subtitle:t})=>x("div",{className:h(Ls,S3),children:[i("h3",{className:Ji,children:e}),t]});var D3=e=>{let{title:t,body:o,icon:n,imgSrcs:a}=e;return x("div",{className:Ls,children:[n?i(De,{name:n,size:18,className:b3}):a&&i(et,{className:g3,imgClassName:f3,imgSrcs:a}),x("div",{className:ky,children:[i("h6",{className:Sa,children:t}),o]})]})};var Bp=T(w());var P3={[di.TopLeft]:c`
    left: 2%;
    top: 4%;
  `,[di.TopRight]:c`
    right: 2%;
    top: 4%;
  `,[di.TopCenter]:c`
    left: 50%;
    top: 4%;
    transform: translateX(-50%);
  `,[di.BottomLeft]:c`
    left: 2%;
    bottom: 4%;
  `,[di.BottomRight]:c`
    right: 2%;
    bottom: 4%;
  `,[di.BottomCenter]:c`
    left: 50%;
    bottom: 4%;
    transform: translateX(-50%);
  `},N3=c`
  position: absolute;

  ${N} {
    left: 50%;
    right: auto;
    transform: translateX(-50%);
  }
`,E3=c`
  width: 100%;
  height: 100%;
  display: flex;
  position: relative;
`,R3=c`
  width: 100%;
`,F3=c`
  display: flex;
  flex-direction: column;
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  width: 100%;
`,B3=c`
  flex: 1;
  position: relative;
`;var Fp=T(w());var Xj=c`
  visibility: visible;
`,Jj=c`
  position: absolute;
  visibility: hidden;
`,$3=({hasVideoSync:e,video:t,currentTime:o})=>{let n=(0,Fp.useRef)(null);return(0,Fp.useEffect)(()=>{Ct(o)||!n.current||!e||(n.current.currentTime=o.current)},[t]),(0,Fp.useEffect)(()=>{let a=n.current;if(!a||!e)return;let s=l=>{let p=l.target;o.current=p.currentTime};return a.addEventListener("timeupdate",s),()=>{a.removeEventListener("timeupdate",s)}},[o,t,e]),i(yi,{className:h(Jj,{[Xj]:!0}),source:t.media?.url,posterSource:t.thumbnailMedia?.url,isBackgroundVideo:!0,sourceType:t.media?.contentType,ref:n})};var _h=({anchorId:e,children:t,className:o,hasVideoSync:n=!0,id:a,mobilePrimaryVideos:s,mobileSecondaryVideos:l,onVideoChange:p=xo,panelPosition:d,primaryVideos:u,style:y,secondaryVideos:m,toggleButtonIcons:g,togglePanelClassName:f,togglePanelLabel:b,preChildren:S,postChildren:C})=>{let[v,k]=(0,Bp.useState)(!1),[I,A]=(0,Bp.useState)(0),D=(0,Bp.useRef)(0);Y("sdsm-multi-video-block");let M=Yo()===lt.Mobile,_=M?[s,l]:[u,m],P=v?_[1]:_[0],$=P[I],R=M?[...s,...l]:[...u,...m],L=U=>{A(U),D.current=0,p(U,v)},G=U=>{k(U),p(I,U)},Z=R.filter(U=>U?.media?.url).map((U,de)=>i("link",{rel:"prefetch",as:"video",href:U.media.url},de));return x("div",{id:e,style:y,className:h("sdsm-multi-video-block",E3,o),children:[Z,$?.thumbnailMedia?.url&&i("img",{className:R3,src:$.thumbnailMedia.url}),$&&i($3,{hasVideoSync:n,isSelected:!0,video:$,currentTime:D}),t,x("div",{className:F3,children:[S,i("div",{className:B3,children:i(c0,{id:a,items:P,label:b,sliderChecked:v,onSliderUpdate:G,onButtonToggle:L,hasToggleSlider:!!_[1]?.length,selectedId:P[I].id,className:h(P3[d],N3,f),buttonIcons:g})}),C]})]})};_h.displayName="MultiVideoBlock";Kf();var Lo=T(w());function L3(e){return t=>{if(!e)return!1;try{let o=`${e.protocol}//${e.hostname}`,n=new URL(t,o),a=e.hostname,s=e.pathname;return a===n.hostname&&s===n.pathname}catch{return!1}}}var W3=T(w());var $p=({fill:e,icon:t,media:o,size:n})=>{if(t)return i(De,{size:n,name:t.name,fill:t.fill?t.fill:e});if(o){let{altText:a,imgSrcs:s}=o;return i(et,{imgSrcs:s,width:n,height:n,altText:a})}return null};$p.displayName="IconOrImage";var My="sdsm-nav-featured-link-title",Ty=c`
  align-items: flex-start;
  background-color: ${r("--global-header-menu-featured-item-bg-color")};
  border-radius: ${r("--global-header-menu-featured-item-border-radius")};
  color: ${r("--global-header-menu-featured-item-fg-color")};
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-s")};
  padding: ${r("--spacing-m")};
  text-decoration: none;
  transition: background-color 0.2s linear;

  &:hover {
    color: ${r("--global-header-menu-featured-item-hover-color")};
    background-color: ${r("--global-header-menu-featured-item-bg-hover-color")};
  }
`,H3=c`
  background-color: ${r("--global-header-menu-featured-item-bg-hover-color")};
  color: ${r("--global-header-menu-featured-item-hover-color")};

  & .${My} {
    color: ${r("--global-header-menu-featured-item-active-color")};
  }

  &:hover {
    & .${My} {
      color: ${r("--global-header-menu-featured-item-active-color")};
    }
  }
`,V3=c`
  && {
    font-size: ${r("--p2-desktop-font-size")};
    font-weight: 500;
    line-height: ${r("--p2-desktop-font-line-height")};
    margin: 0;
  }
`,O3=c`
  && {
    font-size: ${r("--p3-desktop-font-size")};
    font-weight: 400;
    line-height: ${r("--p3-desktop-font-line-height")};
    margin: 0;
  }
`,G3=c`
  && {
    align-items: center;
    display: flex;
    gap: ${r("--spacing-xs")};
    justify-content: end;
    margin: auto 0 0 0;
    width: 100%;
  }
`,z3=c`
  && {
    font-size: ${r("--p3-desktop-font-size")};
    font-weight: 400;
    line-height: ${r("--p3-desktop-font-line-height")};
    margin: auto 0 0 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;

    ${H} {
      opacity: 0;
      transform: translateX(${r("--spacing-xs")});
      transition: opacity 0.2s linear, transform 0.2s ease-in-out;

      [dir='rtl'] & {
        transform: translateX(calc(${r("--spacing-xs")} * -1));
      }

      ${`.${Ty}`}:hover &,
    ${`.${Ty}`}:focus & {
        opacity: 1;
        transform: translateX(0);
      }
    }
  }
`,U3=c`
  [dir='rtl'] & {
    transform: scaleX(-1);
  }
`;var Lp=({url:e,title:t,dataset:o,description:n,icon:a,media:s,ctaLabel:l,onClick:p,isUrlCurrent:d})=>{let{Anchor:u}=(0,W3.useContext)(He);return x(u,{className:h("sdsm-nav-featured-link",Ty,{[H3]:d}),href:e,role:"menuitem",onClick:p,...ne(o),children:[(a||s)&&i($p,{icon:a,media:s,size:48,fill:r("--global-header-menu-featured-item-icon-color")}),i("span",{className:h(My,V3),children:t}),i("span",{className:O3,children:n}),x("span",{className:G3,children:[i("span",{className:z3,children:l}),i(De,{className:U3,size:24,name:"arrow-right",fill:r("--global-header-menu-featured-item-fg-color")})]})]})};Lp.displayName="NavigatorItemFeaturedLink";var Z3=T(w());var Hp="sdsm-navigator-item-link-text-title",Q3=c`
  background-color: transparent;
  border-radius: ${r("--global-header-menu-item-border-radius")};
  color: ${r("--global-header-menu-item-fg-color")};
  cursor: pointer;
  display: flex;
  gap: 8px;
  padding: 16px;
  text-decoration: none;
  transition: background-color 0.2s linear;
  width: 100%;

  :hover {
    background-color: ${r("--global-header-menu-item-bg-hover-color")};

    & .${Hp} {
      color: ${r("--global-header-menu-item-hover-color")};
    }
  }
`,q3=c`
  background-color: ${r("--global-header-menu-item-bg-hover-color")};
  color: ${r("--global-header-menu-item-hover-color")};

  & .${Hp} {
    color: ${r("--global-header-menu-item-active-color")};
  }

  :hover {
    & .${Hp} {
      color: ${r("--global-header-menu-item-active-color")};
    }
  }
`,K3=c`
  && {
    margin: 1px 0 0 0;
    min-width: 24px;
  }
`,j3=c`
  && {
    display: flex;
    flex-direction: column;
    gap: ${r("--spacing-xs")};
    margin: 0;

    span {
      margin: 0;
    }
  }
`,Y3=c`
  && {
    font-size: ${r("--p2-desktop-font-size")};
    font-weight: 500;
    line-height: ${r("--p2-desktop-font-line-height")};
    margin: 0;
  }
`,X3=c`
  && {
    font-size: ${r("--p3-desktop-font-size")};
    font-weight: 400;
    line-height: ${r("--p3-desktop-font-line-height")};
    margin: 0;
  }
`,J3=c`
  && {
    font-size: ${r("--p3-desktop-font-size")};
    font-weight: 400;
    line-height: ${r("--p3-desktop-font-line-height")};
    margin: 0 0 ${r("--spacing-xs")} 0;
  }
`;var Vp=({url:e,title:t,dataset:o,description:n,icon:a,media:s,showSpacer:l,onClick:p,isUrlCurrent:d})=>{let{Anchor:u}=(0,Z3.useContext)(He);return x(pe,{children:[x(u,{className:h("sdsm-nav-link",Q3,{[q3]:d}),href:e,role:"menuitem",onClick:p,...ne(o),children:[(a||s)&&i("span",{className:K3,children:i($p,{icon:a,media:s,size:24,fill:r("--global-header-menu-item-icon-color")})}),x("span",{className:j3,children:[i("span",{className:h(Hp,Y3),children:t}),!!n&&i("span",{className:X3,children:n})]})]}),!n&&l?i("span",{className:J3,children:"\xA0"}):null]})};Vp.displayName="NavigatorItemLink";var Ay=({col1Label:e,col1Items:t=[],col2Label:o,col2Items:n=[],col3Label:a,col3Items:s=[]})=>[{id:1,hasItems:!!t?.length,hasLabel:!!e},{id:2,hasItems:!!n?.length,hasLabel:!!o},{id:3,hasItems:!!s?.length,hasLabel:!!a}].filter(({hasItems:p})=>p).filter((p,d,u)=>{let y=u[d-1],m=d===0,g=p.hasLabel||y?.hasLabel;return!m&&g}).map(({id:p})=>p);var wh=c`
  align-items: center;
  color: ${r("--global-header-navigator-item-color")};
  display: flex;
  /* Set font-family here or the var from the default motif is used */
  font-family: ${r("--font-family")};
  font-size: ${r("--action-desktop-font-size")};
  font-weight: 500;
  line-height: ${64}px;
  margin-left: ${r("--spacing-m")};
  margin-right: ${r("--spacing-m")};
  padding-bottom: 0;
  padding-top: 0;
  text-decoration: none;
  text-transform: ${r("--global-header-navigator-item-desktop-font-text-transform")};
  white-space: nowrap;

  ${N} {
    font-size: ${r("--action-mobile-font-size")};
  }

  &:hover {
    color: ${r("--global-header-navigator-item-hover-color")};
  }

  & span {
    position: relative; /* For the underline */
    overflow-y: hidden;
  }

  /** Custom underline */
  & > span::after {
    /* TODO: consolidate the rounded underline css? */
    background-color: ${r("--global-header-navigator-indicator-active-color")};
    bottom: -8px;
    content: '';
    height: 8px;
    left: 0;
    position: absolute;
    border-radius: ${r("--action-indicator-border-radius")};
    transform: translateY(0);
    transition: all 0.15s ease;
    width: 100%;
  }

  &:hover > span::after {
    opacity: ${r("--action-indicator-hover-opacity")};
    transform: translateY(-4px);
  }

  & > span.selected {
    color: ${r("--global-header-navigator-item-active-color")};
  }

  & > span.selected::after {
    opacity: 1;
    transform: translateY(-4px);
  }

  &:hover > span.selected::after {
    background-color: ${r("--global-header-navigator-indicator-active-color")};
  }
`,eF=c`
  cursor: pointer;
`,tF=c`
  /**
   * use negative margin to make icon take up space same as previous
   */
  margin: calc(${r("--spacing-xxs")} * -1);
  fill: ${r("--global-header-navigator-item-color")};

  margin-left: calc(${r("--spacing-xs")} - 4px);
  *[dir='rtl'] & {
    margin-right: calc(${r("--spacing-xs")} - 4px);
  }
`,oF=c`
  background-color: ${r("--global-header-menu-bg-color")};
  border: ${r("--border-width-xs")} solid ${r("--global-header-menu-border-color")};
  border-radius: ${r("--global-header-menu-border-radius")};
  border-top: none;
  box-shadow: ${r("--global-header-menu-box-shadow")};
  /* Trim box shadow from the top, otherwise it will overlap the main header bar */
  clip-path: inset(0 -20px -20px -20px);
  left: 50%;
  max-width: calc(100vw - 2 * ${r("--spacing-m")});
  opacity: 0;
  padding: ${r("--spacing-l")};
  position: absolute;
  top: 100%;

  /* Safari fix: with the translateZ fix from below, we need this because for some
  reason there is a tiny 1px gap between the menu and the navbar sometimes.
  We accomadate for this by adding 1px of padding so visually looks the same */
  margin-top: -1px;
  padding-top: calc(${r("--spacing-l")} + 1px);

  /*
    We NEED translateZ(0) otherwise the menu flickers for some reason on safari
    https://developer.apple.com/forums/thread/705172
    not official, but other people have used this workaround
  */
  transform: translate(-50%, 0) translateZ(0);
  transition: opacity 0.2s linear, visibility 0.2s linear;
  visibility: hidden;
  width: 1080px;
`,nF=c`
  width: 1280px;
`,rF=c`
  position: relative;

  > div.sdsm-nav-item-menu {
    transform: unset;
    left: unset;
    right: 0;
  }
`,aF=c`
  position: relative;

  > div.sdsm-nav-item-menu {
    transform: unset;
    left: 0;
  }
`,iF=c`
  opacity: 1;
  visibility: visible;
`,sF=c`
  display: grid;
  gap: ${r("--spacing-l")};
  grid-template-columns: repeat(auto-fit, minmax(0, 1fr));
`,Op=c`
  display: flex;
  flex-direction: column;
  height: 100%;
  position: relative;
`,_y=c`
  &::before {
    background-color: ${r("--global-header-menu-col-divider-color")};
    bottom: 0;
    content: '';
    height: calc(100% - ${r("--spacing-m")});
    left: calc(${r("--spacing-s")} * -1);
    position: absolute;
    width: 1px;

    [dir='rtl'] & {
      left: auto;
      right: calc(${r("--spacing-s")} * -1);
    }
  }
`,wy=c`
  && {
    color: ${r("--global-header-menu-col-label-color")};
    font-size: ${r("--p3-desktop-font-size")};
    font-weight: 500;
    letter-spacing: -0.01em;
    line-height: ${r("--p3-desktop-font-line-height")};
    margin: ${r("--spacing-m")};
    overflow: hidden;
    text-overflow: ellipsis;
    text-transform: uppercase;
    white-space: nowrap;
  }
`;var Zj=e=>{let t=typeof window>"u"?void 0:window?.location;return L3(t)(e)},Gp=({url:e,onClick:t,isSelected:o,title:n,dataset:a,analytics:s,col1Label:l,col1Items:p=[],col2Label:d,col2Items:u=[],col3Label:y,col3Items:m=[],featuredItem:g})=>{Y("sdsm-header");let{Anchor:f}=(0,Lo.useContext)(He),{isUrlCurrent:b}=(0,Lo.useContext)(at),[S,C]=(0,Lo.useState)(o??!1),[v,k]=(0,Lo.useState)(!1),[I,A]=(0,Lo.useState)();(0,Lo.useEffect)(()=>{if(o!==void 0){C(o);return}let Q=[e,...p.map(z=>z.url),...u.map(z=>z.url),...m.map(z=>z.url),g?.url].some(z=>z?b?b(z):Zj(z):!1);C(Q)},[o,e,p,u,m,g?.url,b]);let D=(0,Lo.useRef)(null),B=(0,Lo.useRef)(null),M=v?"chevron-up":"chevron-down",_=(0,Lo.useCallback)(()=>{if(typeof window>"u"||!D.current||!B.current)return;let F=window.innerWidth,Q=D.current.offsetLeft,z=D.current.offsetWidth,Se=Q+z,j=B.current.offsetWidth,fe=F/2-j/2,J=F/2+j/2,ue=F>dt&&Se>J,_e=F>dt&&Q<fe;A(ue?ie.Right:_e?ie.Left:ie.Center)},[]);(0,Lo.useEffect)(()=>{let F=pi(_,500);return window.addEventListener("resize",F),()=>{window.removeEventListener("resize",F)}},[_]);let P=t||e?eF:null,$=h({selected:S}),R=i("span",{className:$,children:n}),L=F=>{F.stopPropagation(),F.key===" "&&F.preventDefault();let Q=B.current?.querySelectorAll('a, button, input, textarea, select, details, [tabindex]:not([tabindex="-1"])'),z=Q?.[0],Se=Q?.[Q.length-1];I||_(),F.key==="Enter"||F.key===" "||F.key==="ArrowDown"?(k(!0),setTimeout(()=>z?.focus(),250)):F.key==="ArrowUp"&&(k(!0),setTimeout(()=>Se?.focus(),250))},G=F=>{if(F.key==="Tab"){let Q=B.current?.querySelectorAll('a, button, input, textarea, select, details, [tabindex]:not([tabindex="-1"])'),z=Q?.[0],Se=Q?.[Q.length-1];F.shiftKey?F.target===z&&k(!1):F.target===Se&&k(!1)}},Z=()=>{I||_(),k(!0)},U=()=>k(!1),de=[p?.length,u?.length,m?.length,g].filter(F=>!!F).length,le=3-de;if(!de)return i(f,{href:e,className:h("sdsm-header",wh,P),onClick:()=>t?.(e,s?.label),tabIndex:0,...ne(a),children:R});let re=p?.some(F=>!!F.description),te=p?.some(F=>!!F.description),ae=p?.some(F=>!!F.description),oe=Ay({col1Label:l,col1Items:p,col2Label:d,col2Items:u,col3Label:y,col3Items:m}),q=p?.some(F=>F?.icon||F?.media),X=u?.some(F=>F?.icon||F?.media),W=m?.some(F=>F?.icon||F?.media),K=(F,Q)=>{k(!1),t?.(F,Q)};return x("section",{ref:D,className:h({[rF]:I===ie.Right,[aF]:I===ie.Left},"sdsm-nav-item-desktop"),children:[x(f,{className:h(wh,P),onMouseEnter:Z,onMouseLeave:U,onKeyDown:L,tabIndex:0,...ne(a),children:[R,i(De,{size:24,className:tF,name:M})]}),i("div",{ref:B,className:h(oF,{[iF]:v,[nF]:de===4},"sdsm-nav-item-menu"),onMouseEnter:Z,onMouseLeave:U,onKeyDown:G,role:"menu","aria-label":"Menu",children:x("div",{className:sF,children:[!!p?.length&&i("div",{children:x("div",{className:h(Op,{[_y]:oe.includes(1)}),children:[!!l&&i("span",{className:wy,children:l}),p?.map(({url:F,title:Q,description:z,icon:Se,media:j,analytics:fe,dataset:J},ue)=>i(Vp,{url:F,title:Q,description:z,icon:q?Se:void 0,media:q?j:void 0,showSpacer:re,onClick:()=>K(F,fe?.label),dataset:v?J:void 0,isUrlCurrent:b?.(F)},ue))]})}),!!u?.length&&i("div",{children:x("div",{className:h(Op,{[_y]:oe.includes(2)}),children:[!!d&&i("span",{className:wy,children:d}),u?.map(({url:F,title:Q,description:z,icon:Se,media:j,analytics:fe,dataset:J},ue)=>i(Vp,{url:F,title:Q,description:z,icon:X?Se:void 0,media:X?j:void 0,showSpacer:te,onClick:()=>K(F,fe?.label),dataset:v?J:void 0,isUrlCurrent:b?.(F)},ue))]})}),!!m?.length&&i("div",{children:x("div",{className:h(Op,{[_y]:oe.includes(3)}),children:[!!y&&i("span",{className:wy,children:y}),m?.map(({url:F,title:Q,description:z,icon:Se,media:j,analytics:fe,dataset:J},ue)=>i(Vp,{url:F,title:Q,description:z,icon:W?Se:void 0,media:W?j:void 0,showSpacer:ae,onClick:()=>K(F,fe?.label),dataset:v?J:void 0,isUrlCurrent:b?.(F)},ue))]})}),Array.from({length:le}).map((F,Q)=>i("div",{},Q)),!!g&&i("div",{children:i("div",{className:Op,children:i(Lp,{url:g.url,title:g.title,description:g.description,icon:g.icon,media:g.media,ctaLabel:g.ctaLabel,onClick:()=>K(g.url,g.analytics?.label),analytics:g.analytics,dataset:v?g.dataset:void 0,isUrlCurrent:b?.(g.url)})})})]})})]})};Gp.displayName="NavigatorItemDesktop";var Dh=T(w());var lF=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-s")};
  padding: ${r("--spacing-m")} 0;
  padding-inline-start: ${r("--spacing-m")};
`,Dy=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-s")};
`,Py=c`
  border-top: 1px solid ${r("--global-header-menu-col-divider-color")};
  margin-top: ${r("--spacing-s")};
  padding-top: ${r("--spacing-l")};
`,pF=c`
  && {
    color: ${r("--global-header-menu-item-fg-color")};
    font-size: ${r("--p2-desktop-font-size")};
    font-weight: 400;
    line-height: ${r("--p2-desktop-font-line-height")};

    a {
      color: ${r("--global-header-menu-item-fg-color")};
    }

    a:hover {
      color: ${r("--global-header-menu-item-hover-color")};
    }
  }
`,cF=c`
  && {
    a {
      color: ${r("--global-header-menu-item-active-color")};
    }

    a:hover {
      color: ${r("--global-header-menu-item-active-color")};
    }
  }
`,Ny=c`
  && {
    color: ${r("--global-header-menu-col-label-color")};
    font-size: ${r("--p3-desktop-font-size")};
    font-weight: 500;
    letter-spacing: -0.01em;
    line-height: ${r("--p3-desktop-font-line-height")};
    overflow: hidden;
    text-overflow: ellipsis;
    text-transform: uppercase;
    white-space: nowrap;
  }
`,dF=c`
  margin-top: ${r("--spacing-s")};
  margin-inline-start: calc(${r("--spacing-m")} * -1);

  :first-child {
    margin-top: 0;
  }
`;var zp=({col1Label:e,col1Items:t=[],col2Label:o,col2Items:n=[],col3Label:a,col3Items:s=[],featuredItem:l,onClick:p,className:d})=>{Y("sdsm-header");let{Anchor:u}=(0,Dh.useContext)(He),{isUrlCurrent:y}=(0,Dh.useContext)(at),m=Ay({col1Label:e,col1Items:t,col2Label:o,col2Items:n,col3Label:a,col3Items:s}),g=({url:f,title:b,analytics:S,dataset:C,isUrlCurrent:v})=>i("div",{className:h(pF,{[cF]:v}),...ne(C),children:i(u,{className:"sdsm-nav-link",href:f,onClick:()=>p?.(f,S?.label),children:b})});return x("div",{className:h(lF,"sdsm-nav-item-mobile",d),children:[!!t?.length&&x("div",{className:h(Dy,{[Py]:m.includes(1)}),children:[!!e&&i("div",{className:Ny,children:e}),t?.map(({url:f,title:b,analytics:S,dataset:C},v)=>i(g,{url:f,title:b,analytics:S,dataset:C,isUrlCurrent:y?.(f)},v))]}),!!n?.length&&x("div",{className:h(Dy,{[Py]:m.includes(2)}),children:[!!o&&i("div",{className:Ny,children:o}),n?.map(({url:f,title:b,analytics:S,dataset:C},v)=>i(g,{url:f,title:b,analytics:S,dataset:C,isUrlCurrent:y?.(f)},v))]}),!!s?.length&&x("div",{className:h(Dy,{[Py]:m.includes(3)}),children:[!!a&&i("div",{className:Ny,children:a}),s?.map(({url:f,title:b,analytics:S,dataset:C},v)=>i(g,{url:f,title:b,analytics:S,dataset:C,isUrlCurrent:y?.(f)},v))]}),!!l&&i("div",{className:dF,children:i(Lp,{url:l.url,title:l.title,description:l.description,icon:l.icon,media:l.media,ctaLabel:l.ctaLabel,onClick:()=>p?.(l.url,l.analytics?.label),dataset:l.dataset,isUrlCurrent:y?.(l.url)})})]})};zp.displayName="NavigatorItemMobile";var Hs=T(w());var eY=c`
  scroll-snap-align: center;
`,uF=({children:e})=>{(0,Hs.useEffect)(()=>{if(typeof window>"u")return;let o=document.getElementsByTagName("html")[0],n=document.body;return o.style.scrollSnapType="y proximity",n.style.scrollSnapType="y proximity",()=>{o.style.scrollSnapType="none",n.style.scrollSnapType="none"}},[]);let t=Hs.Children.toArray(e);return i(pe,{children:e&&t.map((o,n)=>{let a=o,s=n===t.length-1;return(0,Hs.cloneElement)(a,{className:h({[eY]:!s},a.className)})})})};var Ph=({motifScheme:e,backgroundColor:t,backgroundImageSources:o,backgroundMediaStyle:n=Ed.Normal,backgroundPosterSource:a,backgroundVideoSource:s,children:l,className:p,mobileBackgroundVideoSource:d,scrollSnap:u,gutterMatchesPageBackground:y})=>{Y("sdsm-page");let m=h(t1,e??Pe(t),o1,p,o||s?r1:n1),g=y?{"--gutter-color":r("--bg-color")}:void 0;return i("div",{"data-testid":"sdsm-page",className:h(e1,"sdsm-page"),children:x("div",{className:m,style:g,children:[o&&i(et,{imgSrcs:o,imgClassName:n===Ed.Fixed?Kb:qb,fetchPriority:"auto"}),s?i(yi,{className:n===Ed.Fixed?Kb:qb,source:s,mobileSource:d,posterSource:a,isBackgroundVideo:!0}):void 0,u?i(uF,{children:l}):l]})})};Ph.displayName="Page";var CF=T(w());var yF=c`
  align-items: center;
  display: flex;
  height: 44px;
  justify-content: center;
  list-style: none;
  margin: 0;
  padding: ${r("--spacing-l")} 0;

  ${H} {
    padding-block-start: ${r("--spacing-xxxl")};
  }

  li {
    display: flex;
    justify-content: center;
    position: relative;
  }
`,mF=c`
  background-color: transparent;
  border: 0;
  user-select: none;
  color: ${r("--pagination-item-color")};
  cursor: pointer;
  font: inherit;
  font-size: 16px;
  height: 44px;
  letter-spacing: 0.01em;
  padding: 0;
  width: 44px;

  ${Ht} {
    min-width: 40px;
    padding-inline: ${r("--spacing-xxs")};
    width: auto;
  }
`,gF=c`
  ::after {
    border-radius: ${r("--spacing-xxs")} ${r("--spacing-xxs")} 0 0;
    bottom: 0;
    content: ' ';
    height: ${r("--spacing-xxs")};
    position: absolute;
    width: ${r("--spacing-l")};
  }

  ${H} {
    &:hover::after {
      background-color: ${r("--pagination-indicator-hover-color")};
    }
  }
`,fF=c`
  button {
    color: ${r("--pagination-item-active-color")};
    font-weight: 500;
  }

  ::after,
  &:hover::after {
    background-color: ${r("--pagination-indicator-active-color")};
  }
`,Nh=c`
  *[dir='rtl'] & {
    transform: rotate(180deg);
  }
`,bF=c`
  margin-inline-end: ${r("--spacing-xxs")};

  ${H} {
    margin-inline-end: ${r("--spacing-l")};
  }
`,SF=c`
  margin-inline-start: ${r("--spacing-xxs")};

  ${H} {
    margin-inline-start: ${r("--spacing-l")};
  }
`;var Ey=({ariaLabel:e,children:t,disabled:o,handlePageChange:n,isActive:a,type:s})=>s==="previous"?i("li",{children:i(Mo,{size:"small",iconName:"chevron-left","aria-label":e,className:h(Nh,bF),disabled:o,onClick:n,tabIndex:o?-1:0,"data-testid":"pagination-item-previous"})}):s==="next"?i("li",{children:i(Mo,{size:"small",iconName:"chevron-right","aria-label":e,className:h(Nh,SF),disabled:o,onClick:n,tabIndex:o?-1:0,"data-testid":"pagination-item-next"})}):i("li",{className:h(gF,{[fF]:a}),children:i("button",{"aria-label":e,"aria-current":a,className:mF,disabled:o,onClick:n,tabIndex:0,type:"button",children:t?.toLocaleString()})});var Eh=(e,t)=>{let o=t-e+1;return Array.from({length:o},(n,a)=>e+a)},hF=(e,t)=>{let a=Math.max(Math.min(t-0,e-1-0-1),3),s=Math.min(Math.max(t+0,3),e-1-1),l=a>3,p=s<e-1-1,d=2<e-1?2:[],u=e-1>1?e-1:[],y=Eh(2,a-1),m=Eh(s+1,e-1);return[1,l?y:d,...Eh(a,s),p?m:u,e]};var Mi=({ariaLabel:e,className:t,totalPages:o,currentPage:n,onChange:a})=>{Y("sdsm-pagination");let{formatMessage:s}=(0,CF.useContext)(qe),l=s({id:"pagination-go-to-previous-page",defaultMessage:"Go to previous page"}),p=s({id:"pagination-go-to-next-page",defaultMessage:"Go to next page"}),d=m=>s({id:"pagination-go-to-page",defaultMessage:"Go to page {page}"},{page:m});if(!o||!n||o===1)return null;let u=m=>()=>{m>=1&&m<=o&&m!==n&&a(m)},y=hF(o,n);return i("nav",{"aria-label":e,className:h("sdsm-pagination",t),children:x("ul",{className:yF,children:[i(Ey,{disabled:n===1,handlePageChange:u(n-1),type:"previous",ariaLabel:l}),y.map((m,g)=>Array.isArray(m)?m.length?i("li",{children:i("span",{children:"..."})},g):null:i(Ey,{ariaLabel:m===n?`${m}`:`${d(String(m))}`,handlePageChange:u(m),isActive:m===n,disabled:m===n,children:m},g)),i(Ey,{disabled:n===o,handlePageChange:u(n+1),type:"next",ariaLabel:p})]})})};Mi.displayName="Pagination";var Rh=c`
  font-size: 40px;
  line-height: 40px;
  margin-bottom: -20px;
  margin-top: -8px;
`,xF=c`
  margin-inline-start: -16px;
  text-align: start;
`,vF=c`
  margin-inline-end: -20px;
  text-align: end;
`,IF=c`
  padding: ${r("--spacing-xl")};
  border-radius: ${r("--border-radius-l")};

  background-color: ${r("--quote-bg-color")};
  color: ${r("--quote-fg-color")};
`,kF=c`
  text-align: end;
  margin-top: ${r("--spacing-s")};

  ${H} {
    font-size: ${r("--quote-author-desktop-font-size")};
    font-weight: ${r("--quote-author-desktop-font-weight")};
  }

  ${N} {
    font-size: ${r("--quote-author-mobile-font-size")};
    font-weight: ${r("--quote-author-mobile-font-weight")};
  }
`;var Fh=({author:e,children:t})=>(Y("sdsm-quote"),x("div",{className:h("sdsm-quote",IF),children:[i("aside",{className:h(xF,Rh),children:"\u201C"}),t,i("aside",{className:h(vF,Rh),children:"\u201D"}),e&&x("div",{className:kF,children:["\u2014 ",e]})]}));Fh.displayName="Quote";var n_e=c`
  font-size: 40px;
  line-height: 40px;
  margin-bottom: -20px;
  margin-top: -8px;
  text-align: start;
`,r_e=c`
  margin-inline-start: -16px;
  text-align: start;
`,a_e=c`
  margin-inline-end: -20px;
  text-align: end;
`,MF=c`
  /* we separate the values to allow the snap brand to override the LR padding since no "card" is rendered on snap brand */
  padding: ${r("--spacing-xl")} ${r("--quote-card-left-right-padding")};
  border-radius: ${r("--border-radius-l")};

  background-color: ${r("--quote-bg-color")};
  color: ${r("--quote-fg-color")};
  box-shadow: ${r("--quote-box-shadow")};
  font-family: ${r("--h5-font-family")};
  line-height: 120%;

  *[dir='rtl'] & {
    direction: rtl;
  }

  ${H} {
    width: 70%;
    max-width: 700px;
    font-size: ${r("--h5-desktop-font-size")};
    font-weight: ${r("--h5-desktop-font-weight")};
  }

  ${N} {
    width: 100%;
    padding: ${r("--spacing-l")};
    font-size: ${r("--h5-mobile-font-size")};
    font-weight: ${r("--h5-mobile-font-weight")};
  }
`,TF=c`
  ${H} {
    width: 100%;
  }
`,AF=c`
  font-family: ${"Program OT"}, Helvetica, Tahoma, Arial, sans-serif;
  color: ${r("--action-text-active-color")};
  font-size: ${r("--quote-icon-desktop-font-size")};
  line-height: ${r("--quote-icon-desktop-line-height")};
  margin-bottom: ${r("--quote-icon-desktop-margin-bottom")};

  ${N} {
    font-size: ${r("--quote-icon-mobile-font-size")};
    line-height: ${r("--quote-icon-mobile-line-height")};
    margin-bottom: ${r("--quote-icon-mobile-margin-bottom")};
  }
`,_F=c`
  display: block;
  clear: both;
`,wF=c`
  display: block;
  clear: both;
  font-family: ${r("--font-family")};
  line-height: 120%;

  ${H} {
    font-size: ${r("--p1-desktop-font-size")};
    font-weight: ${r("--p1-desktop-font-weight")};
  }

  ${N} {
    font-size: ${r("--p1-mobile-font-size")};
    font-weight: ${r("--p1-mobile-font-weight")};
  }
`,Bh=c`
  display: flex;
  justify-content: flex-end;
  width: 100%;
  max-height: 98px;
  margin-bottom: ${r("--spacing-l")};
  margin-top: ${r("--spacing-l")};

  /* Override default button padding for logo alignment */
  button {
    padding: 0;
  }
`,DF=c`
  display: flex;
  justify-content: flex-start;

  ${N} {
    justify-content: center;
  }
`,$h=c`
  a {
    color: inherit;
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }

  text-align: ${r("--quote-author-text-align")};

  ${H} {
    font-size: ${r("--quote-author-desktop-font-size")};
    font-weight: ${r("--quote-author-desktop-font-weight")};
  }

  ${N} {
    font-size: ${r("--quote-author-mobile-font-size")};
    font-weight: ${r("--quote-author-mobile-font-weight")};
  }
`,PF=c`
  ${$h}
  margin-top: ${r("--spacing-l")};
`,NF=c`
  ${Bh}
`,EF=c`
  ${H} {
    flex-direction: row;
  }

  ${N} {
    flex-direction: column;
  }

  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  /* Force LTR for component layout, but text inside will still respect RTL */
  direction: ltr;
`,RF=c`
  transform: rotate(-2deg) translateX(8px);
  border-radius: ${r("--border-radius-xl")};
  overflow: hidden;
  box-shadow: ${r("--box-shadow-s")};

  ${H} {
    width: 30%;
    height: 100%;
    min-width: 280px;
    max-width: 320px;
  }

  ${N} {
    width: 90%;
    max-width: 360px;
    transform: rotate(-2deg) translateY(16px);
  }
`,FF=c`
  display: block;
  height: 100%;
  object-fit: cover;
  object-position: center;
  width: 100%;
`,BF=c`
  height: 100%;
  object-fit: cover;
  object-position: center;
  width: 100%;
`;var Lh=({author:e,children:t,logoImageSrc:o,isRtl:n=!1,isLongQuote:a=!1,imgSrcs:s,videoSrc:l,mobileVideoSrc:p})=>{Y("sdsm-quote");let d=o?$h:PF,u=a?wF:_F,y=n?"\u201D":"\u201C",m=h(l?BF:FF),g=!!(s||l)&&!a;return x("div",{className:h("sdsm-quote-container",EF),children:[g&&i("div",{className:RF,children:i(Ke,{showVideoControls:!1,videoSource:l,mobileVideoSource:p,imgSrcs:s,className:m,isDraggable:!1})}),x("div",{className:h("sdsm-quote",MF,{[TF]:!g}),children:[i("div",{className:DF,children:x("div",{className:AF,children:[" ",y]})}),i("div",{className:u,children:t}),o&&i("div",{className:e?Bh:NF,children:i($s,{width:98,imgSrcs:o,altText:"Quote background"})}),e&&i("div",{className:d,children:e})]})]})};Lh.displayName="QuoteV2";var Ga=T(w());var GF=T(w());var $F=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-xs")};
`,Hh=c`
  cursor: not-allowed;
  opacity: 0.8;
`,LF=c`
  align-items: center;
  display: flex;
  gap: ${r("--spacing-s")};

  label {
    align-items: center;
    display: flex;
    justify-content: center;
    margin-top: 0;

    a {
      &,
      &:hover,
      &:visited {
        color: ${r("--fg-color")};
      }
    }
  }
`,HF=c`
  appearance: none;
  background-color: ${r("--form-input-bg-color")};
  border-radius: 50%;
  border: ${r("--form-input-border-width")} solid ${r("--form-input-border-color")};
  height: 20px;
  margin: 0;
  padding: 0;
  width: 20px;

  &:checked {
    border-color: ${r("--form-input-active-border-color")};
    box-shadow: ${r("--form-input-active-box-shadow")};
  }

  &:checked::before {
    background-color: ${r("--form-input-active-border-color")};
    border-radius: 50%;
    content: '';
    display: block;
    height: 10px;
    margin: 3px;
    width: 10px;
  }

  &:focus-visible {
    outline: ${r("--form-input-border-width")} solid ${r("--form-input-active-border-color")};
    outline-offset: -2px;
  }

  &:not(:checked):hover {
    border-color: ${r("--form-input-hover-border-color")};
    box-shadow: ${r("--form-input-hover-box-shadow")};
  }

  &[required]:not(:checked)::before {
    border-color: ${r("--form-input-error-color")};
  }

  &[readonly] {
    ${Hh}
  }

  &[readonly]:hover {
    border-color: ${r("--form-input-border-color")};
    box-shadow: none;
  }

  &[readonly]:checked {
    border-color: ${r("--form-input-active-border-color")};
    box-shadow: none;
  }
`,VF=c`
  margin-top: 0 !important;
`,OF=c`
  border: ${r("--form-input-border-width")} solid ${r("--form-input-error-color")};

  &:hover {
    border: ${r("--form-input-border-width")} solid ${r("--form-input-error-color")};
  }
`;var zF=e=>{let{id:t,handleChange:o,handleInvalid:n,hasError:a=!1,label:s,name:l,readOnly:p,value:d,...u}=e,{state:y}=(0,GF.useContext)(mo),m=yr(y.formBody[l]),g=yr(d);return x("div",{className:LF,children:[i("input",{type:"radio",name:l,id:t,value:g,checked:m===g,className:h(HF,{[OF]:a}),disabled:p,onChange:o,onBlur:o,onInvalid:n,readOnly:p,...u}),i("label",{htmlFor:t,className:h(VF,{[Hh]:p}),children:s})]})};var UF=(0,Ga.memo)(e=>{let{error:t,helpText:o,initialValue:n,label:a,name:s,options:l=[],required:p=!1,shouldResetToInitial:d=!1}=e,{state:u,dispatch:y}=(0,Ga.useContext)(mo);(0,Ga.useEffect)(()=>{y({type:"registerField",name:s,field:{required:p,initialValue:n,shouldResetToInitial:d}})},[y,n,s,p,d]);let m=u.fields[s],g=b=>{y({type:"changeFieldValue",name:s,value:b.target.value})},f=(0,Ga.useCallback)(()=>{y({type:"invalidateField",name:s})},[y,s]);return l.length===0?null:i($a,{type:"Radio",name:s,label:a,required:p,helpText:o,error:t,hasError:m?.hasError,children:i("div",{className:$F,children:l.map(({key:b,value:S})=>i(zF,{id:b,name:s,value:S??b,label:S??b,required:p,hasError:m?.hasError,handleChange:g,handleInvalid:f},b))})})});var WF=c`
  position: relative;
  display: flex;
  justify-content: center;
`,QF=c`
  position: sticky;
  top: 0;
  height: 100vh;
  width: 100%;
`;var qF=({className:e,containerRef:t,innerContainerClassName:o,children:n,dataset:a,style:s,anchorId:l})=>i("section",{ref:t,id:l,className:h(WF,e),style:{...s},...ne(a),children:i("div",{className:h(QF,o),children:n})});var Vs=T(w());var KF=({calculateScrollProgress:e,className:t,videoMp4Src:o,videoWebmSrc:n,videoStart:a=0,videoEnd:s,scrubStart:l=0,scrubEnd:p=100,style:d,dataset:u})=>{let y=(0,Vs.useRef)(null),b=(0,Vs.useContext)(Ze).getLowEntropyHints().browsers.some(S=>S.brand==="Firefox")?n:o;return(0,Vs.useEffect)(()=>{y.current&&(y.current.currentTime=a||0);let S=()=>{if(y.current){let C=e(),v=(p-l)/100,k=(C-l/100)*(1/v);if(k>0&&k<=1){let A=(s?Math.min(s,y.current.duration):y.current.duration)-a,D=a+A*k;y.current.currentTime=Number.parseFloat(D.toFixed(3))}}};return window.addEventListener("scroll",S),window.addEventListener("resize",S),()=>{window.removeEventListener("scroll",S),window.removeEventListener("resize",S)}},[e,p,l,s,a]),i("video",{ref:y,src:b,className:t,style:d,...ne(u)})};var Ry=T(w());var jF=340,tY=640,YF=c`
  /* Extra clearance beyond 100% so the panel clears the page container edge. */
  --directional-overlay-lateral-outset: calc(2 * ${r("--spacing-l")});

  background-color: ${r("--side-overlay-bg-color")};
  border: ${r("--border-width-xs")} solid ${r("--side-overlay-border-color")};
  box-shadow: 0 12px 20px 0 #0000001f;
  display: flex;
  flex-direction: column;
  overflow: hidden;

  ${H} {
    border-radius: ${r("--border-radius-l")};
    height: calc(100vh - var(--total-header-height, 0px) - (2 * ${r("--spacing-l")}));
    max-width: ${jF}px;
    top: calc(var(--total-header-height, 0px) + ${r("--spacing-l")});
    width: ${jF}px;
  }

  ${N} {
    border-radius: ${r("--border-radius-l")} ${r("--border-radius-l")} 0 0;
    bottom: 0;
    height: auto;
    left: 0;
    margin-left: auto;
    margin-right: auto;
    max-height: calc(100vh - var(--total-header-height, 0px) - ${r("--spacing-m")});
    max-width: ${tY}px;
    right: 0;
    width: calc(100vw - (2 * ${r("--spacing-m")}));

    *[dir='rtl'] & {
      left: 0;
      right: 0;
    }
  }
`,XF=c`
  ${H} {
    /*
     * 50%              --> move to center of the viewport (from the right)
     * 50cqw            --> move back by half of the page container width to reach its right edge
     * var(--spacing-l) --> adjust to move away from the container edge
     */
    && {
      right: calc(50% - 50cqw + ${r("--spacing-l")});
    }

    *[dir='rtl'] & {
      left: calc(50% - 50cqw + ${r("--spacing-l")});
      right: auto;
    }

    /* RTL: negate the direction-class transform so the panel slides from the left. */
    *[dir='rtl'] &:not(.${xp}) {
      transform: translateX(calc(-100% - var(--directional-overlay-lateral-outset, 0px)));
    }
  }
`,JF=c`
  ${H} {
    && {
      left: calc(50% - 50cqw + ${r("--spacing-l")});
      right: auto;
    }

    *[dir='rtl'] & {
      left: auto;
      right: calc(50% - 50cqw + ${r("--spacing-l")});
    }

    /* RTL: negate the direction-class transform so the panel slides from the right. */
    *[dir='rtl'] &:not(.${xp}) {
      transform: translateX(calc(100% + var(--directional-overlay-lateral-outset, 0px)));
    }
  }
`,ZF=c`
  ${H} {
    /*
     * 50%                       --> move to center of the viewport (from the right)
     * 50cqw                     --> move back by half of the page container width to reach its right edge
     * desktopSideNavWidthPx / 2 --> move back by half of the side navigation width
     * var(--spacing-l)          --> adjust to move away from the container edge
     */
    && {
      right: calc(50% - 50cqw - ${To/2}px + ${r("--spacing-l")});
    }

    *[dir='rtl'] & {
      left: calc(50% - 50cqw - ${To/2}px + ${r("--spacing-l")});
      right: auto;
    }
  }
`,eB=c`
  ${H} {
    && {
      left: calc(50% - 50cqw - ${To/2}px + ${r("--spacing-l")});
      right: auto;
    }

    *[dir='rtl'] & {
      left: auto;
      right: calc(50% - 50cqw - ${To/2}px + ${r("--spacing-l")});
    }
  }
`,tB=c`
  display: flex;
  font-size: ${r("--h6-desktop-font-size")};
  font-weight: ${r("--h6-desktop-font-weight")};
  justify-content: end;
  line-height: ${r("--h6-desktop-font-line-height")};
  padding: ${r("--spacing-m")};
`,oB=c`
  background: transparent;
  border: none;
  cursor: pointer;
  margin: calc(${r("--spacing-m")} * -1);
  padding: ${r("--spacing-m")};
`,nB=c`
  height: 100%;
  margin: 0;
  overflow-y: auto;
  padding: ${r("--spacing-xs")} ${r("--spacing-l")} ${r("--spacing-l")} ${r("--spacing-l")};

  ${N} {
    padding-bottom: ${r("--spacing-xxxxl")};
  }
`,rB=c`
  color: ${r("--side-overlay-fg-color")};
  font-size: ${r("--h6-desktop-font-size")};
  font-weight: ${r("--h6-desktop-font-weight")};
  line-height: ${r("--h6-desktop-font-line-height")};
  margin: 0 0 ${r("--spacing-s")} 0;
  padding: 0;
`,aB=c`
  color: ${r("--side-overlay-fg-color")};
  font-size: ${r("--p2-desktop-font-size")};
  font-weight: ${r("--p2-desktop-font-weight")};
  line-height: ${r("--p2-desktop-font-line-height")};
  margin: 0;
  padding: 0;
`,iB=c`
  ${H} {
    display: none;
  }
`;var oY=24,nY=100,Vh=({isOpen:e,title:t,body:o,onClose:n,className:a,hasSideNav:s,style:l,dataset:p,"data-testid":d,direction:u="right"})=>{Y("sdsm-side-overlay");let y=(0,Ry.useRef)(null);(0,Ry.useEffect)(()=>{e&&setTimeout(()=>{y?.current?.focus()},250)},[e]);let m=f=>{n?.(f)},g=u==="left";return x(bS,{backdropClassName:iB,showBackdrop:!0,className:h("sdsm-side-overlay",YF,g?JF:XF,{[ZF]:s&&!g,[eB]:s&&g},a),dataset:p,"data-testid":d,desktopDirection:u,desktopSizePercent:oY,isOpen:e,mobileDirection:"bottom",mobileSizePercent:nY,onBackdropClick:m,style:l,children:[i("div",{className:tB,children:i("button",{className:oB,type:"button",ref:y,onClick:n,onKeyDown:n,children:i(De,{name:"cross",size:24,fill:r("--side-overlay-fg-color")})})}),x("dl",{className:nB,children:[i("dt",{className:rB,children:t}),i("dd",{className:aB,children:o})]})]})};Vh.displayName="SideOverlay";var Os=T(w());var sB=c`
  width: 100%;
  min-width: 300px;
  max-width: 416px;
  margin: 0 auto;

  > iframe {
    aspect-ratio: 3 / 5;
    width: 100%;
    height: 100%;
  }
`,lB=c`
  background: #c4c4c4;
  border: 0;
  border-radius: 40px;
  box-shadow: 0 0 1px 0 rgba(0, 0, 0, 0.5), 0 1px 10px 0 rgba(0, 0, 0, 0.15);
  margin: 1px;
  min-width: 300px;
  max-width: 416px;
  padding: 0;
  width: 99.375%;
  display: flex;
  flex-direction: column;
  position: relative;
  height: 650px;
`,pB=c`
  display: flex;
  flex-direction: row;
  align-items: center;
`,cB=c`
  background-color: #f4f4f4;
  border-radius: 50%;
  flex-grow: 0;
  height: 40px;
  margin: 16px 14px 16px 16px;
  width: 40px;
  cursor: pointer;
`,dB=c`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  justify-content: center;
`,uB=c`
  flex: 1;
`,yB=c`
  display: flex;
  flex-direction: row;
  align-items: center;
  border-end-end-radius: 40px;
  border-end-start-radius: 40px;
`,mB=c`
  background-color: yellow;
  width: 100%;
  padding: 10px 20px;
  border: none;
  border-radius: inherit;
  cursor: pointer;
  text-align: center;
  display: flex;
  flex-direction: row;
  justify-content: center;
  text-decoration: none;
  color: black;
  align-items: center;
`,gB=c`
  margin-left: 4px;
  padding-bottom: 1px;
  font-size: 14px;
`;var Gs=e=>{let{url:t,dataset:o,className:n}=e,a=(0,Os.useRef)(null);Y("sdsm-snapchat-embed");let{Anchor:s}=(0,Os.useContext)(He);(0,Os.useEffect)(()=>{fn("snapchat-embed","https://www.snapchat.com/embed.js",()=>{let d=new Event("loadEmbed",{bubbles:!0});a.current?.dispatchEvent(d)})},[t]);let l=new URL(t),p=`${l.origin}${l.pathname}`.replace(/\/$/,"");return i("div",{className:h("sdsm-snapchat-embed",sB,n),ref:a,...ne(o),children:x("blockquote",{className:h(lB,"snapchat-embed"),"data-snapchat-embed-width":"416","data-snapchat-embed-height":"692","data-snapchat-embed-url":`${p}/embed`,"data-snapchat-embed-style":"border-radius: 40px;",children:[x("div",{className:pB,children:[i(s,{href:p,className:cB}),i("div",{className:dB})]}),i("div",{className:uB}),i("div",{className:yB,children:i(s,{href:p,className:mB,children:i("div",{className:gB,children:"View more on Snapchat"})})})]})})};var wB=T(w());var rY=400,fB=375,bB=592,aY=440,SB=c`
  align-items: stretch;
  background-color: ${r("--bg-color")};
  display: flex;
  gap: 0;
  justify-content: center;
  min-height: ${rY}px;
  width: 100%;

  ${N} {
    flex-direction: column;
    height: 100%;
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${uo} {
    flex-direction: column;
    height: 100%;
  }
`,hB=c`
  height: calc(100vh - ${64}px);
`,Oh=c`
  flex-direction: row-reverse;
`,CB=c`
  display: flex;
  flex-shrink: 0;
  justify-content: flex-end;
  padding: ${r("--spacing-xxxxl")};
  width: 50%;

  ${vo} {
    width: 60%;
  }

  ${N} {
    padding: 0;
    width: 100%;
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${ji} {
    width: 60%;
  }

  ${uo} {
    padding: 0;
    width: 100%;
  }
`,xB=c`
  color: ${r("--fg-color")};
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-m")};
  padding: ${r("--spacing-xl")};
  width: 100%;

  ${H} {
    max-width: ${bB}px;
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${uo} {
    max-width: unset;
  }

  ${li} {
    max-width: ${bB}px;
  }
`,vB=c`
  ${_k}
  word-break: break-word;
`,IB=c`
  ${yo}
  word-break: break-word;
`,kB=c`
  ${ut}
  margin-bottom: 0;
  word-break: break-word;

  & .${$n.p}:last-child {
    margin-bottom: 0;
  }
`,MB=c`
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  gap: ${r("--spacing-m")};
  margin-top: ${r("--spacing-m")};
`,TB=c`
  background: ${r("--split-block-media-caption-bg-color")};
  border-radius: ${r("--border-radius-s")};
  bottom: ${r("--spacing-m")};
  color: ${fa};
  max-width: ${aY}px;
  padding: ${r("--spacing-xxs")} ${r("--spacing-xs")};
  position: absolute;
  z-index: 2;
  ${qt}

  ${N} {
    margin-inline: ${r("--spacing-xl")};
    max-width: 100%;
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${uo} {
    margin-inline: ${r("--spacing-xl")};
    max-width: 100%;
  }
`,AB=c`
  &::before {
    /* Fallback for browsers without color-mix */
    background: linear-gradient(
      180deg,
      transparent 26.62%,
      ${r("--split-block-media-caption-gradient-color")} 100%
    );
    background: linear-gradient(
      180deg,
      color-mix(in srgb, ${r("--split-block-media-caption-gradient-color")} 0%, transparent) 26.62%,
      color-mix(in srgb, ${r("--split-block-media-caption-gradient-color")} 36%, transparent) 56.58%,
      color-mix(in srgb, ${r("--split-block-media-caption-gradient-color")} 45%, transparent) 71.27%,
      color-mix(in srgb, ${r("--split-block-media-caption-gradient-color")} 60%, transparent) 86.54%
    );
    content: '';
    inset: 0;
    pointer-events: none;
    position: absolute;
    z-index: 1;
  }
`,_B=c`
  display: flex;
  justify-content: center;
  position: relative;
  width: 50%;

  ${vo} {
    width: 40%;
  }

  ${N} {
    height: ${fB}px;
    width: 100%;
  }

  /*
  We are keeping the media queries above in addition to the container queries below in case:
  - this component is ever rendered without a wrapping SDS-M Page component
  - the browser does not support container queries (smart TVs, etc.)
  */
  ${ji} {
    width: 40%;
  }

  ${uo} {
    height: ${fB}px;
    width: 100%;
  }
`,Gh=c`
  inset: 0;
  /* Prevent overflowing elements from adding extra page width, e.g. background media stickers */
  overflow: hidden;
  position: absolute;
  z-index: 0;
`,zh=c`
  height: 100%;
  object-fit: cover;
  width: 100%;
`;var DB=e=>{Y("sdsm-split-block");let{anchorId:t,motifScheme:o,backgroundColor:n,body:a,callsToAction:s,fitWindow:l=!1,imageSources:p,imageAltText:d,mediaCaption:u,mediaContentType:y,mediaDirection:m=ie.End,mobileMediaContentType:g,mobileVideoSource:f,subtitle:b,textAlignment:S=ie.Start,textAlignmentMobile:C=ie.Center,title:v,verticalTextAlignment:k=ie.Center,videoSource:I,posterSource:A,stickers:D}=e,B=wB.Children.toArray(s).length,M=o??Pe(n)??"sdsm-secondary",_=D?.map(P=>({...P,size:sr.Medium,insetPx:16}));return x("article",{id:t,className:h("sdsm-split-block",M,SB,{[hB]:l,[Oh]:m===ie.Start}),children:[i("section",{className:h(CB,{[Oh]:m===ie.Start}),children:x("div",{className:h(xB,Ta[S],ar[C],NM[k]),children:[v&&i("h2",{className:vB,children:v}),b&&i("div",{className:IB,children:b}),a&&i("div",{className:kB,children:a}),B>0?i("section",{className:h(MB,Ta[S],ar[C]),children:s}):null]})}),(p||I)&&x("section",{className:h(_B,{[AB]:!!u}),children:[p&&i(Vn,{altText:d,imgSrcs:p,className:Gh,imgClassName:zh,fetchPriority:"auto",stickers:_}),I&&i(Qr,{className:Gh,videoClassName:zh,isBackgroundVideo:!0,mobileSource:f,mobileSourceType:g,source:I,sourceType:y,posterSource:A,stickers:_}),u&&i("div",{className:TB,children:u})]})]})};var RB=T(w());var PB=c`
  align-items: center;
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-l")};
  justify-content: center;
  text-align: center;
`,NB=c`
  color: ${r("--stats-stat-color")};
  font-family: ${r("--h1-font-family")};
  font-size: ${r("--stats-stat-font-size")};
  font-stretch: condensed;
  font-weight: ${r("--stats-stat-font-weight")};
  line-height: ${r("--stats-stat-font-line-height")};
  margin: 0;
`,EB=c`
  color: ${r("--stats-stat-color")};
  font-family: ${r("--h1-font-family")};
  font-size: ${r("--stats-stat-supplementary-text-font-size")};
  font-stretch: condensed;
  font-weight: ${r("--stats-stat-supplementary-text-font-weight")};
  line-height: ${r("--stats-stat-font-line-height")};
  margin: 0;
`;var Uh=({stat:e,optionalSupplementaryText:t,animation:o,style:n})=>{Y("stats");let a=(0,RB.useRef)(null),s=au(a,o);return x("figure",{ref:a,className:h("stats",PB),style:{...s,...n},children:[i("span",{className:NB,children:e}),t&&i("span",{className:EB,children:t})]})};Uh.displayName="Stats";var Wp=T(w());var FB=c`
  align-items: center;
  background-color: ${r("--bg-color")};
  box-shadow: ${r("--sub-navigation-box-shadow")};
  color: white;
  display: flex;
  height: 56px;
  justify-content: center;
  overflow: hidden;
  position: sticky;
  top: 125px;
  width: 100%;
  z-index: ${Ee.SUB_NAVIGATION};

  ${N} {
    justify-content: flex-start;
  }
`,BB=c`
  align-items: center;
  display: flex;
  height: 100%;
  -ms-overflow-style: none; /* Hide scrollbar for IE and Edge */
  overflow-x: scroll;
  overflow-y: hidden;
  scrollbar-width: none; /* Hide scrollbar for Firefox */

  &::-webkit-scrollbar {
    display: none; /* Hide scrollbar for Chrome and Safari */
  }
`,$B=c`
  align-items: center;
  display: flex;
  gap: ${r("--spacing-xl")};
  height: 100%;
  list-style: none;
  padding-inline: ${r("--spacing-xl")};
`,LB=c`
  align-items: center;
  display: flex;
  height: 100%;
`,Up=8,HB=c`
  align-items: center;
  color: ${r("--sub-navigation-item-color")};
  display: flex;
  font-size: ${r("--action-desktop-font-size")};
  font-weight: ${r("--action-desktop-font-weight")};
  height: 100%;
  line-height: ${r("--action-desktop-font-line-height")};
  position: relative;
  text-decoration: none;
  white-space: nowrap;

  ${N} {
    font-size: ${r("--action-mobile-font-size")};
    font-weight: ${r("--action-mobile-font-weight")};
    line-height: ${r("--action-mobile-font-line-height")};
  }

  @media (hover: hover) {
    &:hover {
      color: ${r("--sub-navigation-item-hover-color")};
    }

    &:hover::after {
      transform: translateY(-${Up/2}px);
    }
  }

  &::after {
    background-color: ${r("--sub-navigation-indicator-hover-color")};
    bottom: -${Up}px;
    content: '';
    height: ${Up}px;
    left: 0;
    position: absolute;
    border-radius: ${r("--action-indicator-border-radius")};
    transform: translateY(0);
    transition: all 0.15s ease;
    width: 100%;
  }

  @media (hover: hover) {
    &:hover {
      color: ${r("--sub-navigation-item-hover-color")};
    }

    &:hover::after {
      transform: translateY(-${Up/2}px);
    }
  }
`,VB=c`
  color: ${r("--sub-navigation-item-active-color")};

  &:hover {
    color: ${r("--sub-navigation-item-active-color")};
  }

  &::after {
    background-color: ${r("--sub-navigation-indicator-active-color")};
    transform: translateY(-${Up/2}px);
  }
`,OB=c`
  background: linear-gradient(to left, transparent 10%, ${r("--bg-color")} 100%);
  content: '';
  display: block;
  height: 100%;
  left: 0;
  pointer-events: none;
  position: absolute;
  width: 80px;
  z-index: 1;
`,GB=c`
  background: linear-gradient(to right, transparent 10%, ${r("--bg-color")} 100%);
  content: '';
  display: block;
  height: 100%;
  right: 0;
  pointer-events: none;
  position: absolute;
  width: 80px;
  z-index: 1;
`;var zB=({motifScheme:e,backgroundColor:t,className:o,children:n,horizontalScrollRef:a,dataset:s})=>{Y("sdsm-sub-navigation");let{width:l}=Sn(),[p,d]=(0,Wp.useState)(!1),[u,y]=(0,Wp.useState)(0);Br(()=>{d(!!a?.current?.closest('[dir="rtl"]'))},[a?.current,l]),(0,Wp.useEffect)(()=>{let S=a?.current;if(!S)return;let C=()=>{y(Math.ceil(a?.current?.scrollLeft??0))};return S.addEventListener("scroll",C,{passive:!1}),S.addEventListener("touchmove",C,{passive:!1}),()=>{S.removeEventListener("scroll",C),S.removeEventListener("touchmove",C)}},[a]);let m=0,g=0;a?.current?.parentElement&&(m=a.current.parentElement.scrollWidth,g=a.current.scrollWidth);let f=!1,b=!1;return p?(f=Math.ceil(-u)<g-m,b=u<0):(f=u>0,b=u<g-m),x("nav",{className:h("sdsm-sub-navigation",FB,e??Pe(t),o),...ne(s),children:[f&&i("div",{className:OB}),i("div",{ref:a,className:BB,children:i("ul",{className:$B,children:n})}),b&&i("div",{className:GB})]})};var zs=T(w());var Wh=({href:e,isActive:t,onLinkClick:o,className:n,children:a,dataset:s})=>{let{Anchor:l}=(0,zs.useContext)(He),p=(0,zs.useRef)(null);return(0,zs.useEffect)(()=>{t&&p.current?.scrollIntoView({behavior:"smooth",block:"nearest",inline:"center"})},[t]),i("li",{ref:p,className:h(LB,n),...ne(s),children:i(l,{className:h(HB,{[VB]:t}),href:e,onClick:o,children:a})})};Wh.displayName="SubNavigationItem";var Ho=T(w());var UB=c`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  width: 100%;

  & > div {
    margin: auto;
  }

  ${N} {
    margin-top: ${r("--spacing-m")};
  }
`,WB=c`
  display: flex;
  z-index: ${Ee.HERO_CURTAIN};
  background-color: ${r("--bg-color")};
  min-width: 80px;
  justify-content: center;
  align-items: center;
  padding: 0 0 0 0;
  margin: 0 0 0 0;
  flex-direction: row;
  [dir='rtl'] & {
    flex-direction: row-reverse;
  }
  ${N} {
    display: none;
  }
`,QB=c`
  cursor: pointer;
  z-index: ${Ee.CAROUSEL_ARROW};
  background-color: ${r("--bg-color")};
  border: none;

  :disabled {
    opacity: 50%;
  }
  ${N} {
    display: none;
  }
`,qB=c`
  background: linear-gradient(to left, transparent 10%, ${r("--bg-color")} 100%);
  content: '';
  display: block;
  height: calc(${r("--spacing-xxxxl")} + 1px);
  left: 0;
  pointer-events: none;
  position: absolute;
  width: 80px;
  z-index: ${Ee.CAROUSEL_SIDE_GRADIENT};

  [dir='rtl'] & {
    /*
    The height is 1px less on the left-side (RTL) on desktop so that this gradient does not cover the bottom border line.
    This is because there are arrow buttons on desktop so the gradient is not the farthest element to the right.
    */
    height: ${r("--spacing-xxxxl")};
    left: ${r("--spacing-xxxxl")};
  }

  ${N} {
    height: calc(${r("--spacing-xxxxl")} + 1px);
    left: 0;

    [dir='rtl'] & {
      height: calc(${r("--spacing-xxxxl")} + 1px);
      left: 0;
    }
  }
`,KB=c`
  background: linear-gradient(to right, transparent 10%, ${r("--bg-color")} 100%);
  content: '';
  display: block;
  /*
  The height is 1px less on the right-side on desktop so that this gradient does not cover the bottom border line.
  This is because there are arrow buttons on desktop so the gradient is not the farthest element to the right.
  */
  height: ${r("--spacing-xxxxl")};
  pointer-events: none;
  position: absolute;
  right: ${r("--spacing-xxxxl")};
  width: 80px;
  z-index: ${Ee.CAROUSEL_SIDE_GRADIENT};

  [dir='rtl'] & {
    height: calc(${r("--spacing-xxxxl")} + 1px);
    right: 0;
  }

  ${N} {
    height: calc(${r("--spacing-xxxxl")} + 1px);
    right: 0;

    [dir='rtl'] & {
      height: calc(${r("--spacing-xxxxl")} + 1px);
      right: 0;
    }
  }
`,jB=c`
  border-bottom: 1px ${r("--tabs-underline-color")} solid;
  display: flex;
  margin: 0 ${r("--spacing-xxxl")} 0 ${r("--spacing-xxxl")};
  max-width: 100%;
  padding-top: ${r("--spacing-xl")};
  position: relative;

  ${N} {
    /*
    The border is applied to a different element on mobile due to different visual requirements:
    - Desktop: continue border under arrow buttons
    - Mobile: border stops at end of last item
    */
    border-bottom: none;
    margin: 0 ${r("--spacing-xs")} 0 ${r("--spacing-xs")};
    padding: 0;
  }
`,YB=c`
  ${N} {
    margin-inline-end: calc(50% - 50vw);
    position: relative;
    max-width: unset;
  }
`,XB=c`
  display: flex;
  overflow: hidden;
  position: relative;
  scroll-behavior: smooth;
  width: 100%;
  z-index: ${Ee.BUTTON};

  ${N} {
    overflow-x: auto;
    padding-inline-start: 0;

    &::-webkit-scrollbar {
      display: none;
    }
  }
`,JB=c`
  padding-inline-end: ${r("--spacing-xl")};
`,ZB=c`
  align-items: center;
  display: flex;
  flex: 1;
  gap: ${r("--spacing-xl")};
  list-style: none;
  margin: 0;
  padding: 0;

  ${N} {
    border-bottom: 1px ${r("--tabs-underline-color")} solid;
    justify-content: start;
  }
`,e4=c`
  justify-content: center;
`,t4=c`
  justify-content: flex-start;
`,iY=c`
  &::after {
    bottom: 0px;
    content: '';
    position: absolute;
    transition: all 0.15s ease;
    visibility: hidden;
    width: 100%;
    text-align: left;
    margin-left: 0;
    height: 0px;
    border-top: 5px solid;
    border-radius: ${r("--action-indicator-border-radius")};
    margin-bottom: -5px;
    color: ${r("--tabs-item-color")};
  }

  &.active::after {
    visibility: visible;
    color: ${r("--tabs-indicator-active-color")};
  }

  &:hover::after {
    transform: translateY(${r("--tabs-indicator-transform-size")});
    visibility: visible;
    color: ${r("--tabs-indicator-hover-color")};
  }
`,sY=c`
  &::after {
    transform: translateY(${r("--tabs-indicator-transform-size")});
    visibility: visible;
    color: ${r("--tabs-indicator-active-color")};
  }
  &:hover::after {
    color: ${r("--tabs-indicator-active-color")};
  }
`,o4=c`
  align-items: center;
  cursor: pointer;
  color: ${r("--tabs-item-color")};
  display: flex;

  :hover {
    color: ${r("--tabs-item-hover-color")};
  }

  position: relative;
  text-decoration: none;
  justify-content: center;
  white-space: nowrap;
  user-select: none;

  ${N} {
    font-size: ${r("--action-mobile-font-size")};
    font-weight: ${r("--action-mobile-font-weight")};
  }

  ${H} {
    font-size: ${r("--action-desktop-font-size")};
    font-weight: ${r("--action-desktop-font-weight")};
  }

  line-height: ${r("--spacing-xxxxl")};

  ${iY}
`,n4=c`
  color: ${r("--tabs-item-active-color")};

  &:hover {
    color: ${r("--tabs-item-active-color")};
  }

  ${sY}
`,ewe=c`
  z-index: ${Ee.NAVIGATOR_BUTTON};
  width: 100%;
  ${N} {
    width: calc(100% - ${r("--spacing-xl")}px);
  }
  height: 16px;
  position: relative;
  margin-top: -${r("--spacing-xs")};
  background-color: ${r("--bg-color")};
`;var Qh=({direction:e,onClick:t,isDisabled:o})=>i("button",{disabled:o,className:QB,onClick:t,children:i(De,{name:e==="Left"?"chevron-left":"chevron-right",size:22})});var Fy=({items:e,className:t,selectTab:o,selectedTab:n})=>{Y("sdsm-tab");let a=(0,Ho.useRef)(null),s=(0,Ho.useRef)(null),l=(0,Ho.useRef)(null),[p,d]=(0,Ho.useState)(!1),[u,y]=(0,Ho.useState)(0),[m,g]=(0,Ho.useState)(!1),{width:f}=Sn(),b=(0,Ho.useCallback)(R=>{if(s.current){let L=s.current.children[R];L&&L.scrollIntoView({behavior:"smooth",block:"nearest",inline:"center"})}},[]),S=(0,Ho.useCallback)(R=>{if(a.current){let L=u+R;a.current.scrollLeft=L}},[u]),C=0,v=0;l.current&&a.current?.parentElement&&(C=a.current.parentElement.scrollWidth-l.current.scrollWidth,v=a.current.scrollWidth);let k=(0,Ho.useCallback)(R=>{p?(R==="Left"&&-u+C<v&&S(Math.min(-C,-u)),R==="Right"&&u<0&&S(Math.max(C,u))):(R==="Left"&&u>0&&S(Math.max(-C,-u)),R==="Right"&&u+C<v&&S(Math.min(C,v-(u+C))))},[p,C,S,u,v]);Br(()=>{let R=0,L=0,G=0;d(!!a?.current?.closest('[dir="rtl"]')),a.current?.parentElement&&(R=a.current.parentElement.scrollWidth,L=a.current.scrollWidth),l.current&&(G=l.current.scrollWidth);let Z=R-G;L>Z?g(!0):g(!1)},[f,e]);let A=Yo()===lt.Mobile,[D,B]=(0,Ho.useState)(0);(0,Ho.useEffect)(()=>{let R=a?.current;if(!R)return;let L=()=>{B(Math.ceil(a?.current?.scrollLeft??0))},G=()=>{B(Math.ceil(a?.current?.scrollLeft??0)),y(Math.ceil(a?.current?.scrollLeft??0))};return R.addEventListener("touchmove",L,{passive:!1}),R.addEventListener("scroll",G,{passive:!1}),()=>{R.removeEventListener("touchmove",L),R.removeEventListener("scroll",G)}},[a]);let M=!1,_=!1;p?(M=u<=-v+C,_=u===0):(M=u===0,_=u>=v-C);let P=!1,$=!1;return p?A?(P=Math.ceil(-D)<v-C,$=D<0):(P=-u<=v-C,$=u<0):A?(P=D>0,$=D<v-C):(P=u>0,$=u<v-C),x("nav",{className:h("sdsm-tabs-item",jB,{[YB]:A&&m}),children:[P&&m&&i("div",{className:qB}),i("div",{ref:a,className:h(XB,{[JB]:A&&m}),children:i("ul",{ref:s,className:h(ZB,{[t4]:m,[e4]:!m}),role:"tablist",children:e?.map((R,L)=>{let G=n===L;return i("li",{role:"tab",tabIndex:0,"aria-current":G,id:`tab-${L}`,className:h(o4,{[n4]:G},t),onClick:()=>{o(L),b(L)},onKeyUp:()=>{o(L),b(L)},children:R.text},`tabItem-${L}`)})})}),$&&m&&i("div",{className:KB}),m&&x("div",{ref:l,className:WB,children:[i(Qh,{direction:"Left",onClick:()=>{k("Left")},isDisabled:M}),i(Qh,{direction:"Right",onClick:()=>{k("Right")},isDisabled:_})]})]})};var Us=T(w());var lY={1:vu,2:Iu,3:ku},r4=({items:e,selectedTab:t})=>i("div",{className:UB,children:e.map((o,n)=>i("div",{role:"tabpanel",className:h(xu,lY[o.maxColumns??3]),style:t!==n?{display:"none"}:void 0,children:o.content.map(a=>a)},`tabPanel-${n}`))});var a4=({items:e,defaultSelectedTab:t=0,onSelectTab:o})=>{let[n,a]=(0,Us.useState)(t),s=(0,Us.useRef)([]);Y("sdsm-tab");let l=(0,Us.useCallback)(p=>{a(p),o?.(p),s.current.forEach(d=>d?.())},[a,o]);return!e||e.length<2?null:i(ds.Provider,{value:{addOnTabChangeListener(p){s.current.push(p)},removeOnTabChangeListener(p){s.current=s.current.filter(d=>d!==p)}},children:x("div",{className:"sdsm-tab","data-testid":"sdsm-tabs",children:[i(Fy,{items:e,selectTab:l,selectedTab:n}),i(r4,{items:e,selectedTab:n})]})})};var fr={Small:"Small",Medium:"Medium",Large:"Large"},Un={Contain:"Contain",Cover:"Cover"};var Qp=29,$y=Qp+12,Ly=28,pY=284,i4=260,s4=461,Hy=419,By=pY,qh=12+s4+$y+4*Ly,qp={[fr.Small]:Math.floor(By/2),[fr.Medium]:By,[fr.Large]:s4},Kp=Uf(qp,e=>qh-e-$y),Dwe=Uf(Kp,e=>Math.floor(e/Ly)),Pwe=32;var Vy=T(w());var l4=c`
  text-decoration: none;
`,p4=c`
  display: flex;
  flex-direction: column;
  width: ${By}px;
  height: ${qh}px;
  border-radius: ${r("--spacing-xxs")};
  box-shadow: ${r("--box-shadow-m")};
  background-color: ${r("--tile-bg-color")};

  *[dir='rtl'] & {
    text-align: right;
  }

  &:hover {
    box-shadow: ${r("--box-shadow-l")};
  }
`,c4=({imageSource:e,imageHeight:t,imageFit:o,imagePadding:n})=>c`
    background-position: center;
    background-repeat: no-repeat;
    background-image: url(${e});
    height: ${n?t-12:t}px;
    margin-top: ${n?12:0}px;
    margin-left: ${n?24:0}px;
    margin-right: ${n?24:0}px;
    background-size: ${o===Un.Cover?"cover":"contain"};
    border-radius: ${n?4:0}px;
    /* do the top corners of the image no matter what */
    border-top-left-radius: ${r("--spacing-xxs")};
    border-top-right-radius: ${r("--spacing-xxs")};
  `,d4=c`
  font-size: 18px;
  line-height: ${Qp}px;
  font-weight: normal;
  margin-bottom: ${r("--spacing-s")};
`,u4=c`
  padding-left: ${r("--spacing-l")};
  padding-right: ${r("--spacing-l")};
  padding-top: ${r("--spacing-s")};
  padding-bottom: ${r("--spacing-s")};
  color: ${r("--tile-fg-color")};
  display: flex;
  flex-direction: column;
  flex-grow: 1;
`,y4=c`
  ${yo}

  /* stylelint-disable-next-line value-no-vendor-prefix */
  display: -webkit-box;
  -webkit-box-orient: vertical;

  text-overflow: ellipsis;
  overflow: hidden;
`,m4=({imageSource:e,imageHeight:t,imageFit:o,imagePadding:n})=>c`
    background-position: center;
    background-repeat: no-repeat;
    background-image: url(${e});
    height: ${t}px;
    margin-top: 0;
    margin-left: ${n?12:0}px;
    margin-right: ${n?12:0}px;
    background-size: ${o===Un.Cover?"cover":"contain"}px;
    border-radius: ${r("--spacing-xs")};
    box-shadow: ${r("--box-shadow-l")};
    /* For node > picture > img */
    img {
      border-radius: ${r("--spacing-xs")};
    }
  `,g4=({imageHeight:e,imageFit:t,imagePadding:o})=>c`
    height: ${e}px;
    margin-top: 0;
    margin-left: ${o?12:0};
    margin-right: ${o?12:0};
    background-size: ${t===Un.Cover?"cover":"contain"};
    border-radius: ${r("--spacing-xs")};
    box-shadow: ${r("--box-shadow-l")};

    > div {
      margin: 0;
    }

    video {
      height: ${e}px;
      width: 100%;
    }

    ${N} {
      video {
        width: ${i4}px;
      }
    }
  `,f4=c`
  display: flex;
  flex-direction: column;
  border-radius: ${r("--spacing-xxs")};
  background-color: transparent;
  align-items: center;
`,b4=c`
  width: 56px;
  height: 56px;
  margin: 16px auto 0 auto;
`,S4=c`
  /* Note: Not using --tile-fg-color here because it has no background. */
  color: ${r("--fg-color")};
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  align-items: center;
  margin-top: 16px;
`,h4=c`
  ${yo}
  text-align: center;
  padding-left: ${r("--spacing-s")};
  padding-right: ${r("--spacing-s")};
`,C4=c`
  ${ut}
  text-align: center;
  padding-left: ${r("--spacing-s")};
  padding-right: ${r("--spacing-s")};
`,Kh=c`
  width: 100%;
  height: 100%;
  object-position: center;
`,jh=c`
  object-fit: cover;
`,Yh=c`
  object-fit: contain;
`,Xh=c`
  background-image: none;
`,x4=c`
  cursor: pointer;
`;var Jh=({imageSize:e,label:t})=>{let o=Kp[e];return t?o:o+$y},v4=({imageSize:e,label:t})=>{let o=Jh({imageSize:e,label:t});return Math.floor(o/Ly)};var Zh=({className:e,title:t,imageSource:o,videoSource:n,iconImageSource:a,label:s,onClick:l,imageSize:p=fr.Large,imageFit:d=Un.Cover,imagePadding:u=!1,link:y,tilesLayout:m,isRTL:g,iconImgSrcs:f,iconAltText:b,imgSrcs:S,imgAltText:C})=>{Y("sdsm-tile");let{Anchor:v}=(0,Vy.useContext)(He),k=g?"rtl":void 0,I=(0,Vy.useCallback)($=>{y&&l&&l(y,$)},[y,l]),A=qp[p],D=c4({imageSource:o,imageFit:d,imageHeight:A,imagePadding:u}),B=m4({imageSource:o,imageFit:d,imageHeight:Hy,imagePadding:u}),M=g4({imageFit:d,imageHeight:Hy,imagePadding:u}),_=x("div",{"data-testid":"sdsm-tile-default-inner",className:h("sdsm-tile",{[x4]:!!l},p4,e),onClick:y?void 0:I,dir:k,children:[(o||S)&&i("div",{"data-testid":"sdsm-tile-image",className:h(D,S?Xh:void 0),children:S&&i(et,{altText:C,imgSrcs:S,imgClassName:h(Kh,d===Un.Cover?jh:Yh)})}),(t||s)&&x("div",{"data-testid":"sdsm-tile-text",className:h(u4,c`
              height: ${Kp[p]+Qp}px;
            `),children:[s&&i("div",{className:d4,children:s}),i("div",{className:y4,style:{WebkitLineClamp:v4({imageSize:p,label:s}),maxHeight:Jh({imageSize:p,label:s})},children:t})]})]}),P=x("div",{"data-testid":"sdsm-tile-alternate-inner",className:h("sdsm-tile",f4,e),onClick:y?void 0:I,dir:k,children:[(o||S)&&i("div",{"data-testid":"sdsm-tile-alternate-image",className:h(B,S?Xh:void 0),children:S&&i(et,{altText:C,imgSrcs:S,imgClassName:h(Kh,d===Un.Cover?jh:Yh)})}),!o&&n&&i("div",{"data-testid":"sdsm-tile-alternate-video",className:M,children:i(Ke,{showVideoControls:!1,videoSource:n,maxHeight:Hy,isBackgroundVideo:!0})}),(a||f)&&i(et,{altText:b,imgSrcs:f,imgClassName:b4,defaultSrc:a}),(t||s)&&x("div",{"data-testid":"sdsm-tile-alternate-text",className:S4,children:[t&&i("div",{className:h4,children:t}),s&&i("div",{className:C4,children:s})]})]});return y?i(v,{"data-testid":"sdsm-tile-click-handler",href:y,className:l4,onClick:I,children:m?P:_}):m?P:_};Zh.displayName="Tile";var eC=c`
  align-items: center;
  background-color: ${r("--topic-bg-color")};
  border: ${r("--topic-border-width")} solid ${r("--topic-border-color")};
  border-radius: ${r("--topic-border-radius")};
  color: ${r("--fg-color")};
  display: flex;
  font-family: ${r("--font-family")};
  font-size: ${r("--topic-font-size")};
  font-weight: ${r("--topic-font-weight")};
  justify-content: center;
  line-height: ${r("--topic-font-line-height")};
  padding: ${r("--topic-padding")};
  text-align: center;
  text-decoration: none;
  text-transform: capitalize;
  white-space: nowrap;
`,I4=c`
  transition: background-color 0.2s linear;

  &:hover {
    background-color: ${r("--topic-hover-bg-color")};
  }
`;var k4=e=>{Y("sdsm-topic");let{displayText:t,url:o}=e;return t?o?i(Jk,{className:h("sdsm-topic",eC,I4),href:o,"data-testid":"sdsm-topic",children:t}):i("span",{className:h("sdsm-topic",eC),"data-testid":"sdsm-topic",children:t}):null};var M4=c`
  background-color: ${fa};
  border-radius: ${r("--border-radius-xl")};
  display: flex;
  justify-content: center;
  padding: 20px;

  ${bn} {
    padding: ${r("--spacing-xxl")};
  }
`,T4=c`
  background-color: ${r("--chart-skeleton-bg-color")};
  border-radius: ${r("--border-radius-xl")};
  overflow: hidden;
  position: relative;
  width: 100%;

  ${bn} {
    margin: 0px 112px;
  }
`,A4=c`
  height: 100%;
  width: 100%;
`,_4=c`
  fill: url('#shimmerGradient');
  mask: url('#shimmerMask');
`,Wn=c`
  fill: ${r("--chart-skeleton-mask-color")};
`,tC=c`
  stop-color: ${r("--chart-skeleton-dark-animation-color")};
`,w4=c`
  stop-color: ${r("--chart-skeleton-light-animation-color")};
`;var D4="2s",_o=()=>(Y("sdsm-skeleton-chart"),i("article",{className:h("sdsm-skeleton-chart",M4),children:i("div",{className:T4,children:x("svg",{viewBox:"0 0 664 328",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:A4,children:[x("defs",{children:[x("linearGradient",{id:"shimmerGradient",x1:"0",y1:"0",x2:"1",y2:"0",children:[i("stop",{className:tC,offset:"0%",strokeOpacity:1}),i("stop",{className:w4,offset:"50%",strokeOpacity:1}),i("stop",{className:tC,offset:"100%",strokeOpacity:1}),i("animate",{attributeName:"x1",values:"-100%;100%",dur:D4,repeatCount:"indefinite"}),i("animate",{attributeName:"x2",values:"0%;200%",dur:D4,repeatCount:"indefinite"})]}),x("mask",{id:"shimmerMask",children:[i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"31.4118",x:"36.955",y:"60.0518"}),i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"31.4118",x:"36.955",y:"113.944"}),i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"31.4118",x:"36.955",y:"167.838"}),i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"31.4118",x:"36.955",y:"221.73"}),i("path",{className:Wn,clipRule:"evenodd",d:`M609.376 62.2274C613.179 65.7331 613.232 71.466 609.493 75.0322L484.305 194.434C479.871 198.663
                472.912 199.467 467.516 196.374L472.552 188.649L467.516 196.374L347.249 127.445L229.404 229.841C225.443
                233.282 219.686 234.2 214.734 232.18L218.588 223.877L214.734 232.18L98.1939 184.629C93.3034 182.634
                91.0641 177.299 93.1923 172.714C95.3205 168.128 101.01 166.029 105.901 168.024L219.015 214.177L337.294
                111.404C341.761 107.523 348.434 106.899 353.63 109.877L348.593 117.603L353.63 109.877L473.715
                178.703L595.719 62.3369C599.458 58.7707 605.573 58.7217 609.376 62.2274ZM470.541 181.73C470.538
                181.733 470.535 181.736 470.532 181.739L474.608 185.495L470.532 181.739L470.541 181.73Z`,fillRule:"evenodd"}),i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"36.955",x:"77.6056",y:"265.152"}),i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"36.955",x:"205.727",y:"265.152"}),i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"36.955",x:"333.848",y:"265.152"}),i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"36.955",x:"461.969",y:"265.152"}),i("rect",{className:Wn,height:"11.0865",rx:"5.54325",width:"36.955",x:"590.09",y:"265.152"})]})]}),i("rect",{x:"0",y:"0",width:"100%",height:"100%",className:_4})]})})}));var Oy=T(w());var P4=({children:e,active:t,onClick:o})=>{let n=h(LD,t&&xS);return i("button",{role:"tab",onClick:o,className:n,children:e})};var N4=({items:e,selectedChart:t,selectChart:o})=>{let n=s=>{t!==s&&o(s)},a=h(FD,SS);return i("div",{className:a,children:i("nav",{className:BD,role:"tablist",children:e.map(({title:s},l)=>i(P4,{active:t===l,onClick:()=>n(l),children:s},`chart-button-${l}`))})})};var E4=({items:e,selectedChart:t})=>i("div",{className:$D,role:"tabpanel",children:e.map(({content:o},n)=>t===n&&i("div",{className:HD,children:o},n))});var R4=({items:e})=>{let[t,o]=(0,Oy.useState)(0);return Y("sdsm-chart-toggle"),(0,Oy.useEffect)(()=>{let{onToggle:n}=e[t];n?.()},[e,t]),e?.length?x("section",{className:"sdsm-chart-toggle",children:[i(N4,{items:e,selectedChart:t,selectChart:o}),i(E4,{items:e,selectedChart:t})]}):null};var F4=({items:e,selectedChart:t})=>i(pe,{children:e.map(({content:o},n)=>t===n.toString()&&o)});var Gy=T(w());var B4=({label:e,items:t,selectedChart:o,selectChart:n})=>{let a=l=>{o!==l.id&&n(l.id)},s=t.map((l,p)=>({id:p.toString(),title:l.title,isSelected:p.toString()===o}));return x("div",{className:h(hS,OD,{[GD]:!e}),children:[e&&i("label",{children:e}),i(es,{items:s,selectedItemId:o,onItemSelect:a})]})};var $4=({items:e,label:t,isLoading:o})=>{let[n,a]=(0,Gy.useState)("0");return Y("sdsm-chart-toggle"),(0,Gy.useEffect)(()=>{if(!e?.length)return;let{onToggle:s}=e[Number(n)];s?.()},[e,n]),o?i(KD,{}):e?.length?x(pe,{children:[i(B4,{label:t,items:e,selectedChart:n,selectChart:a}),i(F4,{items:e,selectedChart:n})]}):null};var L4=({children:e})=>i("section",{className:h("sdsm-chart-toggle",VD),children:e});var H4=T(Hr());var zy=({document:e})=>typeof e=="string"?i(pe,{children:e}):i(pe,{children:(0,H4.documentToPlainTextString)(e)});zy.displayName="PlainRichText";function cY(e){return e&&e.length?e[0]:void 0}var br=cY;function dY(e){return e===void 0}var oC=dY;OI();function uY(e,t,o,n){if(!ql(e))return e;t=ts(t,e);for(var a=-1,s=t.length,l=s-1,p=e;p!=null&&++a<s;){var d=xa(t[a]),u=o;if(d==="__proto__"||d==="constructor"||d==="prototype")return e;if(a!=l){var y=p[d];u=n?n(y,d,p):void 0,u===void 0&&(u=ql(y)?y:sd(t[a+1])?[]:{})}GI(p,d,u),p=p[d]}return e}var V4=uY;function yY(e,t,o){for(var n=-1,a=t.length,s={};++n<a;){var l=t[n],p=os(e,l);o(p,l)&&V4(s,ts(l,e),p)}return s}var Uy=yY;function mY(e,t){if(e==null)return{};var o=gd(YI(e),function(n){return[n]});return t=Jo(t),Uy(e,o,function(n,a){return t(n,a[0])})}var O4=mY;var Gt=T(w());var G4=T(w()),Sr=(0,G4.createContext)({isPreview:!1,isSSR:!1,currentLocale:"en-US"});var z4=T(w());var jp=({component:e})=>(console.error(`${e} not implemented! This must be specified via DesignSystemContext.`),null),Mn=(0,z4.createContext)({buttonComponent:()=>i(jp,{component:"buttonComponent"}),localeDropdownComponent:()=>i(jp,{component:"localeDropdownComponent"}),modalComponent:()=>i(jp,{component:"modalComponent"}),sectionComponent:()=>i(jp,{component:"sectionComponent"}),toggleComponent:()=>i(jp,{component:"toggleComponent"})});var Wy={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"CookieModalQuery"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"preview"}},type:{kind:"NonNullType",type:{kind:"NamedType",name:{kind:"Name",value:"Boolean"}}}},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"locale"}},type:{kind:"NonNullType",type:{kind:"NamedType",name:{kind:"Name",value:"String"}}}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"cookieModalCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"preview"},value:{kind:"Variable",name:{kind:"Name",value:"preview"}}},{kind:"Argument",name:{kind:"Name",value:"locale"},value:{kind:"Variable",name:{kind:"Name",value:"locale"}}},{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"1"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"CookieModalAll"}}]}}]}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"TrackingCookieAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"TrackingCookie"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"name"}},{kind:"Field",name:{kind:"Name",value:"provider"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"json"}}]}},{kind:"Field",name:{kind:"Name",value:"domains"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"json"}}]}},{kind:"Field",name:{kind:"Name",value:"purpose"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"json"}}]}},{kind:"Field",name:{kind:"Name",value:"expiration"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"json"}}]}},{kind:"Field",name:{kind:"Name",value:"pattern"}},{kind:"Field",name:{kind:"Name",value:"subDomains"}},{kind:"Field",name:{kind:"Name",value:"path"}},{kind:"Field",name:{kind:"Name",value:"secure"}},{kind:"Field",name:{kind:"Name",value:"sameSite"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"CookieCategoryAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"CookieCategory"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"description"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"json"}}]}},{kind:"Field",name:{kind:"Name",value:"categoryCookieName"}},{kind:"Field",name:{kind:"Name",value:"displayMode"}},{kind:"Field",name:{kind:"Name",value:"isEssential"}},{kind:"Field",name:{kind:"Name",value:"enableToggle"}},{kind:"Field",name:{kind:"Name",value:"cookiesCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"200"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"TrackingCookieAll"}}]}}]}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"CookieModalAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"CookieModal"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"landingScreenTitle"}},{kind:"Field",name:{kind:"Name",value:"content"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"json"}}]}},{kind:"Field",name:{kind:"Name",value:"acceptAllButtonText"}},{kind:"Field",name:{kind:"Name",value:"essentialOnlyButtonText"}},{kind:"Field",name:{kind:"Name",value:"settingsButtonText"}},{kind:"Field",name:{kind:"Name",value:"settingsScreenTitle"}},{kind:"Field",name:{kind:"Name",value:"cookieCategoriesCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"10"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"CookieCategoryAll"}}]}}]}},{kind:"Field",name:{kind:"Name",value:"acceptSelectedButtonText"}},{kind:"Field",name:{kind:"Name",value:"saveChangesText"}},{kind:"Field",name:{kind:"Name",value:"changesSavedText"}},{kind:"Field",name:{kind:"Name",value:"toggleEnabledText"}},{kind:"Field",name:{kind:"Name",value:"toggleDisabledText"}},{kind:"Field",name:{kind:"Name",value:"gpcLocations"}},{kind:"Field",name:{kind:"Name",value:"enableCookieDeletion"}}]}}]};var nC=new Set(["localhost","sc-corp.net","appspot.com"]),za=class{constructor(t,o){Ae(this,"client");Ae(this,"initializeClient",(t,o)=>{let n=new Ad,a=this.getGrapheneFlavor(o),s=this.getGrapheneFriendlyString(o),l=y0({partitionName:t,flavor:a,variant:s});return n.initialize({networkHandler:new Td(l),debugMode:!1,logTimeInterval:5e3}),n});Ae(this,"getGrapheneFlavor",t=>{let o=va(t);return nC.has(o)?"development":"production"});Ae(this,"getGrapheneFriendlyString",t=>{if(!t)return"Unknown";let o=/[\s.]+/g;return t.replace(o,"_")});Ae(this,"logMetric",(t,o)=>{this.client.increment({metricsName:t,dimensions:o})});Ae(this,"logError",(t,o,n)=>{let a={description:this.getGrapheneFriendlyString(o),error:this.getGrapheneFriendlyString(n.name)};this.client.increment({metricsName:`error_${t}`,dimensions:a})});this.client=this.initializeClient(t,o)}};var Qy=e=>{let t={};for(let o of e){let{categoryCookieName:n}=o;t[n]=!0}return t},Yp=e=>{let t={};for(let o of e){let{categoryCookieName:n,isEssential:a}=o;t[n]=a}return t},qy=(e,t)=>({...Yp(e),...t});var U4=e=>{let t=ro.get(),o=new Set,n=[];for(let[s,l]of e)for(let{name:p,regex:d}of l)d?n.push(d):o.add(p);let a=[];for(let s in t)o.has(s)||n.some(l=>l.test(s))||a.push(s);return a};var gY=(e,t)=>{let{sys:o,name:n,pattern:a,subDomains:s,path:l,secure:p,sameSite:d}=t,u={id:o.id,name:n};return a&&(u.regex=new RegExp(a)),s?.includes(e)&&(u.domain=""),l&&(u.path=l),p&&(u.secure=!0),d&&(u.sameSite=d),u},Ky=e=>{let t=new Map,o=(window?.location?.hostname??"").toLowerCase();for(let n of e){let a=new Set,s=n.categoryCookieName;for(let l of n.cookiesCollection.items){let p=gY(o,l);a.add(p)}t.set(s,a)}return t};var fY="https://www.snapchat.com/cookies/api/is_cookie_popup_eligible",W4=async()=>{let e=await fetch(fY);if(e.status!==200){let{status:o,statusText:n}=e;throw new Error(`${o} : ${n}`)}return(await e.json()).popupEnabled};var bY="https://www.snapchat.com/cookies/api/user_location",jy=async()=>{let e=await fetch(bY);if(e.status!==200){let{status:a,statusText:s}=e;throw new Error(`${a} : ${s}`)}let t=await e.json(),o=t.country,n=t.region;return`${o}-${n}`};var SY=e=>ro.get(e),Yy=e=>{let t={};for(let o of e){let{categoryCookieName:n}=o,a=SY(n);a&&(t[n]=a==="true")}return t};var Xy=e=>{let t=e||(window?.location?.hostname??"").toLowerCase();return va(t)};var hY=(e,t,o,n)=>{let a={domain:e.domain??t,path:e.path,secure:e.secure,sameSite:e.sameSite};if(e.regex)for(let s of Object.keys(o))e.regex.test(s)&&(ro.remove(s,a),n[s]={value:o[s]??""});else e.name in o&&(ro.remove(e.name,a),n[e.name]={value:o[e.name]??""})},CY=(e,t,o,n,a)=>{if(t==="sc-cookies-accepted")return;let s=n.get(t);if(s)for(let l of s)hY(l,e,o,a)},Zy=(e,t,o,n=!1)=>{let a=ro.get(),s={};for(let p in t)t[p]||n&&CY(e,p,a,o,s);let l=ro.get();for(let p in s)s[p].wasRemoved=!l[p];return s};var xY=(e,t,o="")=>{ro.set(e,t,{expires:365,secure:!0,domain:o})},em=(e,t)=>{for(let o in t)xY(o,t[o].toString(),e)};var Q4=T(w());var hr=e=>{let{buttonComponent:t}=(0,Q4.useContext)(Mn);return t(e)};var q4=T(w());var K4=e=>{let{localeDropdownComponent:t}=(0,q4.useContext)(Mn);return t(e)};var j4=T(w());var Y4=e=>{let{modalComponent:t}=(0,j4.useContext)(Mn);return t(e)};var X4=T(w());var J4=e=>{let{sectionComponent:t}=(0,X4.useContext)(Mn);return t(e)};var Z4=T(w());var e$=e=>{let{toggleComponent:t}=(0,Z4.useContext)(Mn);return t(e)};var t$=T(w());var rC=class extends t$.Component{constructor(t){super(t);let{partition:o,hostname:n}=t,a=o&&new za(o,n);this.state={hasError:!1,grapheneClient:a}}componentDidCatch(t){this.setState({hasError:!0}),this.state.grapheneClient?.logError(this.props.component,"unhandled",t),this.props.onError&&this.props.onError(t)}render(){let{children:t,renderInstead:o}=this.props,{hasError:n}=this.state;return n?o??null:t}};function tm(e,t,o){let n=e.displayName??"UnknownComponent";return s=>{let l=(window?.location?.hostname??"unknown").toLowerCase(),{onError:p}=s;return i(rC,{hostname:l,partition:t,component:n,onError:p,renderInstead:o,children:i(e,{...s})})}}var y$=T(sC());var m$=T(w());var nm=({document:e,className:t})=>{let{currentLocale:o}=(0,m$.useContext)(Sr),n=a=>{let s=new URL(a);return s.searchParams.has("lang")||s.searchParams.set("lang",o),s.href};return i("div",{"data-testid":"mwp-cookie-rich-text",className:h("contentful-rich-text",t),dangerouslySetInnerHTML:{__html:(0,y$.documentToHtmlString)(e,{renderNode:{hyperlink:a=>{let s=a.content.map(p=>{if(!(!p||p.nodeType!=="text"))return p.value},[]).join("");return`<a href="${n(a.data.uri)}" target="_blank" rel="noopener">${s}</a>`}}})}})};var rm=({children:e})=>i("div",{className:"modal-footer",children:e});var am=T(w());var g$=({className:e,width:t,height:o,backgroundType:n="White"})=>{let a=n!=="Black"?"#FFFFFF":void 0,s=n==="Black"?"#FFFFFF":void 0;return i("svg",{version:"1.1",xmlns:"http://www.w3.org/2000/svg",x:"0px",y:"0px",viewBox:"0 0 500 500",className:e,width:t,height:o,children:i("g",{id:"Layer_1",children:x("g",{children:[i("g",{children:i("path",{style:{fill:a},d:`M484.6,369.3c-2-6.8-11.9-11.6-11.9-11.6l0,0c-0.9-0.5-1.7-0.9-2.4-1.3c-16.4-7.9-30.8-17.4-43.1-28.2
                c-9.8-8.7-18.2-18.2-25-28.4c-8.2-12.4-12.1-22.8-13.8-28.4c-0.9-3.7-0.8-5.1,0-7c0.6-1.6,2.5-3.1,3.4-3.8
                c5.5-3.9,14.4-9.7,19.9-13.2c4.7-3.1,8.8-5.7,11.2-7.4c7.7-5.4,12.9-10.8,16-16.7c4-7.6,4.5-16,1.4-24.3
                c-4.2-11.1-14.6-17.8-27.8-17.8c-2.9,0-6,0.3-9,1c-7.6,1.6-14.8,4.3-20.8,6.7c-0.4,0.2-0.9-0.2-0.9-0.6
                c0.6-14.9,1.3-34.9-0.3-53.9c-1.5-17.2-5-31.7-10.8-44.3c-5.8-12.7-13.4-22.1-19.3-28.9c-5.7-6.5-15.5-16-30.5-24.5
                c-21-12-45-18.1-71.1-18.1c-26.1,0-50,6.1-71.1,18.1c-15.8,9-25.9,19.2-30.5,24.5c-5.9,6.8-13.5,16.2-19.3,28.9
                c-5.8,12.6-9.3,27.1-10.8,44.3c-1.6,19.1-1,37.5-0.3,53.9c0,0.5-0.5,0.8-0.9,0.6c-6-2.3-13.2-5-20.7-6.7c-3-0.7-6-1-9-1
                c-13.2,0-23.6,6.7-27.8,17.8c-3.1,8.3-2.7,16.7,1.4,24.3c3.1,5.9,8.4,11.4,16,16.7c2.4,1.7,6.4,4.3,11.2,7.4
                c5.3,3.5,14,9.1,19.5,13c0.7,0.5,3,2.3,3.8,4.1c0.8,2,0.9,3.4-0.1,7.3c-1.7,5.7-5.6,15.9-13.7,28.1c-6.8,10.2-15.2,19.7-25,28.4
                C60.5,339,46,348.5,29.7,356.5c-0.8,0.4-1.7,0.8-2.7,1.4l0,0c0,0-9.8,5-11.6,11.4c-2.7,9.5,4.5,18.4,11.9,23.2
                c12.1,7.8,26.9,12,35.4,14.3c2.4,0.6,4.5,1.2,6.5,1.8c1.2,0.4,4.3,1.6,5.6,3.3c1.7,2.1,1.9,4.8,2.5,7.8v0c0.9,5,3,11.2,9.2,15.5
                c6.8,4.7,15.5,5,26.4,5.5c11.5,0.4,25.8,1,42.1,6.4c7.6,2.5,14.4,6.7,22.4,11.6c16.6,10.2,37.2,22.9,72.5,22.9
                c35.3,0,56.1-12.8,72.8-23c7.9-4.8,14.7-9,22.1-11.5c16.3-5.4,30.6-5.9,42.1-6.4c11-0.4,19.6-0.7,26.4-5.5
                c6.6-4.6,8.6-11.4,9.4-16.6c0.5-2.5,0.8-4.8,2.3-6.7c1.2-1.6,4.1-2.7,5.4-3.2c2-0.6,4.2-1.2,6.7-1.9c8.6-2.3,19.3-5,32.3-12.4
                C485.2,385.6,486.3,374.7,484.6,369.3z`})}),i("path",{style:{fill:s},d:`M498.2,364c-3.5-9.5-10.1-14.5-17.6-18.7c-1.4-0.8-2.7-1.5-3.8-2c-2.2-1.2-4.5-2.3-6.8-3.5
              c-23.5-12.5-41.8-28.2-54.6-46.8c-4.3-6.3-7.3-12-9.4-16.6c-1.1-3.1-1-4.9-0.3-6.5c0.6-1.2,2.2-2.5,3-3.1c4-2.7,8.2-5.4,11-7.2
              c5-3.3,9-5.8,11.6-7.6c9.6-6.7,16.4-13.9,20.6-21.9c5.9-11.3,6.7-24.2,2.1-36.3c-6.4-16.8-22.3-27.3-41.5-27.3
              c-4,0-8,0.4-12.1,1.3c-1.1,0.2-2.1,0.5-3.1,0.7c0.2-11.4-0.1-23.6-1.1-35.6c-3.6-42-18.3-64-33.7-81.6c-6.4-7.3-17.5-18-34.2-27.6
              C305.1,10.6,278.8,3.9,250,3.9c-28.7,0-55,6.7-78.3,20c-16.8,9.6-27.9,20.3-34.3,27.6c-15.3,17.5-30,39.6-33.7,81.6
              c-1,11.9-1.3,24.1-1.1,35.6c-1-0.3-2.1-0.5-3.1-0.7c-4-0.9-8.1-1.3-12.1-1.3c-19.3,0-35.2,10.4-41.5,27.3
              c-4.6,12.1-3.8,25,2.1,36.3c4.2,8,11,15.2,20.6,21.9c2.6,1.8,6.6,4.4,11.6,7.6c2.7,1.8,6.7,4.3,10.6,6.9c0.6,0.4,2.7,1.9,3.4,3.4
              c0.8,1.7,0.8,3.5-0.4,6.8c-2.1,4.6-5,10.1-9.2,16.3c-12.4,18.2-30.3,33.6-53,46c-12,6.4-24.6,10.6-29.9,25
              c-4,10.9-1.4,23.2,8.8,33.6l0,0c3.3,3.6,7.5,6.8,12.8,9.7c12.4,6.9,23,10.2,31.3,12.5c1.5,0.4,4.8,1.5,6.3,2.8
              c3.7,3.2,3.2,8.1,8.1,15.2c3,4.4,6.4,7.4,9.2,9.4c10.3,7.1,21.9,7.6,34.2,8c11.1,0.4,23.7,0.9,38.1,5.7c6,2,12.1,5.8,19.3,10.2
              c17.2,10.6,40.8,25,80.2,25c39.4,0,63.1-14.5,80.5-25.2c7.1-4.4,13.3-8.1,19-10c14.4-4.7,27-5.2,38.1-5.7
              c12.3-0.5,23.9-0.9,34.2-8c3.2-2.2,7.3-5.9,10.5-11.5c3.5-6,3.4-10.2,6.8-13.2c1.4-1.2,4.3-2.2,5.9-2.7
              c8.4-2.3,19.1-5.7,31.7-12.6c5.6-3.1,10-6.5,13.4-10.3c0,0,0.1-0.1,0.1-0.1C499.7,386.6,502.1,374.6,498.2,364z M463.2,382.8
              c-21.4,11.8-35.6,10.5-46.6,17.7c-9.4,6-3.8,19.1-10.7,23.8c-8.4,5.8-33.2-0.4-65.1,10.2c-26.4,8.7-43.2,33.8-90.7,33.8
              c-47.6,0-64-25-90.7-33.8c-32-10.6-56.8-4.4-65.1-10.2c-6.8-4.7-1.3-17.7-10.7-23.8c-11-7.1-25.3-5.9-46.6-17.7
              c-13.6-7.5-5.9-12.2-1.4-14.4c77.4-37.5,89.8-95.4,90.3-99.7c0.7-5.2,1.4-9.3-4.3-14.6c-5.5-5.1-30.1-20.3-36.9-25
              c-11.3-7.9-16.2-15.7-12.6-25.4c2.5-6.7,8.8-9.2,15.4-9.2c2,0,4.1,0.2,6.1,0.7c12.4,2.7,24.4,8.9,31.3,10.6c1,0.2,1.8,0.3,2.6,0.3
              c3.7,0,5-1.9,4.8-6.1c-0.8-13.5-2.7-39.9-0.6-64.5c2.9-33.9,13.9-50.7,26.9-65.6c6.2-7.1,35.5-38.1,91.6-38.1
              c56.2,0,85.3,30.9,91.6,38.1c13,14.9,23.9,31.7,26.9,65.6c2.1,24.6,0.3,51-0.6,64.5c-0.3,4.5,1.1,6.1,4.8,6.1
              c0.8,0,1.6-0.1,2.6-0.3c6.9-1.7,19-7.9,31.3-10.6c2-0.4,4.1-0.7,6.1-0.7c6.6,0,12.8,2.5,15.4,9.2c3.7,9.7-1.3,17.5-12.6,25.4
              c-6.8,4.7-31.3,19.9-36.9,25c-5.7,5.3-5,9.4-4.3,14.6c0.6,4.4,12.9,62.2,90.3,99.7C469.1,370.6,476.8,375.3,463.2,382.8z`})]})})})};var im=({backgroundType:e,supportedLocales:t,onLocaleChange:o})=>{let{currentLocale:n}=(0,am.useContext)(Sr),a=(0,am.useRef)(null),s=()=>a.current;return x("div",{"data-testid":"mwp-cookie-modal-header",className:"modal-header",ref:a,children:[i("div",{className:"logo-container",children:i(g$,{width:24,height:24,backgroundType:e})}),i("div",{className:"locale-container",children:i(K4,{supportedLocales:t,currentLocale:t[n],onLocaleChange:o,containerProvider:s})})]})};var f$=({backgroundType:e,supportedLocales:t,title:o,content:n,settingsButtonText:a,acceptAllButtonText:s,essentialOnlyButtonText:l,onSettingsbuttonClick:p,onAcceptAllButtonClick:d,onAcceptEssentialButtonClick:u,onLocaleChange:y})=>x("div",{"data-testid":"mwp-cookie-landing-screen",className:"cookie-landing-screen",children:[i(im,{backgroundType:e,supportedLocales:t,onLocaleChange:y}),x("div",{"data-testid":"mwp-cookie-modal-body",className:"modal-body",children:[i("h2",{className:"cookie-title",children:o}),i(nm,{document:n,className:"landing-content"})]}),x(rm,{children:[i(hr,{isPrimary:!0,text:l,onClick:u}),i(hr,{isPrimary:!0,text:s,onClick:d}),i(hr,{isPrimary:!1,text:a,onClick:p})]})]});var sm=({title:e,cookieCategories:t,categoriesState:o,updateCategoriesState:n,activeToggleLabel:a,inactiveToggleLabel:s,isModal:l})=>x(pe,{children:[i("h2",{className:"cookie-title",children:e}),t.map(p=>{if(l&&p.displayMode==="Settings Only")return null;let d=p.categoryCookieName,u=s;return p.isEssential&&!p.enableToggle&&(u=a),o[d]&&(u=a),i("div",{"data-testid":"mwp-cookie-category-description",children:x("div",{className:"category-border",children:[x("div",{className:"category-title-container",children:[i("h5",{className:"category-title",children:p.title}),i("p",{className:"category-status",children:u}),p.enableToggle===!0&&i("div",{className:"category-toggle",children:i(e$,{id:`${p.sys.id}-slider`,isChecked:!!o[d],onToggle:()=>n(d,!o[d])})})]}),i(nm,{className:"category-description",document:p.description.json})]})},p.sys.id)})]});var b$=({backgroundType:e,supportedLocales:t,onLocaleChange:o,title:n,cookieCategories:a,activeToggleLabel:s,inactiveToggleLabel:l,categoriesState:p,updateCategoriesState:d,acceptAllButtonText:u,essentialOnlyButtonText:y,acceptSelectedButtonText:m,onAcceptAllButtonClick:g,onAcceptEssentialButtonClick:f,onAcceptSelectedButtonClick:b})=>x("div",{"data-testid":"mwp-cookie-modal-settings-screen",className:"cookie-settings-screen",children:[i(im,{backgroundType:e,supportedLocales:t,onLocaleChange:o}),i("div",{className:"modal-body",children:i(sm,{title:n,cookieCategories:a,categoriesState:p,updateCategoriesState:d,activeToggleLabel:s,inactiveToggleLabel:l,isModal:!0})}),x(rm,{children:[i(hr,{isPrimary:!0,text:y,onClick:f}),i(hr,{isPrimary:!0,text:u,onClick:g}),i(hr,{isPrimary:!0,text:m,onClick:b})]})]});var lm="CookieModal",S$=({supportedLocales:e,cookieDomain:t,portalRoot:o,backgroundType:n="White",onLocaleChange:a,onComplete:s,onEvent:l,onGlobalPrivacyControlSet:p,globalPrivacyControl:d,forceVisible:u})=>{let y=(0,Gt.useContext)(Sr),{data:m}=hn(Wy,y,{client:y.client}),g=br(m?.cookieModalCollection.items),f=g?.gpcLocations,{categorySettings:b,cookieCategoryMap:S,enableCookieDeletion:C}=(0,Gt.useMemo)(()=>{if(!g?.cookieCategoriesCollection?.items?.length)return{categorySettings:void 0,cookieCategoryMap:void 0,enableCookieDeletion:!1};let K=g.cookieCategoriesCollection.items,F=Ky(g.cookieCategoriesCollection.items),{enableCookieDeletion:Q}=g;return{categorySettings:K,cookieCategoryMap:F,enableCookieDeletion:Q}},[g]),v=Xy(t),[k,I]=(0,Gt.useState)(),[A,D]=(0,Gt.useState)("Unknown"),[B,M]=(0,Gt.useState)(!1),[_,P]=(0,Gt.useState)({}),$=(K,F)=>{let Q=Fo(_);Q[K]=F,P(Q)},[R,L]=(0,Gt.useState)(!1),[G,Z]=(0,Gt.useState)("landing"),[U,de]=(0,Gt.useState)(),re=!!((window?.navigator?.globalPrivacyControl||d)&&S&&(f?.includes(A)||f?.length===0||!f)),te=(0,Gt.useCallback)(K=>{if(!!nC.has(v))return;let Q=U4(K);for(let z of Q){let Se={cookieName:z,userLocation:A};U?.logMetric("modal_uncategorized_cookie",Se)}},[U,v,A]),ae=(0,Gt.useCallback)((K,F)=>{if(!S||!b)return;let z=((j,fe={})=>O4(j,(J,ue)=>oC(fe[ue])||fe[ue]!==J))(K,F);em(v,z);let Se=Zy(v,K,S,C);for(let j in Se){if(Se[j]?.wasRemoved)continue;let fe={cookieName:j,userLocation:A};U?.logMetric("tracking_cookie_misconfiguration",fe)}te(S),s?.({didUserInteract:B,userLocation:A,cookieAcceptance:K,isGlobalPrivacyControlApplied:re}),M(!1)},[v,S,b,U,B,s,A,M,te,re,C]);(0,Gt.useEffect)(()=>{let K=window.location.hostname,F=new za(ns.COOKIE_MODAL_COMPONENTS,K);de(F)},[de]),(0,Gt.useEffect)(()=>{if(!U)return;(async()=>{try{let F=await W4();I(F)}catch(F){let Q=Ft(F);U.logError(lm,"shouldDisplayModal",Q),I(!0)}})()},[U,I]),(0,Gt.useEffect)(()=>{if(!U)return;(async()=>{try{let F=await jy();D(F)}catch(F){let Q=Ft(F);U.logError(lm,"userLocation",Q)}})()},[U,D]),(0,Gt.useEffect)(()=>{if(!b)return;let K=Yp(b);P(K)},[b,P]),(0,Gt.useEffect)(()=>{if(oC(k)||!S||!b||R)return;L(!0);let K=Yy(b),F=K["sc-cookies-accepted"],Q={userLocation:A,cookieDomain:v};if(F){let Se={...k?Yp(b):Qy(b),...K};re&&K.Marketing?(ae({...Se,Marketing:!1},K),p?.(),U?.logMetric("global_privacy_control",Q)):ae(Se,K);return}if(k)M(!0);else{let z=Qy(b);re?(ae({...z,Marketing:!1}),p?.(),U?.logMetric("global_privacy_control",Q)):ae(z)}},[R,k,S,b,L,M,ae,d,A,re,v,U,p]);let oe=()=>{if(!b)return;let K=Qy(b);ae(K),q("accept_all",K)},q=(K,F)=>{l?.({component:lm,action:"Click",label:K});let Q={preferences:`${F.Preferences??!1}`,performance:`${F.Performance??!1}`,marketing:`${F.Marketing??!1}`,userLocation:A};U?.logMetric(`${K}_clicks_modal`,Q)},X=()=>{if(!b)return;let K=Yp(b);ae(K),q("accept_essential",K)},W=()=>{if(!b)return;let K=qy(b,_);ae(K),q("accept_selected",K)};return g?x(Y4,{isDisplayed:u??B,backgroundType:n,portalRoot:o,children:[G==="landing"&&i(f$,{backgroundType:n,supportedLocales:e,title:g.landingScreenTitle,content:g.content.json,settingsButtonText:g.settingsButtonText,onSettingsbuttonClick:()=>Z("settings"),acceptAllButtonText:g.acceptAllButtonText,onAcceptAllButtonClick:oe,essentialOnlyButtonText:g.essentialOnlyButtonText,onAcceptEssentialButtonClick:X,onLocaleChange:a}),G==="settings"&&i(b$,{backgroundType:n,supportedLocales:e,title:g.landingScreenTitle,cookieCategories:g.cookieCategoriesCollection.items,activeToggleLabel:g.toggleEnabledText,inactiveToggleLabel:g.toggleDisabledText,categoriesState:_,updateCategoriesState:$,acceptAllButtonText:g.acceptAllButtonText,essentialOnlyButtonText:g.essentialOnlyButtonText,acceptSelectedButtonText:g.acceptSelectedButtonText,onAcceptAllButtonClick:oe,onAcceptEssentialButtonClick:X,onAcceptSelectedButtonClick:W,onLocaleChange:a})]}):null};S$.displayName=lm;var pC=tm(S$,ns.COOKIE_MODAL_COMPONENTS);var ec=({children:e,client:t,...o})=>{let{isPreview:n=!1,isSSR:a=!1,currentLocale:s="en-US"}=o,l={isPreview:n,isSSR:a,currentLocale:s,client:t},p=i(Sr.Provider,{value:l,children:i(Mn.Provider,{value:o,children:e})});if(t)return p;let d=new ud({link:Md,cache:new dd});return i(Kl,{client:d,children:p})};var Vo=T(w());var cC="CookieSettings",h$=({backgroundType:e="White",cookieDomain:t,onSubmit:o,onEvent:n})=>{let a=(0,Vo.useContext)(Sr),{data:s}=hn(Wy,a,{client:a.client}),l=br(s?.cookieModalCollection.items),{categorySettings:p,cookieCategoryMap:d,enableCookieDeletion:u}=(0,Vo.useMemo)(()=>{if(!l?.cookieCategoriesCollection?.items)return{categorySettings:void 0,cookieCategoryMap:void 0,enableCookieDeletion:!1};let P=l.cookieCategoriesCollection.items,$=Ky(l.cookieCategoriesCollection.items),{enableCookieDeletion:R}=l;return{categorySettings:P,cookieCategoryMap:$,enableCookieDeletion:R}},[l]),y=Xy(t),[m,g]=(0,Vo.useState)("Unknown"),[f,b]=(0,Vo.useState)({}),S=(P,$)=>{let R=Fo(f);R[P]=$,b(R),v("Enabled")},[C,v]=(0,Vo.useState)("Disabled"),k=()=>{v("Saved"),setTimeout(()=>{v("Disabled")},3e3)},[I,A]=(0,Vo.useState)(),D=(0,Vo.useCallback)(P=>{if(!d||!p)return;em(y,P);let $=Zy(y,P,d,u);for(let R in $){if($[R]?.wasRemoved)continue;let L={cookieName:R,userLocation:m};I?.logMetric("tracking_cookie_misconfiguration",L)}},[y,m,d,p,I,u]);(0,Vo.useEffect)(()=>{let P=window.location.hostname,$=new za(ns.COOKIE_MODAL_COMPONENTS,P);A($)},[A]),(0,Vo.useEffect)(()=>{if(!p)return;let P=()=>{let R=Yy(p);R["sc-cookies-accepted"]&&(b(R),clearInterval($))},$=setInterval(P,1e3);return P(),()=>clearInterval($)},[p,b]),(0,Vo.useEffect)(()=>{if(!I)return;(async()=>{try{let $=await jy();g($)}catch($){let R=Ft($);I.logError(cC,"userLocation",R)}})()},[g,I]);let B=()=>{if(!p)return;let P=qy(p,f);D(P),k(),M("save_changes",P),o?.({userLocation:m,cookieAcceptance:P})},M=(P,$)=>{n?.({component:cC,action:"Click",label:P});let R={preferences:`${$.Preferences??!1}`,performance:`${$.Performance??!1}`,marketing:`${$.Marketing??!1}`,userLocation:m};I?.logMetric(`${P}_clicks_settings`,R)};if(!l)return null;let _={isDisabled:C==="Disabled",isPrimary:C!=="Saved",testId:"mwp-cookie-settings-save-btn",text:C==="Saved"?l.changesSavedText:l.saveChangesText,onClick:B};return x(J4,{backgroundType:e,children:[i("div",{"data-testid":"mwp-cookie-settings-page-body",className:"settings-page-body",children:i(sm,{title:l.settingsScreenTitle,cookieCategories:l.cookieCategoriesCollection.items,categoriesState:f,updateCategoriesState:S,activeToggleLabel:l.toggleEnabledText,inactiveToggleLabel:l.toggleDisabledText})}),i("div",{"data-testid":"mwp-cookie-settings-page-footer",className:"settings-page-footer",children:i(hr,{..._})})]})};h$.displayName=cC;var dC=tm(h$,ns.COOKIE_MODAL_COMPONENTS);var gm=T(w());var C$=T(w());var xr="en-US",qs={[xr]:{code:xr,name:"English (United States)"}},HY=e=>{let t=new URL(e,window.location.href);return window.location.hostname!==t.hostname?!1:window.location.pathname!==t.pathname},VY={currentLocale:xr,supportedLocales:qs,onError:console.error,isPreview:!1,isSSR:!1,isUrlCurrent:HY},ze=(0,C$.createContext)({onError:e=>console.error(e),currentLocale:xr,hostname:"unknown",supportedLocales:qs}),uC=({children:e,value:t})=>i(ze.Provider,{value:tr(VY,t),children:e});var OY=(e,t,o)=>{cm({"gtm.start":Date.now(),event:"gtm.js"});let n=e.createElement("script");n.async=!0,n.src=`https://www.googletagmanager.com/gtm.js?id=${t}`,o&&(n.nonce=o),e.head.appendChild(n)},pm=(e,t)=>{if(e==="")return;let o=x$(e);window[`ga-disable-${o}`]=!t},x$=e=>e.includes("UA-")||e.includes("G-")?e:`UA-${e}`,cm=e=>{window.dataLayer=window.dataLayer??[],window.dataLayer.push(e)},GY=(e,t,o)=>{window&&(pm(t,!0),OY(document,e,o))},zY=e=>{(window.ga.q=window.ga.q??[]).push(...e)},UY=e=>{window.GoogleAnalyticsObject="ga",window.ga=window.ga??zY,window.ga.l=new Date().getTime;let t=document.createElement("script");t.async=!0,t.src="https://www.google-analytics.com/analytics.js",e&&(t.nonce=e),document.head.appendChild(t)},WY=(e,t=[],o)=>{if(window)if(pm(e,!0),e.includes("UA-"))UY(o),ga("create",e,"auto"),t.forEach(n=>{ga("require",n.name,n.options)}),ga("set","anonymizeIp",!0),ga("send","pageview");else{window.dataLayer=window.dataLayer??[];let n=document.createElement("script");n.async=!0,n.src=`https://www.googletagmanager.com/gtag/js?id=${e}`,n.onload=()=>{cm({js:new Date,config:e})},o&&(n.nonce=o),document.head.appendChild(n)}},v$=(e,t,o,n)=>{let a=x$(t);e&&t?GY(e,a,n):t&&WY(a,o,n)};var dm=T(w());var I$="sc-language";var k$=c`
  .sdsm-dropdown-button {
    font-size: 14px;
    line-height: 20px;
  }

  .${o0} {
    max-width: 200%;
  }
`;var Ks=({currentLocale:e,supportedLocales:t,onLocaleChange:o,className:n,buttonComponent:a})=>{let s=(0,dm.useContext)(ze);e??(e=s.currentLocale),t??(t=s.supportedLocales??qs),o??(o=s.onLocaleChange);let l=Object.values(t),p=(0,dm.useCallback)(u=>{let y=u.id;ro.get("Preferences")==="true"&&ro.set(I$,y,{domain:va(window.location.host),secure:!0}),s.onEvent?.({action:sn.LocaleSelect,component:"LocaleDropdown",label:`Language: ${y}`}),o?.(y)},[s,o]);l.sort((u,y)=>u.code.localeCompare(y.code));let d=l.map(u=>{let y=_d[u.code]??u.name;return{id:u.code,title:y}});return i(es,{items:d,className:h(k$,n),"data-testid":"gc-locale-language",selectedItemId:e??xr,onItemSelect:p,buttonComponent:a})};Ks.displayName="LocaleDropdown";var ym=T(w());var qY=c`
  font-family: ${r("--font-family")};

  * {
    box-sizing: border-box;
    margin: 0;
  }
`,M$=c`
  ${ba}
  margin-bottom: ${r("--spacing-m")};
  text-transform: uppercase;
`,um=c`
  ${qY}

  /* override site settings that override header behaviors */
  h1,h2,h3,h4,h5,h6 {
    font-family: ${r("--font-family")};
    line-height: inherit;
    text-transform: initial;
  }

  /* Ensure consistent rendering of lists */
  ul {
    list-style: disc outside;
  }
`,KY=c`
  .modal-header {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    margin-bottom: ${r("--spacing-xs")};

    .logo-container {
      display: flex;
      justify-content: center;
      flex-direction: column;
      opacity: ${r("--cookie-modal-logo-opacity")};
    }

    /* Ensure locale dropdown is aligned to the right regardless of logo display */
    .locale-container {
      margin-inline-start: auto;
    }
  }
`,jY=c`
  a {
    color: inherit;
    font-weight: 500;
  }
  > ul {
    padding-left: ${r("--spacing-l")};
    margin-bottom: ${r("--spacing-s")};
  }
  > ul > li {
    margin-bottom: ${r("--spacing-xxs")};
  }
  > p {
    margin: 0 0 ${r("--spacing-xxs")};
  }
  *[dir='rtl'] & {
    > ul {
      padding-left: unset;
      padding-right: ${r("--spacing-l")};
    }
  }
`,YY=c`
  .contentful-rich-text {
    /* Rich Text Base Styles */
    ${H} {
      font-size: ${r("--cookie-modal-rich-text-base-desktop-font-size")};
      font-weight: ${r("--cookie-modal-rich-text-base-desktop-font-weight")};
      line-height: ${r("--cookie-modal-rich-text-base-desktop-font-line-height")};
      font-stretch: ${r("--cookie-modal-rich-text-base-desktop-font-stretch")};
    }

    ${N} {
      font-size: ${r("--cookie-modal-rich-text-base-mobile-font-size")};
      font-weight: ${r("--cookie-modal-rich-text-base-mobile-font-weight")};
      line-height: ${r("--cookie-modal-rich-text-base-mobile-font-line-height")};
      font-stretch: ${r("--cookie-modal-rich-text-base-mobile-font-stretch")};
    }

    /* Rich Text H3 Styles (title) */
    h3 {
      ${H} {
        font-size: ${r("--cookie-modal-rich-text-title-desktop-font-size")};
        line-height: ${r("--cookie-modal-rich-text-title-desktop-font-line-height")};
        font-weight: ${r("--cookie-modal-rich-text-title-desktop-font-weight")};
        font-stretch: ${r("--cookie-modal-rich-text-title-desktop-font-stretch")};
      }
      ${N} {
        font-size: ${r("--cookie-modal-rich-text-title-mobile-font-size")};
        line-height: ${r("--cookie-modal-rich-text-title-mobile-font-line-height")};
        font-weight: ${r("--cookie-modal-rich-text-title-mobile-font-weight")};
        font-stretch: ${r("--cookie-modal-rich-text-title-mobile-font-stretch")};
      }
    }

    ${jY}
  }
`,T$=c`
  .category-border {
    border: ${r("--cookie-settings-category-border-width")} solid
      ${r("--cookie-settings-category-border-color")};
    border-radius: ${r("--cookie-settings-category-border-radius")};
    margin-bottom: ${r("--spacing-s")};
    padding: ${r("--cookie-settings-category-padding")};
  }

  .category-title-container {
    align-items: center;
    display: flex;
    margin-bottom: ${r("--spacing-xs")};
  }

  .category-title {
    flex: 1;

    ${H} {
      font-size: ${r("--cookie-settings-category-title-desktop-font-size")};
      font-stretch: ${r("--cookie-settings-category-title-desktop-font-stretch")};
      font-weight: ${r("--cookie-settings-category-title-desktop-font-weight")};
      line-height: ${r("--cookie-settings-category-title-desktop-font-line-height")};
    }
    ${N} {
      font-size: ${r("--cookie-settings-category-title-mobile-font-size")};
      font-stretch: ${r("--cookie-settings-category-title-mobile-font-stretch")};
      font-weight: ${r("--cookie-settings-category-title-mobile-font-weight")};
      line-height: ${r("--cookie-settings-category-title-mobile-font-line-height")};
    }

    *[dir='rtl'] & {
      text-align: right;
    }
  }

  .category-status {
    font-size: 12px;
    margin-right: ${r("--spacing-xs")};
    *[dir='rtl'] & {
      margin-right: unset;
      margin-left: ${r("--spacing-xs")};
    }
  }

  .category-toggle {
    display: flex;
    flex-direction: column;
    justify-content: center;
  }

  /* Rich text base styles first; settings screen styles second for cascade priority */
  ${YY}

  .category-description {
    ${H} {
      font-size: ${r("--cookie-settings-category-description-desktop-font-size")};
      font-stretch: ${r("--cookie-settings-category-description-desktop-font-stretch")};
      font-weight: ${r("--cookie-settings-category-description-desktop-font-weight")};
      line-height: ${r("--cookie-settings-category-description-desktop-font-line-height")};
    }
    ${N} {
      font-size: ${r("--cookie-settings-category-description-mobile-font-size")};
      font-stretch: ${r("--cookie-settings-category-description-mobile-font-stretch")};
      font-weight: ${r("--cookie-settings-category-description-mobile-font-weight")};
      line-height: ${r("--cookie-settings-category-description-mobile-font-line-height")};
    }
  }
`,XY=c`
  .modal-footer {
    padding-top: ${r("--spacing-s")}; /* Padding set by design */
    text-align: center;
    display: flex;
    /* Reverse direction so that when we wrap on smaller screens, the break happens on 1st, rather than last element.
       NOTE: requires that content be rendered in reverse order */
    flex-direction: row-reverse;
    gap: ${r("--spacing-s")};
    align-self: center;
    justify-content: center;

    /* Button spacing managed via gap instead of margins */
    .sdsm-button {
      margin: 0;
    }

    ${N} {
      flex-wrap: wrap;
      width: 100%;
    }

    ${Ht} {
      /* See note above, accounts for content rendered in reverse order. */
      flex-direction: column-reverse;
      align-items: center;
    }
  }
`,JY=c`
  .settings-page-footer {
    padding-top: ${r("--spacing-xl")};
    display: flex;
    flex-direction: row;
    gap: ${r("--spacing-s")};
    align-self: center;
    justify-content: center;

    /* Button spacing managed via gap instead of margins */
    .sdsm-button {
      margin: 0;
    }

    ${Ht} {
      padding-top: unset;
      flex-direction: column;
    }
  }
`,tc=c`
  /* card style. */
  background-color: ${r("--bg-color")};
  border: ${r("--cookie-settings-border-width")} solid ${r("--cookie-modal-border-color")};
  border-radius: ${r("--cookie-modal-border-radius")};
  box-shadow: ${r("--cookie-settings-box-shadow")};
  color: ${r("--fg-color")};
  padding: ${r("--cookie-settings-padding")};
`,A$=c`
  --padding-horizontal: ${r("--cookie-modal-desktop-horizontal-padding")};
  --padding-vertical: ${r("--cookie-modal-desktop-vertical-padding")};

  ${N} {
    --padding-horizontal: ${r("--cookie-modal-mobile-horizontal-padding")};
    --padding-vertical: ${r("--cookie-modal-mobile-vertical-padding")};
  }

  --max-height: calc(100vh - var(--padding-vertical));
  /* stylelint-disable-next-line declaration-block-no-duplicate-custom-properties */
  --max-height: calc(100dvh - var(--padding-vertical));

  .sdsm-modal-content {
    ${tc}
    border-width: ${r("--cookie-modal-border-width")};
    box-shadow: ${r("--cookie-modal-box-shadow")};
    padding: var(--padding-vertical) var(--padding-horizontal);
    width: max-content;

    /* stop-gap solution to prevent any part from being hidden */
    overflow: auto;

    /* prevents overflow of this container. */
    max-height: 100%;
    max-width: 100%;

    ${H} {
      max-width: ${r("--cookie-settings-max-width")};
      min-width: ${r("--cookie-modal-min-width")};
    }
  }

  .cookie-landing-screen,
  .cookie-settings-screen {
    max-height: calc(var(--max-height) - calc(2 * calc(1px + var(--padding-vertical))));

    display: flex;
    flex-direction: column;

    /* Header Styles */
    ${KY}

    /* Body Styles */
    .modal-body {
      flex: 1;
      overflow-y: auto;
      min-height: 5em;
      margin-bottom: ${r("--spacing-xs")};
      padding-right: ${r("--cookie-modal-body-inline-padding")};

      *[dir='rtl'] & {
        padding-right: unset;
        padding-left: ${r("--cookie-modal-body-inline-padding")};
      }

      .cookie-title {
        ${M$}
      }

      h3,
      b {
        font-weight: 500;
      }

      ${T$}
    }

    /* Footer Styles */
    ${XY}
  }
`,_$=c`
  /* Container Styles */
  justify-self: center;
  max-width: ${r("--cookie-settings-max-width")};

  /* Body Styles */
  .settings-page-body {
    text-align: left;

    .cookie-title {
      ${M$}
    }

    ${T$}
  }

  /* Footer Styles */
  ${JY}
`;var w$=({backgroundType:e,className:t,children:o,isDisplayed:n,portalRoot:a})=>{Y("sdsm-cookie-modal-settings");let s=Yo(),{width:l}=Sn(),[p,d]=(0,ym.useState)(Xo.Middle);return(0,ym.useEffect)(()=>{let u=Xo.Middle;s==="Mobile"&&(l??Number.POSITIVE_INFINITY)<=Ik&&(u=Xo.Bottom),d(u)},[s,l,d]),i(Iy,{isBlocking:!0,disableBackgroundScroll:!0,verticalAlignment:p,isDisplayed:n,portalRoot:a,className:h("sdsm-cookie-modal-settings",um,Pe(e),A$,t),contentClassName:h(tc),children:o})};var mm={buttonComponent:({text:e,isDisabled:t,isPrimary:o,onClick:n})=>{let a=o?rn.Primary:void 0;return i(no,{disabled:t,onClick:n,size:"Compact",type:a,children:e})},localeDropdownComponent:({currentLocale:e,supportedLocales:t,containerProvider:o,onLocaleChange:n})=>i(Ks,{currentLocale:e.code,supportedLocales:t,containerProvider:o,onLocaleChange:n}),modalComponent:({backgroundType:e,children:t,isDisplayed:o,portalRoot:n})=>i(w$,{backgroundType:e,isDisplayed:o,portalRoot:n,children:t}),sectionComponent:({backgroundType:e,children:t})=>i("section",{className:h(tc,Pe(e)),children:t}),toggleComponent:({id:e,isChecked:t,onToggle:o})=>i(p0,{id:e,isChecked:t,onToggle:o??(()=>{})})};var yC=({portalRoot:e,cookieDomain:t,supportedLocales:o,GTMID:n="",GAID:a="",nonce:s,plugins:l,onLocaleChange:p,onComplete:d,preferencesAcceptedCallback:u,performanceAnalyticsCallback:y,marketingAnalyticsCallback:m,backgroundType:g,forceVisible:f,globalPrivacyControl:b,onGlobalPrivacyControlSet:S})=>{(0,gm.useEffect)(()=>{pm(a,!1)},[a]);let C=(0,gm.useContext)(ze),{Anchor:v,globalApolloClient:k,currentLocale:I,isPreview:A,isSSR:D,onEvent:B,onError:M}=C;t??(t=C.hostname),o??(o=C.supportedLocales??qs),p??(p=C.onLocaleChange);let _={...mm,isSSR:D,isPreview:A,currentLocale:I,client:k};return i(or,{value:{Anchor:v},children:i(ec,{..._,children:i(pC,{...{supportedLocales:o,cookieDomain:t,portalRoot:e,backgroundType:g,onLocaleChange:p,onComplete:L=>{let{cookieAcceptance:G,userLocation:Z}=L;cm({userLocation:Z}),G.Performance&&v$(n,a,l,s),G.Preferences&&u?.(),G.Performance&&y?.(),G.Marketing&&m?.(),d?.(L)},onEvent:({label:L})=>B?.({component:"CookieModal",label:L,action:"Click"}),onError:M,forceVisible:f,globalPrivacyControl:b,onGlobalPrivacyControlSet:S}})})})};var D$=T(w());var mC=({backgroundType:e,cookieDomain:t,onSubmit:o})=>{Y("sdsm-cookie-modal-settings");let n=(0,D$.useContext)(ze),{Anchor:a,currentLocale:s,isPreview:l,isSSR:p,onEvent:d,onError:u,globalApolloClient:y}=n;t??(t=n.hostname);let m={...mm,isSSR:p,isPreview:l,currentLocale:s,client:y},g={backgroundType:e,cookieDomain:t,onSubmit:o,onEvent:d,onError:u};return i(or,{value:{Anchor:a},children:i("div",{"data-testid":"mwp-cookie-settings",className:h("sdsm-cookie-modal-settings",um,_$),children:i(ec,{...m,children:i(dC,{...g})})})})};var ZY=Sk(function(e,t,o){return e+(o?"_":"")+t.toLowerCase()}),P$=ZY;var E$=T(w());var N$={utm_source:"global_footer",utm_medium:"referral",utm_campaign:"universal_navigation",utm_content:"footer_item_link"},gC=e=>{let{id:t,url:o,title:n,analyticsLabel:a,trackingParameters:s}=e,{isUrlCurrent:l,onEvent:p,hostname:d}=(0,E$.useContext)(ze),u=s??(d?{...N$,utm_source:P$(d)}:N$),y=$d(o,u),m=()=>{p?.({action:sn.Click,component:"FooterItem",label:a,url:y})};return i(N2,{id:t,isSelected:l?.(o??""),url:y,title:n,onClick:m},t)};var G$=T(w());var R$={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"FooterV3CollectionQuery"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"preview"}},type:{kind:"NonNullType",type:{kind:"NamedType",name:{kind:"Name",value:"Boolean"}}}},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"locale"}},type:{kind:"NonNullType",type:{kind:"NamedType",name:{kind:"Name",value:"String"}}}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"footerV3Collection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"preview"},value:{kind:"Variable",name:{kind:"Name",value:"preview"}}},{kind:"Argument",name:{kind:"Name",value:"locale"},value:{kind:"Variable",name:{kind:"Name",value:"locale"}}},{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"1"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"FooterV3All"}}]}}]}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"AssetAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"Asset"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"description"}},{kind:"Field",name:{kind:"Name",value:"url"}},{kind:"Field",name:{kind:"Name",value:"contentType"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"ImageAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"Image"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"media"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"AssetAll"}}]}},{kind:"Field",name:{kind:"Name",value:"wrap"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"FooterItemV3All"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterItemV3"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"url"}},{kind:"Field",name:{kind:"Name",value:"analytics"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"label"}}]}},{kind:"Field",name:{kind:"Name",value:"hideOnDomains"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"FooterLocaleDropdownAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterLocaleDropdown"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"hideOnDomains"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"FooterCookiesSettingsLinkAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterCookiesSettingsLink"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"hideOnDomains"}},{kind:"Field",name:{kind:"Name",value:"analytics"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"label"}}]}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"FooterGroupAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterGroup"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"groupKey"}},{kind:"Field",name:{kind:"Name",value:"itemsCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"10"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"__typename"}},{kind:"InlineFragment",typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterItemV3"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"FooterItemV3All"}}]}},{kind:"InlineFragment",typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterLocaleDropdown"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"FooterLocaleDropdownAll"}}]}},{kind:"InlineFragment",typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterCookiesSettingsLink"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"FooterCookiesSettingsLinkAll"}}]}}]}}]}},{kind:"Field",name:{kind:"Name",value:"analytics"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"label"}}]}},{kind:"Field",name:{kind:"Name",value:"hideOnDomains"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"FooterV3All"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterV3"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"logo"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"ImageAll"}}]}},{kind:"Field",name:{kind:"Name",value:"url"}},{kind:"Field",name:{kind:"Name",value:"hideLogoOnDomains"}},{kind:"Field",name:{kind:"Name",value:"columnsCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"10"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"InlineFragment",typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterGroup"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"FooterGroupAll"}}]}}]}}]}},{kind:"Field",name:{kind:"Name",value:"barCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"10"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"InlineFragment",typeCondition:{kind:"NamedType",name:{kind:"Name",value:"FooterGroup"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"FooterGroupAll"}}]}}]}}]}}]}}]};var F$={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"GlobalNavConfigCollectionQuery"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"preview"}},type:{kind:"NonNullType",type:{kind:"NamedType",name:{kind:"Name",value:"Boolean"}}}},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"locale"}},type:{kind:"NonNullType",type:{kind:"NamedType",name:{kind:"Name",value:"String"}}}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"globalNavConfigCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"preview"},value:{kind:"Variable",name:{kind:"Name",value:"preview"}}},{kind:"Argument",name:{kind:"Name",value:"locale"},value:{kind:"Variable",name:{kind:"Name",value:"locale"}}},{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"1"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"globalNavLabel"}},{kind:"Field",name:{kind:"Name",value:"globalNavButtonAriaLabel"}},{kind:"Field",name:{kind:"Name",value:"globalNavGroupsCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"20"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"GlobalNavAll"}}]}}]}}]}}]}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"AnalyticsAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"Analytics"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"label"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"AssetAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"Asset"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"description"}},{kind:"Field",name:{kind:"Name",value:"url"}},{kind:"Field",name:{kind:"Name",value:"contentType"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"ImageAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"Image"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"media"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"AssetAll"}}]}},{kind:"Field",name:{kind:"Name",value:"wrap"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"ButtonAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"Button"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"json"}}]}},{kind:"Field",name:{kind:"Name",value:"url"}},{kind:"Field",name:{kind:"Name",value:"size"}},{kind:"Field",name:{kind:"Name",value:"theme"}},{kind:"Field",name:{kind:"Name",value:"buttonType"}},{kind:"Field",name:{kind:"Name",value:"image"},selectionSet:{kind:"SelectionSet",selections:[{kind:"InlineFragment",typeCondition:{kind:"NamedType",name:{kind:"Name",value:"Image"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"ImageAll"}}]}}]}},{kind:"Field",name:{kind:"Name",value:"iconName"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"CallToActionAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"CallToAction"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"analytics"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"AnalyticsAll"}}]}},{kind:"Field",name:{kind:"Name",value:"presentation"},selectionSet:{kind:"SelectionSet",selections:[{kind:"InlineFragment",typeCondition:{kind:"NamedType",name:{kind:"Name",value:"Button"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"ButtonAll"}}]}}]}},{kind:"Field",name:{kind:"Name",value:"url"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"GlobalNavHighlightAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"GlobalNavHighlight"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"cta"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"CallToActionAll"}}]}},{kind:"Field",name:{kind:"Name",value:"background"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"AssetAll"}}]}},{kind:"Field",name:{kind:"Name",value:"cardTitleV2"}},{kind:"Field",name:{kind:"Name",value:"cardBodyV2"}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"GlobalNavItemAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"GlobalNavItem"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"url"}},{kind:"Field",name:{kind:"Name",value:"hideHostnameRegex"}},{kind:"Field",name:{kind:"Name",value:"analytics"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"AnalyticsAll"}}]}}]}},{kind:"FragmentDefinition",name:{kind:"Name",value:"GlobalNavAll"},typeCondition:{kind:"NamedType",name:{kind:"Name",value:"GlobalNav"}},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sys"},selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"}}]}},{kind:"Field",name:{kind:"Name",value:"title"}},{kind:"Field",name:{kind:"Name",value:"groupKey"}},{kind:"Field",name:{kind:"Name",value:"primaryHostnameRegex"}},{kind:"Field",name:{kind:"Name",value:"hideHostnameRegex"}},{kind:"Field",name:{kind:"Name",value:"highlight"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"GlobalNavHighlightAll"}}]}},{kind:"Field",name:{kind:"Name",value:"itemsCollection"},arguments:[{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"IntValue",value:"20"}}],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"items"},selectionSet:{kind:"SelectionSet",selections:[{kind:"FragmentSpread",name:{kind:"Name",value:"GlobalNavItemAll"}}]}}]}}]}}]};var fm=({id:e,title:t,items:o,onClick:n,orientation:a="Vertical",isFooterBar:s,beforeItems:l,afterItems:p,onToggle:d})=>{if(!o?.length&&!l&&!p)return null;let u=o?.map((y,m)=>i(gC,{id:y.id,url:y.url,title:y.title,analyticsLabel:y.analyticsLabel},y.id||m));return x(_2,{isFooterBar:s,id:e,title:t,onClick:n,orientation:a,onToggle:d,children:[l,...u,p]})};var fC=c`
  width: 100%;

  ${H} {
    width: auto;
  }
`,B$=c`
  display: flex;
  align-items: center;
  margin-top: ${r("--spacing-xxxs")};

  padding-block-end: ${r("--spacing-xs")};

  ${H} {
    padding-block-end: 0;
  }
`,$$=c`
  &.sdsm-logo {
    fill: #221f20;
  }
`;var L$=c`
  ${N} {
    width: 100%;
    .sdsm-dropdown,
    .sdsm-dropdown-button {
      width: 100%;
    }
  }
`,H$=c`
  display: flex;
  flex-direction: column;
  gap: ${r("--spacing-s")};
`,V$=c`
  flex-direction: row;
  align-items: center;

  ${N} {
    flex-direction: column;
    align-items: flex-start;
  }
`,O$=c`
  color: ${r("--fg-color")};
  /* Set font-family here or the var from the default motif is used */
  font-family: ${r("--font-family")};
  font-size: 14px;
  font-weight: 600;
  line-height: 16px;
`;var bm=({title:e,currentOrientation:t,buttonComponent:o})=>x("div",{className:h(H$,{[V$]:t==="Horizontal"}),children:[e&&i("label",{className:O$,children:e}),i(Ks,{className:L$,buttonComponent:o})]});bm.displayName="FooterLocaleDropdown";var bC=(e,t,o)=>{let n=Fo(t),a=e.reduce((l,p)=>{let d=n.findIndex(y=>y.groupKey.trim()===p.groupKey.trim()),u=tX(p.itemsCollection.items,o);if(!u.length)return l;if(d>=0){let m=n.splice(d,1)[0],g={id:m.id??p.sys.id,title:m.title??p.title,items:m.items.concat(u),analyticsLabel:m.analyticsLabel??p.analytics?.label};l.push(g)}else{let y={id:p.sys.id,title:p.title,items:u,analyticsLabel:p.analytics?.label};l.push(y)}return l},[]),s=n.map(l=>({id:l.id,title:l.title,items:l.items,analyticsLabel:l.analyticsLabel}));return[...a,...s]},SC=(e,t)=>e.filter(n=>!n.hideOnDomains||!n.hideOnDomains.includes(t)).map(n=>({...n,itemsCollection:{...n.itemsCollection,items:n.itemsCollection.items.filter(a=>!a.hideOnDomains||!a.hideOnDomains.includes(t))}})),tX=(e,t)=>e.map(n=>{if(n.__typename==="FooterCookiesSettingsLink")return t?{id:n.sys.id,title:n.title,url:t}:void 0;if(n.__typename!=="FooterLocaleDropdown")return{analyticsLabel:n?.analytics?.label,id:n.sys.id,title:n.title,url:n.url}}).filter(n=>!!n);var z$=({customColumns:e,customFooterBar:t,motifScheme:o,backgroundColor:n,logo:a,socialBar:s,footerType:l="Full Footer",cookieSettingsUrl:p,hasSideNav:d,customLocaleDropdownButton:u,className:y,onGroupToggle:m})=>{let{Anchor:g,supportedLocales:f,currentLocale:b,hostname:S,isPreview:C,isSSR:v,globalApolloClient:k}=(0,G$.useContext)(ze),{data:I,loading:A,error:D}=hn(R$,{currentLocale:b??xr,isPreview:C??!1,isSSR:v??!1},{client:k});if(A||D||!S||!I)return null;let B=o??Pe(n)??"sdsm-tertiary",M=Object.keys(f||{}).length>1,_=br(I.footerV3Collection.items),P=_?.columnsCollection.items??[],$=SC(P,S),R=_?.barCollection.items??[],L=SC(R,S),G;L.forEach(re=>{let te=re.itemsCollection.items.find(ae=>ae.__typename==="FooterLocaleDropdown");te&&!te.hideOnDomains?.includes(S)&&(G={title:te.title,id:te.sys.id})});let Z=bC($,e??[],p),U=bC(L,t??[],p),de;if(U.length&&(a?de=a:de=i(ki,{url:_?.url,className:B$,innerLogoClassName:B!=="sdsm-secondary"?$$:void 0,logoType:"SnapInc",openInNewTab:!0}),de&&!_?.hideLogoOnDomains?.includes(S)&&(U[0].beforeItems=i("li",{children:de})),G)){let re=i("li",{id:G.id,className:fC,children:i(bm,{title:G.title,currentOrientation:"Horizontal",buttonComponent:u})},G.id);U.push({id:"localeDropdownGroup",title:"",items:[],orientation:"Horizontal",afterItems:re})}let le=null;if(l==="No Footer"){if(!M||!G)return null;let re=i("li",{id:G.id,className:fC,children:i(bm,{title:G.title,currentOrientation:"Horizontal",buttonComponent:u})},G.id);le=x(Uu,{motifScheme:B,className:y,children:[s,i(_S,{hasSideNav:d,children:i(fm,{id:"localeDropdown",title:"",items:[],orientation:"Horizontal",afterItems:re},"noFooter")})]})}else{let re=i(_S,{hasSideNav:d,children:U.map((te,ae)=>i(fm,{id:te.id,title:te.title,items:te.items,orientation:"Horizontal",beforeItems:te.beforeItems,afterItems:te.afterItems,isFooterBar:!0},`${ae}-${te.id}`))});if(l==="Simple Footer")le=x(Uu,{motifScheme:B,className:y,children:[s,re]});else{let te=Z.map((ae,oe)=>i(fm,{id:ae.id,title:ae.title,items:ae.items,onToggle:m},`${oe}-${ae.id}`));le=x(Uu,{motifScheme:B,className:y,children:[s,i(k2,{hasSideNav:d,children:te}),re]})}}return i(or,{value:{Anchor:g},children:le})};var hC=({footerType:e="Full Footer",onGroupToggle:t,...o})=>i(z$,{footerType:e,...o,onGroupToggle:t});var Ua=T(w());var Y$=T(w());var Q$=T(w());var W$=T(w());var CC=e=>{let{Anchor:t,onEvent:o}=(0,W$.useContext)(ze),{url:n,target:a,buttonType:s,theme:l,title:p,size:d,image:u,iconName:y}=e;return i(or,{value:{Anchor:t},children:i(no,{link:n,target:a,type:s??l,onClick:()=>{o?.({action:sn.Click,component:"Button",url:n,label:e.analyticsLabel})},size:d,image:u?.media?{...u?.media,width:24,height:24}:void 0,iconName:y,children:p?.json&&i(zy,{document:p.json})})})};CC.displayName="Button";var xC=e=>{let{onError:t}=(0,Q$.useContext)(ze),{presentation:o,analytics:n,url:a}=e;return a&&t?.(new Error('The "url" field on CallToAction is no longer supported')),o.__typename==="Button"?i(CC,{analyticsLabel:n?.label,...o}):(t?.(new Error(`Unable to render CTA presentation "${o.__typename}"`)),null)};xC.displayName="CallToAction";var Sm=T(w());var q$=({triggered:e,ctaProps:t})=>{let o=(0,Sm.useContext)(ze),{onEvent:n}=o,{presentation:a,url:s,analytics:l}=t??{},p=a?.__typename==="Button";(0,Sm.useEffect)(()=>{if(!e||!p)return;let d=s??a?.url;n&&n({action:sn.Click,component:"VirtualCallToAction",label:l?.label,url:d}),window&&(window.location.href=d)},[e,s,l?.label,n,p,a?.url])};var vC=(e,t)=>{let o={baseDprSettings:{height:e}};return t<=e?o:e<t&&t<e*2?(o.additionalDpr={dpr:Number.parseFloat((t/e).toFixed(4)),settings:{height:t}},o):(o.additionalDpr={dpr:2,settings:{height:e*2}},o)},oc=(e,t,o)=>{let n=vC(e,t);return n.additionalDpr?{size:{sizeToUrl:[{size:"1x",settings:{...n.baseDprSettings,quality:o}},{size:`${n.additionalDpr.dpr}x`,settings:{...n.additionalDpr.settings,quality:o}}]}}:{image:{height:e,quality:o}}};var Tn=({imageUrl:e,settings:t,currentUrl:o})=>{if(!t||!e)return e??"";let{progressive:n,width:a,height:s,format:l,quality:p=40,fit:d}=t;try{let u=new URL(e,o);return l&&u.searchParams.set("fm",l),d&&u.searchParams.set("fit",d),p>0&&p<=100?u.searchParams.set("q",String(p)):u.searchParams.set("q",String(40)),n&&u.searchParams.set("fl","progressive"),a&&0<a&&a<4e3&&u.searchParams.set("w",String(a)),s&&0<s&&s<4e3&&u.searchParams.set("h",String(s)),u.href}catch(u){return console.error("Error parsing URL",e,u),e}};var nc=T(w());var oX=new Set(["slow-2g","2g","3g"]),vr=(e,t,o)=>{if(!e)return"";if(t&&"size"in t&&t.size)return t.size.sizeToUrl.map(({size:a,settings:s})=>a?`${Tn({imageUrl:e,settings:{...s,format:o??s?.format}})} ${a}`:Tn({imageUrl:e,settings:{...s,format:o??s?.format}})).join(",");let n=t&&"image"in t&&t.image?t.image:void 0;return Tn({imageUrl:e,settings:{...n,format:o??n?.format}})};function ve(){let e=(0,nc.useContext)(Ze),t=e.getCachedHighEntropyHints()?.connection,o=e.getLowEntropyHints().saveData||!!(t&&oX.has(t)),n=e.getLowEntropyHints();return nX({isSlowConnection:o,supportsAvif:pd(n),supportsWebP:ZI(n)})}var nX=e=>{let{isSlowConnection:t,supportsAvif:o,supportsWebP:n}=e,a=(0,nc.useCallback)((l,p)=>{if(!l)return;p&&t&&("image"in p?tr(p,{image:{quality:10}}):p.quality=10);let d=l.toLowerCase().endsWith(".svg"),u=[];if(d)u=[{type:"image/svg+xml",url:l}];else{let m=p&&"size"in p?p?.size?.sizes:void 0,g=p&&"media"in p?p?.media:void 0;u.unshift({type:"image/webp",url:vr(l,p,"webp"),sizes:m,media:g}),o&&u.unshift({type:"image/avif",url:vr(l,p,"avif"),sizes:m,media:g})}let y=p&&"image"in p?{image:p?.image}:void 0;return p&&"size"in p&&p.size&&(y={image:p.size.sizeToUrl.reduce((g,f)=>g&&Number.parseFloat(g.size)<Number.parseFloat(f.size)?g:f).settings}),{sources:u,default:vr(l,y,d?void 0:"webp")}},[t,o]),s=(0,nc.useCallback)((l,p)=>{if(!l)return;if(l.toLowerCase().endsWith(".svg"))return l;let d=o&&"avif"||n&&"webp"||"jpg",u={...p};return d&&(u.format=d),Tn({imageUrl:l,settings:u})},[o,n]);return{getImageSources:a,getBestBgImgSrc:s}};var K$=T(w());var rc=e=>e?e.startsWith("video"):!1,hm=e=>e?e.startsWith("image"):!1;var j$=e=>{let{onError:t}=(0,K$.useContext)(ze),{contentType:o,url:n,description:a,sizedSrcSets:s}=e,{getImageSources:l}=ve();if(hm(o)){let p=l(n);return s&&(p=l(n,{size:s})),i(Ke,{sourceType:o,imgSrcs:p,altText:a})}return rc(o)?i(Ke,{sourceType:o,videoSource:n,showVideoControls:!0,maxHeight:600,altText:a}):(t?.(`Unsupported Mdea type ${o}`),null)};var rX=[480,960,1440,1920,2560],aX=452,Cm=`(max-width: ${jo}px) 100vw, calc(100vw - ${aX}px)`,IC={sizeToUrl:rX.map(e=>({size:`${e}w`,settings:{quality:70,width:e}})),sizes:Cm},ac=e=>{let[t,o]=(0,Y$.useState)(0);q$({triggered:t,ctaProps:e?.cta});let{cta:n,background:a,cardTitleV2:s,cardBodyV2:l}=e,p=()=>{o(t+1)};return i($b,{cardTitleV2:s,cardBodyV2:l,background:i(j$,{...a,sizedSrcSets:IC}),callToAction:i(xC,{...n}),onActivate:p})};ac.displayName="GlobalNavHighlight";var n5=T(w());function iX(e,t){var o=[];return Va(e,function(n,a,s){t(n,a,s)&&o.push(n)}),o}var X$=iX;var sX="Expected a function";function lX(e){if(typeof e!="function")throw new TypeError(sX);return function(){var t=arguments;switch(t.length){case 0:return!e.call(this);case 1:return!e.call(this,t[0]);case 2:return!e.call(this,t[0],t[1]);case 3:return!e.call(this,t[0],t[1],t[2])}return!e.apply(this,t)}}var J$=lX;function pX(e,t){var o=Qo(e)?jI:X$;return o(e,J$(Jo(t,3)))}var Z$=pX;var o5=T(w());var t5=T(w());var e5=T(w());var cX=(e,t)=>!!e&&new RegExp(e).test(t),kC=({hideHostnameRegex:e,title:t,url:o,analytics:n})=>{let{onEvent:a,isUrlCurrent:s}=(0,e5.useContext)(ze),l=()=>{a&&a({action:sn.Click,component:"GlobalNavItem",label:n?.label,url:o})};return cX(e,window.location.hostname)?null:i(Yr,{title:t,href:o,showExternalIcon:!1,onClick:l,isSelected:s?.(o)})};kC.displayName="GlobalNavItem";var MC=({title:e,groupKey:t,itemsCollection:o,highlight:n,onGlobalNavGroupSummaryClick:a})=>{let{isUrlCurrent:s}=(0,t5.useContext)(ze),l=i(ac,{...n}),p=a?()=>a({navGroupKey:t,title:e}):void 0;return i(Nb,{navGroupKey:t,title:e,mobileHighlight:l,isExpandable:!0,isActive:o?.items.some(d=>s?.(d.url)),onSummaryClick:p,children:o?.items.map((d,u)=>i(kC,{...d},`nav-item-${u}`))})};MC.displayName="GlobalNavGroup";function dX(e,t){return[...e.filter(t),...Z$(e,t)]}var uX=(e,t)=>e.filter(o=>!o.hideHostnameRegex||new RegExp(o.hideHostnameRegex).test(t)),TC=({navGroups:e,onGlobalNavGroupSummaryClick:t})=>{let{hostname:o}=(0,o5.useContext)(ze),n=l=>!!l.primaryHostnameRegex&&new RegExp(l.primaryHostnameRegex).test(o),a=uX(e,o),s=dX(a,n);return i(pe,{children:s.map(l=>i(MC,{...l,onGlobalNavGroupSummaryClick:t},l.groupKey))})};TC.displayName="GlobalNavGroupCollection";var AC=e=>{let t=new Map;return e.navGroups.filter(o=>!!o.highlight).forEach(o=>{t.set(o.groupKey,i(ac,{...o.highlight}))}),i(S_,{highlights:t})};AC.displayName="GlobalNavHighlightCollection";var _C=({motifScheme:e,backgroundColor:t,localNavMobile:o,localNavMobileFooter:n,navGroups:a,globalNavHeading:s,showMobileGlobalLinks:l,onGlobalNavGroupSummaryClick:p})=>{let{toggleExpanded:d}=(0,n5.useContext)(at);return i(Gb,{localNavMobile:o,localNavMobileFooter:n,onNavClose:d??(()=>null),motifScheme:e,backgroundColor:t,globalNavHeading:s,highlight:i(AC,{navGroups:a}),globalNav:i(TC,{navGroups:a,onGlobalNavGroupSummaryClick:p}),showMobileGlobalLinks:l})};_C.displayName="GlobalNavGroupScreen";var xm=T(w());var r5=(e,t=!1,o)=>{let{onError:n}=(0,xm.useContext)(ze);(0,xm.useEffect)(()=>{if(!(!document||!e)&&!o?.skipPreload?.())if(t){let a=e.map(s=>{let l=document.createElement("link");return l.rel="preload",l.as=rc(s.contentType)?"video":"image",l.href=s.url,l});document.head.append(...a)}else for(let a of e)if(rc(a.contentType)){let s=document.createElement("video"),l=document.createElement("source");l.type=a.contentType,l.src=a.url,s.appendChild(l),s.load()}else if(hm(a.contentType)){if(!a.url)return;let s=document.createElement("picture"),l=document.createElement("source"),p=document.createElement("source"),d=document.createElement("img");if(a.url.endsWith(".svg"))d.src=a.url;else if(o?.sizedSrcSets){let{sizedSrcSets:u}=o;l.srcset=vr(a.url,{size:u},"avif"),l.type="image/avif",p.srcset=vr(a.url,{size:u},"webp"),p.type="image/webp",u.sizes&&(l.sizes=u.sizes,p.sizes=u.sizes,d.sizes=u.sizes),s.appendChild(l),s.appendChild(p),s.appendChild(d),d.srcset=vr(a.url,{size:u},"jpg")}else l.srcset=Tn({imageUrl:a.url,settings:{format:"avif"}}),l.type="image/avif",p.srcset=Tn({imageUrl:a.url,settings:{format:"webp"}}),p.type="image/webp",s.appendChild(l),s.appendChild(p),s.appendChild(d),d.src=a.url}else n?.(`Cannot preload assets of type ${a.contentType}`)},[e,t,n,o])};var a5=Lt.Black,yX="snapchat";at.displayName="GlobalHeaderContextSDSM";var mX={sizedSrcSets:IC,skipPreload:()=>window?window.innerWidth<=jo:!0},ic=({motifScheme:e,backgroundColor:t,className:o,defaultGroupKey:n,siteName:a,displayed:s,trackingSiteName:l,cta:p,ctaItems:d,localNavDesktop:u,localNavMenuItems:y,logo:m,logoProps:g,localNavMobile:f,localNavMobileFooter:b,onToggleExpanded:S,search:C,searchOpen:v,endChildrenDesktopClassName:k,endChildrenMobileClassName:I,showGlobalLinks:A=!0,showNavScreen:D,pathname:B,navItemAlignment:M,customIcon:_,lessMargins:P,addBottomBorder:$,headerClassName:R,onGlobalNavGroupSummaryClick:L})=>{let G=(0,Ua.useContext)(ze),{Anchor:Z,onEvent:U}=G,{data:de}=hn(F$,{currentLocale:G.currentLocale??xr,isPreview:G.isPreview??!1,isSSR:G.isSSR??!1},{client:G.globalApolloClient}),le=br(de?.globalNavConfigCollection.items),re=(0,Ua.useMemo)(()=>le?.globalNavGroupsCollection.items??[],[le?.globalNavGroupsCollection.items]),te=(0,Ua.useContext)(Ze),ae=md(te),oe=(0,Ua.useMemo)(()=>A?re.map(j=>j.highlight?.background).filter(j=>!!j):[],[re,A]);r5(oe,!1,mX);let q=j=>{U?.({component:"GlobalHeader",action:sn.Click,label:j?"expand":"collapse"}),S?.(j)},X=p??Ua.Children.toArray(d?.map((j,fe)=>i(no,{link:j.url,type:j.type,size:"Compact",onClick:j.onClick,children:j.title},fe))),W=v?C:x(pe,{children:[X,C]}),K=g?i(ki,{...g,logoType:"Ghost"}):null,F=!(v&&ae),Q=ae?I:k,z,Se;return f?z=f:y&&(z=y?.map(({id:j,url:fe,title:J,isSelected:ue,col1Label:_e,col1Items:we,col2Label:Be,col2Items:Ce,col3Label:We,col3Items:Pt,featuredItem:$e})=>i(Yr,{showExternalIcon:!1,href:fe,title:J,isSelected:ue,children:(we?.length||Ce?.length||Pt?.length||!!$e)&&i(zp,{col1Label:_e,col1Items:we,col2Label:Be,col2Items:Ce,col3Label:We,col3Items:Pt,featuredItem:$e})},j))),u?Se=u:y&&(Se=y?.map(({id:j,url:fe,title:J,isSelected:ue,col1Label:_e,col1Items:we,col2Label:Be,col2Items:Ce,col3Label:We,col3Items:Pt,featuredItem:$e})=>i(Gp,{url:fe,isSelected:ue,title:J??"",col1Label:_e,col1Items:we,col2Label:Be,col2Items:Ce,col3Label:We,col3Items:Pt,featuredItem:$e},j))),i(or,{value:{Anchor:Z},children:i(wb,{className:o,siteName:a,motifScheme:e,backgroundColor:t??a5,displayed:s,logo:F&&(m??K),onToggleExpanded:q,cta:W,localNavDesktop:Se,defaultGroupKey:n??yX,stayOpenInvariant:B,trackingSiteName:l??G.hostname,endChildrenClassName:v?Q:void 0,showGlobalLinks:A,showNavScreen:D,isUrlCurrent:G.isUrlCurrent,navItemAlignment:M,buttonAriaLabel:le?.globalNavButtonAriaLabel,lessMargins:P,addBottomBorder:$,customIcon:_,headerClassName:R,children:le&&i(_C,{motifScheme:e,backgroundColor:t??a5,localNavMobile:z,localNavMobileFooter:b,globalNavHeading:le?.globalNavLabel,navGroups:re,showMobileGlobalLinks:A,onGlobalNavGroupSummaryClick:L})})})};ic.displayName="GlobalHeader";function i5(e){var t=e||{},o=t.initial,n=o===void 0?300:o,a=t.jitter,s=a===void 0?!0:a,l=t.max,p=l===void 0?1/0:l,d=s?n:n/2;return function(y){var m=Math.min(p,d*Math.pow(2,y));return s&&(m=Math.random()*m),m}}function s5(e){var t=e||{},o=t.retryIf,n=t.max,a=n===void 0?5:n;return function(l,p,d){return l>=a?!1:o?o(d,p):!!d}}var gX=(function(){function e(t,o,n,a,s){var l=this;this.observer=t,this.operation=o,this.forward=n,this.delayFor=a,this.retryIf=s,this.retryCount=0,this.currentSubscription=null,this.onError=function(p){return rk(l,void 0,void 0,function(){var d;return ak(this,function(u){switch(u.label){case 0:return this.retryCount+=1,[4,this.retryIf(this.retryCount,this.operation,p)];case 1:return d=u.sent(),d?(this.scheduleRetry(this.delayFor(this.retryCount,this.operation,p)),[2]):(this.observer.error(p),[2])}})})},this.try()}return e.prototype.cancel=function(){this.currentSubscription&&this.currentSubscription.unsubscribe(),clearTimeout(this.timerId),this.timerId=void 0,this.currentSubscription=null},e.prototype.try=function(){this.currentSubscription=this.forward(this.operation).subscribe({next:this.observer.next.bind(this.observer),error:this.onError,complete:this.observer.complete.bind(this.observer)})},e.prototype.scheduleRetry=function(t){var o=this;if(this.timerId)throw new Error("RetryLink BUG! Encountered overlapping retries");this.timerId=setTimeout(function(){o.timerId=void 0,o.try()},t)},e})(),l5=(function(e){cd(t,e);function t(o){var n=e.call(this)||this,a=o||{},s=a.attempts,l=a.delay;return n.delayFor=typeof l=="function"?l:i5(l),n.retryIf=typeof s=="function"?s:s5(s),n}return t.prototype.request=function(o,n){var a=this;return new qi(function(s){var l=new gX(s,o,n,a.delayFor,a.retryIf);return function(){l.cancel()}})},t})(gn);var Rn=T(w());function vm(e,t){return vm=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(o,n){return o.__proto__=n,o},vm(e,t)}function An(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e,vm(e,t)}var wt=T(w()),LC=T(s0());function Im(e){return e.charAt(0)==="/"}function wC(e,t){for(var o=t,n=o+1,a=e.length;n<a;o+=1,n+=1)e[o]=e[n];e.pop()}function fX(e,t){t===void 0&&(t="");var o=e&&e.split("/")||[],n=t&&t.split("/")||[],a=e&&Im(e),s=t&&Im(t),l=a||s;if(e&&Im(e)?n=o:o.length&&(n.pop(),n=n.concat(o)),!n.length)return"/";var p;if(n.length){var d=n[n.length-1];p=d==="."||d===".."||d===""}else p=!1;for(var u=0,y=n.length;y>=0;y--){var m=n[y];m==="."?wC(n,y):m===".."?(wC(n,y),u++):u&&(wC(n,y),u--)}if(!l)for(;u--;u)n.unshift("..");l&&n[0]!==""&&(!n[0]||!Im(n[0]))&&n.unshift("");var g=n.join("/");return p&&g.substr(-1)!=="/"&&(g+="/"),g}var c5=fX;var bX=!0,DC="Invariant failed";function Ir(e,t){if(!e){if(bX)throw new Error(DC);var o=typeof t=="function"?t():t,n=o?"".concat(DC,": ").concat(o):DC;throw new Error(n)}}function lc(e){return e.charAt(0)==="/"?e:"/"+e}function d5(e){return e.charAt(0)==="/"?e.substr(1):e}function SX(e,t){return e.toLowerCase().indexOf(t.toLowerCase())===0&&"/?#".indexOf(e.charAt(t.length))!==-1}function b5(e,t){return SX(e,t)?e.substr(t.length):e}function S5(e){return e.charAt(e.length-1)==="/"?e.slice(0,-1):e}function hX(e){var t=e||"/",o="",n="",a=t.indexOf("#");a!==-1&&(n=t.substr(a),t=t.substr(0,a));var s=t.indexOf("?");return s!==-1&&(o=t.substr(s),t=t.substr(0,s)),{pathname:t,search:o==="?"?"":o,hash:n==="#"?"":n}}function wo(e){var t=e.pathname,o=e.search,n=e.hash,a=t||"/";return o&&o!=="?"&&(a+=o.charAt(0)==="?"?o:"?"+o),n&&n!=="#"&&(a+=n.charAt(0)==="#"?n:"#"+n),a}function Oo(e,t,o,n){var a;typeof e=="string"?(a=hX(e),a.state=t):(a=Co({},e),a.pathname===void 0&&(a.pathname=""),a.search?a.search.charAt(0)!=="?"&&(a.search="?"+a.search):a.search="",a.hash?a.hash.charAt(0)!=="#"&&(a.hash="#"+a.hash):a.hash="",t!==void 0&&a.state===void 0&&(a.state=t));try{a.pathname=decodeURI(a.pathname)}catch(s){throw s instanceof URIError?new URIError('Pathname "'+a.pathname+'" could not be decoded. This is likely caused by an invalid percent-encoding.'):s}return o&&(a.key=o),n?a.pathname?a.pathname.charAt(0)!=="/"&&(a.pathname=c5(a.pathname,n.pathname)):a.pathname=n.pathname:a.pathname||(a.pathname="/"),a}function NC(){var e=null;function t(l){return e=l,function(){e===l&&(e=null)}}function o(l,p,d,u){if(e!=null){var y=typeof e=="function"?e(l,p):e;typeof y=="string"?typeof d=="function"?d(y,u):u(!0):u(y!==!1)}else u(!0)}var n=[];function a(l){var p=!0;function d(){p&&l.apply(void 0,arguments)}return n.push(d),function(){p=!1,n=n.filter(function(u){return u!==d})}}function s(){for(var l=arguments.length,p=new Array(l),d=0;d<l;d++)p[d]=arguments[d];n.forEach(function(u){return u.apply(void 0,p)})}return{setPrompt:t,confirmTransitionTo:o,appendListener:a,notifyListeners:s}}var h5=!!(typeof window<"u"&&window.document&&window.document.createElement);function C5(e,t){t(window.confirm(e))}function CX(){var e=window.navigator.userAgent;return(e.indexOf("Android 2.")!==-1||e.indexOf("Android 4.0")!==-1)&&e.indexOf("Mobile Safari")!==-1&&e.indexOf("Chrome")===-1&&e.indexOf("Windows Phone")===-1?!1:window.history&&"pushState"in window.history}function xX(){return window.navigator.userAgent.indexOf("Trident")===-1}function vX(){return window.navigator.userAgent.indexOf("Firefox")===-1}function IX(e){return e.state===void 0&&navigator.userAgent.indexOf("CriOS")===-1}var u5="popstate",y5="hashchange";function m5(){try{return window.history.state||{}}catch{return{}}}function x5(e){e===void 0&&(e={}),h5||Ir(!1);var t=window.history,o=CX(),n=!xX(),a=e,s=a.forceRefresh,l=s===void 0?!1:s,p=a.getUserConfirmation,d=p===void 0?C5:p,u=a.keyLength,y=u===void 0?6:u,m=e.basename?S5(lc(e.basename)):"";function g(te){var ae=te||{},oe=ae.key,q=ae.state,X=window.location,W=X.pathname,K=X.search,F=X.hash,Q=W+K+F;return m&&(Q=b5(Q,m)),Oo(Q,q,oe)}function f(){return Math.random().toString(36).substr(2,y)}var b=NC();function S(te){Co(re,te),re.length=t.length,b.notifyListeners(re.location,re.action)}function C(te){IX(te)||I(g(te.state))}function v(){I(g(m5()))}var k=!1;function I(te){if(k)k=!1,S();else{var ae="POP";b.confirmTransitionTo(te,ae,d,function(oe){oe?S({action:ae,location:te}):A(te)})}}function A(te){var ae=re.location,oe=B.indexOf(ae.key);oe===-1&&(oe=0);var q=B.indexOf(te.key);q===-1&&(q=0);var X=oe-q;X&&(k=!0,$(X))}var D=g(m5()),B=[D.key];function M(te){return m+wo(te)}function _(te,ae){var oe="PUSH",q=Oo(te,ae,f(),re.location);b.confirmTransitionTo(q,oe,d,function(X){if(X){var W=M(q),K=q.key,F=q.state;if(o)if(t.pushState({key:K,state:F},null,W),l)window.location.href=W;else{var Q=B.indexOf(re.location.key),z=B.slice(0,Q+1);z.push(q.key),B=z,S({action:oe,location:q})}else window.location.href=W}})}function P(te,ae){var oe="REPLACE",q=Oo(te,ae,f(),re.location);b.confirmTransitionTo(q,oe,d,function(X){if(X){var W=M(q),K=q.key,F=q.state;if(o)if(t.replaceState({key:K,state:F},null,W),l)window.location.replace(W);else{var Q=B.indexOf(re.location.key);Q!==-1&&(B[Q]=q.key),S({action:oe,location:q})}else window.location.replace(W)}})}function $(te){t.go(te)}function R(){$(-1)}function L(){$(1)}var G=0;function Z(te){G+=te,G===1&&te===1?(window.addEventListener(u5,C),n&&window.addEventListener(y5,v)):G===0&&(window.removeEventListener(u5,C),n&&window.removeEventListener(y5,v))}var U=!1;function de(te){te===void 0&&(te=!1);var ae=b.setPrompt(te);return U||(Z(1),U=!0),function(){return U&&(U=!1,Z(-1)),ae()}}function le(te){var ae=b.appendListener(te);return Z(1),function(){Z(-1),ae()}}var re={length:t.length,action:"POP",location:D,createHref:M,push:_,replace:P,go:$,goBack:R,goForward:L,block:de,listen:le};return re}var g5="hashchange",kX={hashbang:{encodePath:function(t){return t.charAt(0)==="!"?t:"!/"+d5(t)},decodePath:function(t){return t.charAt(0)==="!"?t.substr(1):t}},noslash:{encodePath:d5,decodePath:lc},slash:{encodePath:lc,decodePath:lc}};function v5(e){var t=e.indexOf("#");return t===-1?e:e.slice(0,t)}function sc(){var e=window.location.href,t=e.indexOf("#");return t===-1?"":e.substring(t+1)}function MX(e){window.location.hash=e}function PC(e){window.location.replace(v5(window.location.href)+"#"+e)}function I5(e){e===void 0&&(e={}),h5||Ir(!1);var t=window.history,o=vX(),n=e,a=n.getUserConfirmation,s=a===void 0?C5:a,l=n.hashType,p=l===void 0?"slash":l,d=e.basename?S5(lc(e.basename)):"",u=kX[p],y=u.encodePath,m=u.decodePath;function g(){var oe=m(sc());return d&&(oe=b5(oe,d)),Oo(oe)}var f=NC();function b(oe){Co(ae,oe),ae.length=t.length,f.notifyListeners(ae.location,ae.action)}var S=!1,C=null;function v(oe,q){return oe.pathname===q.pathname&&oe.search===q.search&&oe.hash===q.hash}function k(){var oe=sc(),q=y(oe);if(oe!==q)PC(q);else{var X=g(),W=ae.location;if(!S&&v(W,X)||C===wo(X))return;C=null,I(X)}}function I(oe){if(S)S=!1,b();else{var q="POP";f.confirmTransitionTo(oe,q,s,function(X){X?b({action:q,location:oe}):A(oe)})}}function A(oe){var q=ae.location,X=_.lastIndexOf(wo(q));X===-1&&(X=0);var W=_.lastIndexOf(wo(oe));W===-1&&(W=0);var K=X-W;K&&(S=!0,L(K))}var D=sc(),B=y(D);D!==B&&PC(B);var M=g(),_=[wo(M)];function P(oe){var q=document.querySelector("base"),X="";return q&&q.getAttribute("href")&&(X=v5(window.location.href)),X+"#"+y(d+wo(oe))}function $(oe,q){var X="PUSH",W=Oo(oe,void 0,void 0,ae.location);f.confirmTransitionTo(W,X,s,function(K){if(K){var F=wo(W),Q=y(d+F),z=sc()!==Q;if(z){C=F,MX(Q);var Se=_.lastIndexOf(wo(ae.location)),j=_.slice(0,Se+1);j.push(F),_=j,b({action:X,location:W})}else b()}})}function R(oe,q){var X="REPLACE",W=Oo(oe,void 0,void 0,ae.location);f.confirmTransitionTo(W,X,s,function(K){if(K){var F=wo(W),Q=y(d+F),z=sc()!==Q;z&&(C=F,PC(Q));var Se=_.indexOf(wo(ae.location));Se!==-1&&(_[Se]=F),b({action:X,location:W})}})}function L(oe){t.go(oe)}function G(){L(-1)}function Z(){L(1)}var U=0;function de(oe){U+=oe,U===1&&oe===1?window.addEventListener(g5,k):U===0&&window.removeEventListener(g5,k)}var le=!1;function re(oe){oe===void 0&&(oe=!1);var q=f.setPrompt(oe);return le||(de(1),le=!0),function(){return le&&(le=!1,de(-1)),q()}}function te(oe){var q=f.appendListener(oe);return de(1),function(){de(-1),q()}}var ae={length:t.length,action:"POP",location:M,createHref:P,push:$,replace:R,go:L,goBack:G,goForward:Z,block:re,listen:te};return ae}function f5(e,t,o){return Math.min(Math.max(e,t),o)}function k5(e){e===void 0&&(e={});var t=e,o=t.getUserConfirmation,n=t.initialEntries,a=n===void 0?["/"]:n,s=t.initialIndex,l=s===void 0?0:s,p=t.keyLength,d=p===void 0?6:p,u=NC();function y(_){Co(M,_),M.length=M.entries.length,u.notifyListeners(M.location,M.action)}function m(){return Math.random().toString(36).substr(2,d)}var g=f5(l,0,a.length-1),f=a.map(function(_){return typeof _=="string"?Oo(_,void 0,m()):Oo(_,void 0,_.key||m())}),b=wo;function S(_,P){var $="PUSH",R=Oo(_,P,m(),M.location);u.confirmTransitionTo(R,$,o,function(L){if(L){var G=M.index,Z=G+1,U=M.entries.slice(0);U.length>Z?U.splice(Z,U.length-Z,R):U.push(R),y({action:$,location:R,index:Z,entries:U})}})}function C(_,P){var $="REPLACE",R=Oo(_,P,m(),M.location);u.confirmTransitionTo(R,$,o,function(L){L&&(M.entries[M.index]=R,y({action:$,location:R}))})}function v(_){var P=f5(M.index+_,0,M.entries.length-1),$="POP",R=M.entries[P];u.confirmTransitionTo(R,$,o,function(L){L?y({action:$,location:R,index:P}):y()})}function k(){v(-1)}function I(){v(1)}function A(_){var P=M.index+_;return P>=0&&P<M.entries.length}function D(_){return _===void 0&&(_=!1),u.setPrompt(_)}function B(_){return u.appendListener(_)}var M={length:f.length,action:"POP",location:f[g],index:g,entries:f,createHref:b,push:S,replace:C,go:v,goBack:k,goForward:I,canGo:A,block:D,listen:B};return M}var B5=T(D5()),uBe=T(BU());function Ys(e,t){if(e==null)return{};var o={};for(var n in e)if({}.hasOwnProperty.call(e,n)){if(t.indexOf(n)!==-1)continue;o[n]=e[n]}return o}var BX=T($U()),BC=1073741823,P5=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:{};function $X(){var e="__global_unique_id__";return P5[e]=(P5[e]||0)+1}function LX(e,t){return e===t?e!==0||1/e===1/t:e!==e&&t!==t}function HX(e){var t=[];return{on:function(n){t.push(n)},off:function(n){t=t.filter(function(a){return a!==n})},get:function(){return e},set:function(n,a){e=n,t.forEach(function(s){return s(e,a)})}}}function VX(e){return Array.isArray(e)?e[0]:e}function OX(e,t){var o,n,a="__create-react-context-"+$X()+"__",s=(function(p){An(d,p);function d(){for(var y,m=arguments.length,g=new Array(m),f=0;f<m;f++)g[f]=arguments[f];return y=p.call.apply(p,[this].concat(g))||this,y.emitter=HX(y.props.value),y}var u=d.prototype;return u.getChildContext=function(){var m;return m={},m[a]=this.emitter,m},u.componentWillReceiveProps=function(m){if(this.props.value!==m.value){var g=this.props.value,f=m.value,b;LX(g,f)?b=0:(b=typeof t=="function"?t(g,f):BC,b|=0,b!==0&&this.emitter.set(m.value,b))}},u.render=function(){return this.props.children},d})(wt.default.Component);s.childContextTypes=(o={},o[a]=LC.default.object.isRequired,o);var l=(function(p){An(d,p);function d(){for(var y,m=arguments.length,g=new Array(m),f=0;f<m;f++)g[f]=arguments[f];return y=p.call.apply(p,[this].concat(g))||this,y.observedBits=void 0,y.state={value:y.getValue()},y.onUpdate=function(b,S){var C=y.observedBits|0;(C&S)!==0&&y.setState({value:y.getValue()})},y}var u=d.prototype;return u.componentWillReceiveProps=function(m){var g=m.observedBits;this.observedBits=g??BC},u.componentDidMount=function(){this.context[a]&&this.context[a].on(this.onUpdate);var m=this.props.observedBits;this.observedBits=m??BC},u.componentWillUnmount=function(){this.context[a]&&this.context[a].off(this.onUpdate)},u.getValue=function(){return this.context[a]?this.context[a].get():e},u.render=function(){return VX(this.props.children)(this.state.value)},d})(wt.default.Component);return l.contextTypes=(n={},n[a]=LC.default.object,n),{Provider:s,Consumer:l}}var GX=wt.default.createContext||OX,$5=function(t){var o=GX();return o.displayName=t,o},L5=$5("Router-History"),kr=$5("Router"),Xs=(function(e){An(t,e),t.computeRootMatch=function(a){return{path:"/",url:"/",params:{},isExact:a==="/"}};function t(n){var a;return a=e.call(this,n)||this,a.state={location:n.history.location},a._isMounted=!1,a._pendingLocation=null,n.staticContext||(a.unlisten=n.history.listen(function(s){a._pendingLocation=s})),a}var o=t.prototype;return o.componentDidMount=function(){var a=this;this._isMounted=!0,this.unlisten&&this.unlisten(),this.props.staticContext||(this.unlisten=this.props.history.listen(function(s){a._isMounted&&a.setState({location:s})})),this._pendingLocation&&this.setState({location:this._pendingLocation})},o.componentWillUnmount=function(){this.unlisten&&(this.unlisten(),this._isMounted=!1,this._pendingLocation=null)},o.render=function(){return wt.default.createElement(kr.Provider,{value:{history:this.props.history,location:this.state.location,match:t.computeRootMatch(this.state.location.pathname),staticContext:this.props.staticContext}},wt.default.createElement(L5.Provider,{children:this.props.children||null,value:this.props.history}))},t})(wt.default.Component),zX=(function(e){An(t,e);function t(){for(var n,a=arguments.length,s=new Array(a),l=0;l<a;l++)s[l]=arguments[l];return n=e.call.apply(e,[this].concat(s))||this,n.history=k5(n.props),n}var o=t.prototype;return o.render=function(){return wt.default.createElement(Xs,{history:this.history,children:this.props.children})},t})(wt.default.Component),gBe=(function(e){An(t,e);function t(){return e.apply(this,arguments)||this}var o=t.prototype;return o.componentDidMount=function(){this.props.onMount&&this.props.onMount.call(this,this)},o.componentDidUpdate=function(a){this.props.onUpdate&&this.props.onUpdate.call(this,this,a)},o.componentWillUnmount=function(){this.props.onUnmount&&this.props.onUnmount.call(this,this)},o.render=function(){return null},t})(wt.default.Component);var N5={},UX=1e4,E5=0;function WX(e,t){var o=""+t.end+t.strict+t.sensitive,n=N5[o]||(N5[o]={});if(n[e])return n[e];var a=[],s=(0,B5.default)(e,a,t),l={regexp:s,keys:a};return E5<UX&&(n[e]=l,E5++),l}function pc(e,t){t===void 0&&(t={}),(typeof t=="string"||Array.isArray(t))&&(t={path:t});var o=t,n=o.path,a=o.exact,s=a===void 0?!1:a,l=o.strict,p=l===void 0?!1:l,d=o.sensitive,u=d===void 0?!1:d,y=[].concat(n);return y.reduce(function(m,g){if(!g&&g!=="")return null;if(m)return m;var f=WX(g,{end:s,strict:p,sensitive:u}),b=f.regexp,S=f.keys,C=b.exec(e);if(!C)return null;var v=C[0],k=C.slice(1),I=e===v;return s&&!I?null:{path:g,url:g==="/"&&v===""?"/":v,isExact:I,params:S.reduce(function(A,D,B){return A[D.name]=k[B],A},{})}},null)}function QX(e){return wt.default.Children.count(e)===0}var Wa=(function(e){An(t,e);function t(){return e.apply(this,arguments)||this}var o=t.prototype;return o.render=function(){var a=this;return wt.default.createElement(kr.Consumer,null,function(s){s||Ir(!1);var l=a.props.location||s.location,p=a.props.computedMatch?a.props.computedMatch:a.props.path?pc(l.pathname,a.props):s.match,d=Co({},s,{location:l,match:p}),u=a.props,y=u.children,m=u.component,g=u.render;return Array.isArray(y)&&QX(y)&&(y=null),wt.default.createElement(kr.Provider,{value:d},d.match?y?typeof y=="function"?y(d):y:m?wt.default.createElement(m,d):g?g(d):null:typeof y=="function"?y(d):null)})},t})(wt.default.Component);function HC(e){return e.charAt(0)==="/"?e:"/"+e}function qX(e,t){return e?Co({},t,{pathname:HC(e)+t.pathname}):t}function KX(e,t){if(!e)return t;var o=HC(e);return t.pathname.indexOf(o)!==0?t:Co({},t,{pathname:t.pathname.substr(o.length)})}function R5(e){return typeof e=="string"?e:wo(e)}function $C(e){return function(){Ir(!1)}}function F5(){}var VC=(function(e){An(t,e);function t(){for(var n,a=arguments.length,s=new Array(a),l=0;l<a;l++)s[l]=arguments[l];return n=e.call.apply(e,[this].concat(s))||this,n.handlePush=function(p){return n.navigateTo(p,"PUSH")},n.handleReplace=function(p){return n.navigateTo(p,"REPLACE")},n.handleListen=function(){return F5},n.handleBlock=function(){return F5},n}var o=t.prototype;return o.navigateTo=function(a,s){var l=this.props,p=l.basename,d=p===void 0?"":p,u=l.context,y=u===void 0?{}:u;y.action=s,y.location=qX(d,Oo(a)),y.url=R5(y.location)},o.render=function(){var a=this.props,s=a.basename,l=s===void 0?"":s,p=a.context,d=p===void 0?{}:p,u=a.location,y=u===void 0?"/":u,m=Ys(a,["basename","context","location"]),g={createHref:function(b){return HC(l+R5(b))},action:"POP",location:KX(l,Oo(y)),push:this.handlePush,replace:this.handleReplace,go:$C("go"),goBack:$C("goBack"),goForward:$C("goForward"),listen:this.handleListen,block:this.handleBlock};return wt.default.createElement(Xs,Co({},m,{history:g,staticContext:d}))},t})(wt.default.Component),OC=(function(e){An(t,e);function t(){return e.apply(this,arguments)||this}var o=t.prototype;return o.render=function(){var a=this;return wt.default.createElement(kr.Consumer,null,function(s){s||Ir(!1);var l=a.props.location||s.location,p,d;return wt.default.Children.forEach(a.props.children,function(u){if(d==null&&wt.default.isValidElement(u)){p=u;var y=u.props.path||u.props.from;d=y?pc(l.pathname,Co({},u.props,{path:y})):s.match}}),d?wt.default.cloneElement(p,{location:l,computedMatch:d}):null})},t})(wt.default.Component);var H5=wt.default.useContext;function na(){return H5(L5)}function zt(){return H5(kr).location}var _n=T(w());var V5=(function(e){An(t,e);function t(){for(var n,a=arguments.length,s=new Array(a),l=0;l<a;l++)s[l]=arguments[l];return n=e.call.apply(e,[this].concat(s))||this,n.history=x5(n.props),n}var o=t.prototype;return o.render=function(){return _n.default.createElement(Xs,{history:this.history,children:this.props.children})},t})(_n.default.Component),wBe=(function(e){An(t,e);function t(){for(var n,a=arguments.length,s=new Array(a),l=0;l<a;l++)s[l]=arguments[l];return n=e.call.apply(e,[this].concat(s))||this,n.history=I5(n.props),n}var o=t.prototype;return o.render=function(){return _n.default.createElement(Xs,{history:this.history,children:this.props.children})},t})(_n.default.Component),GC=function(t,o){return typeof t=="function"?t(o):t},zC=function(t,o){return typeof t=="string"?Oo(t,null,null,o):t},UC=function(t){return t},Js=_n.default.forwardRef;typeof Js>"u"&&(Js=UC);function jX(e){return!!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)}var YX=Js(function(e,t){var o=e.innerRef,n=e.navigate,a=e.onClick,s=Ys(e,["innerRef","navigate","onClick"]),l=s.target,p=Co({},s,{onClick:function(u){try{a&&a(u)}catch(y){throw u.preventDefault(),y}!u.defaultPrevented&&u.button===0&&(!l||l==="_self")&&!jX(u)&&(u.preventDefault(),n())}});return UC!==Js?p.ref=t||o:p.ref=o,_n.default.createElement("a",p)}),cc=Js(function(e,t){var o=e.component,n=o===void 0?YX:o,a=e.replace,s=e.to,l=e.innerRef,p=Ys(e,["component","replace","to","innerRef"]);return _n.default.createElement(kr.Consumer,null,function(d){d||Ir(!1);var u=d.history,y=zC(GC(s,d.location),d.location),m=y?u.createHref(y):"",g=Co({},p,{href:m,navigate:function(){var b=GC(s,d.location),S=wo(d.location)===wo(zC(b)),C=a||S?u.replace:u.push;C(b)}});return UC!==Js?g.ref=t||l:g.innerRef=l,_n.default.createElement(n,g)})});var O5=function(t){return t},Mm=_n.default.forwardRef;typeof Mm>"u"&&(Mm=O5);function XX(){for(var e=arguments.length,t=new Array(e),o=0;o<e;o++)t[o]=arguments[o];return t.filter(function(n){return n}).join(" ")}var DBe=Mm(function(e,t){var o=e["aria-current"],n=o===void 0?"page":o,a=e.activeClassName,s=a===void 0?"active":a,l=e.activeStyle,p=e.className,d=e.exact,u=e.isActive,y=e.location,m=e.sensitive,g=e.strict,f=e.style,b=e.to,S=e.innerRef,C=Ys(e,["aria-current","activeClassName","activeStyle","className","exact","isActive","location","sensitive","strict","style","to","innerRef"]);return _n.default.createElement(kr.Consumer,null,function(v){v||Ir(!1);var k=y||v.location,I=zC(GC(b,k),k),A=I.pathname,D=A&&A.replace(/([.+*?=^!:${}()[\]|/\\])/g,"\\$1"),B=D?pc(k.pathname,{path:D,exact:d,sensitive:m,strict:g}):null,M=!!(u?u(B,k):B),_=typeof p=="function"?p(M):p,P=typeof f=="function"?f(M):f;M&&(_=XX(_,s),P=Co({},P,l));var $=Co({"aria-current":M&&n||null,className:_,style:P,to:I},C);return O5!==Mm?$.ref=t||S:$.innerRef=S,_n.default.createElement(cc,$)})});var Tm=T(w()),JX=T(ma());var ZX="mwp-app-portal",G5=(0,Tm.memo)(e=>{let{appPortalRef:t}=(0,Tm.useContext)(ee);return i("aside",{className:e.className,"data-testid":ZX,ref:t})});var _m=T(w());var eJ=[V.domainName,`www.${V.domainName}`,"localhost","127.0.0.1","[::]","[::1]",/.*-dot-entapps-web-dev.gae.sc-corp.net/],un=e=>{for(let t of eJ)if(typeof t=="string"&&e.hostname===t||typeof t=="object"&&t.test(e.hostname))return!0;return!1},io=e=>{if(!e)return!1;try{let t=new URL(e);return un(t)?!1:(V.sameTabDomains??[]).some(n=>t.hostname===n)}catch{}return!1},WC=e=>(t,o)=>{let n=new URL(e()),a=new URL(t,n);if(!un(a))return!1;if(a.pathname==="/")return n.pathname==="/";if(!o?.ignoredPathPrefix)return n.pathname===a.pathname;let s=new RegExp(`^${o.ignoredPathPrefix}`);return n.pathname.replace(s,"")===a.pathname};var z5=[...V.persistentQueryParams??[],"gtm_debug","alternateMotif","mwp_debug"],U5=["lang"],W5=(e,t)=>un(e)?!0:[...V.sameTabDomains??[],t.hostname].some(n=>e.hostname===n),Q5=(e,t)=>{if(un(e))return!0;let o=new Set(V.persistQueryParamsDomains??[]);return o.add(t.hostname),o.has(e.hostname)};var q5="businesshelp.snapchat.com",tJ={ar:"ar","da-DK":"da","de-DE":"de","el-GR":"el","en-GB":"en_GB","en-US":"en_US","es-ES":"es","es-MX":"es_MX","fi-FI":"fi","fr-CA":"fr","fr-FR":"fr","id-ID":"in","it-IT":"it","ja-JP":"ja","ko-KR":"ko","nb-NO":"no","nl-NL":"nl_NL","pl-PL":"pl","pt-BR":"pt_BR","pt-PT":"pt_PT","ru-RU":"ru","sv-SE":"sv","th-TH":"th","tr-TR":"tr","vi-VN":"vi","zh-Hans":"zh_CN","zh-Hant":"zh_TW"},K5=(e,t)=>{let o=tJ[t];o&&!e.searchParams.has("language")&&e.searchParams.set("language",o)};var oJ="http://",QBe=oJ.toUpperCase(),nJ="https://",qBe=nJ.toUpperCase();var rJ=(e,t,o)=>{let n=e.searchParams.get("referrer"),a=n?new URL(n):null;for(let s of o){let l=e.searchParams.get(s)??t.searchParams.get(s)??a?.searchParams.get(s);l&&(e.searchParams.set(s,l),a?.searchParams.set(s,l))}a&&e.searchParams.set("referrer",a.href)},Am=(e,t,o=[])=>{rJ(e,t,[...M0,...Object.keys(k0),...o])},aJ=e=>e.hostname.includes("snap.com")||e.hostname.includes("snapchat.com")||e.hostname.includes("pixy.com")||e.hostname.includes("yellowla.com")||e.hostname.includes("spectacles.com")||e.hostname.includes("arcadiacreativestudio.com"),j5=(e,t)=>{!t||!aJ(e)||(e.hostname===q5?K5(e,t):e.searchParams.has("lang")||e.searchParams.set("lang",t))};var iJ=Object.keys(_d);function Y5(e){if(!e.destination)return{};let t=new URL(e.destination,e.currentUrl),o=W5(t,e.currentUrl),n=Q5(t,e.currentUrl),a=e.newTab!==void 0?e.newTab:!o,s=un(t);if(e.isDownload)return{href:t.href,rel:s?"opener":"noopener",target:"_blank"};let l=[...n?z5:[],...U5];if(Am(t,e.currentUrl,l),s||j5(t,e.locale),s){let p=iJ.find(d=>t.pathname.match(`^/${d}(/|$)`));p&&(t.pathname=t.pathname.replace(`/${p}`,""))}return s&&t.pathname.length>1&&t.pathname[t.pathname.length-1]==="/"&&(t.pathname=t.pathname.slice(0,-1)),{href:t.href,rel:s?"opener":"noopener",target:a?"_blank":"_self"}}var dc=null,X5=()=>{if(dc!==null)return dc;if(typeof window>"u"||typeof window.matchMedia!="function")return!1;let e=window.matchMedia("(prefers-reduced-motion: reduce)");return dc=e.matches,e.addEventListener("change",t=>{dc=t.matches}),dc};var yn=(0,_m.forwardRef)((e,t)=>{let{currentLocale:o,getCurrentUrl:n}=(0,_m.useContext)(ee);if(!e.href)return i("a",{...e,ref:t});let a=new URL(n()),s=Y5({destination:e.href,currentUrl:a,locale:o,isDownload:e.download}),l=new URL(s.href,a);if(un(l)){let{href:p,onClick:d,...u}=e;return i(cc,{...u,onClick:m=>{d?.(m);let g=m.metaKey||m.altKey||m.ctrlKey||m.shiftKey;if(m.defaultPrevented||m.button!==0||g)return;let f=new URL(n());!l.hash&&l.pathname===f.pathname&&l.search===f.search&&(document.body.tabIndex=-1,document.body.focus({preventScroll:!0}),document.body.removeAttribute("tabindex"),window.scrollTo({top:0,behavior:X5()?"auto":"smooth"}))},ref:t,to:{pathname:l.pathname,search:l.search,hash:l.hash},target:"_self"})}return i("a",{ref:t,...e,...s})});var mc=T(w());var J5=T(w()),be=(0,J5.createContext)({elementLocation:void 0});var Qn=T(w());var bL=T(w());var Ut=T(w());var Qa=T(w());var wm=T(w());var Z5=T(w()),en=(0,Z5.createContext)({currentLocale:"en-US",supportedLocales:{}});function sJ(e){return typeof e=="function"?e:id}var eL=sJ;function lJ(e,t){var o=Qo(e)?KI:Va;return o(e,eL(t))}var tL=lJ;var oL=e=>{let t="";return tL(e,(o,n)=>{Ct(o)||(t.length===0?t=`${n}=${o}`:t=`${t}&${n}=${o}`)}),t},nL=e=>{let t={};return new URLSearchParams(e).forEach((o,n)=>{o&&(t[n]=o)}),t};var Zs=()=>{let{search:e}=zt(),{getUrlParams:t}=(0,wm.useContext)(en);return(0,wm.useMemo)(()=>{let o=t?.()??{};return new URLSearchParams(o)},[e,t])};var pJ="view",rL=({view:e,queryParameterName:t=pJ,onOpen:o,onClose:n,ignore:a=!1})=>{let s=na(),{search:l}=zt(),p=Zs(),d=p.get(t),u=e??"",y=u!=="",m=!a&&y&&d===u,[g,f]=(0,Qa.useState)(()=>m);(0,Qa.useEffect)(()=>{f(m)},[m]);let b=(0,Qa.useCallback)(v=>{let k=new URLSearchParams(p);v===void 0?k.delete(t):k.set(t,v);let I=k.toString(),A=I?`?${I}`:"";A!==l&&s.push({hash:s.location.hash,pathname:s.location.pathname,search:A})},[s,t,p,l]),S=(0,Qa.useCallback)(()=>{a||!y||(f(!0),b(u),o?.())},[u,y,a,o,b]);return{closeDrawer:(0,Qa.useCallback)(()=>{a||!g&&!m||(f(!1),m&&b(void 0),n?.())},[a,g,n,m,b]),isOpen:g,openDrawer:S}};var go=T(w());async function aL(e,t){let o=new URLSearchParams({market:e});t&&o.set("lang",t);try{let n=await fetch(`/api/shopify/products?${o.toString()}`,{cache:"no-store",credentials:"same-origin"});return n.ok?await n.json():null}catch{return null}}var QC="mwp-stinson-market",el="OTHER";function tl(e){return e===el||sL(e)}var iL=[{countryCode:"US",currencyCode:"USD"},{countryCode:"FR",currencyCode:"EUR"},{countryCode:"GB",currencyCode:"GBP"}];function cJ(e){if(e)return iL.find(t=>t.countryCode===e)}function sL(e){return cJ(e)!==void 0}function Dm(){return iL[0]}function lL(e){let t=Array.isArray(e)?e[0]:e;if(!t)return;let o=t.toUpperCase();return tl(o)?o:void 0}function pL(e){if(e)return tl(e)?e.toLowerCase():void 0}function cL(e){let t=Array.isArray(e.queryParam)?e.queryParam[0]:e.queryParam;return tl(t)?t:sL(e.geoCountry)?e.geoCountry:e.fallback??Dm().countryCode}var dJ=({node:e},t)=>{let o=Number(e.price.amount??"0"),n=t!=null&&t!==o;return{id:e.id,title:e.title,sku:e.sku,price:t??o,...n?{dueTodayPrice:o}:{},available:e.availableForSale,selectedOptions:e.selectedOptions.map(({name:a,value:s})=>({name:a,value:s})),compareAtPrice:e.compareAtPrice??null,currencyCode:e.price.currencyCode,quantityAvailable:e.quantityAvailable??null,quantityRule:e.quantityRule}},uJ=(e,t)=>{if(!e)return;let o=l=>Vr({component:"ShopifyProvider",message:`issue with "${t}.sellingplandata": ${l}`}),n;try{n=JSON.parse(e)}catch{o("invalid JSON \u2014 skipping");return}if(!n||typeof n!="object"||Array.isArray(n)){o(`expected an object keyed by currency code, got ${Array.isArray(n)?"array":typeof n}`);return}let a=Object.entries(n);if(a.length===0){o("object is empty");return}let s={};for(let[l,p]of a){if(!p||typeof p!="object"){o(`currency "${l}" value is not an object`);return}let d=p;if(typeof d.amount!="number"||d.amount<=0){o(`currency "${l}" has invalid amount: ${JSON.stringify(d.amount)}`);return}let u=typeof d.selling_plan_id=="number"?`gid://shopify/SellingPlan/${d.selling_plan_id}`:void 0;s[l.toUpperCase()]={sellingPlanId:u,amount:d.amount}}return s},yJ=(e,t,o)=>{let n=(d,u)=>Re({component:"ShopifyProvider",message:`issue with "${t}.finalpricedata": ${d}`,error:u});if(!e){n("empty value \u2014 falling back to Shopify price");return}let a;try{a=JSON.parse(e)}catch(d){n("invalid JSON \u2014 falling back to Shopify price",d);return}if(!a||typeof a!="object"||Array.isArray(a)){n(`expected an object keyed by currency code, got ${Array.isArray(a)?"array":typeof a}`);return}let s=a[o.toUpperCase()];if(!s||typeof s!="object"||Array.isArray(s)){n(`missing valid "${o}" entry \u2014 falling back to Shopify price`);return}let{amount:l}=s,p=Number(l);if(!Number.isFinite(p)||p<=0){n(`currency "${o}" has invalid amount: ${JSON.stringify(l)}`);return}return p},mJ=(e,t)=>{let o=e?.find(a=>a?.namespace==="custom"&&a?.key==="maxquantity");if(o?.value)return Number.parseInt(o.value);let n=t?.node.metafields?.find(a=>a?.key==="maxQuantity");return n?Number.parseInt(n.value):void 0},gJ=(e,t,o)=>{let n=e?.node.metafields?.find(a=>a?.key==="ATPBufferDays");return n?o({available:t,atp:Number.parseInt(n.value)}):null},dL=(e,t)=>{let o={},n={};if(!e)return{catalog:o,productOptionById:n};for(let{node:a}of e.products.edges){let s=a.handle,l=a.variants.edges[0],p=a.priceRange.maxVariantPrice.currencyCode,d=a.metafields?.find(b=>b?.namespace==="custom"&&b?.key==="sellingplandata"),u=a.metafields?.find(b=>b?.namespace==="custom"&&b?.key==="finalpricedata"),y=u?yJ(u.value,s,p):void 0,m=y!=null?void 0:uJ(d?.value,s),g=a.variants.edges.map(b=>dJ(b,y)),f={productKey:s,nodeId:a.id,title:a.title,featuredImage:a.featuredImage?.url,images:a.images?.edges.map(b=>b.node)??[],available:a.availableForSale,options:g,maxQuantity:mJ(a.metafields,l),currencyCode:p,atpMessage:gJ(l,a.availableForSale,t),...m?{sellingPlan:{depositData:m,requiresPlan:a.requiresSellingPlan??!1}}:{}};o[s]=f;for(let b of g)n[b.id]={productKey:s,option:b}}return{catalog:o,productOptionById:n}};var fJ={catalog:{},productOptionById:{}},Kt=(0,go.createContext)(fJ),qC=({children:e,shopifyData:t})=>{let{userLocation:{country:o}}=(0,go.useContext)(ee),{formatMessage:n}=(0,go.useContext)(qe),{currentLocale:a}=(0,go.useContext)(ze),s=na(),l=Zs(),[p,d]=(0,go.useState)(t),u=(0,go.useRef)(),y=(0,go.useCallback)(({available:B,atp:M=0})=>{if(M===0&&B)return n({id:"shopifyATPTodayFreeShipping",defaultMessage:"Ships for free today"});if(M>0&&B){if(M<7)return M===1?n({id:"shopifyATPDayFreeShipping",defaultMessage:"Ships for free in 1 day"}):n({id:"shopifyATPDaysFreeShipping",defaultMessage:"Ships for free in {days} days"},{days:String(M)});let _=M%7,P=(M-_)/7,$=`${P}-${P+1}`;return P===1?n({id:"shopifyATPWeekFreeShipping",defaultMessage:"Ships for free in 1 week"}):n({id:"shopifyATPWeeksFreeShipping",defaultMessage:"Ships for free in {weeks} weeks"},{weeks:$})}return null},[n]),m=(0,go.useMemo)(()=>cL({queryParam:lL(l.get("market")),geoCountry:o,fallback:el}),[o,l]),g=m===el?Dm().countryCode:m,f=(0,go.useCallback)(async B=>{if(typeof window>"u"||!tl(B))return;let M=B===el?Dm().countryCode:B,_=(a??"en-US").slice(0,2).toUpperCase();u.current=B;let P=await aL(M,_);if(u.current!==B||!P)return;ci(QC,B);let $=new URL(window.location.href);$.searchParams.set("market",pL(B)??B),s.replace(`${$.pathname}${$.search}${$.hash}`),d(P)},[a,s]);if((0,go.useEffect)(()=>{if(typeof window>"u"||l.has("market"))return;let B=rs(QC);tl(B)&&B!==m&&f(B)},[m,l,f]),!V.shopify)return i(pe,{children:e});let{catalog:b,productOptionById:S}=dL(p,y),C=V.shopify?.singleStoreMode===!0,v;if(C){let B=Object.keys(V.shopify?.stores??{});v=V.shopify.stores[B[0]]?.[V.deploymentType]}else{let B=V.shopify?.stores[g];v=B?B[V.deploymentType]:void 0}let I=Object.values(b)[0]?.currencyCode??p?.shop.paymentSettings.currencyCode,D=l.has("market")?m!==el:p?.shop?.shipsToCountries?.includes(o)??void 0;return i(Kt.Provider,{value:{catalog:b,productOptionById:S,store:v,currencyCode:I,shopData:p?.shop,rawShopifyResponse:p,isCountrySupported:D,market:g,setMarket:f},children:e})};var uL=(e,t,o)=>{let n=t?.sellingPlan?.depositData&&o?t.sellingPlan.depositData[o]?.amount:void 0;return e.dueTodayPrice??n??e.price};var KC="???",_i=({catalog:e,currencyCode:t,lines:o,productOptionById:n})=>{let a=0,s=o.map(({optionId:p,quantity:d})=>{let u=n[p],y=u?.option,m=u?e[u.productKey]:void 0;if(!m||!y)return Vr({component:"Cart",message:`Unable to resolve product/option for cart analytics; logging placeholder values. productKey: ${u?.productKey??"undefined"}, optionId: ${p}`}),{item_id:KC,item_name:KC,item_variant:KC,price:0,quantity:d,shopify_id:p};let g=uL(y,m,t??void 0);return a+=g*d,{item_id:y.sku,item_name:m.title,item_variant:y.title,price:g,quantity:d,shopify_id:p}}),l=V.shopify?.options?.getExtraEcommerceItems?.(o);return l?.length&&s.push(...l),{value:a,currency:t??null,items:s}};var aa=(e,t,o)=>{if(e.optionId!==t)return!1;let n=o??{},a=e.attributes??{},s=Object.keys(n);return s.length!==Object.keys(a).length?!1:s.every(l=>n[l]===a[l])},yL={lines:[],isHydrated:!1},mL=(e,t)=>{switch(t.type){case"hydrate":return{lines:t.lines,isHydrated:!0};case"addLine":{let{optionId:o,productKey:n,attributes:a}=t,s=e.lines.findIndex(p=>aa(p,o,a)),l=s>=0?e.lines.map((p,d)=>d===s?{...p,quantity:p.quantity+1}:p):[...e.lines,{optionId:o,productKey:n,quantity:1,...a?{attributes:a}:{}}];return{...e,lines:l}}case"removeLine":{let{optionId:o,attributes:n}=t,a=e.lines.findIndex(p=>aa(p,o,n));if(a<0)return e;let l=e.lines[a].quantity<=1?e.lines.filter((p,d)=>d!==a):e.lines.map((p,d)=>d===a?{...p,quantity:p.quantity-1}:p);return{...e,lines:l}}case"removeLineEntirely":{let{optionId:o,attributes:n}=t,a=e.lines.findIndex(s=>aa(s,o,n));return a<0?e:{...e,lines:e.lines.filter((s,l)=>l!==a)}}case"updateLine":{let{optionId:o,attributes:n,newOptionId:a,newAttributes:s}=t,l=e.lines.findIndex(m=>aa(m,o,n)),p=e.lines[l];if(!p)return e;let d=e.lines.findIndex(m=>aa(m,a,s)),u=s&&Object.keys(s).length>0,y=d>=0&&d!==l?e.lines.map((m,g)=>g===d?{...m,quantity:m.quantity+p.quantity}:m).filter((m,g)=>g!==l):e.lines.map((m,g)=>g===l?{productKey:p.productKey,quantity:p.quantity,optionId:a,...u?{attributes:s}:{}}:m);return{...e,lines:y}}case"clearCart":return{...e,lines:[]};default:return e}};var gL="mwp-shopify-cart",fL={lines:[],cartOpen:!1,isHydrated:!1,addLine:nr,removeLine:nr,removeLineEntirely:nr,updateLine:nr,clearCart:nr,setCartOpen:nr,discountCode:"",setDiscountCode:nr},bJ=e=>{try{return new URL(e).searchParams.get("discount")??""}catch{return""}},SJ=e=>{if(!e||typeof e!="object")return null;let t=e;if("lineItems"in t&&!("lines"in t)||!Array.isArray(t.lines))return null;let o=t.lines;for(let n of o){if(!n||typeof n!="object")return null;let a=n;if(typeof a.optionId!="string"||typeof a.productKey!="string"||typeof a.quantity!="number"||a.quantity<1||a.attributes!==void 0&&(typeof a.attributes!="object"||a.attributes===null||!Object.values(a.attributes).every(s=>typeof s=="string")))return null}return t.lines},hJ=e=>{ci(gL,JSON.stringify({lines:e}))};var jC=()=>{let e=(0,Ut.useContext)(ee),{elementLocation:t}=(0,Ut.useContext)(be),{catalog:o,productOptionById:n}=(0,Ut.useContext)(Kt),a=e.userLocation.country,s=bJ(e.getCurrentUrl()),[{lines:l,isHydrated:p},d]=(0,Ut.useReducer)(mL,yL),[u,y]=(0,Ut.useState)(s),{isOpen:m,openDrawer:g,closeDrawer:f}=rL({view:"cart"}),b=(0,Ut.useCallback)(B=>{ot({eventCategory:"Cart",eventAction:"Click",eventLabel:B?"Open Cart":"Close Cart",subscribedEventType:"user_interaction"}),B?g():f()},[g,f]),S=(0,Ut.useCallback)(({productKey:B,optionId:M,currencyCode:_,openCart:P=!1,attributes:$})=>{o[B]&&(d({type:"addLine",optionId:M,productKey:B,attributes:$}),ot({subscribedEventType:"ecommerce",eventCategory:"Cart",eventAction:"Add",eventLabel:M,context:{elementLocation:t},eventName:"add_to_cart",ecommerce:_i({catalog:o,currencyCode:_,lines:[{optionId:M,quantity:1,attributes:$}],productOptionById:n})}),P&&g())},[o,t,g,n]),C=(0,Ut.useCallback)(({productKey:B,optionId:M,currencyCode:_,attributes:P})=>{!o[B]||l.findIndex(L=>aa(L,M,P))<0||(d({type:"removeLine",optionId:M,attributes:P}),ot({subscribedEventType:"ecommerce",eventCategory:"Cart",eventAction:"Remove",eventLabel:M,context:{elementLocation:t},eventName:"remove_from_cart",ecommerce:_i({catalog:o,currencyCode:_,lines:[{optionId:M,quantity:1,attributes:P}],productOptionById:n})}))},[l,o,t,n]),v=(0,Ut.useCallback)(({productKey:B,optionId:M,currencyCode:_,attributes:P})=>{if(!o[B])return;let R=l.findIndex(G=>aa(G,M,P));if(R<0)return;let L=l[R].quantity;d({type:"removeLineEntirely",optionId:M,attributes:P}),ot({subscribedEventType:"ecommerce",eventCategory:"Cart",eventAction:"Remove",eventLabel:M,context:{elementLocation:t},eventName:"remove_from_cart",ecommerce:_i({catalog:o,currencyCode:_,lines:[{optionId:M,quantity:L,attributes:P}],productOptionById:n})})},[l,o,t,n]),k=(0,Ut.useCallback)(({productKey:B,optionId:M,currencyCode:_,attributes:P,newOptionId:$,newAttributes:R})=>{if(!o[B]||M===$&&is(P??{},R??{}))return;let G=l.find(U=>aa(U,M,P));if(!G)return;let Z=G.quantity;d({type:"updateLine",optionId:M,attributes:P,newOptionId:$,newAttributes:R}),ot({subscribedEventType:"ecommerce",eventCategory:"Cart",eventAction:"Edit > Remove",eventLabel:M,context:{elementLocation:t},eventName:"remove_from_cart",ecommerce:_i({catalog:o,currencyCode:_,lines:[{optionId:M,quantity:Z,attributes:P}],productOptionById:n})}),ot({subscribedEventType:"ecommerce",eventCategory:"Cart",eventAction:"Edit > Add",eventLabel:$,context:{elementLocation:t},eventName:"add_to_cart",ecommerce:_i({catalog:o,currencyCode:_,lines:[{optionId:$,quantity:Z,attributes:R}],productOptionById:n})})},[l,o,t,n]),I=(0,Ut.useCallback)(({currencyCode:B})=>{l.length&&ot({subscribedEventType:"ecommerce",eventCategory:"Cart",eventAction:"Clear",eventLabel:null,context:{elementLocation:t},eventName:"remove_from_cart",ecommerce:_i({catalog:o,currencyCode:B,lines:l,productOptionById:n})}),d({type:"clearCart"})},[l,o,t,n]),A=(0,Ut.useCallback)(()=>{let B=rs(gL);if(B)try{let M=JSON.parse(B),_=SJ(M);if(_){d({type:"hydrate",lines:_});return}}catch{}d({type:"hydrate",lines:[]})},[]);(0,Ut.useEffect)(()=>{V.shopify&&A()},[a,A]);let D=(0,Ut.useRef)(!1);return(0,Ut.useEffect)(()=>{if(!D.current){D.current=!0;return}hJ(l)},[l]),{lines:l,cartOpen:m,isHydrated:p,addLine:S,removeLine:C,removeLineEntirely:v,updateLine:k,clearCart:I,setCartOpen:b,discountCode:u,setDiscountCode:y}};var tn=(0,bL.createContext)(fL),Pm=({children:e})=>{let t=jC();return i(tn.Provider,{value:t,children:e})};Pm.displayName="CartProvider";var Nm=T(w());var CJ=e=>{let t=new Map;for(let o of e)t.set(o.productKey,(t.get(o.productKey)??0)+o.quantity);return t},YC=e=>{let{lines:t}=(0,Nm.useContext)(tn);return(0,Nm.useMemo)(()=>e?CJ(t).get(e)??0:0,[t,e])};var xJ=[2560,1440,1024,768,425,375,320],k$e=xJ.reverse();var wi=e=>`@media (min-width: ${e}px)`,Mr={over320_mobile_small:wi(320),over375_mobile_medium:wi(375),over425_mobile_large:wi(425),over768_desktop_small:wi(768),over1024_desktop_medium:wi(1024),over1440_desktop_large:wi(1440),over2560_desktop_larger:wi(2560)};var SL=c`
  color: ${r("--palette-gray-v300")};
  border: 1px solid ${r("--palette-gray-v300")};
  background-color: ${r("--palette-gray-v200")};
`,XC=c`
  position: relative;
  margin-top: ${16}px;
`,hL=c`
  background: ${r("--palette-black-v200")};
  border-radius: 6px;
  box-shadow: 0px 6px 12px 4px rgba(0, 0, 0, 0.1);
  color: ${r("--palette-plain-white")};
  font-size: 14px;
  font-weight: 700;
  position: absolute;
  bottom: 125%;
  left: 0;
  padding: 6px 7px;
  text-align: center;
  width: 100%;

  &:after {
    content: '';
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: ${r("--palette-black-v200")} transparent transparent transparent;
  }

  ${Mr.over768_desktop_small} {
    padding: 6px ${8}px;
  }
`;var IJ=({productKey:e="",optionId:t,showTooltip:o,label:n,buttonClassName:a,onAfterAdd:s,hideMaxQuantityTooltip:l,openCart:p=!0,attributes:d,forceDisabled:u})=>{let y=(0,Qn.useContext)(tn),{catalog:m,currencyCode:g=""}=(0,Qn.useContext)(Kt),f=m[e],b=(0,Qn.useContext)(be).elementLocation,S=YC(e);if(!f)return null;let C=t||f.options[0]?.id,v=f.maxQuantity!=null&&S>=f.maxQuantity,k=v||!f.available||!!u,I=()=>v?i(Ln,{id:"maxCartQuantity",values:{quantity:String(f.maxQuantity)},defaultMessage:"Limit {quantity} per customer."}):null,A=()=>{k||(ge({eventCategory:"AddToCart",eventAction:"Click",eventLabel:`add_to_cart: ${e}`,context:{elementText:"Add to Cart",elementLocation:b}}),y.addLine({productKey:e,optionId:C??"",currencyCode:g,openCart:p,...d?{attributes:d}:{}}),s?.())};return x(pe,{children:[i(no,{type:"Primary",className:h(a,k&&!a?SL:void 0),onClick:A,disabled:k,children:n??i(Ln,{id:"addToCart",defaultMessage:"Add to Cart"})}),o&&v&&!l&&i("span",{className:hL,children:I()})]})},Em=({className:e,productKey:t="",optionId:o,label:n,buttonClassName:a,onAfterAdd:s,hideMaxQuantityTooltip:l,keepButtonOnUnavailable:p,openCart:d,attributes:u})=>{let{store:y,catalog:m,isCountrySupported:g}=(0,Qn.useContext)(Kt),f=!!y&&g!==!1,b=(0,Qn.useRef)(null),[S,C]=(0,Qn.useState)(!1),v=m[t],k=f&&!!v?.available;return(0,Qn.useEffect)(()=>{let I=b.current;if(!I)return;let A=()=>C(!0),D=()=>C(!1);return I.addEventListener("mouseenter",A),I.addEventListener("mouseleave",D),()=>{I.removeEventListener("mouseenter",A),I.removeEventListener("mouseleave",D)}},[]),!k&&!p?i("div",{ref:b,className:h(e,"sdsm-default",XC),children:"Product not available in your country"}):x("div",{ref:b,className:h(e,"sdsm-default",XC),children:[i(IJ,{productKey:t,optionId:o,showTooltip:S,label:n,buttonClassName:a,onAfterAdd:s,hideMaxQuantityTooltip:l,openCart:d,attributes:u,forceDisabled:!k}),!k&&i("p",{children:"Product not available in your country"})]})};Em.displayName="AddToCart";var yc=T(w());var JC=T(w());var uc=e=>{let{userLocation:t}=(0,JC.useContext)(ee),{currencyCode:o}=(0,JC.useContext)(Kt);return e===0?"":new Intl.NumberFormat(t.country,{style:"currency",currency:o??"USD"}).format(e)};var Di=({productPrice:e,className:t})=>{let o=uc(e);return i("div",{className:h("mw-price",t),children:o})};var CL=e=>c`
  background-color: ${r("--palette-plain-white")};
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.06);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: ${e?"normal":"center"};
  height: 100%;
  overflow-y: auto;
  pointer-events: none;
  position: fixed;
  right: -400px;
  top: 0;
  transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1);
  z-index: 100;
  width: 375px;
  text-align: center;
`,xL=c`
  opacity: 1;
  pointer-events: all;
  right: 0;
  left: 0;
  width: 100%;

  ${Mr.over768_desktop_small} {
    left: unset;
    width: 400px;
  }
`,vL=c`
  background-color: ${fa}cc;
  position: fixed;
  opacity: 0;
  top: 0;
  right: 0;
  width: 100%;
  height: 100%;
  transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1);
  display: none;

  ${Mr.over768_desktop_small} {
    display: unset;
  }
`,IL=c`
  opacity: 1;
  right: 400px;
`,kL=c`
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
`,ML=c`
  color: ${r("--palette-black-v200")};
  cursor: pointer;
  background: transparent;
  border-radius: 50px;
  padding-top: ${16}px;
  padding-right: ${16}px;
`,TL=c`
  font-weight: bold;
`,AL=c`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 0 ${8}px;
`,_L=e=>c`
  background: url(${e}) no-repeat center center;
  background-size: contain;
  width: 200px;
  height: 200px;
`,wL=c`
  display: flex;
  justify-content: flex-end;
  width: 100%;
  height: ${40}px;
`,DL=c`
  color: ${r("--palette-plain-white")};
  width: ${40}px;
  height: ${40}px;
  background-color: ${r("--palette-black-v200")};
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 20px;
  margin: 20px 5px;
`,t5e=c`
  width: 100%;
  max-width: 400px;
  padding: 0 ${40}px;
`,o5e=c`
  display: flex;
  align-items: center;
  justify-content: space-between;
  border: 1px solid ${r("--palette-gray-v150")};
  margin: ${16}px 0;
  padding: 0 ${16}px;
`,n5e=c`
  width: ${40}px;
  height: ${40}px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 20px ${16}px;
`,PL=c`
  display: flex;
  align-items: center;
`,r5e=c`
  padding: ${12}px 0;
  text-align: left;
`,a5e=c`
  margin-bottom: ${4}px;
  font-weight: 500;
`,ZC=c`
  background: ${r("--palette-plain-white")};
  border: 1px solid ${r("--palette-gray-v200")};
  color: ${r("--palette-black-v200")};
  cursor: pointer;
  font-size: 12px;
  width: ${32}px;
  height: ${32}px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 20px;
  margin: 0 ${4}px;
  transition: border 0.05s ease-in-out;

  &:hover {
    border: 2px solid ${r("--palette-yellow-v100")};
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.14);
  }
`,NL=c`
  background: ${r("--palette-gray-v100")};
  border: unset;
  color: ${r("--palette-gray-v300")};
  cursor: default;
  pointer-events: none;
`,i5e=c`
  background: ${r("--palette-plain-white")};
  color: ${r("--palette-black-v200")};
  cursor: pointer;
  font-size: 12px;
`,s5e=c`
  color: ${r("--palette-gray-v300")};
  pointer-events: none;
`,EL=c`
  margin: ${16}px 0;
  font-size: 30px;
`,RL=c`
  color: ${r("--palette-gray-v300")};
`,FL=c`
  font-size: 24px;
`,BL=c`
  margin-top: ${8}px;
  text-align: center;
`,$L=c`
  font-size: 16px;
  font-weight: 600;
`,LL=c`
  font-size: 12px;
  color: ${r("--palette-gray-v300")};
`,HL=c`
  font-size: 14px;
  color: ${r("--palette-gray-v300")};
  text-decoration: line-through;
`,VL=c`
  margin-top: ${40}px;
  font-size: 24px;
  text-align: center;
`,OL=c`
  button.sdsm-button {
    background-color: transparent;
  }

  margin-top: ${16}px;
  padding: 0 ${16}px;
`,GL=c`
  color: ${r("--palette-gray-v300")};
  margin-top: ${32}px;
  padding-bottom: ${40}px;
`,zL=c`
  display: flex;
  flex: 1;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`,UL=c`
  text-align: center;
  font-size: 24px;
`,WL=e=>c`
  background: url(${e}) no-repeat center center;
  background-size: contain;
  width: 200px;
  height: 200px;
`,QL=c`
  text-align: center;
  font-size: 30px;
`,qL=c`
  margin-top: ${16}px;
  font-size: 24px;
`,KL=c`
  margin-top: ${16}px;
`,jL=c`
  background: transparent;
  color: ${r("--palette-black-v200")};
  cursor: pointer;
  font-size: 22px;
  display: flex;
  align-items: center;
  position: relative;
  text-decoration: none;
`,YL=c`
  background-color: ${r("--palette-yellow-v100")};
  border-radius: 50%;
  position: absolute;
  font-size: 16px;
  font-weight: 400;
  top: -14px;
  left: 13px;
  text-align: center;
  padding: ${12}px;
  width: 8px;
  height: 8px;
  display: flex;
  align-items: center;
  justify-content: center;

  ${Mr.over768_desktop_small} {
    top: -18px;
    left: 15px;
  }
`,XL=c`
  margin: 0 -2.5px;
`;var JL=({productKey:e,title:t,image:o,atpMessage:n,price:a,optionId:s,maxQuantity:l,optionTitle:p,sellingPlanDepositData:d})=>{let u=(0,yc.useContext)(tn),{currencyCode:y=""}=(0,yc.useContext)(Kt),{formatMessage:m}=(0,yc.useContext)(qe),g=(0,yc.useContext)(be).elementLocation,b=u.lines.find(k=>k.optionId===s)?.quantity??0,S=l===b,v=(d&&y?d[y]:null)?.amount??null;return x("div",{className:AL,children:[i("div",{className:_L(o)}),x("div",{className:EL,children:[t,p&&p!=="Default Title"?` - ${p}`:""]}),v?x("div",{className:BL,children:[i(Di,{className:HL,productPrice:a}),i(Di,{className:$L,productPrice:v}),i("div",{className:LL,children:m({id:"depositDueToday",defaultMessage:"Deposit due today"})})]}):i(Di,{className:FL,productPrice:a}),x("div",{className:PL,children:[i("button",{onClick:()=>{ge({eventCategory:"CartItem",eventAction:"ItemRemove",eventLabel:`line_item_remove: ${s}`,context:{elementText:t,elementLocation:g}}),u.removeLine({productKey:e,optionId:s,currencyCode:y})},className:ZC,children:i(De,{name:"remove"})}),i("span",{className:DL,children:b}),i("button",{disabled:S,onClick:()=>{ge({eventCategory:"CartItem",eventAction:"ItemAdd",eventLabel:`line_item_add: ${s}`,context:{elementText:t,elementLocation:g}}),u.addLine({productKey:e,optionId:s,currencyCode:y})},className:h(ZC,{[NL]:S}),children:i(De,{name:"add"})})]}),n&&i("div",{className:RL,children:n})]})};var Rm=T(w());var ex=()=>{let{userLocation:e,getCurrentUrl:t,currentLocale:o,cookieManager:n}=(0,Rm.useContext)(ee),a=(0,Rm.useContext)(tn),{store:s,currencyCode:l,catalog:p,market:d}=(0,Rm.useContext)(Kt),{options:u}=V.shopify??{},y=n.getCookie("_ga"),m=[];a.lines.forEach((A,D)=>{let B=A.optionId.match(/\/(\d+)/)?.[1];if(!B)return;m.push(`items[${D}][id]=${B}`),m.push(`items[${D}][quantity]=${A.quantity}`);let M=l&&p[A.productKey]?.sellingPlan?.depositData?.[l]?.sellingPlanId;if(M){let _=M.match(/\/(\d+)/)?.[1];_&&m.push(`items[${D}][selling_plan]=${_}`)}});let g={"attributes[locale]":o,locale:o,"checkout[shipping_address][country]":d??e.country,...l?{currency:l}:{},access_token:s?.storefrontAccessToken??"","attributes[source]":"web"};u?.checkoutQueryParams&&(g={...g,...u.checkoutQueryParams}),y&&(g._ga=y),a.discountCode&&(g.discount=a.discountCode);let f=u?.getCheckoutAttributes?.(a.lines);f&&(g={...g,...f});let b=Object.entries(g).map(([A,D])=>`${A}=${D}`).join("&"),S=m.join("&"),C=new URL(`https://${s?.domain}/checkout?${b}`);Am(C,new URL(t()),V.persistentQueryParams);let v=C.pathname+C.search,k=`/cart/add?${S}&return_to=${encodeURIComponent(v)}`;return new URL(`https://${s?.domain}/cart/clear?return_to=${encodeURIComponent(k)}`)};var tx=()=>{let e=(0,mc.useContext)(be).elementLocation,{formatMessage:t}=(0,mc.useContext)(qe),{catalog:o,productOptionById:n,currencyCode:a}=(0,mc.useContext)(Kt),s=(0,mc.useContext)(tn),l=V.shopify?.options.featuredProduct??"",p=o[l],d=ex(),u=t({id:"cartCheckoutButton",defaultMessage:"Checkout"}),y=t({id:"cartCheckoutDisclaimer",defaultMessage:"Shipping calculated at checkout"}),m=t({id:"noCartItems",defaultMessage:"Nothing added to cart yet"}),g=s.lines.length>0,f=s.lines.reduce((I,A)=>{let D=n[A.optionId];return D?I+D.option.price*A.quantity:I},0),b=s.lines.reduce((I,A)=>{let D=n[A.optionId];if(D){let B=o[D.productKey],_=(B?.sellingPlan?.depositData&&a?B.sellingPlan.depositData[a]:void 0)?.amount??D.option.price;return I+_*A.quantity}return I},0),S=b!==f,C=uc(S?b:f),v=t({id:S?"cartDepositTotal":"cartTotal",defaultMessage:S?"Due today {total}":"Total {total}"},{total:C}),k=()=>{ge({eventAction:"Click",eventCategory:"CheckoutButton",eventLabel:null,context:{targetUrl:d.href,elementText:u,elementLocation:e}}),Me.flush()};return x("div",{className:h(CL(g),{[xL]:s?.cartOpen}),children:[i("div",{onClick:()=>s.setCartOpen(!1),className:h(vL,{[IL]:s?.cartOpen})}),i("div",{className:wL,children:i("button",{className:ML,onClick:()=>s.setCartOpen(!1),children:i(De,{name:"cross",className:TL})})}),i("div",{className:kL}),s.lines.map(I=>{let A=n[I.optionId];if(!A)return null;let D=o[A.productKey];return D?i(JL,{productKey:A.productKey,title:D.title,image:D.featuredImage??"",price:A.option.price,sku:A.option.sku,optionId:A.option.id,optionTitle:A.option.title,maxQuantity:D.maxQuantity,atpMessage:D.atpMessage,sellingPlanDepositData:D.sellingPlan?.depositData},I.optionId):null}),!g&&x("div",{className:zL,children:[i("div",{className:UL,children:m}),p&&x(pe,{children:[i("div",{className:WL(p.featuredImage??"")}),i("div",{className:QL,children:p.title}),i(Di,{className:qL,productPrice:p.options[0]?.price??0}),i(Em,{className:KL,productKey:l})]})]}),g&&x(pe,{children:[i("div",{className:VL,children:v}),i("div",{className:OL,children:i(no,{link:d.href,type:"Primary",onClick:k,children:u})}),i("div",{className:GL,children:y})]})]})};var ZL=T(w());var ox=()=>{let e=(0,ZL.useContext)(tn),t=e.lines.reduce((o,n)=>o+n.quantity,0);return x("button",{className:jL,onClick:()=>e.setCartOpen(!0),children:[t!==0&&i("span",{className:YL,children:t}),i(De,{name:"cart",size:27,className:XL})]})};var Bm=T(w());var o6=T(w());var e6=T(w());var so="en-US";var Pi=(0,e6.createContext)({preview:!1,locale:so});Pi.displayName="ContentfulContext";function t6(e,t){let o="cache-first",n=t.get("contentfulFetchPolicy");return V.isClient&&!V.isDeploymentTypeProd&&n&&(o=n),!V.isClient&&V.isPreview&&(o="network-only"),{preview:V.isPreview,locale:e,fetchPolicy:o}}var qa=()=>{let e=(0,o6.useContext)(Pi);if(e===void 0)throw new Error("The useContentfulQuery hook can only be used in combination with ContentProvider");return e};var Fm=T(w());var gc=(0,Fm.createContext)({}),n6=({children:e})=>{let[t,o]=(0,Fm.useState)(!1);return i(gc.Provider,{value:{hasLivePreview:t,setHasLivePreview:n=>o(n)},children:e})};var r6=()=>{let{locale:e}=qa(),{setHasLivePreview:t}=(0,Bm.useContext)(gc),o=!V.isDeploymentTypeProd;return(0,Bm.useInsertionEffect)(()=>{async function n(){let{ContentfulLivePreview:a}=await import("./chunks/live-preview-KTWRHASY.mjs"),s=await a.init({locale:e,enableInspectorMode:!0,enableLiveUpdates:!0,experimental:{hideCoveredElementOutlines:!0}});return s&&(t?.(!0),Me.logEvent({type:Te.USER_ACTION,component:"ContentfulLivePreview",action:"Open",label:"Live Preview Panel"})),s}o&&n()},[o,e]),null};var rx=T(w());var nx="sc-persona";function ia(e){return e.getCookieJson(nx)}function $m(e,t){if(!t||e.getCookie("Preferences")!=="true")return;let n=ia(e);if(is(t,n))return;let a=new Date;a.setFullYear(a.getFullYear()+1);let s=!V.isDeploymentTypeProd||!V.isCompilationModeProd?"":V.trackingSettings.cookieDomain;e.setCookieJson(nx,t,{secure:!0,expires:a,sameSite:"strict",domain:s})}var kJ=5e3,fc,MJ=()=>fc||(fc=(async()=>{if(window.Shopify?.customerPrivacy?.setTrackingConsent||(await new Promise(t=>{fn("shopify-consent-tracking-api","https://cdn.shopify.com/shopifycloud/consent-tracking-api/v0.1/consent-tracking-api.js",t)}),window.Shopify?.customerPrivacy?.setTrackingConsent))return window.Shopify.customerPrivacy;let e=window.Shopify;if(!e?.loadFeatures)throw new Error("Shopify consent tracking API failed to initialize");if(await new Promise((t,o)=>{e.loadFeatures([{name:"consent-tracking-api",version:"0.1"}],n=>{if(n){o(n instanceof Error?n:new Error(String(n)));return}t()})}),!window.Shopify?.customerPrivacy?.setTrackingConsent)throw new Error("Shopify customerPrivacy API unavailable after loading consent-tracking-api");return window.Shopify.customerPrivacy})().catch(e=>{throw fc=void 0,e}),fc),TJ=(e,t,o)=>{let n=t.domain;return{marketing:e.Marketing===!0,analytics:e.Performance===!0,preferences:e.Preferences===!0,sale_of_data:o,headlessStorefront:!0,checkoutRootDomain:n,storefrontRootDomain:n,storefrontAccessToken:t.storefrontAccessToken}},Lm=async({cookieAcceptance:e,store:t,saleOfData:o=!0,timeoutMs:n=kJ})=>{await Promise.race([(async()=>{let a=await MJ(),s=TJ(e,t,o);await new Promise(l=>a.setTrackingConsent(s,l))})(),new Promise((a,s)=>{window.setTimeout(()=>s(new Error(`Shopify tracking consent timed out after ${n}ms`)),n)})])};var AJ=Lt.White,i6=({isClient:e,backgroundColor:t=AJ,globalPrivacyControl:o})=>{let{cookieManager:n,personasRef:a}=(0,rx.useContext)(ee),{store:s}=(0,rx.useContext)(Kt),p=vt().submitShopifyTrackingConsent==="true";if(!e)return null;let d=t===Lt.Black?"Black":"White",u=!V.isDeploymentTypeProd||!V.isCompilationModeProd?"":void 0;return i(yC,{cookieDomain:u,backgroundType:d,onComplete:y=>{if(y.cookieAcceptance.Marketing&&D0().catch(m=>Re({component:"CookiePopup",error:m})),y.cookieAcceptance.Performance&&P0().catch(m=>Re({component:"CookiePopup",error:m})),y.cookieAcceptance.Preferences&&$m(n,a?.current??void 0),s&&p&&Lm({cookieAcceptance:y.cookieAcceptance,store:s,saleOfData:!y.isGlobalPrivacyControlApplied}).catch(m=>Re({component:"CookiePopup",error:m})),V.site==="for-business"&&((void 0)?.(n,!!y.cookieAcceptance.Marketing),y.cookieAcceptance.Preferences)){let g=ia(n)?.snap??[];for(let f of g){let b=C0[f];b&&ot({subscribedEventType:"internal",eventCategory:"SnapPersona",eventAction:"Get",eventLabel:b})}}},globalPrivacyControl:o})};var s6=T(w());var _J=new Set(["ar","arc","dv","fa","ha","he","khw","ks","ku","ps","ur","yi"]),Hm=e=>{let t=e??so,[o]=t.split("-");return _J.has(o)?"rtl":"ltr"};var ax=()=>{let e=(0,s6.useContext)(ee);return i(Mt,{children:i("html",{dir:Hm(e?.currentLocale)})})};ax.displayName="DirectionDirective";var Ka=T(w());function wJ(e,t){var o={};return t=Jo(t,3),kd(e,function(n,a,s){ad(o,a,t(n,a,s))}),o}var l6=wJ;function Vm(e){if(e==null)return;if(typeof e!="object")return e;let t=Fo(e),o=Array.isArray(e)?e.map(Vm):l6(t,Vm);return Object.freeze(o)}var se=(e,t)=>{let{getCurrentUrl:o}=(0,Ka.useContext)(ee),{preview:n,locale:a,fetchPolicy:s}=qa(),{hasLivePreview:l}=(0,Ka.useContext)(gc),p={fetchPolicy:s,...t,context:{currentUrl:o(),...t?.context},variables:{preview:n,locale:a,...t?.variables},ssr:t?.ssr??V.isSSR},d=yd(e,p);(0,Ka.useEffect)(()=>{if(t?.pollInterval)return d.startPolling(t.pollInterval),d.stopPolling},[d.data,t,d.startPolling,d.stopPolling]);let[u,y]=(0,Ka.useState)({});(0,Ka.useEffect)(()=>{let g=nr;async function f(){let{ContentfulLivePreview:b}=await import("./chunks/live-preview-KTWRHASY.mjs"),S=Object.keys(d.data).filter(I=>d.data?.[I].sys&&d.data?.[I].__typename),C=Object.keys(d.data).filter(I=>d.data?.[I].items),v=S.map(I=>b.subscribe({data:d.data[I],locale:a,callback:A=>{y(D=>({...D,[I]:A}))},query:e})),k=C.map(I=>b.subscribe({data:d.data[I].items,locale:a,callback:A=>{y(D=>({...D,[I]:{items:A}}))},query:e}));g=()=>[...v,...k].forEach(I=>I())}return l&&d.data&&f(),g},[d.data,l,a,e]);let m=d;if(d.data){m=Fo(d);let g=l&&Object.keys(u).length?u:d.data;m.data=Vm(g)}return m};var O=E`
  fragment ContentfulSysId on Entry {
    sys {
      id
    }
    __typename
  }
`;var Om=T(w());var Dn=e=>{if(e){let t=e.split("?")[0].split("/").pop();if(t){let o=t.split("."),n=o.slice(-1)[0];return{fileName:o.slice(0,o.length-1).join(".").trim(),extension:n}}}return{fileName:"",extension:""}};var p6=e=>{let t=e.getBoundingClientRect();return t.top>=0&&t.left>=0&&t.bottom<=(window.innerHeight??document.documentElement.clientHeight)&&t.right<=(window.innerWidth??document.documentElement.clientWidth)};var bc=e=>e.__typename==="Video",ja=({autoPlay:e=!0,eventLabel:t,getPreviousWatchTime:o,setPreviousWatchTime:n,elementLocation:a})=>l=>{if(e)return;let p=l.target,d=p.readyState>2,u=p.currentTime>0&&!p.paused&&!p.ended&&d,y=Math.abs(o()-p.currentTime),m=p6(p);u&&m&&!document.hidden&&y>=.9&&(Ma({eventCategory:"Video",eventLabel:t,eventVariable:"video_watch",eventValue:Math.floor(p.currentTime),context:{elementLocation:a}}),n(p.currentTime))};var Pn=E`
  fragment AssetAll on Asset {
    sys {
      id
    }
    contentType
    width
    height
    title
    description
    url
    size
  }
`,$t={all:Pn},c6=E`
  query AssetsQuery($preview: Boolean!, $locale: String!, $id: String!) {
    asset(preview: $preview, locale: $locale, id: $id) {
      ...AssetAll
    }
  }
  ${Pn}
`;var DJ=e=>e?e.startsWith("image"):!1,d6=c`
  margin-bottom: ${r("--spacing-m")};
`,ix=e=>{let{data:t}=se(c6,{variables:{id:e.sys.id}}),{getImageSources:o}=ve(),n=(0,Om.useContext)(be).elementLocation,[a,s]=(0,Om.useState)(!1),l=-1;if(!t)return null;let{asset:p}=t;if(!p)return null;let{contentType:d,url:u,description:y}=p;if(DJ(d)){let b=oc(600,t.asset.height??0),S=o(u,b);return i(Ke,{className:e.isEmbedded?d6:void 0,imgSrcs:S,altText:y})}let m=b=>{if(u&&!a){let{fileName:S}=Dn(u);ge({eventAction:"Play",eventCategory:"Video",eventLabel:S,context:{elementLocation:n}}),s(!0)}},g=b=>{if(u){let{fileName:S}=Dn(u);ge({eventAction:"Pause",eventCategory:"Video",eventLabel:S,context:{elementLocation:n}})}},f=ja({autoPlay:!1,eventLabel:p.sys.id,getPreviousWatchTime:()=>l,setPreviousWatchTime:b=>{l=b},elementLocation:n});return i(Ke,{sourceType:d,className:e.isEmbedded?d6:void 0,videoSource:u,showVideoControls:!0,onPlay:m,onPause:g,onTimeUpdate:f,maxHeight:600,altText:y})};ix.displayName="Media";var PJ={all:E`
    fragment FaviconAll on Favicon {
      ...ContentfulSysId
      asset {
        ...AssetAll
      }
      size
    }
    ${$t.all}
    ${O}
  `},u6=E`
  query FaviconCollectionQuery($preview: Boolean!, $locale: String!) {
    faviconCollection(preview: $preview, locale: $locale, order: sys_publishedAt_ASC) {
      items {
        ...FaviconAll
      }
    }
  }
  ${PJ.all}
`;var y6=()=>{let{data:e}=se(u6,{});return e?e?.faviconCollection?.items?.some(o=>!!o.asset)?i(Mt,{children:e.faviconCollection.items.filter(o=>!!o.asset).map(o=>{let{sys:n,asset:a,size:s}=o;return i("link",{rel:"icon",type:"image/png",href:`${a.url}?fm=png`,sizes:s?`${s}x${s}`:void 0},n.id)})}):i(Mt,{children:i("link",{rel:"icon",type:"image/png",href:"/images/favicon.png"})}):null};var ml=T(w());var m6=T(w());var on=(0,m6.createContext)({footerView:"Full Footer",headerView:"Full Header",hasSideNav:!1,hasSubNav:!1,hasCustomSideNav:!1});var g6=T(w());function Ya(e,t){let{getCurrentUrl:o}=(0,g6.useContext)(ee);if(V.isDeploymentTypeProd)return;let a=new URL(o()).searchParams.get("alternateMotif");if(!a)return;let s=e.alternateBrandPropOverrides;if(!s)return;let l=s[a];if(l)return l[t]}var f6=T(w());function ol(){let{getCurrentUrl:e}=(0,f6.useContext)(ee),t=wd[V.site];if(V.site==="sandbox"){let n=new URL(e()).searchParams.get("alternateMotif");n&&m0.includes(n)&&(t=n)}return t}function it(e){return ol()==="snap"?e??"sdsm-default":e??void 0}var n8=T(w());var b6=e=>!!e.id,lo=e=>e.sys!==void 0;var S6=e=>{let t=new Set(Object.keys(e));return["__typename","id","ids","sys"].forEach(o=>t.delete(o)),t.size===0},Gm=e=>{let t=new Set(Object.keys(e));return["__typename","sys"].forEach(o=>t.delete(o)),t.size>0};function Fe({entryId:e,fieldIds:t,locale:o}){if(V.isDeploymentTypeProd)return{};let n={};return t.forEach(a=>{let s=`${String(a)}Dataset`;n[s]={contentfulEntryId:e,contentfulFieldId:a,contentfulLocale:o}}),n}var Z6=T(Hr());var e8=T(w());var X6=T(zm());var I6=T(w());var Za=({uri:e,className:t,onClick:o,children:n})=>{let a=(0,I6.useContext)(be).elementLocation;return i(hh,{link:e,onClick:()=>{ge({eventAction:"Click",eventCategory:"Hyperlink",eventLabel:`Hyperlink: ${e}`,context:{targetUrl:e,elementLocation:a,elementText:typeof n=="string"?n:void 0}}),io(e)&&Me.flush(),o?.()},className:t,children:n})};Za.displayName="Hyperlink";var il=c`
  && {
    line-height: 160%;
  }
`,Um=({children:e})=>i("div",{className:h($n.h1,bd,il),children:e});Um.displayName="H1";var Wm=({children:e})=>i("div",{className:h($n.h2,ba,il),children:e});Wm.displayName="H2";var Qm=({children:e})=>i("div",{className:h($n.h3,yo,il),children:e});Qm.displayName="H3";var qm=({children:e})=>i("div",{className:h($n.h4,ut,il),children:e});qm.displayName="H4";var Km=({children:e})=>i("div",{className:h($n.h5,qt,il),children:e});Km.displayName="H5";var jm=({children:e})=>i("div",{className:h($n.h6,Sd,il),children:e});jm.displayName="H6";var K6=T(zm()),ft=T(u0());function HJ(e,t,o,n){for(var a=-1,s=e==null?0:e.length;++a<s;){var l=e[a];t(n,l,o(l),e)}return n}var k6=HJ;function VJ(e,t,o,n){return Va(e,function(a,s,l){t(n,a,o(a),l)}),n}var M6=VJ;function OJ(e,t){return function(o,n){var a=Qo(o)?k6:M6,s=t?t():{};return a(o,e,Jo(n,2),s)}}var T6=OJ;var GJ=T6(function(e,t,o){ad(e,o,t)}),ux=GJ;var yx=e=>{let{item:t,children:o}=e,n=t.__typename,a=n!=="Slug"&&n!=="Asset",s=n==="Slug"&&!t.slug,l=n==="Asset"&&!t.url;if(!n||a||s||l)return Re({component:"AssetEntryLink",message:"Invalid data for hyperlink",context:{sysId:t.sys.id}}),null;let p="";return t.__typename==="Slug"&&(p=`https://${V.domainName}/${t.slug}`),t.__typename==="Asset"&&t.url&&(p=t.url),i(Za,{uri:p,children:o})};yx.displayName="AssetEntryHyperlink";var sl=T(w());var Do=({children:e,fallbackElement:t=null})=>{let[o,n]=(0,sl.useState)(!0);return(0,sl.useEffect)(()=>{n(!1)},[]),o?t:i(sl.Suspense,{fallback:t,children:e})};var zJ=Ko(()=>import("./chunks/LazyCode-Z3UITUM2.mjs").then(e=>({default:e.Code}))),mx=e=>i(Do,{children:i(zJ,{...e})});mx.displayName="Code";var A6={all:E`
    fragment CodeAll on Code {
      ...ContentfulSysId
      code
      language
    }
    ${O}
  `};var Yn=T(w());var ll=T(w());var UJ={isOpen:!1,open:()=>{},close:()=>{}},hc=(0,ll.createContext)(UJ),_6=({children:e})=>{let[t,o]=(0,ll.useState)(!1),[n,a]=(0,ll.useState)(),[s,l]=(0,ll.useState)(),p=({title:u,body:y},m)=>{a({title:u,body:y}),l(m),o(!0)},d=()=>{a(void 0),l(void 0),o(!1)};return i(hc.Provider,{value:{isOpen:t,open:p,close:d,content:n,triggerRef:s},children:e})};var Cc=({displayText:e,fullText:t,anchorId:o,overlayTitle:n,overlayBody:a,className:s})=>{let{open:l,close:p,triggerRef:d}=(0,Yn.useContext)(hc),u=(0,Yn.useContext)(be).elementLocation,y=(0,Yn.useRef)(null),m=y===d,g=(0,Yn.useMemo)(()=>({title:n??e,body:a??fo(t)}),[e,t,n,a]);(0,Yn.useEffect)(()=>{o&&window.location.hash===`#${o}`&&l(g,y)},[]);let f=(0,Yn.useCallback)(()=>{if(m){ge({eventCategory:"Definition",eventAction:"Close",eventLabel:null,context:{elementLocation:u}}),p();let b=new URL(window.location.href);b.hash="",window.history.replaceState(null,"",b)}else{ge({eventCategory:"Definition",eventAction:"Open",eventLabel:null,context:{elementLocation:u}}),l(g,y);let b=new URL(window.location.href);b.hash=o?`#${o}`:"",window.history.replaceState(null,"",b)}},[m,o,g,y,l,p,u]);return e?t?i(kD,{ref:y,anchorId:o,isActive:m,onClick:f,className:s,children:e}):i(pe,{children:e}):null};Cc.displayName="Definition";var gx=T(w());var fx=({className:e})=>{let{hasSideNav:t}=(0,gx.useContext)(on),{isOpen:o,close:n,content:a,triggerRef:s}=(0,gx.useContext)(hc),l=p=>{["Enter"," "].includes(p?.key)&&(p.preventDefault(),s?.current?.focus()),n();let d=new URL(window.location.href);d.hash="",window.history.replaceState(null,"",d)};return i(Vh,{isOpen:o,title:a?.title,body:a?.body,onClose:l,className:e,hasSideNav:t})};fx.displayName="DefinitionOverlay";var WJ={all:E`
    fragment DownloadableAssetAll on DownloadableAsset {
      ...ContentfulSysId
      linkText
      file {
        url
      }
    }
    ${O}
  `},w6=E`
  query DownloadableAssetQuery($preview: Boolean!, $locale: String!, $id: String!) {
    downloadableAsset(preview: $preview, locale: $locale, id: $id) {
      ...DownloadableAssetAll
    }
  }
  ${WJ.all}
`;var bx=e=>{let t=!!e?.linkText&&!!e?.file?.url,{data:o}=se(w6,{variables:{id:b6(e)?e.id:e.sys.id},skip:t}),n=t?e:o?.downloadableAsset;return n?i(Za,{uri:n?.file?.url,children:n?.linkText}):null};bx.displayName="DownloadableAsset";var D6=e=>{let{text:t=""}=e;return i(YD,{text:t})};var ei=E`
  fragment EmphasizedTextAll on EmphasizedText {
    ...ContentfulSysId
    text
  }
  ${O}
`;var P6=c`
  padding-bottom: 0;
`,N6=c`
  font-size: 10px;
  line-height: 18px;
`,E6=c`
  font-size: 10px;
  line-height: 20px;
  margin-inline-end: 0.125em;
`,R6=c`
  display: flex;
`;var Sx=({number:e,displayText:t,fullText:o,...n})=>{let a=x(pe,{children:[t,i("span",{className:N6,children:x(np,{children:[" ",e]})})]}),s=x("div",{className:R6,children:[i("span",{className:E6,children:x(np,{children:[e," "]})}),fo(o)]});return i(Cc,{...n,displayText:a,fullText:o,overlayTitle:"",overlayBody:s,className:t?void 0:P6})};Sx.displayName="FootnoteInline";function Le(e){if(!e.mobile)return e.desktop;if(e.desktop)return{sources:[...e.mobile.sources.map(t=>({...t,media:t.media??"(max-width: 768px)"})),...e.desktop.sources],default:e.desktop.default,defaultSrcSet:e.desktop.defaultSrcSet,defaultSizes:e.desktop.defaultSizes}}var Ym=e=>({imageSource:e.url,imageAltText:e.description,imageSize:{height:e.height,width:e.width},contentType:e.contentType}),hx=e=>({videoSource:e.url,contentType:e.contentType}),je=e=>!e||!e.url?{}:e.contentType?.startsWith("video")?hx(e):e.contentType?.startsWith("image")?Ym(e):{};var Xm=e=>e.__typename==="Image",Dt=({desktopHeight:e,mobileHeight:t,desktopDefaultHeight:o=800,mobileDefaultHeight:n=800,enableHighDpi:a=!1,quality:s="Standard"})=>{let l=Xn[s],p={image:{height:o,quality:l}},d={image:{height:n,quality:l}},u=a?oc(o,e,l):p,y=a?oc(n,t??e,l):d;return{desktopSettings:{...u,quality:l},mobileSettings:{...y,quality:l}}};var Xn={Standard:40,High:65,"Very High":85},Cx=e=>{let{enableHighDpi:t,quality:o,dataset:n}=e,{imageSource:a,imageAltText:s}=je(e.media),{imageSource:l}=je(e.mobileMedia),{getImageSources:p}=ve(),{desktopSettings:d,mobileSettings:u}=Dt({desktopHeight:e.media?.height??0,mobileHeight:e.mobileMedia?.height,enableHighDpi:t,quality:o}),y=Le({desktop:p(a,d),mobile:p(l??a,u)});return i(xn,{altText:s,imgSrcs:y,wrap:e.wrap??void 0,dataset:n})};Cx.displayName="Image";var xc=E`
  fragment StickerAll on Sticker {
    ...ContentfulSysId
    asset {
      ...AssetAll
    }
    position
    rotation
  }
  ${O}
  ${$t.all}
`,E7e=E`
  query StickerQuery($preview: Boolean!, $locale: String!, $id: String!) {
    sticker(preview: $preview, locale: $locale, id: $id) {
      ...StickerAll
    }
  }
  ${xc}
`;var Oe={all:E`
    fragment ImageAll on Image {
      sys {
        id
      }
      media {
        ...AssetAll
      }
      mobileMedia {
        ...AssetAll
      }
      wrap
      enableHighDpi
      quality
      stickersCollection {
        items {
          ...StickerAll
        }
      }
    }
    ${$t.all}
    ${xc}
  `},O7e=E`
  query ImageQuery($preview: Boolean!, $locale: String!, $id: String!) {
    image(preview: $preview, locale: $locale, id: $id) {
      ...ImageAll
    }
  }
  ${Oe.all}
`;var xx={all:E`
    fragment CustomerQuoteAll on CustomerQuote {
      ...ContentfulSysId
      author {
        json
      }
      authorName
      body {
        json
      }
      media {
        __typename
        ... on Video {
          ...VideoAll
        }
        ... on Image {
          ...ImageAll
        }
      }
      logo {
        ...ImageAll
      }
      isLongQuote
    }
    ${O}
    ${Oe.all}
  `},F6=E`
  query CustomerQuotesQuery($preview: Boolean!, $locale: String!, $id: String!) {
    customerQuote(preview: $preview, locale: $locale, id: $id) {
      ...CustomerQuoteAll
    }
  }
  ${xx.all}
`;var B6=T(w());var $6=e=>{let t=S6(e),{getImageSources:o}=ve(),{isRTL:n}=(0,B6.useContext)(ee),{data:a}=se(F6,{variables:{id:e.sys.id},skip:!t});if(t&&!a)return null;let{author:s,authorName:l,body:p,logo:d,isLongQuote:u,media:y}=a?.customerQuote??e,m=d?.media?.url?o(d.media.url):void 0,g=y?.__typename==="Image"?o(y.media.url):void 0,f=y?.__typename==="Video"?y.media.url:void 0,b=y?.__typename==="Video"?y.mobileMedia?.url:void 0,S=Ct(s)?l:Ar(s);return i(Lh,{author:S,logoImageSrc:m,isRtl:n,isLongQuote:u??!1,imgSrcs:g,videoSrc:f,mobileVideoSrc:b,children:Ar(p)})};var vc=E`
  fragment SnapchatEmbedAll on SnapchatEmbed {
    ...ContentfulSysId
    url
  }
  ${O}
`,L6=E`
  query SnapchatEmbedQuery($preview: Boolean!, $locale: String!, $id: String!) {
    snapchatEmbed(preview: $preview, locale: $locale, id: $id) {
      ...SnapchatEmbedAll
    }
  }
  ${vc}
`;var H6=e=>{let t=lo(e)?e.sys.id:void 0,{data:o}=se(L6,{skip:!t,variables:{id:t}});return o?i(Gs,{...o.snapchatEmbed}):null};var gt={all:E`
    fragment VideoAll on Video {
      ...ContentfulSysId
      media {
        ...AssetAll
      }
      disableStreaming
      streamUrl
      mobileMedia {
        ...AssetAll
      }
      mobileMediaStreamUrl
      thumbnailMedia {
        ...AssetAll
      }
      captions {
        ...AssetAll
      }
      autoPlay
      wrap
      externalId
      stickersCollection {
        items {
          ...StickerAll
        }
      }
    }
    ${$t.all}
    ${xc}
    ${O}
  `},V6=E`
  query VideoQuery($preview: Boolean!, $locale: String!, $id: String!) {
    video(preview: $preview, locale: $locale, id: $id) {
      ...VideoAll
    }
  }
  ${gt.all}
`;var Jm=T(w());var G6=T(w());var QJ=e=>({media:Ym(e.media),mobileMedia:e.mobileMedia?Ym(e.mobileMedia):{}}),O6=(e,t,o)=>{let n=hx(e);if(!o||!t)return n;let a=S0(e.url,t);return a?{...n,videoSource:a.videoSource,contentType:a.contentType}:n},qJ=(e,t,o=!1)=>{let n=e.media,a=e.mobileMedia,s=t(e.thumbnailMedia?.url),l=O6(n,e.streamUrl,o),p=a?O6(a,e.mobileMediaStreamUrl,o):{};return{media:l,mobileMedia:p,thumbnailSource:s}},z6=(e,{hlsFeatureEnabled:t,getBestBgImgSrc:o,onHlsVideo:n})=>{let a=e?.__typename==="Video"&&e.media.contentType?.startsWith("video"),s=e?.__typename==="Image"&&e.media.contentType?.startsWith("image"),l=a?e:void 0,p=l?.disableStreaming===!0,d=a&&!p&&(l?.streamUrl?.endsWith(".m3u8")||l?.mobileMediaStreamUrl?.endsWith(".m3u8"));return!V.isClient&&d&&t&&n(),e?a?qJ(e,o,t&&!!d):s?QJ(e):{media:{},mobileMedia:{}}:{media:{},mobileMedia:{}}},U6=()=>{let e=vt(),t=(0,G6.useContext)(ee),{getBestBgImgSrc:o}=ve();return{hlsFeatureEnabled:e.enableHlsPlayback==="true",getBestBgImgSrc:o,onHlsVideo:t.onHlsVideo}},Yt=e=>{let t=U6();return z6(e,t)},W6=e=>{let t=U6();return e?.map(o=>z6(o,t))??[]};var Zm=(e,t)=>{let{media:o,mobileMedia:n,thumbnailMedia:a,autoPlay:s=!0,wrap:l,captions:p}=e,{videoSource:d}=je(o),{videoSource:u}=je(n),y=t(e.thumbnailMedia?.url,{width:728});return{videoSource:d,mobileVideoSource:u,posterSource:y,showVideoControls:Ct(s)?!1:!s,wrap:Ct(l)?void 0:l,captionsSource:p?.url,altText:a?.description??o?.description}},vx=e=>{let t=lo(e)?e.sys.id:void 0,{data:o}=se(V6,{skip:!t,variables:{id:t}}),[n,a]=(0,Jm.useState)(!1),{getBestBgImgSrc:s}=ve(),l=(0,Jm.useContext)(be).elementLocation,p=-1,{media:{videoSource:d},mobileMedia:{videoSource:u},thumbnailSource:y}=Yt(o?.video);if(!o)return null;let m=Zm(o.video,s),g=S=>{if(d&&!n){if(o.video.autoPlay)return;let{fileName:C}=Dn(d);ge({eventAction:"Play",eventCategory:"Video",eventLabel:C,context:{elementLocation:l}}),a(!0)}},f=S=>{if(d&&!o.video.autoPlay){let{fileName:C}=Dn(d);ge({eventAction:"Pause",eventCategory:"Video",eventLabel:C,context:{elementLocation:l}})}},b=ja({autoPlay:o.video.autoPlay,eventLabel:o.video.externalId??t??"unknown",getPreviousWatchTime:()=>p,setPreviousWatchTime:S=>{p=S},elementLocation:l});return i(xn,{mediaClassName:e.mediaClassName,onPlay:g,onPause:f,onTimeUpdate:b,dataset:e.dataset,...m,videoSource:d,mobileVideoSource:u,posterSource:y})};vx.displayName="Video";var Ix="mwp-cta",KJ=e=>{let o=Rt()?400:600;return e.url?i(ix,{...e,url:Tn({imageUrl:e.url,settings:{height:o}}),isEmbedded:!0}):null},jJ=e=>i(St,{...e,className:Ix}),eg={FootNotes:Sx,CustomerQuote:$6,Asset:KJ,CallToAction:jJ,SnapchatEmbed:H6,Image:Cx,Video:vx,Code:mx,Definition:Cc,DownloadableAsset:bx,EmphasizedText:D6};var Q6=c`
  width: 100%;
`;var Tx=e=>e,Ic=(e,t)=>t?i(pe,{children:t}):(Re({component:"RenderText",message:"Default node renderer cannot render this node.",context:{node:JSON.stringify(e)}}),null),kx=e=>e?t=>i(e,{children:t}):Tx,po=e=>e?(t,o)=>i(e,{...t.data,children:o}):Ic,YJ=(e,t)=>o=>{let n=ux(t,p=>p.sys.id),a=o.data.target.sys.id,s=n[a],l=s?.__typename;if(!l)return Re({component:"RenderText",message:"Node typename wasn't in the query response",context:{entryId:a}}),Ic(o,null);if(l==="Asset")return Re({component:"RenderText",message:`Attempted to render embedded asset: ${a} but this is no longer supported.`,context:{entryId:a}}),null;if(l in e){if(l==="Video"){let d=e[l];return i(d,{...s,mediaClassName:Q6})}let p=e[l];return i(p,{...s})}return Re({component:"RenderText",message:"No rich text renderer found",context:{typename:l}}),Ic(o,null)},j6=e=>e.json!==void 0,Mx=e=>{let{data:t,contentfulComponentMap:o,accessPath:n}=e,a;if(!t||!j6(t))a=Ic;else{let s=_p(t,n);a=YJ(o,s)}return a},q6=e=>{let{data:t,accessPath:o}=e;return!t||!j6(t)?Ic:(n,a)=>{let s=_p(t,o),p=ux(s,d=>d.sys.id)[n.data.target.sys.id];return i(yx,{item:p,children:a})}},XJ=e=>{let{data:t,components:o}=e,n=Mx({data:t,contentfulComponentMap:eg,accessPath:"links.assets.block"}),a=Mx({data:t,contentfulComponentMap:eg,accessPath:"links.entries.inline"}),s=Mx({data:t,contentfulComponentMap:eg,accessPath:"links.entries.block"}),l=q6({data:t,accessPath:"links.assets.hyperlink"}),p=q6({data:t,accessPath:"links.entries.hyperlink"});return{renderText:o.Text??Tx,renderMark:{[ft.MARKS.BOLD]:kx(o.Bold),[ft.MARKS.CODE]:Tx,[ft.MARKS.ITALIC]:kx(o.Italics),[ft.MARKS.UNDERLINE]:kx(o.Underline)},renderNode:{[ft.BLOCKS.DOCUMENT]:po(o.Document),[ft.BLOCKS.EMBEDDED_ASSET]:n,[ft.BLOCKS.EMBEDDED_ENTRY]:s,[ft.BLOCKS.HEADING_1]:po(o.H1),[ft.BLOCKS.HEADING_2]:po(o.H2),[ft.BLOCKS.HEADING_3]:po(o.H3),[ft.BLOCKS.HEADING_4]:po(o.H4),[ft.BLOCKS.HEADING_5]:po(o.H5),[ft.BLOCKS.HEADING_6]:po(o.H6),[ft.BLOCKS.HR]:po(o.HorizontalRule),[ft.BLOCKS.LIST_ITEM]:po(o.ListItem),[ft.BLOCKS.PARAGRAPH]:po(o.Paragraph),[ft.BLOCKS.QUOTE]:po(o.BlockQuote),[ft.BLOCKS.UL_LIST]:po(o.UnorderedList),[ft.BLOCKS.OL_LIST]:po(o.OrderedList),[ft.INLINES.ASSET_HYPERLINK]:l,[ft.INLINES.ENTRY_HYPERLINK]:p,[ft.INLINES.EMBEDDED_ENTRY]:a,[ft.INLINES.HYPERLINK]:po(o.Hyperlink),table:po(o.Table),"table-cell":po(o.TableCell),"table-header-cell":po(o.TableHeader),"table-row":po(o.TableRow)}}},Ei=e=>t=>{let{components:o={}}=e;if(!t)return;if(typeof t=="string")return t;let n=XJ({data:t,components:o});return(0,K6.documentToReactComponents)(t.json,n)};var Ax=T(w());var JJ=c`
  max-width: 100%;
`,Y6=({children:e})=>i("div",{"data-testid":"mwp-rich-text",className:JJ,children:Ax.Children.toArray(e)}),ZJ=c`
  margin: 0;
`,_x=({children:e})=>i("p",{className:ZJ,children:Ax.Children.toArray(e)});function eZ(e,t){return a0(ny(e,t),1)}var wx=eZ;var tZ=e=>wx(e.split(`
`),(t,o)=>o>0?[i("br",{}),t]:[t]),oZ=e=>typeof e=="string"&&e.includes("Snap Inc.")?e.split("Snap Inc.").flatMap((o,n)=>n===0?[mr(o)]:[i("span",{dir:"ltr",children:"Snap Inc."},o),mr(o)]):[typeof e=="string"?mr(e):e],Dx=(e="")=>{let t=tZ(e);return wx(t,oZ)};var Px={Document:Y6,Text:Dx,Bold:ep,Italics:tp,Underline:op,H1:jf,H2:Yf,H3:Xf,H4:Jf,H5:Zf,H6:eb,Paragraph:Kk,Hyperlink:Za,ListItem:Xk,UnorderedList:jk,OrderedList:Yk,Table:Ib,TableCell:iu,TableHeader:cp,TableRow:su,HorizontalRule:Zk,BlockQuote:Fh},Ri=e=>{if(e)return typeof e=="string"?e:(0,X6.documentToReactComponents)(e.json)},Po=Ei({components:{Bold:ep,Italics:tp,Underline:op}}),co=Ei({components:{Text:Dx,Bold:ep,Italics:tp,Underline:op,Paragraph:_x}}),J6=Ei({components:{Bold:ep,Italics:tp,Underline:op,Hyperlink:Za,Paragraph:_x}}),fo=Ei({components:Px}),Ar=Ei({components:{...Px,H1:Um,H2:Wm,H3:Qm,H4:qm,H5:Km,H6:jm}}),tg=(e=!1,t=!1)=>Ei({components:{...Px,...e?{H1:jf,H2:Yf,H3:Xf,H4:Jf,H5:Zf,H6:eb}:{H1:Um,H2:Wm,H3:Qm,H4:qm,H5:Km,H6:jm},Table:t?SA:Ib}});var Nx=e=>{let{url:t,onClick:o,buttonType:n,title:a,size:s,image:l,iconName:p,targetAsset:d,className:u,buttonTextDataset:y}=e,m=(0,e8.useContext)(be).elementLocation,{getImageSources:g}=ve(),f=()=>{o?.();let C;a?.json?C=(0,Z6.documentToPlainTextString)(a.json):l?.media?.title?C=`${l.media.title} - Image`:C=p??"unknown",ge({eventCategory:"Button",eventAction:"Click",eventLabel:t?`to: ${t}`:null,context:{elementText:C,targetUrl:d?.url??t,elementLocation:m}}),io(t)&&Me.flush()},b=n??rn.Primary,S=g(l?.media?.url);return i(no,{className:u,link:d?.url??t,type:b,onClick:f,size:s,iconName:p??void 0,imgSrcs:S,imgAltText:l?.media?.title,buttonTextDataset:y,children:Po(a)})};Nx.displayName="Button";var t8=E`
  fragment ButtonAll on Button {
    ...ContentfulSysId
    title {
      json
    }
    url
    targetAsset {
      ...AssetAll
    }
    size
    buttonType
    image {
      ... on Image {
        ...ImageAll
      }
    }
    iconName
  }
  ${$t.all}
  ${Oe.all}
  ${O}
`;var bo={all:E`
    fragment AnalyticsAll on Analytics {
      ...ContentfulSysId
      label
    }
    ${O}
  `},iOe=E`
  query AnalyticsQuery($preview: Boolean!, $locale: String!, $id: String!) {
    analytics(preview: $preview, locale: $locale, id: $id) {
      ...AnalyticsAll
    }
  }
  ${bo.all}
`;var bt=E`
  fragment CallToActionAll on CallToAction {
    ...ContentfulSysId
    analytics {
      ...AnalyticsAll
    }
    presentation {
      ... on Entry {
        ...ContentfulSysId
      }
      ... on Button {
        ...ButtonAll
      }
    }
    url
  }
  ${t8}
  ${O}
  ${bo.all}
`,o8=E`
  query CallToActionQuery($preview: Boolean!, $locale: String!, $id: String!) {
    callToAction(preview: $preview, locale: $locale, id: $id) {
      ...CallToActionAll
    }
  }
  ${bt}
`;var St=e=>{let t=(0,n8.useContext)(be).elementLocation,{className:o,...n}=e,{data:a}=se(o8,{skip:Gm(n),variables:{id:e.sys.id}}),s=a?a?.callToAction:e;if(!s||!s.sys||!s.presentation)return null;let{presentation:l,analytics:p,url:d,className:u}=s,y=p?.label,m=()=>{(y||d)&&ge({eventCategory:"CTA",eventAction:"Click",eventLabel:y??(d?`to: ${d}`:null),context:{elementText:y,targetUrl:d,elementLocation:t}})};if(l.__typename==="Button"){let g=l,{titleDataset:f}=Fe({entryId:g.sys.id,fieldIds:["title"]});return i(Nx,{onClick:m,...g,className:h(o,u),buttonTextDataset:f})}return null};St.displayName="CallToAction";var kc=T(w());var nZ=e=>e.split(";").filter(Boolean).reduce((t,o)=>{let[n,a]=o.split(":").map(s=>s.trim());if(n&&a){let s=n.replace(/-([a-z])/g,(l,p)=>p.toUpperCase());t[s]=a}return t},{}),rZ={"Fade in left":qo`from {opacity: 0; transform: translateX(-50px);} to {opacity: 1; transform: translateX(0);}`,"Fade in right":qo`from {opacity: 0; transform: translateX(50px);} to {opacity: 1; transform: translateX(0);}`,"Fade in top":qo`from {opacity: 0; transform: translateY(-50px);} to {opacity: 1; transform: translateY(0);}`,"Fade in bottom":qo`from {opacity: 0; transform: translateY(50px);} to {opacity: 1; transform: translateY(0);}`},Ex=e=>{if(!e)return{animation:void 0,styles:void 0};let t={},o="";return e?.advancedKeyframes?.keyframes?(o=qo(e.advancedKeyframes.keyframes),e.advancedKeyframes.startingCss&&(t=nZ(e.advancedKeyframes.startingCss))):(t.opacity=0,o=e.animation?rZ[e.animation]??"":""),{animation:{animationName:o,delay:e?.delay,direction:e?.direction,duration:e?.duration,iterationCount:e?.iterationCount,timingFunction:e?.advancedKeyframes?.timingFunction,transformOrigin:e?.advancedKeyframes?.transformOrigin},styles:t}};var a8=T(w());var Rx=E`
  fragment ImageButtonAll on ImageButton {
    ...ContentfulSysId
    url
    height
    width
    image {
      ...AssetAll
    }
  }

  ${O}
  ${$t.all}
`,r8=E`
  query ImageButtonQuery($preview: Boolean!, $locale: String!, $id: String!) {
    imageButton(preview: $preview, locale: $locale, id: $id) {
      ...ImageButtonAll
    }
  }

  ${Rx}
`;var i8=e=>{let{data:t}=se(r8,{variables:{id:e.sys.id}}),{getImageSources:o}=ve(),n=(0,a8.useContext)(be).elementLocation;if(!t?.imageButton)return null;let{url:a,image:s,...l}=t.imageButton,{imageSource:p,imageAltText:d}=je(s),u=o(p);return i($s,{...l,url:a,onClick:()=>{ge({eventAction:"Click",eventCategory:"ImageButton",eventLabel:null,context:{targetUrl:a,elementLocation:n}}),io(a)&&Me.flush()},imgSrcs:u,altText:d})};var s8=c`
  max-width: 100%;
  max-height: 400px;
`,l8=c`
  margin-bottom: inherit;
  max-height: 600px;

  ${N} {
    max-width: 100%;
    height: inherit;
  }
`,p8=c`
  .${"sdsm-content-body"} {
    .${fs} {
      margin-block-end: ${r("--spacing-m")};
    }

    video {
      max-height: 800px;
    }
  }

  /* Unset margin for media wrapper inside quote component */
  /* For quote component, the asset should cover the entire container */
  .sdsm-quote-container .${fs} {
    margin-block-end: unset;
  }
`,c8=c`
  /* Unlike images, videos will always expand to the width of their container. The benefits are two fold...

   1. We don't have to worry about the poster image being a different size than the video.
   2. We don't have to worry about different video resolutions (but same aspect ratio) rendering as different sizes.

  */
  width: 100%;
`;var Mc=e=>{let[t,o]=(0,kc.useState)(!1),{getImageSources:n}=ve(),a=(0,kc.useContext)(be).elementLocation,{isRTL:s}=(0,kc.useContext)(ee),p=ol()==="snap",{sys:d,mediaWrap:u,showVideoControls:y,layout:m,mediaDirection:g,mediaDirectionMobile:f,displayOn:b,asset:S,title:C,subtitle:v,titleAlignment:k,titleAlignmentMobile:I,showFullResolutionMedia:A,body:D,bodyAlignment:B,bodyAlignmentMobile:M,callsToActionCollection:_,theme:P,brandBackgroundColor:$,backgroundColor:R,brandBorderColor:L,borderColor:G,anchorId:Z,useHeadingTagsForBody:U,collapseMobileTable:de,listIcon:le,entranceAnimation:re}=e,te=it($),oe=S&&!(C||v||D),{getBestBgImgSrc:q}=ve(),X=q(le?.media?.url,{width:72,height:72,resizeFocus:"center",fit:"fill"}),W=tg(U,de),{media:{imageSource:K,imageAltText:F,imageSize:Q,videoSource:z},mobileMedia:{imageSource:Se,imageSize:j,videoSource:fe},thumbnailSource:J}=Yt(S),ue=Fe({entryId:d.id,fieldIds:["body","title","subtitle","asset"]}),{animation:_e,styles:we}=Ex(re),Be=[];if(_?.items)for(let ke of _.items)ke.__typename==="ImageButton"?Be.push(i(i8,{...ke},ke.sys.id)):ke.__typename==="CallToAction"&&Be.push(i(St,{...ke},ke.sys.id));let Ce=A&&Q?.height?Q.height:oe?600:400,{desktopSettings:We,mobileSettings:Pt}=Dt({desktopHeight:Q?.height??0,mobileHeight:j?.height,desktopDefaultHeight:Ce,mobileDefaultHeight:Ce,enableHighDpi:S?.enableHighDpi,quality:S?.quality}),$e=Le({desktop:n(K,We),mobile:n(Se,Pt)}),Ro=-1,eo=()=>{if(z&&!t){if(S.autoPlay)return;let{fileName:ke}=Dn(z);ge({eventAction:"Play",eventCategory:"Content",eventLabel:ke,context:{elementLocation:a}}),o(!0)}},Ie=()=>{if(z&&!S.autoPlay){let{fileName:ke}=Dn(z);ge({eventAction:"Pause",eventCategory:"Content",eventLabel:ke,context:{elementLocation:a}})}},me;if(S){let ke=S.__typename,Nt=ja({autoPlay:S.autoPlay,eventLabel:S.externalId??S?.sys.id,getPreviousWatchTime:()=>Ro,setPreviousWatchTime:to=>{Ro=to},elementLocation:a});if(ke==="Video"||ke==="Image"){let to=S.wrap,{thumbnailMedia:ce,captions:ht,autoPlay:st,media:rt}=S,Et=ce?.description??rt.description,Uo=y??(Ct(st)?!1:!st),oo=ke==="Image"&&(Q?.height??0)>(Q?.width??0),mn=h({[l8]:!A&&oe,[s8]:!A&&!oe,"strict-height":!A&&oo,[c8]:ke==="Video"}),Wo=S?.stickersCollection?.items?.map(Ye=>({imgSrcs:n(Ye?.asset?.url),position:Ye?.position,rotation:Ye?.rotation}));me=i(xn,{mediaClassName:mn,altText:F??Et,imgSrcs:$e,posterSource:J,wrap:to??u,dataset:ue.assetDataset,imageSource:K,showVideoControls:Uo,videoSource:z,mobileVideoSource:fe,onPlay:eo,onPause:Ie,onTimeUpdate:Nt,captionsSource:ht?.url,stickers:Wo})}else if(ke==="SnapchatEmbed")me=i(Gs,{...S,dataset:ue.assetDataset});else if(ke==="Stats"){let to=S;me=i(Uh,{stat:to.stat,optionalSupplementaryText:to.optionalSupplementaryText,animation:_e,style:we})}}return i(As,{title:co(C),subtitle:co(v),titleAlignment:k??void 0,titleAlignmentMobile:I,body:W(D),layout:m,mediaDirection:g,mediaDirectionMobile:f,bodyAlignment:B??void 0,bodyAlignmentMobile:M,className:p8,callsToAction:Be,displayOn:b??void 0,motifScheme:te,backgroundColor:R??P,borderColor:L??(p?void 0:G),anchorId:Z,animation:_e,isRTL:s,asset:me,style:we,listIconUrl:X,...ue})};Mc.displayName="Content";var xGe={contentAll:E`
    fragment ContentAnimationAll on ContentAnimation {
      keyframes {
        ...ContentfulSysId
        timingFunction
        transformOrigin
      }
      target
    }
    ${O}
  `},vGe=E`
  query AnimationCollectionQuery($preview: Boolean!, $locale: String!) {
    animationKeyframesCollection(
      preview: $preview
      locale: $locale
      limit: 20
      order: sys_publishedAt_ASC
    ) {
      items {
        ...ContentfulSysId
        timingFunction
        transformOrigin
        keyframes
      }
    }
  }
  ${O}
`,aZ=E`
  fragment AnimationKeyframesAll on AnimationKeyframes {
    ...ContentfulSysId
    timingFunction
    transformOrigin
    startingCss
    keyframes
  }
  ${O}
`,og=E`
  fragment EntranceAnimationAll on EntranceAnimation {
    ...ContentfulSysId
    delay
    direction
    duration
    iterationCount
    animation
    advancedKeyframes {
      ...ContentfulSysId
      ...AnimationKeyframesAll
    }
  }
  ${O}
  ${aZ}
`;var Fx=E`
  fragment DefinitionAll on Definition {
    ...ContentfulSysId
    displayText
    fullText {
      json
    }
    anchorId
  }
  ${O}
`,TGe=E`
  query DefinitionQuery($preview: Boolean!, $locale: String!, $id: String!) {
    Definition(preview: $preview, locale: $locale, id: $id) {
      ...DefinitionAll
    }
  }
  ${Fx}
`;var Bx=e=>{let{number:t,fullText:o}=e;return o?i(DS,{index:String(t),children:fo(o)}):null};Bx.displayName="Footnote";var Tc={all:E`
    fragment FootNotesAll on FootNotes {
      ...ContentfulSysId
      number
      displayText
      fullText {
        json
      }
      anchorId
    }
    ${O}
  `},RGe=E`
  query FootNotesQuery($preview: Boolean!, $locale: String!, $id: String!) {
    footNotes(preview: $preview, locale: $locale, id: $id) {
      ...FootNotesAll
    }
  }
  ${Tc.all}
`;var ng=E`
  fragment StatsAll on Stats {
    __typename
    sys {
      id
    }
    stat
    optionalSupplementaryText
    entranceAnimation {
      ...EntranceAnimationAll
    }
  }
  ${og}
`,GGe=E`
  query StatsQuery($preview: Boolean!, $locale: String!, $id: String!) {
    stats(preview: $preview, locale: $locale, id: $id) {
      ...StatsAll
    }
  }
  ${ng}
`;var d8=E`
  fragment ContentAssetAll on ContentAsset {
    ...ContentfulSysId
    ... on Video {
      ...VideoAll
    }
    ... on Image {
      ...ImageAll
    }
    ... on SnapchatEmbed {
      ...SnapchatEmbedAll
    }
    ... on Stats {
      ...StatsAll
    }
  }
  ${O}
  ${Oe.all}
  ${gt.all}
  ${vc}
  ${ng}
`,$x={all:E`
    fragment ContentAll on Content {
      ...ContentfulSysId
      title {
        json
      }
      subtitle {
        json
      }
      # CTA Collection limit has to be 3 or less for GraphQL query complexity issues.
      callsToActionCollection(limit: 3) {
        items {
          ... on CallToAction {
            ...CallToActionAll
          }
          ... on ImageButton {
            ...ContentfulSysId
          }
        }
      }
      showVideoControls
      mediaWrap
      layout
      mediaDirection
      mediaDirectionMobile
      titleAlignment
      titleAlignmentMobile
      bodyAlignment
      bodyAlignmentMobile
      listIcon {
        ...ContentfulSysId
        media {
          url
        }
      }
      useHeadingTagsForBody
      collapseMobileTable
      showFullResolutionMedia
      displayOn
      theme
      brandBackgroundColor
      backgroundColor
      brandBorderColor
      borderColor
      anchorId
      asset {
        ...ContentAssetAll
      }
      entranceAnimation {
        ...EntranceAnimationAll
      }
      body {
        json
        # TODO: There's an inline expansion into embedded content. Consider lazy-loading this
        # to reduce the query complexity for the typical use-case.
        links {
          entries {
            block {
              ...ContentfulSysId
              ... on CustomerQuote {
                ...CustomerQuoteAll
              }
              ... on CallToAction {
                ...CallToActionAll
              }
              ... on Code {
                ...CodeAll
              }
              ... on Image {
                ...ImageAll
              }
            }
            inline {
              ...ContentfulSysId
              ... on FootNotes {
                ...FootNotesAll
              }
              ... on CustomerQuote {
                ...CustomerQuoteAll
              }
              ... on CallToAction {
                ...CallToActionAll
              }
              ... on Definition {
                ...DefinitionAll
              }
            }
            hyperlink {
              ...ContentfulSysId
              ... on Slug {
                slug
              }
            }
          }
          assets {
            block {
              ...AssetAll
            }
            hyperlink {
              ...AssetAll
            }
          }
        }
      }
    }
    ${Pn}
    ${bt}
    ${Tc.all}
    ${Fx}
    ${xx.all}
    ${gt.all}
    ${Oe.all}
    ${A6.all}
    ${d8}
    ${og}
  `,media:E`
    fragment ContentMedia on Content {
      ...ContentfulSysId
      title {
        json
      }
      asset {
        ...ContentAssetAll
      }
    }
    ${O}
    ${d8}
  `},rg={all:E`
    query ContentQuery($preview: Boolean!, $locale: String!, $id: String!) {
      content(preview: $preview, locale: $locale, id: $id) {
        ...ContentAll
      }
    }
    ${$x.all}
  `};var Fi=25,pl=E`
  fragment BlockAll on Block {
    ...ContentfulSysId
    anchorId
    theme
    brandBackgroundColor
    backgroundColor
    backgroundMediaV2 {
      __typename
      ... on Video {
        ...VideoAll
      }
      ... on Image {
        ...ImageAll
      }
    }
    showCurtain
    eyebrow
    title {
      json
      links {
        entries {
          inline {
            ...ContentfulSysId
            ... on EmphasizedText {
              ...EmphasizedTextAll
            }
          }
        }
      }
    }
    subtitle {
      json
    }
    titleAlignment
    titleAlignmentMobile
    maxColumns
    isNarrow
    widthStyle
    fullHeight
    contentsCollection(limit: 15) {
      items {
        ...ContentfulSysId
      }
    }
    callsToActionCollection(limit: 9) {
      items {
        ... on CallToAction {
          ...CallToActionAll
        }
      }
    }
  }
  ${O}
  ${bt}
  ${$t.all}
  ${gt.all}
  ${Oe.all}
  ${ei}
`,Ize=E`
  fragment BlockPreview on Block {
    ...ContentfulSysId
    title {
      json
    }
    contentsCollection(limit: 5) {
      items {
        ... on Content {
          ...ContentMedia
        }
      }
    }
  }
  ${O}
  ${$x.media}
`,ag=E`
  fragment BlockShallow on Block {
    ...ContentfulSysId
    contentsCollection(limit: 15) {
      items {
        ...ContentfulSysId
      }
    }
  }
  ${O}
`,u8=E`
  query BlockQuery($preview: Boolean!, $locale: String!, $id: String!) {
    block(preview: $preview, locale: $locale, id: $id) {
      ...BlockAll
    }
  }
  ${pl}
`;var Xt=E`
  fragment CriteriaAll on Criteria {
    ...ContentfulSysId
    trafficRangeStart
    trafficRangeEnd
    countryAction
    countries
    languageAction
    languages
    deviceAction
    devices
    platformAction
    platforms
    utmParams
    utmParamsAction
    businessPersonaAction
    businessPersonasMatchAll
    businessPersonas
    snapPersonaAction
    snapPersonas
  }
  ${O}
`,y8=E`
  fragment SiteMapExperiment on Experiment {
    sys {
      id
    }
    defaultReference {
      ...SiteMapPage
    }
  }
`;function ig(e,t,o,n=10){return E`
    fragment ExperimentOn${e}Loading${t} on Entry {
      ... on ${e} {
        ...${t}
      }
      ... on Experiment {
        ...ContentfulSysId
        defaultReference {
          ...${t}
        }
        experimentArmsCollection(limit: ${n}) {
          items {
            ...ContentfulSysId
            reference {
              ...${t}
            }
            criteria {
              ...CriteriaAll
            }
            abExperimentsCollection(limit: ${n}) {
              items {
                ...ContentfulSysId
                analyticsId
                seed
                reference {
                  ...ContentfulSysId
                }
                abVariantsCollection(limit: 5) {
                  items {
                    ...ContentfulSysId
                    replacement {
                      ...ContentfulSysId
                      ... on Page {
                        # The standard page level block query has a set limit, which, at the time of writing this comment
                        # is 25. However, this particular query, due to its nested nature, requires a lower limit, otherwise
                        # it will break our query complexity cap. Therefore, we drastically lower the limit for this particular
                        # query to be much smaller than the established "blockQueryLimit".
                        #
                        # Rather than hardcoding this limit, we use the existing blockQueryLimit constant, and scale it down
                        # to 40% of its original value. This should ensure that this query stays sufficiently within the complexity
                        # cap.
                        blocksCollection(limit: ${Math.floor(Fi*(2/5))}) {
                          items {
                            ...ContentfulSysId
                            ... on Block {
                              ...BlockShallow
                            }
                          }
                        }
                      }
                      ... on Block {
                        ...ContentfulSysId
                        contentsCollection(limit: 10) {
                          items {
                            ...ContentfulSysId
                          }
                        }
                      }
                    }
                    trafficStartRange
                    trafficEndRange
                    analyticsId
                  }
                }
              }
            }
            analyticsId
          }
        }
        analyticsId
      }
    }
    ${ag}
    ${O}
    ${Xt}
    ${o}
  `}function ti(e,t,o,n=10){return E`
    fragment ExperimentOn${e}Loading${t} on Entry {
      ... on ${e} {
        ...${t}
      }
      ... on Experiment {
        ...ContentfulSysId
        defaultReference {
          ...${t}
        }
        experimentArmsCollection(limit: ${n}) {
          items {
            ...ContentfulSysId
            reference {
              ...${t}
            }
            criteria {
              ...CriteriaAll
            }
            analyticsId
          }
        }
        analyticsId
      }
    }
    ${O}
    ${Xt}
    ${o}
  `}var yl=T(w());var cl=T(w());var m8=e=>{let t=0,o=0;for(let n=0;n<e.length;n++)t=(t+e.charCodeAt(n))%1024,o=(o+n*e.charCodeAt(n))%1024;return t+o};var iZ="useAbExperiments";function sg(){let{getUserInfo:e,getCurrentUrl:t}=(0,cl.useContext)(ee),[o,n]=(0,cl.useState)(!1),{data:a}=an({skip:!o,dataId:"userInfo",dataAsync:e,onError:l=>Me.logError({component:iZ,error:l})});return(0,cl.useCallback)(l=>(!o&&n(!0),sZ(l,{userInfo:a,getCurrentUrl:t})),[o,t,a])}var sZ=(e,t)=>{let{userInfo:o,getCurrentUrl:n}=t;if(!o)return{isThinking:!0,decision:void 0};let a=o.experimentBucket.id+e.seed,l=m8(a)%1024/1024*100;if(!V.isDeploymentTypeProd){let d=new URL(n()).searchParams.get("experimentsUserBucket"),u=d?Number.parseInt(d):void 0;u!==void 0&&u>=0&&u<=100&&(l=u)}if(!e.variants)return{isThinking:!1,decision:e.default};for(let p of e.variants)if(!(Ct(p.trafficStartRange)||Ct(p.trafficEndRange))&&p.trafficStartRange<=l&&p.trafficEndRange>=l)return{isThinking:!1,decision:p};return{isThinking:!1,decision:e.default}};var dl=T(w());var lg=class lg{constructor(t){Ae(this,"ref");Ae(this,"deref",()=>this.ref);this.ref=t}get[Symbol.toStringTag](){return lg.tag}};Ae(lg,"tag","WeakRef");var Lx=lg,lZ=50;function pZ(e,t){return e.length!==t.length?!1:e.every((o,n)=>{let a=t[n];return typeof a=="object"&&a!==null&&"deref"in a?o===a.deref():o===a})}function cZ(e){return typeof e=="object"&&e!==null?WeakRef?new WeakRef(e):new Lx(e):typeof e=="string"||typeof e=="number"||typeof e=="boolean"?e:String(e)}function g8({key:e,callback:t,dependencies:o,cache:n}){n.has(e)||n.set(e,[]);let a=n.get(e);a.some(s=>pZ(o,s))||(a.length>=lZ&&a.shift(),a.push(o.map(cZ)),t())}var Hx=(0,dl.createContext)(new Map);function pg(){let e=(0,dl.useContext)(Hx);return(0,dl.useCallback)(o=>g8({...o,cache:e}),[e])}var ul=T(w());var dZ="useUserBusinessProfile";function f8(){let{cookieManager:e,getPersona:t,personasRef:o}=(0,ul.useContext)(ee),[n,a]=(0,ul.useState)(!1),{data:s}=an({skip:!n,dataId:"persona",dataAsync:t,onError:p=>Me.logError({component:dZ,error:p})});return(0,ul.useCallback)(()=>{let p=o?.current;if(p?.biz!==void 0)return{isThinking:!1,decision:p.biz};let d=ia(e);return d?.biz!==void 0?{isThinking:!1,decision:d.biz}:(n||a(!0),uZ(s))},[e,n,s,o])}var uZ=e=>e?e?.matches?.length?{isThinking:!1,decision:[...e.matches]}:{isThinking:!1,decision:null}:{isThinking:!0,decision:void 0};var cg=T(w());function b8(){let{cookieManager:e,personasRef:t}=(0,cg.useContext)(ee);return(0,cg.useCallback)(()=>{if(t?.current?.snap!==void 0)return t.current.snap??[];let n=ia(e);return n?.snap!==void 0?n.snap??[]:[]},[e,t])}var S8=e=>{let t=new URL(e),o={};for(let[n,a]of t.searchParams.entries())n.startsWith("utm_")&&(o[n]=a);return o};var yZ=!1;function Bi(e,t,o,n){yZ&&(e??(e="synthetic"),n??(n="Allow"),console.debug(`Criteria not applicable for arm '${e}' because of check '${t}' in '${o}' has action '${n}'.`))}function nn(){let{cookieManager:e,currentLocale:t,userLocation:o,getCurrentUrl:n,personasRef:a,updatePersonas:s}=(0,yl.useContext)(ee),l=(0,yl.useContext)(Ze),p=pg(),d=sg(),u=b8(),y=f8(),m=t??"Unknown",g=o.country??"Unknown",f=l.getLowEntropyHints().platform??"Unknown",b=l.getLowEntropyHints().isMobile?"Mobile":"Non-Mobile",S=S8(n()),C=(0,yl.useCallback)(k=>h8(k,{language:m,country:g,platform:f,deviceType:b,utmParams:S}),[m,g,f,b,S]);return{decideExperiment:(0,yl.useCallback)((k,I)=>mZ(k,{language:m,country:g,platform:f,deviceType:b,singleCallback:p,getCurrentUrl:n,decideAbExperiment:d,utmParams:S,getUserSnapProfile:u,getUserBusinessProfile:y,personasRef:a,updatePersonas:s,cookieManager:e},I),[m,g,f,b,p,d,n,S,u,y,a,s,e]),checkCriteria:C}}var _c=(e,t,o)=>(o??(o="Allow"),!!(o==="Allow"&&e&&!e.includes(t)||o==="Deny"&&e?.includes(t)));function h8(e,t,o){if(!e)return!0;if(_c(e.countries,t.country,e.countryAction))return Bi(o,t.country,e.countries,e.countryAction),!1;if(_c(e.languages,t.language,e.languageAction))return Bi(o,t.language,e.languages,e.languageAction),!1;if(_c(e.platforms,t.platform,e.platformAction))return Bi(o,t.platform,e.platforms,e.platformAction),!1;if(_c(e.devices,t.deviceType,e.deviceAction))return Bi(o,t.deviceType,e.devices,e.deviceAction),!1;if(e.utmParams){for(let[n,a]of Object.entries(e.utmParams))if(_c(a,t.utmParams[n]??"",e.utmParamsAction))return Bi(o,t.utmParams[n]??"",e.utmParams[n],e.utmParamsAction),!1}return!0}function mZ(e,t,o){if(e.__typename!=="Experiment")return o.logImpression&&ot({subscribedEventType:"experiment_impression",experimentId:void 0,variantId:void 0,context:{locale:t.language}}),{decision:e};let n=e,a="default",s=n.defaultReference,l={},p=t.singleCallback,d=!1;for(let u of n.experimentArmsCollection?.items??[]){if(!u.criteria)continue;let y=h8(u.criteria,t,u.analyticsId),m=u.criteria?.snapPersonas,g=u.criteria?.businessPersonas,f=u.criteria?.businessPersonasMatchAll,b=!!g?.length||f,S=!!m?.length;if(!y&&!b&&!S)continue;if(b){let v=t.getUserBusinessProfile();if(v.isThinking){d=!0;break}let k=v.decision,A={...ia(t.cookieManager)||t.personasRef?.current,biz:k};if(t.updatePersonas?.(A),$m(t.cookieManager,A),!k||k.length===0)continue;let D=u.criteria?.businessPersonaAction??"Allow";if(f){if(D==="Deny")continue}else{let B=k.some(_=>g?.includes(_)),M=!1;if(D==="Allow"&&!B&&(M=!0),D==="Deny"&&B&&(M=!0),M){k.forEach(_=>{Bi(u.analyticsId,_,g,D)});continue}}}if(S){let v=t.getUserSnapProfile(),k=u.criteria?.snapPersonaAction??"Allow",I=v.some(D=>m?.includes(D)),A=!1;if(k==="Allow"&&!I&&(A=!0),k==="Deny"&&I&&(A=!0),A){v.forEach(D=>{Bi(u.analyticsId,D,m,k)});continue}}if(s=u.reference,a=u.analyticsId??a,(u.abExperimentsCollection?.items.length??0)>0&&u.abExperimentsCollection?.items.length){let v=u.abExperimentsCollection.items;for(let k of v){let I=k.reference?.sys.id,A=!1;if(!I)continue;let{isThinking:D,decision:B}=t.decideAbExperiment({seed:k.seed??k.sys.id,variants:k.abVariantsCollection?.items});B&&(B.replacement?.__typename==="Page"?s=B.replacement:B.replacement?l[I]={...B.replacement}:l[I]=void 0,p({key:"useExperimentVariantSwap",callback:()=>Hn({eventCategory:"Experiment",eventAction:"experimentExposure",eventLabel:`${a}:${k.analyticsId}:${B.analyticsId}`,context:{locale:t.language}}),dependencies:[a,k.analyticsId,B.analyticsId]}),A=!0),!D&&!A&&p({key:"useExperimentDefault",callback:()=>Hn({eventCategory:"Experiment",eventAction:"experimentExposure",eventLabel:`${a}:${k.analyticsId}:default`,context:{locale:t.language}}),dependencies:[a,k.analyticsId]})}}break}return d?{decision:s}:(p({key:"useExperiment",callback:()=>Hn({eventCategory:"Experiment",eventAction:"useExperiment",eventLabel:`${er(n.analyticsId??"")}:${er(a)}`,context:{locale:t.language}}),dependencies:[n.analyticsId,a]}),o.logImpression&&p({key:"experimentImpression",callback:()=>ot({subscribedEventType:"experiment_impression",experimentId:n.analyticsId??"Unknown",variantId:a,context:{locale:t.language}}),dependencies:[n.analyticsId,a]}),{decision:s,experimentId:n.analyticsId,variantId:a,replacements:l})}var C8=c`
  display: flex;
`,x8=c`
  display: flex;
  align-items: center;
`,v8=c`
  padding-block-end: ${r("--spacing-xs")};

  ${H} {
    padding-block-end: 0;
  }
`;var gZ=(e,t)=>{if(e.__typename==="FooterCookiesSettingsLink")return{id:e.sys.id,title:e.title??"",url:t};if(e.__typename!=="FooterLocaleDropdown"&&e.__typename==="FooterItem")return!e.url||!e.title?void 0:{analyticsLabel:e?.analytics?.label,id:e.sys.id,title:e.title,url:e.url}},Vx=(e,t,o)=>{if(!o||!o.length)return[];let n=s=>s.reduce((l,p)=>{if(e(p)){let d=gZ(p,t);d&&l.push(d)}return l},[]);return(s=>s.reduce((l,p)=>{if(e(p)){if(!p.groupKey||!p.itemsCollection?.items)return l;l.push({items:n(p.itemsCollection.items),title:p.title??"",groupKey:p.groupKey})}return l},[]))(o)};var k8=({cookieSettingsUrl:e})=>{let{footerView:t,hasSideNav:o,hasCustomSideNav:n}=(0,ml.useContext)(on),{getImageSources:a}=ve(),s=(0,ml.useCallback)((M,_)=>{ge({eventCategory:"Footer",eventAction:"Click",eventLabel:`footer_group_toggle: ${M}`,context:{elementText:_,elementLocation:"Footer"}})},[]),l=Ya(V,"footer"),{formatMessage:p}=(0,ml.useContext)(qe),d=p({id:"navigate-to-snap-com",defaultMessage:"Navigate to snap.com"}),u={...V.theme?.footerPropsOverride,...l},{sitewideValues:y}=(0,ml.useContext)(ka),m=it(y?.customFooter?.brandBackgroundColor),{checkCriteria:g}=nn(),f=t==="Simple Footer",b=t==="No Footer",S="Full Footer";if(b?S="No Footer":f&&(S="Simple Footer"),b)return null;if(V.site==="stinson")return i(void 0,{cookieSettingsUrl:e});let C=M=>g(M.criteria),v=y?.customFooter,k=Vx(C,e,v?.columnsCollection?.items),I=Vx(C,e,v?.barCollection?.items),A=v?.socialCollection?.items?.length?i(L2,{title:v?.socialLabel??void 0,hasSideNav:o||n,children:v?.socialCollection?.items?.map((M,_)=>{let{image:P,height:$,sys:R,url:L,width:G}=M;return i($s,{url:L,height:$,imgSrcs:a(P?.url),altText:P?.description,width:G,pictureClassName:C8,className:x8},`${R.id}-${_}`)})}):null,D=v?.logo,B;if(D){let M=a(D.media?.url,{image:{height:24}}),_=v?.url,P=i(Ke,{sourceType:D.media?.contentType,marginBottom:!1,imgSrcs:M,altText:D.media?.description});if(_){let $=v?.logoAriaLabel||d;B=i(yn,{href:_,className:v8,"aria-label":$,children:P})}else B=P}return i(hC,{customColumns:k,customFooterBar:I,cookieSettingsUrl:e,motifScheme:m,backgroundColor:v?.backgroundColor,logo:B,socialBar:A,footerType:S,hasSideNav:o||n,onGroupToggle:s,...u})};var T8=()=>{switch(V.site){case"avalon":return i(void 0,{});default:return null}};var Nn=T(w());var A8=e=>{let{checkCriteria:t}=nn(),o=zt(),{displayMode:n="DesktopHeader"}=e,a=o.pathname.substring(1)||"home",s=e.displayModes?.includes(n),l=!e.hideCriteria||t(e.hideCriteria),p=e.hideForSlugs?.some(d=>a===d);return!s||!l||p?null:e.callToAction?i(St,{...e.callToAction}):null};var wc=E`
  fragment NavigationCta on NavigationCallToAction {
    ...ContentfulSysId
    callToAction {
      ...CallToActionAll
    }
    displayModes
    hideCriteria {
      ...CriteriaAll
    }
    hideForSlugs
  }
  ${Xt}
  ${O}
  ${bt}
`,JUe=E`
  query NavigationCtaQuery($preview: Boolean!, $locale: String!, $id: String!) {
    cavigationCta(preview: $preview, locale: $locale, id: $id) {
      ...NavigationCta
    }
  }
  ${wc}
`;var Gx=({displayRegion:e="Header",callsToAction:t})=>{let o=Rt();if(!t)return null;let n="DesktopHeader";o&&e==="Header"&&(n="MobileHeader"),o&&e==="Screen"&&(n="MobileScreen");let a=t.map(s=>{switch(s.__typename){case"NavigationCallToAction":{let l=Io(s),p=l.callToAction?.presentation;return!o||e==="Screen"?p&&(p.size=Qf.Compact):p&&(p.buttonType=rn.Flat),i(A8,{...l,displayMode:n},s.sys.id)}case"CallToAction":{let l=Io(s),p=l.presentation;return!o||e==="Screen"?p&&(p.size=Qf.Compact):p&&(p.buttonType=rn.Flat),i(St,{...l},s.sys.id)}default:throw new Error(`Unknown navigation CTA ${s.__typename}`)}});return i(pe,{children:a})};var zx=T(w());var _8=()=>{let{sitewideValues:e}=(0,zx.useContext)(ka),{formatMessage:t}=(0,zx.useContext)(qe),o=t({id:"navigate-to-home",defaultMessage:"Navigate to home page"}),n=e?.navigationBar,{getImageSources:a}=ve();if(!n)return null;let{url:s,logoV2:l}=n,p=Le({mobile:a(l?.mobileMedia?.url),desktop:a(l?.media?.url)});return i(pe,{children:i(ki,{imgSrcs:p,url:s,logoType:"Ghost",ariaLabel:o})})};var Ux=T(w());var w8=({setSearchOpen:e,autocompleteProps:t})=>{let{formatMessage:o}=(0,Ux.useContext)(qe),{pathname:n}=zt(),{onRedirect:a}=(0,Ux.useContext)(ee),s=l=>{a?.(`/search?q=${encodeURIComponent(l)}`)};return i(pu,{autocompleteResults:[],cancelMessage:o({id:"globalHeaderSearchCancel",defaultMessage:"Cancel"}),collapsible:!0,disabled:n==="/search",hideSuggestions:!0,loadingAutocompleteTerms:!1,onChange:xo,onCollapseChange:l=>e(l),onSeeResults:s,onSelect:xo,placeholder:o({id:"placeholderSearchPageInput",defaultMessage:"Search..."}),shortBar:n!=="/search",...t})};var D8=T(w());var P8=({items:e})=>{let t=(0,D8.useContext)(be).elementLocation;if(!e||!e.length)return null;let o=n=>{let{contentfulDescriptionDataset:a}=Fe({entryId:n,fieldIds:["contentfulDescription"]});return a};return i(pe,{children:e.map(n=>{let{sys:a,url:s,title:l,isSelected:p,analytics:d,column1Label:u,column1Items:y,column2Label:m,column2Items:g,column3Label:f,column3Items:b,featuredMenuItem:S}=n,C=a.id,v=(k,I)=>{ge({eventCategory:"NavigatorItem",eventAction:"Click",eventLabel:I??k,context:{targetUrl:k,elementText:l,elementLocation:t}}),io(k)&&Me.flush()};return i(Gp,{dataset:o(C),id:C,url:s??"",isSelected:p,title:l??"",analytics:d?.label?{label:d.label}:void 0,col1Label:u,col1Items:y,col2Label:m,col2Items:g,col3Label:f,col3Items:b,featuredItem:S,onClick:v},C)})})};var dg=T(w());var Wx=T(w());var N8=({sys:e,url:t,title:o,isSelected:n,analytics:a,column1Label:s,column1Items:l,column2Label:p,column2Items:d,column3Label:u,column3Items:y,featuredMenuItem:m})=>{let g=(0,Wx.useContext)(be).elementLocation,{getCurrentUrl:f}=(0,Wx.useContext)(ee),{contentfulDescriptionDataset:b}=Fe({entryId:e.id,fieldIds:["contentfulDescription"]});if(!o)return null;let S=(I,A)=>{ge({eventAction:"Click",eventCategory:"LocalNavItemMobile",eventLabel:A??null,context:{elementText:o,targetUrl:I,elementLocation:g}}),io(I)&&Me.flush()},C=new URL(t??"",f()),v=un(C),k=!!(l?.length||d?.length||y?.length||m);return i(Yr,{showExternalIcon:!v,href:t,title:o,onClick:()=>S(t??"",a?.label),isSelected:n,dataset:b,addTrackingParams:!v,onToggle:I=>{ge({eventAction:"Click",eventCategory:"LocalNavMobile",eventLabel:a?.label??null,context:{elementText:I,elementLocation:g}})},children:k&&i(zp,{col1Label:s,col1Items:l,col2Label:p,col2Items:d,col3Label:u,col3Items:y,featuredItem:m,onClick:S})})};var E8=({items:e})=>{let{setGroupKey:t}=(0,dg.useContext)(at);return(0,dg.useEffect)(()=>{t?.(_b)},[t]),!e||!e.length?null:i(pe,{children:e.map((o,n)=>i(N8,{...o},`${o.sys.id}-${n}`))})};var R8=T(w());var ug=()=>{let e=(0,R8.useContext)(en);if(e===void 0)throw new Error("ConsumerContext can only be used in combination with ConsumerProvider");return e};var F8=c`
  width: 500px;
  &&& {
    margin-left: auto;
  }
`,B8=c`
  width: 100%;
  &&& {
    margin-left: auto;
  }
`,$8=c`
  & > *:first-child {
    width: 100%;
  }
`,L8=c`
  display: inline-block;
  cursor: pointer;
  color: ${r("--fg-color")};
  text-decoration: none;
`,H8=c`
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: ${Ee.NAVIGATOR};
`,V8=c`
  margin: 0;
`;function O8(e,t,o,n){let a=[];for(let s of e??[]){let l=bZ(s,t,o,n);l&&a.push(l)}return a}var bZ=(e,t,o,n)=>{if(!(o?.(e.hideCriteria)??!0))return null;let s=(!!e.url&&t?.(e.url))??!1,l=(k,I)=>{if(!(o?.(I.hideCriteria)??!0))return k;let D=(!!I.url&&t?.(I.url))??!1;return s||(s=D),k.push({title:I.title??"",url:I.url??"",description:I.description,analytics:G8(I),icon:z8(I),media:U8(I,n),dataset:Fe({entryId:I.sys.id,fieldIds:["contentfulDescription"]}).contentfulDescriptionDataset}),k},{column1MenuItemsCollection:p,column2MenuItemsCollection:d,column3MenuItemsCollection:u,featuredHeaderMenuItem:y,...m}=e,g=p?.items.reduce(l,[]),f=d?.items.reduce(l,[]),b=u?.items.reduce(l,[]),S=SZ(e,n),C=o?.(e.featuredHeaderMenuItem?.hideCriteria)??!0;if(e.featuredHeaderMenuItem&&C){let k=(!!e.featuredHeaderMenuItem.url&&t?.(e.featuredHeaderMenuItem.url))??!1;s||(s=k)}return{...m,isSelected:s,column1Items:g,column2Items:f,column3Items:b,featuredMenuItem:S}},G8=e=>{let t=e.analytics?.label;if(t)return{label:t}},z8=e=>{let t=e.icon?.icon;if(t)return{name:t}},U8=(e,t)=>{let o=e.icon?.media?.contentType==="image/svg+xml",n=e.icon?.media;if(!o||!n||!t)return;let a=Le({desktop:t(n.url)});return{altText:n.description,imgSrcs:a}},SZ=(e,t)=>{if(!e.featuredHeaderMenuItem)return;let{title:o,url:n,description:a,ctaLabel:s}=e.featuredHeaderMenuItem;return{title:o??"",url:n??"",description:a,ctaLabel:s,analytics:G8(e.featuredHeaderMenuItem),icon:z8(e.featuredHeaderMenuItem),media:U8(e.featuredHeaderMenuItem,t),dataset:Fe({entryId:e.featuredHeaderMenuItem.sys.id,fieldIds:["contentfulDescription"]}).contentfulDescriptionDataset}};var Dc=T(w()),W8=T(ma());var hZ="mwp-header-portal",Qx=(0,Dc.memo)(e=>{let{headerPortalRef:t}=(0,Dc.useContext)(ee);return i("aside",{className:e.className,"data-testid":hZ,ref:t})});Qx.displayName="HeaderPortal";var CZ=({children:e})=>{let{headerPortalRef:t}=(0,Dc.useContext)(ee);return t?.current?(0,W8.createPortal)(e,t.current):null};CZ.displayName="IntoHeaderPortal";var xZ=64,Q8=e=>{xZ=e};var Tt="--total-header-height",gl=()=>Number.parseInt(getComputedStyle(document.documentElement).getPropertyValue(Tt),10);var K8=({config:e})=>{let[t,o]=(0,Nn.useState)(!1),n=zt(),{checkCriteria:a}=nn(),{headerView:s,headerBackgroundColorOverride:l}=(0,Nn.useContext)(on),{sitewideValues:p}=(0,Nn.useContext)(ka),{getImageSources:d}=ve(),u=Ya(V,"header"),y=vt(),m=y.enableSiteSearch==="true",{isUrlCurrent:g}=ug(),f=p?.navigationBar,b=it(f?.brandBackgroundColor),S=f?.callsToActionCollection,C=O8(f?.headerMenuItemGroupsCollection?.items,g,a,d),v=(0,Nn.useRef)(null),k=(0,Nn.useMemo)(()=>{if(typeof window<"u"){let P=64;return new ResizeObserver($=>{let{height:R}=$[0].contentRect;P!==R&&(P=R,document.documentElement.style.setProperty(Tt,`${R}px`))})}Q8(64)},[]);(0,Nn.useEffect)(()=>{if(v.current&&k)return k.observe(v.current,{box:"border-box"}),()=>{k.disconnect()}},[k]);let I=(0,Nn.useContext)(be).elementLocation,A=P=>{ge({eventCategory:"GlobalNavGroup",eventAction:"Click",eventLabel:P.navGroupKey,context:{elementLocation:I,elementText:P.title}})};if(s==="No Header")return null;if(V.site==="stinson")return i(void 0,{});let D=f?.title??e.theme?.globalNavProps?.siteName??"",B=P=>{ge({eventCategory:"Header",eventAction:P?"Open":"Close",eventLabel:null,context:{elementLocation:I}})},M={...e.theme?.globalNavProps,motifScheme:b,backgroundColor:l??f?.backgroundColor??void 0,logo:i(_8,{}),pathname:n.pathname,siteName:D,onToggleExpanded:B,onGlobalNavGroupSummaryClick:A};if((s==="Minimized Header"||s==="Reduced Header"||s==="Full Header")&&(M.cta=x(pe,{children:[i(Gx,{callsToAction:S?.items}),i(Qx,{className:V8}),V.shopify&&i(ox,{})]}),M.endChildrenDesktopClassName=h(e.theme?.globalNavProps?.endChildrenDesktopClassName,F8),M.endChildrenMobileClassName=h(e.theme?.globalNavProps?.endChildrenMobileClassName,B8)),s==="Reduced Header"||s==="Full Header"){let P=n?.pathname!=="/search"&&m,$=i(yn,{href:f?.url,className:L8,children:D});M.className=h(e.theme?.globalNavProps?.className,t?$8:void 0),M.search=P&&i(w8,{setSearchOpen:o},"search"),M.searchOpen=t,M.siteName=$}if(s==="Full Header"){let P=()=>i(P8,{items:C}),$=()=>i(E8,{items:C}),R=S?.items.length;M.localNavDesktop=t?null:P({}),M.localNavMobile=$({}),M.localNavMobileFooter=R?i(Gx,{callsToAction:S?.items,displayRegion:"Screen"}):null,M.navItemAlignment=y.globalNavItemsPosition}let _={...M,...u};return s==="Simple Header"||s==="Minimized Header"?i(ic,{..._,showGlobalLinks:!1,showNavScreen:!1}):i("div",{"data-testid":"mwp-header",ref:v,className:h(H8,e.headerProps?.className),children:i(ic,{..._})})};var J8=T(w());var j8=E`
  fragment MessageAll on Message {
    ...ContentfulSysId
    key
    value
  }
  ${O}
`,Y8=E`
  query IntlMessages($preview: Boolean!, $locale: String!) {
    messageCollection(preview: $preview, locale: $locale) {
      items {
        ...MessageAll
      }
    }
  }
  ${j8}
`,X8=E`
  query LocalIntlMessages($preview: Boolean!, $locale: String!) {
    messageCollection(preview: $preview, locale: $locale, limit: 100) {
      items {
        ...MessageAll
      }
    }
  }
  ${j8}
`;var Z8=({children:e})=>{let t=qa(),{globalApolloClient:o}=(0,J8.useContext)(ze),{data:n}=se(X8),{data:a}=hn(Y8,{currentLocale:t.locale,isPreview:t.preview,isSSR:V.isSSR},{client:o}),s=a?Object.fromEntries(a.messageCollection.items.map(u=>[u.key,u.value])):null,l=n?Object.fromEntries(n.messageCollection.items.map(u=>[u.key,u.value])):null;if(!s||!l)return i(qe.Provider,{value:{formatMessage:n0},children:e});let p={...l,...s},d=(u,y)=>{let m=p[u.id]??u.defaultMessage;if(!y)return m;for(let[g,f]of Object.entries(y))m=m.replace(`{${g}}`,f);return m};return i(qe.Provider,{value:{formatMessage:d},children:e})};var t9=T(w());var e9=e=>{let t=e||so,[o]=t.split("-");return o};var Kx=()=>{let e=(0,t9.useContext)(ee);return i(Mt,{children:i("html",{lang:e9(e?.currentLocale)})})};Kx.displayName="LanguageDirective";var fl=T(w());var a9=T(GU());var yg=class{constructor(){Ae(this,"startSpan",t=>({endSpan:xo}));Ae(this,"addEventListener",t=>xo)}};var o9=new yg;function No(){return o9}function n9(e){o9=e}var r9=e=>{let{timeoutMs:t}=e,o=new AbortController,n=new Error(`Connection timed out after ${(t/1e3).toFixed(1)} seconds.`),a=setTimeout(()=>o.abort(n),t);return{signal:o.signal,clear:()=>clearTimeout(a)}};var mg=new Set,gg=new Set,En=(e,t)=>new Promise((o,n)=>{mg.forEach(f=>f());let a=No().startSpan(`Fetch: ${e}`),s=String(e).includes("contentful")?b0:3e4,l=V.isClient||t?.signal?void 0:r9({timeoutMs:s}),p=!1,d=t?.signal??l?.signal,u=!1,y=()=>{u||(u=!0,gg.forEach(f=>f()),a.endSpan(),l?.clear(),d?.removeEventListener("abort",m))};function m(){p||(n(d?.reason??new Error("Request aborted.")),p=!0,y())}d?.addEventListener("abort",m);let g={...t,signal:d};(0,a9.default)(e,g).then(f=>{o(f)}).catch(f=>{p||(n(f),p=!0)}).finally(y)});var jx=(0,fl.memo)(()=>{let[e,t]=(0,fl.useState)(0);return(0,fl.useEffect)(()=>{let o=()=>{setTimeout(()=>{t(a=>a+1)},0)},n=()=>{T0(()=>t(a=>Math.max(0,a-1)),{timeout:5e3})};return mg.add(o),gg.add(n),()=>{mg.delete(o),gg.delete(n)}},[]),e===0?null:i(IR,{className:"react-loading-bar"})});jx.displayName="LoadingBar";var fg=T(w(),1),IZ=Object.defineProperty,kZ=(e,t)=>IZ(e,"name",{value:t,configurable:!0});function zo(e,t){let o=(0,fg.useRef)(null);(0,fg.useEffect)(()=>{if(!is(o.current,t))return o.current=t,e()},t)}kZ(zo,"useImperativeEffect");var i9=()=>(zo(()=>{fn("detect-ad-blocker","/openad.js",xo),setTimeout(()=>{let e=Ct(window.snapMarketingWeb?.hasAdBlocker);Hn({eventAction:"Exists",eventCategory:"AdBlocker",eventLabel:`${e}`})},500)},[]),null);var l9=T(w());function Yx(e){if(e)try{let t=new URL(e);return`${t.origin}${t.pathname}`}catch{return e}}var s9={"https://www.googletagmanager.com/gtm.js":new Set(["eval"]),[`https://${V.domainName}/mwp-chunks/`]:new Set(["eval","properties"]),Unknown:new Set(["eval","inline"])},p9=()=>((0,l9.useEffect)(()=>{let e=new Set,t=o=>{let{blockedURI:n,violatedDirective:a,sourceFile:s}=o,l=`${n}|${a}|${s}`;if(!e.has(l)){for(let p in s9)if(s9[p]?.has(n)&&s.startsWith(p)){e.add(l);return}Re({component:"Csp",error:"CspViolationError",message:`Blocked ${n}, ${s}, ${a}`,context:{blockedUri:Yx(n),sourceFile:s,violatedDirective:Yx(a)}}),e.add(l)}};return document.addEventListener("securitypolicyviolation",t),()=>{document.removeEventListener("securitypolicyviolation",t)}},[]),null);function MZ(e,t){return Uy(e,t,function(o,n){return ty(e,n)})}var c9=MZ;var TZ=i0(function(e,t){return e==null?{}:c9(e,t)}),oi=TZ;function d9(){let e=performance.getEntriesByType("navigation"),[t]=e,o=["connectEnd","domComplete","domContentLoadedEventEnd","domInteractive","duration","loadEventEnd","responseEnd","transferSize"];for(let[n,a]of Object.entries(oi(t,o)))typeof a=="number"&&(n==="transferSize"?Ma({eventCategory:"NavigationTiming",eventLabel:`${t.type} ${window.location.pathname}`,eventVariable:n,eventValue:a}):Or({eventCategory:"NavigationTiming",eventLabel:`${t.type} ${window.location.pathname}`,eventVariable:n,eventValue:a}))}async function AZ(){let e=await En("/api/profile");if(!e.ok)return;let t=await e.json();if(t?.profiles?.length)for(let o of t.profiles)ot({subscribedEventType:"internal",eventCategory:"PersonaMatch",eventAction:"Fetch",eventLabel:`${o.id}:${o.tp}`});t.internal&&ot({subscribedEventType:"internal",eventCategory:"InternalTrafficDetection",eventAction:"Fetch",eventLabel:t.internal?"true":"false"})}var u9=()=>(zo(()=>{ot({subscribedEventType:"first_page_load"}),AZ()},[]),zo(()=>{if(document.readyState==="complete"){d9();return}let e=()=>{setTimeout(d9,0)};return window.addEventListener("load",e),()=>{window.removeEventListener("load",e)}},[]),null);var bl=T(w());var Xx=[25,50,75,90,100],y9=()=>{let{pathname:e}=zt(),t=(0,bl.useRef)(0),[o,n]=(0,bl.useState)(0);return(0,bl.useEffect)(()=>{let a=yk({interval:500},()=>{let s=window.scrollY,l=document.documentElement.scrollHeight-window.innerHeight,p=s/l,d=Math.round(p*100);n(d)});return window.addEventListener("scroll",a,{passive:!0}),()=>{window.removeEventListener("scroll",a)}},[n]),zo(()=>{t.current=0},[e]),zo(()=>{if(!(o<=t.current)){for(let a=0;a<Xx.length;a++){let s=Xx[a],l=Xx[a+1],p=!l;if(!(t.current>=s||o<s||!p&&o>=l)){Ma({eventCategory:"LogScrollDepth",eventLabel:`scroll breakpoint: ${s}%`,eventVariable:"scroll_percentage",eventValue:o});break}}t.current=o}},[o]),null};var f9=T(w());var bg=Gk;var m9=Xi(Yi,{name:"Blue",fontFamily:["Ghost Sans"],"sdsm-default":{name:"Imported Deafult",legacyName:"Yellow","sdsm-hyperlink":{"--hyperlink-desktop-font-text-decoration":"underline","--hyperlink-mobile-font-text-decoration":"underline","--hyperlink-mobile-font-weight":"Medium","--hyperlink-desktop-font-weight":"Medium","--hyperlink-color":`${r("--action-text-hover-color")}`},sdsm:{"--border-radius-l":"12px","--border-radius-xl":"16px","--box-shadow-l":"0px 16px 32px 0 #000 12%","--bg-color":r("--palette-blue-v100"),"--action-text-default-color":r("--neutral-v500"),"--action-text-hover-color":r("--neutral-v600")},"sdsm-button":{"--button-primary-fg-color":r("--palette-blue-v50"),"--button-secondary-bg-color":r("--palette-blue-v50"),"--button-secondary-hover-bg-color":r("--palette-blue-v50"),"--button-secondary-border-color":r("--palette-blue-v50"),"--button-secondary-hover-border-color":r("--palette-blue-v50"),"--button-flat-fg-color":`${r("--fg-color")}`,"--button-border-radius":`${r("--border-radius-s")}`,"--button-hover-shadow":`${r("--box-shadow-l")}`,"--button-regular-padding":"var(--spacing-s) var(--spacing-m)","--button-compact-padding":"var(--spacing-xs) var(--spacing-m)"},"sdsm-header":{"--global-header-nav-screen-fg-color":r("--neutral-v650")},"sdsm-block":{"--block-eyebrow-color":r("--neutral-v700"),"--block-title-color":r("--neutral-v700"),"--block-subtitle-color":r("--neutral-v700")},"sdsm-tab":{},"sdsm-break":{},"sdsm-accordion":{"--accordion-header-color":`${r("--fg-color")}`,"--accordion-divider-border-color":`${r("--fg-color")}`,"--accordion-header-divider-border-color":`${r("--fg-color")}`},"sdsm-quote":{"--quote-bg-color":r("--palette-blue-v50")},"sdsm-footer":{"--footer-bg-color":`${r("--bg-color")}`,"--footer-divider-border-color":`${r("--fg-color")}`,"--footer-bar-bg-color":`${r("--bg-color")}`},"sdsm-summary-card":{"--summary-card-title-color":r("--neutral-v700"),"--summary-card-description-color":r("--neutral-v600"),"--summary-card-bg-color":r("--palette-blue-v50")},"sdsm-form":{"--form-input-bg-color":r("--palette-blue-v50"),"--form-input-border-radius":`${r("--border-radius-xl")}`,"--form-input-padding":"var(--spacing-m) var(--spacing-l)","--form-grid-gap":`${r("--spacing-m")}`},"sdsm-footnote":{"--footnote-fg-color":r("--neutral-v500"),"--footnote-bg-color":r("--palette-blue-v50")},"sdsm-dropdown-menu":{"--dropdown-menu-bg-color":r("--palette-blue-v50")},"sdsm-banner":{"--banner-bg-color":`${r("--bg-color")}`,"--banner-fg-color":`${r("--fg-color")}`},"sdsm-content":{"--content-mobile-grid-gap":`${r("--spacing-l")}`},"sdsm-mosaic":{"--mosaic-border-radius":"24px","--mosaic-grid-gap":"32px","--mosaic-highlight-color":r("--palette-blue-v100"),"--mosaic-title-color":r("--palette-blue-v50")},"sdsm-media":{},"sdsm-search":{},"sdsm-pagination":{},"sdsm-side-navigation":{},"sdsm-spinner":{"--spinner-fg-color":`${r("--button-primary-fg-color")}`},"sdsm-modal":{"--modal-bg-color":"rgba(0,0,0,0.7)","--modal-close-fg-color":r("--palette-blue-v50")},"sdsm-icon-button":{"--icon-button-bg-color":r("--neutral-v700"),"--icon-button-hover-bg-color":r("--neutral-v600"),"--icon-button-disabled-bg-color":"rgba(0,0,0,0)"}},"sdsm-secondary":{name:"Imported secondary",legacyName:"Black","sdsm-hyperlink":{"--hyperlink-desktop-font-text-decoration":"underline","--hyperlink-mobile-font-text-decoration":"underline","--hyperlink-mobile-font-weight":"Medium","--hyperlink-desktop-font-weight":"Medium","--hyperlink-color":`${r("--action-text-hover-color")}`},sdsm:{"--box-shadow-s":"0px 4px 8px 0 rgba(0, 0, 0, 0.12)","--box-shadow-m":"0px 8px 16px 0 rgba(0, 0, 0, 0.12)","--border-radius-xs":"1px","--border-radius-s":"4px","--border-radius-m":"8px","--border-radius-l":"12px","--border-radius-xl":"16px","--spacing-xxxs":"2px","--spacing-xxs":"4px","--spacing-xs":"8px","--spacing-s":"12px","--spacing-m":"16px","--spacing-l":"24px","--spacing-xl":"32px","--spacing-xxl":"40px","--spacing-xxxxl":"64px","--box-shadow-l":"0px 16px 32px 0 #000 12%","--fg-color":r("--palette-blue-v50"),"--action-text-default-color":r("--neutral-v500"),"--action-text-hover-color":r("--neutral-v600"),"--action-text-active-color":r("--neutral-v700")},"sdsm-button":{"--button-primary-bg-color":r("--palette-blue-v100"),"--button-primary-hover-bg-color":r("--palette-blue-v100"),"--button-primary-border-color":r("--palette-blue-v100"),"--button-primary-hover-border-color":r("--palette-blue-v100"),"--button-secondary-bg-color":r("--palette-blue-v50"),"--button-secondary-hover-bg-color":r("--palette-blue-v50"),"--button-secondary-border-color":r("--palette-blue-v50"),"--button-secondary-hover-border-color":r("--palette-blue-v50"),"--button-flat-fg-color":r("--palette-blue-v50"),"--button-border-radius":`${r("--border-radius-s")}`,"--button-hover-shadow":`${r("--box-shadow-l")}`,"--button-regular-padding":"var(--spacing-s) var(--spacing-m)","--button-compact-padding":"var(--spacing-xs) var(--spacing-m)"},"sdsm-header":{"--global-header-nav-screen-fg-color":r("--neutral-v650"),"--global-header-fg-color":r("--neutral-v200")},"sdsm-block":{"--block-eyebrow-color":r("--palette-blue-v50"),"--block-title-color":r("--palette-blue-v50"),"--block-subtitle-color":r("--palette-blue-v50")},"sdsm-tab":{"--tabs-underline-color":r("--neutral-v600")},"sdsm-break":{},"sdsm-accordion":{"--accordion-header-color":`${r("--fg-color")}`,"--accordion-divider-border-color":`${r("--fg-color")}`,"--accordion-header-divider-border-color":`${r("--fg-color")}`},"sdsm-quote":{"--quote-bg-color":r("--palette-blue-v50")},"sdsm-footer":{"--footer-bg-color":`${r("--bg-color")}`,"--footer-divider-border-color":`${r("--fg-color")}`,"--footer-bar-bg-color":`${r("--bg-color")}`},"sdsm-summary-card":{"--summary-card-title-color":r("--neutral-v700"),"--summary-card-description-color":r("--neutral-v600"),"--summary-card-bg-color":r("--palette-blue-v50")},"sdsm-form":{"--form-input-bg-color":r("--palette-blue-v50"),"--form-input-border-radius":`${r("--border-radius-xl")}`,"--form-input-padding":"var(--spacing-m) var(--spacing-l)","--form-grid-gap":`${r("--spacing-m")}`},"sdsm-footnote":{"--footnote-fg-color":r("--neutral-v500"),"--footnote-bg-color":r("--palette-blue-v50")},"sdsm-dropdown-menu":{"--dropdown-menu-bg-color":r("--neutral-v600")},"sdsm-banner":{"--banner-bg-color":`${r("--bg-color")}`,"--banner-fg-color":`${r("--fg-color")}`},"sdsm-content":{"--content-mobile-grid-gap":`${r("--spacing-l")}`},"sdsm-mosaic":{"--mosaic-border-radius":"24px","--mosaic-grid-gap":"32px","--mosaic-highlight-color":r("--palette-blue-v100"),"--mosaic-title-color":r("--palette-blue-v50")},"sdsm-media":{},"sdsm-search":{"--search-no-results-bg-color":r("--neutral-v150"),"--search-no-results-fg-color":r("--neutral-v650")},"sdsm-pagination":{"--pagination-item-color":r("--neutral-v400"),"--pagination-item-hover-color":r("--neutral-v300"),"--pagination-item-active-color":r("--palette-blue-v50"),"--pagination-indicator-hover-color":r("--neutral-v300")},"sdsm-spinner":{"--spinner-fg-color":`${r("--button-primary-fg-color")}`},"sdsm-modal":{"--modal-bg-color":"rgba(0,0,0,0.7)","--modal-close-bg-color":r("--neutral-v700"),"--modal-close-fg-color":r("--palette-blue-v50")},"sdsm-icon-button":{"--icon-button-hover-bg-color":r("--neutral-v200"),"--icon-button-disabled-bg-color":r("--neutral-v500"),"--icon-button-border-color":r("--neutral-v0"),"--icon-button-fg-color":r("--neutral-v700"),"--icon-button-disabled-fg-color":r("--neutral-v400")}},"sdsm-tertiary":{name:"Imported tertiary",legacyName:"White","sdsm-hyperlink":{"--hyperlink-desktop-font-text-decoration":"underline","--hyperlink-mobile-font-text-decoration":"underline","--hyperlink-mobile-font-weight":"Medium","--hyperlink-desktop-font-weight":"Medium","--hyperlink-color":`${r("--action-text-hover-color")}`},sdsm:{"--box-shadow-s":"0px 4px 8px 0 rgba(0, 0, 0, 0.12)","--box-shadow-m":"0px 8px 16px 0 rgba(0, 0, 0, 0.12)","--border-radius-xs":"1px","--border-radius-s":"4px","--border-radius-m":"8px","--border-radius-l":"12px","--border-radius-xl":"16px","--spacing-xxxs":"2px","--spacing-xxs":"4px","--spacing-xs":"8px","--spacing-s":"12px","--spacing-m":"16px","--spacing-l":"24px","--spacing-xl":"32px","--spacing-xxl":"40px","--spacing-xxxxl":"64px","--box-shadow-l":"0px 16px 32px 0 #000 12%","--bg-color":r("--palette-blue-v50"),"--action-text-default-color":r("--neutral-v500"),"--action-text-hover-color":r("--neutral-v600")},"sdsm-button":{"--button-primary-bg-color":r("--palette-blue-v100"),"--button-primary-hover-bg-color":r("--palette-blue-v100"),"--button-primary-border-color":r("--palette-blue-v100"),"--button-primary-hover-border-color":r("--palette-blue-v100"),"--button-secondary-fg-color":r("--palette-blue-v50"),"--button-border-radius":`${r("--border-radius-s")}`,"--button-hover-shadow":`${r("--box-shadow-l")}`,"--button-regular-padding":"var(--spacing-s) var(--spacing-m)","--button-compact-padding":"var(--spacing-xs) var(--spacing-m)"},"sdsm-header":{"--global-header-nav-screen-bg-color":r("--palette-blue-v50"),"--global-header-nav-screen-fg-color":r("--neutral-v650"),"--global-header-nav-screen-global-links-bg-color":r("--palette-blue-v50"),"--global-header-fg-color":r("--neutral-v650")},"sdsm-block":{"--block-eyebrow-color":r("--neutral-v700"),"--block-title-color":r("--neutral-v700"),"--block-subtitle-color":r("--neutral-v700")},"sdsm-tab":{},"sdsm-break":{},"sdsm-accordion":{"--accordion-header-color":`${r("--fg-color")}`,"--accordion-divider-border-color":`${r("--fg-color")}`,"--accordion-header-divider-border-color":`${r("--fg-color")}`},"sdsm-quote":{"--quote-bg-color":r("--palette-blue-v50")},"sdsm-footer":{"--footer-bg-color":`${r("--bg-color")}`},"sdsm-summary-card":{"--summary-card-title-color":r("--neutral-v700"),"--summary-card-description-color":r("--neutral-v600"),"--summary-card-bg-color":r("--palette-blue-v50")},"sdsm-form":{"--form-input-bg-color":r("--palette-blue-v50"),"--form-input-border-radius":`${r("--border-radius-xl")}`,"--form-input-padding":"var(--spacing-m) var(--spacing-l)","--form-grid-gap":`${r("--spacing-m")}`},"sdsm-footnote":{"--footnote-fg-color":r("--neutral-v500"),"--footnote-bg-color":r("--palette-blue-v50")},"sdsm-dropdown-menu":{"--dropdown-menu-bg-color":r("--palette-blue-v50")},"sdsm-banner":{"--banner-bg-color":`${r("--bg-color")}`,"--banner-fg-color":`${r("--fg-color")}`},"sdsm-content":{"--content-mobile-grid-gap":`${r("--spacing-l")}`},"sdsm-mosaic":{"--mosaic-border-radius":"24px","--mosaic-grid-gap":"32px","--mosaic-highlight-color":r("--palette-blue-v100"),"--mosaic-title-color":r("--palette-blue-v50")},"sdsm-media":{},"sdsm-search":{"--search-no-results-bg-color":r("--neutral-v150"),"--search-no-results-fg-color":r("--neutral-v650")},"sdsm-pagination":{},"sdsm-spinner":{"--spinner-fg-color":`${r("--button-primary-fg-color")}`},"sdsm-modal":{"--modal-bg-color":"rgba(0,0,0,0.7)","--modal-close-bg-color":r("--neutral-v700"),"--modal-close-fg-color":r("--palette-blue-v50")},"sdsm-icon-button":{"--icon-button-bg-color":r("--neutral-v700"),"--icon-button-hover-bg-color":r("--neutral-v600"),"--icon-button-disabled-bg-color":"rgba(0,0,0,0)"}},"sdsm-quaternary":{name:"Imported quaternary",legacyName:"Gray","sdsm-hyperlink":{"--hyperlink-desktop-font-text-decoration":"underline","--hyperlink-mobile-font-text-decoration":"underline","--hyperlink-mobile-font-weight":"Medium","--hyperlink-desktop-font-weight":"Medium","--hyperlink-color":`${r("--action-text-hover-color")}`},sdsm:{"--box-shadow-s":"0px 4px 8px 0 rgba(0, 0, 0, 0.12)","--box-shadow-m":"0px 8px 16px 0 rgba(0, 0, 0, 0.12)","--border-radius-xs":"1px","--border-radius-s":"4px","--border-radius-m":"8px","--border-radius-l":"12px","--border-radius-xl":"16px","--spacing-xxxs":"2px","--spacing-xxs":"4px","--spacing-xs":"8px","--spacing-s":"12px","--spacing-m":"16px","--spacing-l":"24px","--spacing-xl":"32px","--spacing-xxl":"40px","--spacing-xxxxl":"64px","--box-shadow-l":"0px 16px 32px 0 #000 12%","--action-text-default-color":r("--neutral-v500"),"--action-text-hover-color":r("--neutral-v600")},"sdsm-button":{"--button-primary-bg-color":r("--palette-blue-v100"),"--button-primary-hover-bg-color":r("--palette-blue-v100"),"--button-primary-border-color":r("--palette-blue-v100"),"--button-primary-hover-border-color":r("--palette-blue-v100"),"--button-secondary-bg-color":r("--palette-blue-v50"),"--button-secondary-hover-bg-color":r("--palette-blue-v50"),"--button-secondary-border-color":r("--palette-blue-v50"),"--button-secondary-hover-border-color":r("--palette-blue-v50"),"--button-border-radius":`${r("--border-radius-s")}`,"--button-hover-shadow":`${r("--box-shadow-l")}`,"--button-regular-padding":"var(--spacing-s) var(--spacing-m)","--button-compact-padding":"var(--spacing-xs) var(--spacing-m)"},"sdsm-header":{"--global-header-nav-screen-bg-color":r("--palette-blue-v50"),"--global-header-nav-screen-fg-color":r("--neutral-v650"),"--global-header-nav-screen-global-links-bg-color":r("--palette-blue-v50"),"--global-header-fg-color":r("--neutral-v650")},"sdsm-block":{"--block-eyebrow-color":r("--palette-blue-v200"),"--block-title-color":r("--palette-blue-v200"),"--block-subtitle-color":r("--neutral-v700")},"sdsm-tab":{},"sdsm-break":{},"sdsm-accordion":{"--accordion-header-color":`${r("--fg-color")}`,"--accordion-divider-border-color":`${r("--fg-color")}`,"--accordion-header-divider-border-color":`${r("--fg-color")}`},"sdsm-quote":{"--quote-bg-color":r("--palette-blue-v50")},"sdsm-footer":{"--footer-bg-color":`${r("--bg-color")}`,"--footer-bar-bg-color":`${r("--bg-color")}`},"sdsm-summary-card":{"--summary-card-title-color":r("--neutral-v700"),"--summary-card-description-color":r("--neutral-v600"),"--summary-card-bg-color":r("--palette-blue-v50")},"sdsm-form":{"--form-input-bg-color":r("--palette-blue-v50"),"--form-input-border-radius":`${r("--border-radius-xl")}`,"--form-input-padding":"var(--spacing-m) var(--spacing-l)","--form-grid-gap":`${r("--spacing-m")}`},"sdsm-footnote":{"--footnote-fg-color":r("--neutral-v500"),"--footnote-bg-color":r("--palette-blue-v50")},"sdsm-dropdown-menu":{"--dropdown-menu-bg-color":r("--palette-blue-v50")},"sdsm-banner":{"--banner-bg-color":`${r("--bg-color")}`,"--banner-fg-color":`${r("--fg-color")}`},"sdsm-content":{"--content-mobile-grid-gap":`${r("--spacing-l")}`},"sdsm-mosaic":{"--mosaic-border-radius":"24px","--mosaic-grid-gap":"32px","--mosaic-highlight-color":r("--palette-blue-v100"),"--mosaic-title-color":r("--palette-blue-v50")},"sdsm-media":{},"sdsm-search":{"--search-no-results-bg-color":r("--neutral-v150"),"--search-no-results-fg-color":r("--neutral-v650")},"sdsm-pagination":{},"sdsm-spinner":{"--spinner-fg-color":`${r("--button-primary-fg-color")}`},"sdsm-modal":{"--modal-bg-color":"rgba(0,0,0,0.7)","--modal-close-bg-color":r("--neutral-v700"),"--modal-close-fg-color":r("--palette-blue-v50")},"sdsm-icon-button":{"--icon-button-bg-color":r("--neutral-v700"),"--icon-button-hover-bg-color":r("--neutral-v600"),"--icon-button-disabled-bg-color":"rgba(0,0,0,0)"}}});var g9=Xi(Yi,{name:"Green",fontFamily:["Ghost Sans"],"sdsm-default":{name:"Imported Deafult",legacyName:"Yellow",sdsm:{"--border-radius-l":"12px","--border-radius-xl":"16px","--bg-color":"#02B790","--fg-color":"#042500"},"sdsm-button":{"--button-primary-bg-color":"#042500","--button-primary-hover-bg-color":"#042500","--button-primary-border-color":"#042500","--button-primary-hover-border-color":"#042500","--button-primary-fg-color":"#f0fff0","--button-secondary-bg-color":"#f0fff0","--button-secondary-hover-bg-color":"#f0fff0","--button-secondary-border-color":"#f0fff0","--button-secondary-hover-border-color":"#f0fff0","--button-secondary-fg-color":"#042500","--button-flat-fg-color":`${r("--fg-color")}`,"--button-border-radius":`${r("--border-radius-m")}`,"--button-hover-shadow":`${r("--box-shadow-l")}`,"--button-regular-padding":"var(--spacing-s) var(--spacing-xl)","--button-compact-padding":"var(--spacing-xs) var(--spacing-m)"},"sdsm-header":{},"sdsm-block":{"--block-eyebrow-color":"#042500","--block-title-color":"#042500","--block-subtitle-color":"#042500"},"sdsm-break":{},"sdsm-accordion":{"--accordion-header-color":`${r("--fg-color")}`},"sdsm-quote":{"--quote-bg-color":"#f0fff0","--quote-fg-color":"#042500"},"sdsm-footer":{"--footer-bg-color":`${r("--bg-color")}`,"--footer-bar-bg-color":`${r("--bg-color")}`},"sdsm-form":{"--form-grid-gap":`${r("--spacing-m")}`},"sdsm-footnote":{},"sdsm-dropdown-menu":{"--dropdown-menu-bg-color":"#f0fff0","--dropdown-item-fg-color":r("--neutral-v500"),"--dropdown-item-fg-active-color":"#042500","--dropdown-item-bg-hover-color":"#c6dfc6"},"sdsm-banner":{"--banner-bg-color":`${r("--bg-color")}`,"--banner-fg-color":`${r("--fg-color")}`},"sdsm-hyperlink":{"--hyperlink-color":r("--neutral-v600")},"sdsm-mosaic":{"--mosaic-border-radius":"24px","--mosaic-grid-gap":"32px","--mosaic-highlight-color":"#02B790","--mosaic-title-color":"#f0fff0"},"sdsm-search":{"--search-no-results-bg-color":"#c6dfc6"},"sdsm-pagination":{"--pagination-item-active-color":"#042500"},"sdsm-spinner":{"--spinner-fg-color":`${r("--button-primary-fg-color")}`},"sdsm-modal":{"--modal-bg-color":"rgba(0,0,0,0.7)","--modal-close-bg-color":"#042500","--modal-close-fg-color":"#f0fff0"},"sdsm-icon-button":{"--icon-button-bg-color":r("--neutral-v700"),"--icon-button-hover-bg-color":r("--neutral-v600"),"--icon-button-disabled-bg-color":"rgba(0,0,0,0)"}},"sdsm-secondary":{name:"Imported secondary",legacyName:"Black",sdsm:{"--box-shadow-s":"0px 4px 8px 0 rgba(0, 0, 0, 0.12)","--box-shadow-m":"0px 8px 16px 0 rgba(0, 0, 0, 0.12)","--border-radius-xs":"1px","--border-radius-s":"4px","--border-radius-m":"8px","--border-radius-l":"12px","--border-radius-xl":"16px","--spacing-xxxs":"2px","--spacing-xxs":"4px","--spacing-xs":"8px","--spacing-s":"12px","--spacing-m":"16px","--spacing-l":"24px","--spacing-xl":"32px","--spacing-xxl":"40px","--spacing-xxxxl":"64px","--bg-color":"#042500","--fg-color":"#f0fff0"},"sdsm-button":{"--button-primary-bg-color":"#02B790","--button-primary-hover-bg-color":"#02B790","--button-primary-border-color":"#02B790","--button-primary-hover-border-color":"#02B790","--button-primary-fg-color":"#042500","--button-secondary-bg-color":"#f0fff0","--button-secondary-hover-bg-color":"#f0fff0","--button-secondary-border-color":"#f0fff0","--button-secondary-hover-border-color":"#f0fff0","--button-secondary-fg-color":"#042500","--button-flat-fg-color":"#f0fff0","--button-border-radius":`${r("--border-radius-m")}`,"--button-hover-shadow":`${r("--box-shadow-l")}`,"--button-regular-padding":"var(--spacing-s) var(--spacing-xl)","--button-compact-padding":"var(--spacing-xs) var(--spacing-m)"},"sdsm-header":{"--global-header-fg-color":r("--neutral-v200")},"sdsm-block":{"--block-eyebrow-color":"#f0fff0","--block-title-color":"#f0fff0","--block-subtitle-color":"#f0fff0"},"sdsm-break":{},"sdsm-accordion":{"--accordion-header-color":`${r("--fg-color")}`},"sdsm-quote":{"--quote-bg-color":"#f0fff0","--quote-fg-color":"#042500"},"sdsm-footer":{"--footer-bg-color":`${r("--bg-color")}`,"--footer-bar-bg-color":`${r("--bg-color")}`,"--footer-divider-border-color":`${r("--fg-color")}`},"sdsm-form":{"--form-grid-gap":`${r("--spacing-m")}`},"sdsm-footnote":{"--footnote-fg-color":r("--neutral-v400"),"--footnote-bg-color":r("--neutral-v0")},"sdsm-dropdown-menu":{"--dropdown-menu-bg-color":r("--neutral-v600"),"--dropdown-item-fg-color":r("--neutral-v300"),"--dropdown-item-fg-active-color":"#f0fff0"},"sdsm-banner":{"--banner-bg-color":`${r("--bg-color")}`,"--banner-fg-color":`${r("--fg-color")}`},"sdsm-hyperlink":{"--hyperlink-color":r("--neutral-v250")},"sdsm-mosaic":{"--mosaic-border-radius":"24px","--mosaic-grid-gap":"32px","--mosaic-highlight-color":"#02B790","--mosaic-title-color":"#f0fff0"},"sdsm-search":{"--search-no-results-bg-color":"#c6dfc6","--search-no-results-fg-color":r("--neutral-v650")},"sdsm-pagination":{"--pagination-item-color":r("--neutral-v400"),"--pagination-item-hover-color":r("--neutral-v300"),"--pagination-item-active-color":"#f0fff0","--pagination-indicator-hover-color":r("--neutral-v300")},"sdsm-spinner":{"--spinner-fg-color":`${r("--button-primary-fg-color")}`},"sdsm-modal":{"--modal-bg-color":"rgba(0,0,0,0.7)","--modal-close-bg-color":"#042500","--modal-close-fg-color":"#f0fff0"},"sdsm-icon-button":{"--icon-button-hover-bg-color":r("--neutral-v200"),"--icon-button-disabled-bg-color":r("--neutral-v500"),"--icon-button-border-color":r("--neutral-v0"),"--icon-button-fg-color":r("--neutral-v700"),"--icon-button-disabled-fg-color":r("--neutral-v400")}},"sdsm-tertiary":{name:"Imported tertiary",legacyName:"White",sdsm:{"--box-shadow-s":"0px 4px 8px 0 rgba(0, 0, 0, 0.12)","--box-shadow-m":"0px 8px 16px 0 rgba(0, 0, 0, 0.12)","--border-radius-xs":"1px","--border-radius-s":"4px","--border-radius-m":"8px","--border-radius-l":"12px","--border-radius-xl":"16px","--spacing-xxxs":"2px","--spacing-xxs":"4px","--spacing-xs":"8px","--spacing-s":"12px","--spacing-m":"16px","--spacing-l":"24px","--spacing-xl":"32px","--spacing-xxl":"40px","--spacing-xxxxl":"64px","--bg-color":"#f0fff0","--fg-color":"#042500"},"sdsm-button":{"--button-primary-bg-color":"#02B790","--button-primary-hover-bg-color":"#02B790","--button-primary-border-color":"#02B790","--button-primary-hover-border-color":"#02B790","--button-primary-fg-color":"#042500","--button-secondary-bg-color":"#042500","--button-secondary-hover-bg-color":"#042500","--button-secondary-border-color":"#042500","--button-secondary-hover-border-color":"#042500","--button-secondary-fg-color":"#f0fff0","--button-flat-fg-color":"#042500","--button-border-radius":`${r("--border-radius-m")}`,"--button-hover-shadow":`${r("--box-shadow-l")}`,"--button-regular-padding":"var(--spacing-s) var(--spacing-xl)","--button-compact-padding":"var(--spacing-xs) var(--spacing-m)"},"sdsm-header":{"--global-header-nav-screen-bg-color":"#f0fff0","--global-header-nav-screen-global-links-bg-color":"#f0fff0","--global-header-fg-color":r("--neutral-v650")},"sdsm-block":{"--block-eyebrow-color":"#042500","--block-title-color":"#042500","--block-subtitle-color":"#042500"},"sdsm-accordion":{"--accordion-header-color":`${r("--fg-color")}`},"sdsm-quote":{"--quote-bg-color":"#f0fff0","--quote-fg-color":"#042500"},"sdsm-footer":{"--footer-bg-color":`${r("--bg-color")}`,"--footer-bar-bg-color":"#c6dfc6"},"sdsm-form":{"--form-grid-gap":`${r("--spacing-m")}`},"sdsm-footnote":{"--footnote-fg-color":r("--neutral-v400"),"--footnote-bg-color":r("--neutral-v0")},"sdsm-dropdown-menu":{"--dropdown-menu-bg-color":"#f0fff0","--dropdown-item-fg-color":r("--neutral-v500"),"--dropdown-item-fg-active-color":"#042500","--dropdown-item-bg-hover-color":"#c6dfc6"},"sdsm-banner":{"--banner-bg-color":`${r("--bg-color")}`,"--banner-fg-color":`${r("--fg-color")}`},"sdsm-hyperlink":{"--hyperlink-color":r("--neutral-v600")},"sdsm-mosaic":{"--mosaic-border-radius":"24px","--mosaic-grid-gap":"32px","--mosaic-highlight-color":"#02B790","--mosaic-title-color":"#f0fff0"},"sdsm-search":{"--search-no-results-bg-color":"#c6dfc6","--search-no-results-fg-color":r("--neutral-v650")},"sdsm-pagination":{"--pagination-item-active-color":"#042500"},"sdsm-spinner":{"--spinner-fg-color":`${r("--button-primary-fg-color")}`},"sdsm-modal":{"--modal-bg-color":"rgba(0,0,0,0.7)","--modal-close-bg-color":"#042500","--modal-close-fg-color":"#f0fff0"},"sdsm-icon-button":{"--icon-button-bg-color":r("--neutral-v700"),"--icon-button-hover-bg-color":r("--neutral-v600"),"--icon-button-disabled-bg-color":"rgba(0,0,0,0)"}},"sdsm-quaternary":{name:"Imported quaternary",legacyName:"Gray",sdsm:{"--box-shadow-s":"0px 4px 8px 0 rgba(0, 0, 0, 0.12)","--box-shadow-m":"0px 8px 16px 0 rgba(0, 0, 0, 0.12)","--border-radius-xs":"1px","--border-radius-s":"4px","--border-radius-m":"8px","--border-radius-l":"12px","--border-radius-xl":"16px","--spacing-xxxs":"2px","--spacing-xxs":"4px","--spacing-xs":"8px","--spacing-s":"12px","--spacing-m":"16px","--spacing-l":"24px","--spacing-xl":"32px","--spacing-xxl":"40px","--spacing-xxxxl":"64px","--bg-color":"#c6dfc6","--fg-color":"#042500"},"sdsm-button":{"--button-primary-bg-color":"#02B790","--button-primary-hover-bg-color":"#02B790","--button-primary-border-color":"#02B790","--button-primary-hover-border-color":"#02B790","--button-primary-fg-color":"#042500","--button-secondary-bg-color":"#f0fff0","--button-secondary-hover-bg-color":"#f0fff0","--button-secondary-border-color":"#f0fff0","--button-secondary-hover-border-color":"#f0fff0","--button-secondary-fg-color":"#042500","--button-flat-fg-color":"#042500","--button-border-radius":`${r("--border-radius-m")}`,"--button-hover-shadow":`${r("--box-shadow-l")}`,"--button-regular-padding":"var(--spacing-s) var(--spacing-xl)","--button-compact-padding":"var(--spacing-xs) var(--spacing-m)"},"sdsm-header":{"--global-header-nav-screen-bg-color":"#f0fff0","--global-header-nav-screen-global-links-bg-color":"#f0fff0","--global-header-fg-color":r("--neutral-v650")},"sdsm-block":{"--block-eyebrow-color":"#042500","--block-title-color":"#042500","--block-subtitle-color":"#042500"},"sdsm-break":{},"sdsm-accordion":{"--accordion-header-color":`${r("--fg-color")}`},"sdsm-quote":{"--quote-bg-color":"#f0fff0","--quote-fg-color":"#042500"},"sdsm-footer":{"--footer-bg-color":`${r("--bg-color")}`,"--footer-bar-bg-color":`${r("--bg-color")}`},"sdsm-form":{"--form-grid-gap":`${r("--spacing-m")}`},"sdsm-footnote":{"--footnote-fg-color":r("--neutral-v400"),"--footnote-bg-color":r("--neutral-v0")},"sdsm-dropdown-menu":{"--dropdown-menu-bg-color":"#f0fff0","--dropdown-item-fg-color":r("--neutral-v500"),"--dropdown-item-fg-active-color":"#042500","--dropdown-item-bg-hover-color":"#c6dfc6"},"sdsm-banner":{"--banner-bg-color":`${r("--bg-color")}`,"--banner-fg-color":`${r("--fg-color")}`},"sdsm-hyperlink":{"--hyperlink-color":r("--neutral-v600")},"sdsm-mosaic":{"--mosaic-border-radius":"24px","--mosaic-grid-gap":"32px","--mosaic-highlight-color":"#02B790","--mosaic-title-color":"#f0fff0"},"sdsm-search":{"--search-no-results-bg-color":"#c6dfc6","--search-no-results-fg-color":r("--neutral-v650")},"sdsm-pagination":{"--pagination-item-active-color":"#042500"},"sdsm-spinner":{"--spinner-fg-color":`${r("--button-primary-fg-color")}`},"sdsm-modal":{"--modal-bg-color":"rgba(0,0,0,0.7)","--modal-close-bg-color":"#042500","--modal-close-fg-color":"#f0fff0"},"sdsm-icon-button":{"--icon-button-bg-color":r("--neutral-v700"),"--icon-button-hover-bg-color":r("--neutral-v600"),"--icon-button-disabled-bg-color":"rgba(0,0,0,0)"}}});var wZ=Ko(async()=>import("./chunks/LazyCustomMotifHandler-DKFUZL2T.mjs").then(e=>({default:e.LazyCustomMotifHandler}))),S9=({children:e,motif:t,...o})=>{let{getCurrentUrl:n}=(0,f9.useContext)(ee),a=vt(),s=t,p=new URL(n()).searchParams.get("alternateMotif");if(a.useGhostMotif==="true"&&V.site==="for-business"&&(s=void 0),!V.isDeploymentTypeProd){if(p==="true"||p==="green")s=g9;else if(p==="blue")s=m9;else if(p==="snap"&&V.site==="sandbox")s=bg;else if(p==="figma-upload")return i(Do,{fallbackElement:i("p",{children:"...Loading"}),children:i(wZ,{motif:t,...o,children:e})})}return i(Pk,{motif:s,...o,children:e})};var h9=T(w());var C9=()=>{let e=(0,h9.useContext)(Ze),t="width=device-width, initial-scale=1";return e.getLowEntropyHints().platform==="iOS"&&(t+=", viewport-fit=cover"),i(Mt,{children:i("meta",{name:"viewport",content:t})})};var $i=T(w());var x9=({sessionValue:e,children:t})=>{let[o,n]=(0,$i.useState)(e.footerView??"Full Footer"),[a,s]=(0,$i.useState)(e.headerView??"Full Header"),[l,p]=(0,$i.useState)(e.headerBackgroundColorOverride),[d,u]=(0,$i.useState)(!1),[y,m]=(0,$i.useState)(!1),[g,f]=(0,$i.useState)(!1),b={footerView:o,headerView:a,headerBackgroundColorOverride:l,hasSideNav:d,hasSubNav:y,hasCustomSideNav:g,setFooterView:S=>{n(S),e.setFooterView?.(S)},setHeaderView:S=>{s(S),e.setHeaderView?.(S)},setHeaderBackgroundColorOverride:S=>{p(S),e.setHeaderBackgroundColorOverride?.(S)},setHasSideNav:S=>u(S),setHasSubNav:S=>m(S),setHasCustomSideNav:S=>f(S)};return i(on.Provider,{value:b,children:t})};var k9=T(w());var Jx=E`
  fragment FooterItemAll on FooterItem {
    ...ContentfulSysId
    title
    url
    analytics {
      ...ContentfulSysId
      label
    }
    criteria {
      ...CriteriaAll
    }
  }
  ${O}
  ${Xt}
`,Zx=E`
  fragment FooterLocaleDropdownAll on FooterLocaleDropdown {
    ...ContentfulSysId
    title
    criteria {
      ...CriteriaAll
    }
  }
  ${O}
  ${Xt}
`,ev=E`
  fragment FooterCookiesSettingsLinkAll on FooterCookiesSettingsLink {
    ...ContentfulSysId
    title
    criteria {
      ...CriteriaAll
    }
  }
  ${O}
  ${Xt}
`,tv=E`
  fragment FooterGroupAll on FooterGroup {
    ...ContentfulSysId
    __typename
    title
    groupKey
    itemsCollection(limit: 10) {
      items {
        __typename
        ... on FooterItem {
          ...FooterItemAll
        }

        ... on FooterLocaleDropdown {
          ...FooterLocaleDropdownAll
        }

        ... on FooterCookiesSettingsLink {
          ...FooterCookiesSettingsLinkAll
        }
      }
    }
    analytics {
      ...ContentfulSysId
      label
    }
    criteria {
      ...CriteriaAll
    }
  }
  ${O}
  ${Jx}
  ${Zx}
  ${ev}
  ${Xt}
`,Sg=E`
  fragment CustomFooterAll on CustomFooter {
    ...ContentfulSysId
    columnsCollection(limit: 10) {
      items {
        ... on FooterGroup {
          ...FooterGroupAll
        }
      }
    }
    barCollection(limit: 10) {
      items {
        ... on FooterGroup {
          ...FooterGroupAll
        }
      }
    }
    brandBackgroundColor
    backgroundColor
    logo {
      ...ImageAll
    }
    logoAriaLabel
    url
    socialLabel
    socialCollection(limit: 10) {
      items {
        ... on ImageButton {
          ...ImageButtonAll
        }
      }
    }
  }
  ${O}
  ${Rx}
  ${Oe.all}
  ${tv}
`,wKe=E`
  query FooterQuery($preview: Boolean!, $locale: String!) {
    customFooterCollection(preview: $preview, locale: $locale, limit: 1) {
      items {
        ...CustomFooterAll
      }
    }
  }

  ${Sg}
`;var ov=E`
  fragment HeaderMenuItemGroupFieldsOnly on HeaderMenuItemGroup {
    ...ContentfulSysId
    title
    url
    column1Label
    column1MenuItemsCollection {
      items {
        ...HeaderMenuItemFieldsOnly
      }
    }
    column2Label
    column2MenuItemsCollection {
      items {
        ...HeaderMenuItemFieldsOnly
      }
    }
    column3Label
    column3MenuItemsCollection {
      items {
        ...HeaderMenuItemFieldsOnly
      }
    }
    featuredHeaderMenuItem {
      ...FeaturedHeaderMenuItemFieldsOnly
    }
  }
  ${O}
`,nv=E`
  fragment HeaderMenuItemFieldsOnly on HeaderMenuItem {
    ...ContentfulSysId
    title
    url
    description
    icon {
      ...ContentfulSysId
      icon
      media {
        ...AssetAll
      }
    }
    analytics {
      ...AnalyticsAll
    }
    hideCriteria {
      ...CriteriaAll
    }
  }
  ${O}
  ${bo.all}
  ${Xt}
  ${Pn}
`,rv=E`
  fragment FeaturedHeaderMenuItemFieldsOnly on FeaturedHeaderMenuItem {
    ...ContentfulSysId
    title
    url
    description
    icon {
      ...ContentfulSysId
      icon
      media {
        ...AssetAll
      }
    }
    ctaLabel
    analytics {
      ...AnalyticsAll
    }
    hideCriteria {
      ...CriteriaAll
    }
  }
  ${O}
  ${bo.all}
  ${Xt}
  ${Pn}
`,v9=E`
  fragment NavigatorLocal on Navigator {
    ...ContentfulSysId
    title
    logoV2 {
      ... on Image {
        ...ImageAll
      }
    }
    theme
    brandBackgroundColor
    backgroundColor
    headerMenuItemGroupsCollection(limit: 7) {
      items {
        ...HeaderMenuItemGroupFieldsOnly
      }
      total
    }
    callsToActionCollection(limit: 10) {
      items {
        ... on CallToAction {
          ...CallToActionAll
        }
        ... on NavigationCallToAction {
          ...NavigationCta
        }
      }
    }
    url
    analytics {
      ...AnalyticsAll
    }
  }
  ${O}
  ${bo.all}
  ${ov}
  ${nv}
  ${rv}
  ${bt}
  ${wc}
  ${$t.all}
`;var DZ=E`
  fragment SitewideValuesAll on SitewideValues {
    ...ContentfulSysId
    navigationBar {
      ...NavigatorLocal
    }
    customFooter {
      ...CustomFooterAll
    }
    featureFlags {
      ...ContentfulSysId
      featureFlags
    }
  }
  ${O}
`,PZ=E`
  fragment SitewideConfiguration on SitewideConfiguration {
    ...ContentfulSysId
    reference {
      ... on SitewideValues {
        ...SitewideValuesAll
      }
      ... on SitewideExperiment {
        ...ContentfulSysId
        default {
          ...SitewideValuesAll
        }
        seed
        variantsCollection(limit: 5) {
          items {
            ...ContentfulSysId
            trafficStartRange
            trafficEndRange
            analyticsId
            replacementsCollection(limit: 10) {
              items {
                ...ContentfulSysId
                replacementTarget {
                  ...ContentfulSysId
                }
                replacement {
                  ... on Navigator {
                    ...NavigatorLocal
                  }
                  ... on HeaderMenuItemGroup {
                    ...HeaderMenuItemGroupFieldsOnly
                  }
                  ... on HeaderMenuItem {
                    ...HeaderMenuItemFieldsOnly
                  }
                  ... on FeaturedHeaderMenuItem {
                    ...FeaturedHeaderMenuItemFieldsOnly
                  }
                  ... on NavigationCallToAction {
                    ...NavigationCta
                  }
                  ... on CallToAction {
                    ...CallToActionAll
                  }
                  ... on FeatureFlags {
                    ...ContentfulSysId
                    featureFlags
                  }
                  ... on CustomFooter {
                    ...CustomFooterAll
                  }
                  ... on FooterCookiesSettingsLink {
                    ...FooterCookiesSettingsLinkAll
                  }
                  ... on FooterGroup {
                    ...FooterGroupAll
                  }
                  ... on FooterItem {
                    ...FooterItemAll
                  }
                  ... on FooterLocaleDropdown {
                    ...FooterLocaleDropdownAll
                  }
                }
              }
            }
          }
        }
        analyticsId
      }
    }
  }
  ${O}
  ${v9}
  ${Sg}
  ${DZ}
  ${wc}
  ${ov}
  ${nv}
  ${rv}
  ${bt}
  ${tv}
  ${ev}
  ${Zx}
  ${Jx}
  ${Sg}
`,I9=E`
  query SitewideConfigurationQuery($preview: Boolean!, $locale: String!) {
    sitewideConfigurationCollection(preview: $preview, locale: $locale, limit: 1) {
      items {
        ...SitewideConfiguration
      }
    }
  }
  ${PZ}
`;var NZ=e=>typeof e=="object"&&e.sys?.id!==void 0,EZ=e=>typeof e=="object"&&Array.isArray(e.items),RZ=50;function hg(e,t,o=0){let n=Fo(e);if(o>RZ)return console.error("Max depth reached in replaceEntries"),n;if(e.sys.id in t)return t[e.sys.id]===void 0?void 0:(n=t[e.sys.id],hg(n,t,o+1));for(let a in n){let s=n[a];if(a.endsWith("Collection")&&EZ(s)){let l=s.items.map(p=>hg(p,t,o+1)).filter(p=>!!p);n[a]={...s,items:l}}else NZ(s)&&(n[a]=hg(s,t,o+1))}return n}var M9=({children:e})=>{let t=sg(),{currentLocale:o}=(0,k9.useContext)(ee),{data:n}=se(I9),a=pg(),l=(p=>{if(!p||!p?.sitewideConfigurationCollection?.items)return;let d=Ki(p.sitewideConfigurationCollection.items)?.reference;if(d){if(d.__typename==="SitewideValues")return{sitewideValues:d};if(d.__typename==="SitewideExperiment"){if(!d.default)return;let u=d.default,y={};if(!d.variantsCollection?.items)return{sitewideValues:u};let{isThinking:m,decision:g}=t({seed:d.seed??d.sys.id,variants:d.variantsCollection.items});if(g?.replacementsCollection?.items){for(let f of g.replacementsCollection.items)if(f?.replacementTarget?.sys.id){if(!f.replacementTarget.__typename)continue;if(f?.replacement===void 0){y[f.replacementTarget.sys.id]=void 0;continue}y[f.replacementTarget.sys.id]={...f.replacement}}a({key:"sitewideExperimentExposure",callback:()=>Hn({eventCategory:"Experiment",eventAction:"sitewideExperimentExposure",eventLabel:`${d.analyticsId??"Unknown"}:${g.analyticsId??"Unknown"}`,context:{locale:o}}),dependencies:[d.analyticsId,g.analyticsId]})}if(!m&&!g&&a({key:"sitewideExperimentExposure",callback:()=>Hn({eventCategory:"Experiment",eventAction:"sitewideExperimentExposure",eventLabel:`${d.analyticsId??"Unknown"}:default`,context:{locale:o}}),dependencies:[d.analyticsId]}),Object.entries(y).length>0){u=Io(d.default);let f=hg(u,y);f&&(u=f)}return{sitewideValues:u}}}})(n)||{};return i(ka.Provider,{value:l,children:e})};var A9=T(w());var FZ=c`
  display: flex;
  align-items: center;
  flex-direction: column;
  justify-content: center;
  overflow-x: hidden;
  position: relative;
  width: 100%;
  height: 100vh;
  text-align: center;
  background-color: #fffc00;

  h1 {
    font-size: 7em;
    font-weight: 600;
    margin-bottom: 40px;
  }

  p {
    margin-top: 0.5em;
  }

  a {
    text-decoration: none;
  }
`,T9=()=>x("div",{className:FZ,children:[i("h1",{children:"500"}),i("h2",{children:"Oops! Something went wrong"}),i("p",{children:i("a",{href:"/",children:"Go to home"})})]});var Cg=class extends A9.Component{constructor(t){super(t),this.state={hasError:!1}}componentDidCatch(t,o){this.setState({hasError:!0});let n=this.props.tracer?.startSpan("fetchError");En("/error").then(a=>n?.endSpan()),Re({component:"UncaughtError",error:t??void 0,context:{componentStack:o?.componentStack}})}render(){let{children:t}=this.props,{hasError:o}=this.state;return o?i(T9,{}):t}};var _9="https://web-platform.snap.com/fonts/font.graphik.css",BZ="https://snap-design-system.storage.googleapis.com/fonts/font.graphik.css",$Z=()=>fetch(_9).then(()=>!0).catch(e=>(Ft(e).message==="Failed to fetch"?console.warn(`Your browser is blocking "${new URL(_9).hostname}" which hosts our fonts. Allow this domain through your content blocker to see this website the way it was meant to be seen.`):console.error("Failed to fetch fonts",e),!1)),w9=()=>(zo(()=>{$Z().then(e=>{if(e)return;let t=document.createElement("link");t.type="text/css",t.rel="stylesheet",t.href=BZ,document.head.appendChild(t)})},[]),null);var LZ=Object.defineProperty,Jt=(e,t)=>LZ(e,"name",{value:t,configurable:!0}),Sl,av=(Sl=class extends Dd{constructor(t){super({...t,requiredPermissions:["logging","performance"]}),this.flushInternal=Jt(()=>Promise.resolve(),"flushInternal"),this.props=t,this.init=this.init.bind(this),this.logEventInternal=this.logEventInternal.bind(this)}async init(){let{initBlizzard:t,logEvent:o,CollectionMode:n}=await import("./chunks/dist-VIMAELK7.mjs");await t({...this.props,appEnvironment:{appType:"WEB_DESKTOP",appBuild:"PROD"},cookiesArgs:{customDomain:this.props.isProd?this.props.cookieDomain:void 0},debugLoggingEnabled:!1,mode:this.props.isProd?n.PROD:n.STAGE}),this.logBlizzardEvent=o}logEventInternal(t,o){let n=this.props.eventFormatter(t,o);if(!n)return;let a=Array.isArray(n)?n:[n];for(let s of a)this.logBlizzardEvent(s)}},Jt(Sl,"BlizzardClientEventListener"),Sl),HZ=Jt((e,t)=>{let o=new URL(window.location.href),n={event_name:"WEB_PLATFORM_EVENT",host:o.host,path:o.pathname,query:JSON.stringify(Object.fromEntries(o.searchParams.entries()))};switch(e.type){case Te.DEBUG:return{...n,type:Te.DEBUG,component:e.component,message:e.message};case Te.ERROR:{let a=Ft(e.error);return{...n,type:Te.ERROR,component:e.component,message:a.message,action:e.action}}case Te.INFO:return{...n,type:Te.INFO,component:e.component,action:e.action,label:e.label};case Te.TIMING:return{...n,type:Te.TIMING,component:e.component,variable:e.variable,value:e.valueMs.toString(),label:e.label};case Te.VALUE:return{...n,type:Te.VALUE,component:e.component,variable:e.variable,value:e.value.toString(),label:e.label};case Te.WARNING:return{...n,type:Te.WARNING,component:e.component,message:e.message,action:e.action}}},"formatWebPlatformEvent");function VZ(e){return new av({isProd:e.isProd,cookieDomain:e.cookieDomain,eventFormatter:HZ})}Jt(VZ,"getCommonBlizzardClientEventListener");var ni,D9=(ni=class extends w0{constructor(t={}){super({...t,messageTransform:ni.messageTransform}),this.clientProps=t}},Jt(ni,"ConsoleClientEventListener"),ni.messageTransform=Jt((t,o)=>{if(o.length<1)return o;let n=o.shift(),a=`%c${n}`;switch(t){case Te.ERROR:return[a,"color: bloodOrange;",...o];case Te.WARNING:return[a,"color: yellow;",...o];case Te.TIMING:return[a,"color: dodgerblue;",...o];case Te.VALUE:return[a,"color: dodgerblue;",...o];case Te.DEBUG:return[a,"color: gray;",...o];case Te.CUSTOM:return[a,"font-weight: bold;",...o];default:return[n,...o]}},"messageTransform"),ni);function P9(e,t){switch(e[0]){case"get":case"set":return!1}return e[2]||(e[2]={}),e[2].event_callback=t,e[2].event_timeout=2e3,!0}Jt(P9,"addGa4EventCallback");function N9(...e){window.dataLayer.push(arguments)}Jt(N9,"gtag");var hl,xje=(hl=class extends Pd{constructor(t){super(t),this.addEventCallback=P9,this.gaProps=t}addEventToDataLayer(t){if(!Array.isArray(t))throw new Error("Unexpected event for GA4. GA4 events are arrays.");N9(...t)}init(){window.dataLayer=window.dataLayer||[];let t=document.createElement("script");return t.async=!0,t.src=`https://www.googletagmanager.com/gtag/js?id=${this.gaProps.gaId}`,this.gaProps.nonce&&(t.nonce=this.gaProps.nonce),document.head.appendChild(t),this.gaProps.privacyConfig&&this.applyPrivacyConfig(this.gaProps.privacyConfig),this.addEventToDataLayer(["js",this.gaProps.clock?new Date(this.gaProps.clock()):new Date]),this.addEventToDataLayer(["config",this.gaProps.gaId,{debug_mode:this.gaProps.debugMode??!1,send_page_view:this.gaProps.sendPageView??!0,user_id:this.gaProps.userId}]),Promise.resolve()}applyPrivacyConfig(t){this.addEventToDataLayer(["consent","default",{ad_storage:"granted",analytics_storage:"granted",ad_user_data:"granted",ad_personalization:"granted",wait_for_update:500}]),t.restrictDataProcessing&&this.addEventToDataLayer(["set","restricted_data_processing",!0]),t.configureConsent&&this.addEventToDataLayer(["consent","update",{ad_storage:"denied",analytics_storage:"granted",ad_user_data:"denied",ad_personalization:"denied",wait_for_update:500}]),t.redactAdsData&&this.addEventToDataLayer(["set","ads_data_redaction",!0])}},Jt(hl,"GoogleAnalytics4ClientEventListener"),hl),OZ="gtm-script";function E9(e,t){if(typeof e!="object")throw new Error("Unexpected event for GTM. GTM events are objects.");return e.eventCallback=t,e.eventTimeout=2e3,!0}Jt(E9,"addGtmEventCallback");function R9(...e){window.dataLayer.push(arguments)}Jt(R9,"gtag");var Cl,F9=(Cl=class extends Pd{constructor(t){super(t),this.addEventCallback=E9,this.gtmProps=t}addEventToDataLayer(t){typeof t=="object"&&t!==null&&!Array.isArray(t)?window.dataLayer.push(t):R9(...t)}init(){window.dataLayer=window.dataLayer||[];let t=document.createElement("script");return t.async=!0,t.src=`https://www.googletagmanager.com/gtm.js?id=${this.gtmProps.gtmId}`,t.id=OZ,this.gtmProps.nonce&&(t.nonce=this.gtmProps.nonce),document.head.appendChild(t),this.gtmProps.privacyConfig&&this.applyPrivacyConfig(this.gtmProps.privacyConfig),this.addEventToDataLayer({"gtm.start":Date.now(),event:"gtm.js"}),Promise.resolve()}applyPrivacyConfig(t){this.addEventToDataLayer(["consent","default",{ad_storage:"granted",analytics_storage:"granted",ad_user_data:"granted",ad_personalization:"granted",wait_for_update:500}]),t.restrictDataProcessing&&this.addEventToDataLayer(["set","restricted_data_processing",!0]),t.configureConsent&&this.addEventToDataLayer(["consent","update",{ad_storage:"denied",analytics_storage:"granted",ad_user_data:"denied",ad_personalization:"denied",wait_for_update:500}]),t.redactAdsData&&this.addEventToDataLayer(["set","ads_data_redaction",!0])}},Jt(Cl,"GoogleTagManagerClientEventListener"),Cl),xl,B9=(xl=class extends A0{constructor(){super(...arguments),this.getNetworkHandler=Jt(t=>new Td(t),"getNetworkHandler"),this.getClient=Jt(()=>new Ad,"getClient")}},Jt(xl,"GrapheneClientEventListener"),xl),GZ=/.*/,vl,$9=(vl=class extends _0{constructor(t){super(t),this.isInitCalled=!1,this.loadSentryAndInit=Jt(async()=>{if(this.isInitCalled)return;this.isInitCalled=!0;let{init:o,captureException:n,captureEvent:a}=await import("./chunks/dist-HVM4MXQX.mjs");this.clientCaptureException=n,this.clientCaptureEvent=a,o({allowUrls:[GZ],...this.browserProps})},"loadSentryAndInit"),this.getExceptionCapturer=Jt(async()=>(await this.loadSentryAndInit(),this.clientCaptureException),"getExceptionCapturer"),this.getEventCapturer=Jt(async()=>(await this.loadSentryAndInit(),this.clientCaptureEvent),"getEventCapturer"),this.browserProps=t}},Jt(vl,"SentryClientEventListener"),vl);var Pc="analyticsEvent",zZ="analyticsValueEvent",UZ="analyticsTimingEvent",Li=class Li extends F9{constructor(o){let{initialContext:n,...a}=o;super({...a,eventFormatter:Li.eventFormat});Ae(this,"isOutsideCalifornia",!1);Ae(this,"userLocation","Unknown");Ae(this,"globalPrivacyControl",!1);Ae(this,"isGtmDebug",!1);Ae(this,"initialContext");Ae(this,"hasAllPermissions",()=>{let o=new URL(window.location.href).searchParams.has("gtm_debug");if(o)return this.isGtmDebug=o,!0;if(this.isGtmDebug)return!0;let n=!0;for(let a of this.baseProps.requiredPermissions)if(!this.permissions.has(a)){n=!1;break}return!!n});Ae(this,"checkRegion",async()=>{if(!this.isOutsideCalifornia)try{let n=await(await fetch("https://web-platform.snap.com/cookies/user_location")).json();this.userLocation=`${n.country}-${n.region}`,this.isOutsideCalifornia=n.country!=="US"||n.region!=="ca"}catch(o){console.warn("Unable to determine user location:",Ft(o).message),this.isOutsideCalifornia=!0}});Ae(this,"flushInternal",()=>Promise.resolve());this.initialContext=n}async init(){window.dataLayer=window.dataLayer||[],await this.checkRegion(),window.dataLayer.push({userLocation:this.userLocation});let o=!this.isOutsideCalifornia,n=o&&this.initialContext.globalPrivacyControl;return this.applyPrivacyConfig({restrictDataProcessing:o,configureConsent:n,redactAdsData:n}),this.permissions.has("logging")&&this.allow("logging"),this.addEventToDataLayer({pageLocale:this.initialContext.locale}),await super.init()}static eventFormat(o,n){switch(o.type){case Te.USER_ACTION:return{event:Pc,eventAction:o.action,eventLabel:o.label||null,eventCategory:o.component,elementLocation:n.elementLocation??null,elementText:n.elementText??null,targetUrl:n.targetUrl??null,eventNonInt:!1};case Te.INFO:return{event:Pc,eventAction:o.action,eventLabel:o.label??null,eventCategory:o.component,elementLocation:n.elementLocation??null,elementText:n.elementText??null,targetUrl:n.targetUrl??null,eventNonInt:!0};case Te.VALUE:return{event:zZ,eventCategory:o.component,eventVariable:o.variable,eventLabel:o.label??null,eventValue:o.value,elementLocation:n.elementLocation??null,elementText:n.elementText??null,targetUrl:n.targetUrl??null,eventNonInt:!0};case Te.TIMING:return{event:UZ,eventCategory:o.component,eventVariable:o.variable,eventLabel:o.label??null,eventValue:o.valueMs,elementLocation:n.elementLocation??null,elementText:n.elementText??null,targetUrl:n.targetUrl??null,eventNonInt:!0};case Te.CUSTOM:{switch(o.subscribedEventType){case"page_load":{let a=Li.getFieldsFromContext(n);return{type:"multiple",events:[{...a,event:"virtualPageview",eventNonInt:!0,eventAction:"View",eventCategory:"Page",virtualPageviewPath:window.location.pathname},{...a,event:Pc,eventNonInt:!0,eventAction:"Load",eventCategory:"Page",eventLabel:window.location.pathname}]}}case"ecommerce":{let a=Li.getFieldsFromContext(n),{type:s,subscribedEventType:l,...p}=o;return{type:"multiple",events:[{ecommerce:null},{...a,...p,event:"ecommerce"}]}}case"experiment_impression":return!o.experimentId&&!o.variantId?null:{...Li.getFieldsFromContext(n),event:"experiment_impression",experiment_id:o.experimentId,variant_id:`${o.experimentId}.${o.variantId}`,elementLocation:n.elementLocation??null,elementText:n.elementText??null,targetUrl:n.targetUrl??null}}return null}}return null}};Ae(Li,"getFieldsFromContext",o=>({pagePath:o?.path,pageLocation:o?.url?.toString(),pageLocale:o?.locale}));var xg=Li;var hI=T(w());var kG=T(w());var Kc=T(w());var L9=T(w());var WZ={all:E`
    fragment AccordionAll on Accordion {
      ...ContentfulSysId
      title
      multipleOpen
      itemsCollection(limit: 30) {
        items {
          ...ContentfulSysId
          ... on AccordionItem {
            title
            body {
              json
            }
            callsToActionCollection(limit: 2) {
              items {
                ... on CallToAction {
                  ...CallToActionAll
                }
              }
            }
          }
        }
      }
    }
    ${O}
    ${bt}
  `},vg={all:E`
    query accordionQuery($preview: Boolean!, $locale: String!, $id: String!) {
      accordion(preview: $preview, locale: $locale, id: $id) {
        ...AccordionAll
      }
    }
    ${WZ.all}
  `};var H9=e=>{let t=lo(e)?e.sys.id:void 0,o=(0,L9.useContext)(be).elementLocation,{data:n}=se(vg.all,{skip:!t,variables:{id:t}});if(!n)return null;let{titleDataset:a}=Fe({entryId:t,fieldIds:["title"]}),s=n?.accordion.itemsCollection.items;return i(VM,{"data-testid":"accordion",multipleOpen:n?.accordion.multipleOpen,title:n?.accordion.title,titleDataset:a,children:s.map(l=>{let{titleDataset:p}=Fe({entryId:l.sys.id,fieldIds:["title"]}),d=l.title?l.title:l.sys.id;return i(mb,{id:l.sys.id,title:Po(l.title),titleDataset:p,onToggle:u=>{ge({eventCategory:"Accordion",eventAction:u?"Open":"Close",eventLabel:null,context:{elementText:d,elementLocation:o}})},children:i(Mc,{body:l.body,callsToActionCollection:l.callsToActionCollection??{items:[]},hasLinks:!1,sys:l.sys})},l.sys.id)})})};var QZ={all:E`
    fragment AnimatedAccordionAll on AnimatedAccordion {
      ...ContentfulSysId
      accordionContentsCollection {
        items {
          ...ContentfulSysId
          image {
            ...ImageAll
          }
          title
          body {
            json
          }
        }
      }
      mediaDirection
      autoPlaySpeed
      textAlignmentMobile
    }
    ${Oe.all}
    ${O}
  `},Ig=E`
  query AnimatedAccordionQuery($preview: Boolean!, $locale: String!, $id: String!) {
    animatedAccordion(preview: $preview, locale: $locale, id: $id) {
      ...AnimatedAccordionAll
    }
  }
  ${QZ.all}
`;var Il=T(w());var z9=T(w());var V9=e=>{let{getImageSources:t}=ve(),{title:o,image:n}=e,{desktopSettings:a,mobileSettings:s}=Dt({desktopHeight:n?.media?.height??0,mobileHeight:n?.mobileMedia?.height,desktopDefaultHeight:120,mobileDefaultHeight:120,enableHighDpi:n?.enableHighDpi,quality:n?.quality}),l=Le({desktop:t(n?.media?.url,a),mobile:t(n?.mobileMedia?.url,s)});return i(A3,{title:o,imgSrcs:l})};var O9=({stat:e="",subtitle:t})=>i(w3,{stat:e,subtitle:co(t)});var G9=e=>{let{getImageSources:t}=ve(),{title:o="",icon:n,body:a}=e,s;return n?.media&&(s=Le({desktop:t(n?.media?.url)})),i(D3,{title:o,body:co(a),imgSrcs:s,icon:n?.icon})};var qZ={"3:2":315,"9:16":656,"1:1":472,"16:9":265},KZ={"3:2":180,"9:16":400,"1:1":271,"16:9":152},kg=e=>{let{getImageSources:t}=ve(),{isRTL:o}=(0,z9.useContext)(ee),{anchor:n,brandBackgroundColor:a,backgroundColor:s,title:l,multiValuePropBlockSubtitle:p,body:d,subtopicsCollection:u,callsToActionCollection:y,mediaCollection:m,desktopMediaAspectRatio:g,mobileMediaAspectRatio:f,mediaDirection:b,autoplayCarousel:S,fullHeight:C,style:v}=e,k=it(a),I=y?.items?.map(_=>i(St,{..._},_.sys.id)),A=W6(m?.items),D=m?.items?.map((_,P)=>{if(_.__typename==="Image"){let{desktopSettings:$,mobileSettings:R}=Dt({desktopHeight:_.media?.height??0,mobileHeight:_.mobileMedia?.height,desktopDefaultHeight:qZ[g],mobileDefaultHeight:KZ[f],enableHighDpi:_.enableHighDpi,quality:_.quality});return{type:_.__typename,altText:_.media.description,sources:Le({desktop:t(_.media.url,$),mobile:t(_.mobileMedia?.url,R)})}}if(_.__typename==="Video"){let{media:$,mobileMedia:R}=A[P]??{};return{type:_.__typename,autoPlay:!!_.autoPlay,videoSource:$?.videoSource??_.media.url,mobileVideoSource:R?.videoSource??_?.mobileMedia?.url,sourceType:$?.contentType??_.media.contentType}}}),B=u.items,M;return m?.items?.length===1&&(M=m.items[0]?.stickersCollection?.items?.map(P=>({imgSrcs:t(P?.asset?.url),position:P?.position,rotation:P?.rotation}))),i(_3,{anchor:n,motifScheme:k,backgroundColor:s,title:co(l),subtitle:p,body:Ar(d),autoplayCarousel:S,callsToAction:I?.length?I:void 0,mediaSources:D,desktopMediaAspectRatio:g,mobileMediaAspectRatio:f,mediaDirection:b,fullHeight:C,style:v,stickers:M,isRtl:o,children:B.map(_=>_.__typename==="ImageSubtopic"?i(V9,{..._},_.sys.id):_.__typename==="StatSubtopic"?i(O9,{..._},_.sys.id):_.__typename==="TextSubtopic"?i(G9,{..._},_.sys.id):null)})};var U9=e=>{let{title:t,subtitle:o,titleAlignment:n,titleAlignmentMobile:a,brandBackgroundColor:s,backgroundColor:l=Lt.White,fullHeight:p=!1,tabsCollection:d,anchorId:u}=e,y=it(s),m=(0,Il.useContext)(be).elementLocation,[g,f]=(0,Il.useState)(0),b=(0,Il.useCallback)(C=>{let v=d?.items?.[C]?.tabText;f(C),ge({eventAction:"Click",eventCategory:"Block Tab",eventLabel:`tab:${C}`,context:{elementLocation:m,elementText:v}})},[d,m]),S=d?.items?d.items.filter(C=>C.block.__typename==="MultiValuePropBlock").map((C,v)=>({text:C.tabText,content:[i(kg,{...C.block,fullHeight:p,autoplayCarousel:g===v?C.block.autoplayCarousel:!1,brandBackgroundColor:s,backgroundColor:l,style:{display:g!==v?"none":"flex"}},C.sys.id)],maxColumns:1})):[];return x(pe,{children:[i(ao,{motifScheme:y,backgroundColor:l,title:co(t),subtitle:co(o),titleAlignment:n,titleAlignmentMobile:a,anchorId:u,children:S.length>=2&&i(Fy,{items:S,selectTab:b,selectedTab:g})}),S.map(C=>C.content)]})};var jZ=Fr`
  fragment TextSubtopicAll on TextSubtopic {
    ...ContentfulSysId
    icon {
      ...ContentfulSysId
      icon
      media {
        ...AssetAll
      }
    }
    title
    body {
      json
    }
  }
`,YZ=Fr`
  fragment ImageSubtopicAll on ImageSubtopic {
    ...ContentfulSysId
    image {
      ... on Image {
        ...ImageAll
      }
    }
    title
  }
`,XZ=Fr`
  fragment StatSubtopicAll on StatSubtopic {
    ...ContentfulSysId
    stat
    subtitle {
      json
    }
  }
`,Nc=Fr`
  fragment MultiValuePropBlockAll on MultiValuePropBlock {
    ...ContentfulSysId
    mediaCollection {
      items {
        ... on Video {
          ...VideoAll
        }
        ... on Image {
          ...ImageAll
        }
      }
    }
    anchor
    desktopMediaAspectRatio
    mobileMediaAspectRatio
    mediaDirection
    autoplayCarousel
    title {
      json
    }
    multiValuePropBlockSubtitle: subtitle
    body {
      json
    }
    subtopicsCollection {
      items {
        __typename
        ... on ImageSubtopic {
          ...ImageSubtopicAll
        }
        ... on StatSubtopic {
          ...StatSubtopicAll
        }
        ... on TextSubtopic {
          ...TextSubtopicAll
        }
      }
    }
    callsToActionCollection(limit: 2) {
      items {
        ... on CallToAction {
          ...CallToActionAll
        }
      }
    }
    brandBackgroundColor
    backgroundColor
    fullHeight
  }
  ${O}
  ${bt}
  ${Oe.all}
  ${gt.all}
  ${YZ}
  ${XZ}
  ${jZ}
`,W9=Fr`
  query MultiValuePropBlockQuery($preview: Boolean!, $locale: String!, $id: String!) {
    multiValuePropBlock(preview: $preview, locale: $locale, id: $id) {
      ...MultiValuePropBlockAll
    }
  }
  ${Nc}
`;var iv=Fr`
  fragment BlockTabsAll on BlockTabs {
    ...ContentfulSysId
    tabsCollection {
      items {
        ...ContentfulSysId
        tabText
        block {
          ... on MultiValuePropBlock {
            ...MultiValuePropBlockAll
          }
        }
      }
    }
    title {
      json
      links {
        entries {
          inline {
            ...ContentfulSysId
            ... on EmphasizedText {
              ...EmphasizedTextAll
            }
          }
        }
      }
    }
    subtitle {
      json
    }
    titleAlignment
    titleAlignmentMobile
    brandBackgroundColor
    backgroundColor
    fullHeight
    anchorId
  }
  ${O}
  ${ei}
  ${Nc}
`,Q9=Fr`
  query BlockTabs($preview: Boolean!, $locale: String!, $id: String!) {
    blockTabs(preview: $preview, locale: $locale, id: $id) {
      ...BlockTabsAll
    }
  }
  ${iv}
`;var sv=E`
  fragment BreakAll on Break {
    ...ContentfulSysId
    brandType
    type
    media {
      ...ImageAll
    }
    brandTopColor
    topColor
    brandBottomColor
    bottomColor
    isOverlaid
  }
  ${Oe.all}
  ${O}
`,q9=E`
  query BreakQuery($preview: Boolean!, $locale: String!, $id: String!) {
    break(preview: $preview, locale: $locale, id: $id) {
      ...BreakAll
    }
  }
  ${sv}
`;var wg=T(w());var K9=T(w());var Mg=e=>({sizeToUrl:[{size:"600w",settings:{width:600,quality:e}}],sizes:"600px"}),j9=[622,728],JZ=j9.map(e=>`${e}px`).join(", "),Tg=e=>({sizeToUrl:j9.map(t=>({size:`${t}w`,settings:{width:t,quality:e}})),sizes:`(max-width: ${jo}px) ${JZ}`}),Ec=({cardItem:e,mediaAspectRatio:t,isVisible:o,shouldLoad:n,isResponsiveWidth:a,hideLinkArrow:s,...l})=>{let p=e.media,{imageSource:d,imageAltText:u}=je(p.media),{imageSource:y}=je(p.mobileMedia),{getImageSources:m}=ve(),g=(0,K9.useContext)(be).elementLocation,f=Xn[p.quality??"Standard"],S={size:t==="9:16"?Mg(f):Tg(f),quality:f},C=Le({desktop:m(d,S),mobile:m(y,S)}),v=e.logo,k,I;if(v){let{imageSource:M,imageAltText:_}=je(v.media),{imageSource:P}=je(v.mobileMedia),$=Xn[v.quality??"Standard"],R=t==="9:16"?Mg($):Tg($);k=Le({desktop:m(M,{size:R,quality:$}),mobile:m(P,{size:R,quality:$})}),I=_}let A=e.slugReference?.slug,D=A?`/${A}`:e.url,B=()=>{D&&(ge({eventAction:"Click",eventCategory:"CarouselV3",eventLabel:`CarouselV3.ImageItem - ${D}`,context:{targetUrl:D,elementLocation:g}}),io(D)&&Me.flush())};return i(Gn,{aspectRatio:t,body:e.body,subtitle:e.subtitle,title:e.title,url:D,imgSrcs:C,imgAltText:u,isVisible:o,shouldLoad:n,onClick:B,isResponsiveWidth:a,hideLinkArrow:s,logoSrcs:k,logoAltText:I,...l},e.sys.id)};Ec.displayName="CarouselV3ImageItem";var Y9=T(Hr());var X9=T(w());var lv=({textItem:e})=>{let t=Ri(e?.description),o=Ri(e?.subtext),n=e.slugReference?.slug,a=n?`/${n}`:e.url,s=(0,X9.useContext)(be).elementLocation,l=e.description?.json?(0,Y9.documentToPlainTextString)(e.description.json):void 0;return i(lS,{description:t,subText:o,url:a,onClick:()=>{a&&ge({eventAction:"Click",eventCategory:"CarouselV3",eventLabel:`CarouselV3.TextItem - ${a}`,context:{targetUrl:a,elementLocation:s,elementText:l}})}},e.sys.id)};lv.displayName="CarouselV3TextItem";var Ag=T(w());var Rc=({cardItem:e,mediaAspectRatio:t,enableVideoControls:o,isVisible:n,shouldLoad:a,isResponsiveWidth:s,hideLinkArrow:l,...p})=>{let[d,u]=(0,Ag.useState)(!1),y=-1,m=(0,Ag.useContext)(be).elementLocation,g=e.media,{getBestBgImgSrc:f,getImageSources:b}=ve(),S=f(g.thumbnailMedia?.url,{width:728}),{media:{videoSource:C},mobileMedia:{videoSource:v}}=Yt(e.media),k=e.logo,I,A;if(k){let{imageSource:R,imageAltText:L}=je(k.media),{imageSource:G}=je(k.mobileMedia),Z=Xn[k.quality??"Standard"],U=t==="9:16"?Mg(Z):Tg(Z);I=Le({desktop:b(R,{size:U,quality:Z}),mobile:b(G,{size:U,quality:Z})}),A=L}let D=R=>{if(C&&!d){if(g.autoPlay)return;let{fileName:L}=Dn(C);ge({eventAction:"Play",eventCategory:"Video",eventLabel:L,context:{elementLocation:m}}),u(!0)}},B=R=>{if(C&&!g.autoPlay){let{fileName:L}=Dn(C);ge({eventAction:"Pause",eventCategory:"Video",eventLabel:L,context:{elementLocation:m}})}},M=ja({autoPlay:g.autoPlay,eventLabel:g.externalId??e.sys.id,getPreviousWatchTime:()=>y,setPreviousWatchTime:R=>{y=R},elementLocation:m}),_=e.slugReference?.slug,P=_?`/${_}`:e.url,$=()=>{P&&(ge({eventAction:"Click",eventCategory:"CarouselV3",eventLabel:`CarouselV3.VideoItem - ${P}`,context:{targetUrl:P,elementLocation:m}}),io(P)&&Me.flush())};return i(Gn,{aspectRatio:t,body:e.body,showVideoControls:o,subtitle:e.subtitle,title:e.title,url:P,videoSource:C,mobileVideoSource:v,onPlay:D,onPause:B,onTimeUpdate:M,isVisible:n,shouldLoad:a,onClick:$,posterSource:S,isResponsiveWidth:s,hideLinkArrow:l,logoSrcs:I,logoAltText:A,...p},e.sys.id)};Rc.displayName="CarouselV3VideoItem";var J9={text:E`
    fragment CarouselTextAll on CarouselText {
      ...ContentfulSysId
      description {
        json
      }
      subtext {
        json
      }
      slugReference {
        ...ContentfulSysId
        slug
      }
      url
    }
    ${O}
  `,card:E`
    fragment CarouselCardAll on CarouselCard {
      ...ContentfulSysId
      title
      subtitle
      body
      media {
        __typename
        ... on Video {
          ...VideoAll
        }
        ... on Image {
          ...ImageAll
        }
      }
      slugReference {
        ...ContentfulSysId
        slug
      }
      url
      showShadow
    }
    ${Oe.all}
    ${gt.all}
    ${O}
  `},ZZ={all:E`
    fragment CarouselV3All on CarouselV3 {
      ...ContentfulSysId
      layout
      enableOverflowDecoration
      mediaAspectRatio
      contentsCollection {
        items {
          ... on CarouselText {
            ...CarouselTextAll
          }
          ... on CarouselCard {
            ...CarouselCardAll
          }
        }
      }
    }
    ${J9.text}
    ${J9.card}
  `},_g=E`
  query CarouselV3Query($preview: Boolean!, $locale: String!, $id: String!) {
    carouselV3(preview: $preview, locale: $locale, id: $id) {
      ...CarouselV3All
    }
  }
  ${ZZ.all}
`;var eee=c`
  box-shadow: unset;
`,Fc=e=>{let{isRTL:t}=(0,wg.useContext)(ee),{getCurrentUrl:o}=(0,wg.useContext)(ee),n=(0,wg.useContext)(be).elementLocation,a=new URL(o()),s=V.deploymentType!=="production"&&a.searchParams.get("pauseAnimations")==="true",l=Ya(V,"carousel"),{data:p}=se(_g,{variables:{id:e.sys.id}}),d=p?.carouselV3?.contentsCollection?.items?.[0]?.__typename;if(!p?.carouselV3)return null;let{contentsCollection:u,mediaAspectRatio:y}=p.carouselV3,m=u.items,g=d==="CarouselText"||p?.carouselV3?.layout==="Single slide view",f=p?.carouselV3.enableOverflowDecoration??l?.defaultCarouselOverflowDecoration??V.theme?.defaultCarouselOverflowDecoration;return i(dr,{isSingleView:g,autoPlay:!s,isRtl:t,enableOverflowDecoration:f,onSlideChange:(b,S)=>{ge({eventCategory:"Carousel",eventAction:S==="drag"?"Scroll":"Click",eventLabel:`slide_change: ${b}`,context:{elementLocation:n}})},children:m.map(b=>{if(b.__typename==="CarouselCard"){let S=b,C=S.media.__typename==="Video",v=S.media.autoPlay??!0,k=C&&!v,I=S.showShadow??!0?void 0:eee;return C?i(Rc,{cardItem:S,mediaAspectRatio:y,enableVideoControls:k,className:I},S.sys.id):i(Ec,{cardItem:S,mediaAspectRatio:y,className:I},S.sys.id)}if(b.__typename==="CarouselText"){let S=b;return i(lv,{textItem:S},S.sys.id)}return null})})};Fc.displayName="CarouselV3";var nt=T(w());var cv="form_submit",dv=V.isDeploymentTypeProd?"6LcIxP8sAAAAAEwO5rCTbP8YilRqP3ChpLPtPQhq":"6LdRmf4sAAAAAHl3BsZ9q3v48AdrHK2afAxVQ-I8",CJe=V.isDeploymentTypeProd?"marketing-web-platform":"entapps-web-dev",Z9=`https://www.google.com/recaptcha/enterprise.js?render=${dv}`;var o7=T(w());var e7="1A7AAF5C-0F05-4719-BFD4-2A7C94BE53AE",t7="664578B2-FE27-4BE6-952F-E1023A4BA422";var Bc,n7=({nonce:e,onReady:t,onCompleted:o,onError:n,onReset:a,arkoseClientRef:s,enableArkose:l,arkoseDevKey:p=e7,arkoseProdKey:d=t7})=>{let u=V.isDeploymentTypeProd?d:p,y=f=>{f.setConfig({publicKey:u,onReady:()=>{t?.()},onCompleted:b=>{o?.(b.token)},onError:b=>{n?.(b?.error)},onReset:()=>{a?.()}})},m=()=>{s.current||(s.current={run:()=>{Bc&&(y(Bc),Bc.run())}})},g=f=>{Bc=f,m(),y(f)};(0,o7.useEffect)(()=>{if(!l)return;let f={type:"text/javascript","data-callback":"setupArkoseEnforcement",async:"true",defer:"true"};e&&(f.nonce=e),Bc?m():(window.setupArkoseEnforcement||(window.setupArkoseEnforcement=g),fn("snap-api.arkoselabs.com/v2/api",`https://snap-api.arkoselabs.com/v2/${u}/api.js`,()=>{window.setupArkoseEnforcement&&m()},f))},[])};function tee(e){if(e.sheet)return e.sheet;for(var t=0;t<document.styleSheets.length;t++)if(document.styleSheets[t].ownerNode===e)return document.styleSheets[t]}function oee(e){var t=document.createElement("style");return t.setAttribute("data-emotion",e.key),e.nonce!==void 0&&t.setAttribute("nonce",e.nonce),t.appendChild(document.createTextNode("")),t}var r7=(function(){function e(o){this.isSpeedy=o.speedy===void 0?!0:o.speedy,this.tags=[],this.ctr=0,this.nonce=o.nonce,this.key=o.key,this.container=o.container,this.before=null}var t=e.prototype;return t.insert=function(n){if(this.ctr%(this.isSpeedy?65e3:1)===0){var a=oee(this),s;this.tags.length===0?s=this.before:s=this.tags[this.tags.length-1].nextSibling,this.container.insertBefore(a,s),this.tags.push(a)}var l=this.tags[this.tags.length-1];if(this.isSpeedy){var p=tee(l);try{var d=n.charCodeAt(1)===105&&n.charCodeAt(0)===64;p.insertRule(n,d?0:p.cssRules.length)}catch{}}else l.appendChild(document.createTextNode(n));this.ctr++},t.flush=function(){this.tags.forEach(function(n){return n.parentNode.removeChild(n)}),this.tags=[],this.ctr=0},e})();function nee(e){function t(q,X,W,K,F){for(var Q=0,z=0,Se=0,j=0,fe,J,ue=0,_e=0,we,Be=we=fe=0,Ce=0,We=0,Pt=0,$e=0,Ro=W.length,eo=Ro-1,Ie,me="",ke="",Nt="",to="",ce;Ce<Ro;){if(J=W.charCodeAt(Ce),Ce===eo&&z+j+Se+Q!==0&&(z!==0&&(J=z===47?10:47),j=Se=Q=0,Ro++,eo++),z+j+Se+Q===0){if(Ce===eo&&(0<We&&(me=me.replace(g,"")),0<me.trim().length)){switch(J){case 32:case 9:case 59:case 13:case 10:break;default:me+=W.charAt(Ce)}J=59}switch(J){case 123:for(me=me.trim(),fe=me.charCodeAt(0),we=1,$e=++Ce;Ce<Ro;){switch(J=W.charCodeAt(Ce)){case 123:we++;break;case 125:we--;break;case 47:switch(J=W.charCodeAt(Ce+1)){case 42:case 47:e:{for(Be=Ce+1;Be<eo;++Be)switch(W.charCodeAt(Be)){case 47:if(J===42&&W.charCodeAt(Be-1)===42&&Ce+2!==Be){Ce=Be+1;break e}break;case 10:if(J===47){Ce=Be+1;break e}}Ce=Be}}break;case 91:J++;case 40:J++;case 34:case 39:for(;Ce++<eo&&W.charCodeAt(Ce)!==J;);}if(we===0)break;Ce++}switch(we=W.substring($e,Ce),fe===0&&(fe=(me=me.replace(m,"").trim()).charCodeAt(0)),fe){case 64:switch(0<We&&(me=me.replace(g,"")),J=me.charCodeAt(1),J){case 100:case 109:case 115:case 45:We=X;break;default:We=de}if(we=t(X,We,we,J,F+1),$e=we.length,0<re&&(We=o(de,me,Pt),ce=p(3,we,We,X,G,L,$e,J,F,K),me=We.join(""),ce!==void 0&&($e=(we=ce.trim()).length)===0&&(J=0,we="")),0<$e)switch(J){case 115:me=me.replace(B,l);case 100:case 109:case 45:we=me+"{"+we+"}";break;case 107:me=me.replace(k,"$1 $2"),we=me+"{"+we+"}",we=U===1||U===2&&s("@"+we,3)?"@-webkit-"+we+"@"+we:"@"+we;break;default:we=me+we,K===112&&(we=(ke+=we,""))}else we="";break;default:we=t(X,o(X,me,Pt),we,K,F+1)}Nt+=we,we=Pt=We=Be=fe=0,me="",J=W.charCodeAt(++Ce);break;case 125:case 59:if(me=(0<We?me.replace(g,""):me).trim(),1<($e=me.length))switch(Be===0&&(fe=me.charCodeAt(0),fe===45||96<fe&&123>fe)&&($e=(me=me.replace(" ",":")).length),0<re&&(ce=p(1,me,X,q,G,L,ke.length,K,F,K))!==void 0&&($e=(me=ce.trim()).length)===0&&(me="\0\0"),fe=me.charCodeAt(0),J=me.charCodeAt(1),fe){case 0:break;case 64:if(J===105||J===99){to+=me+W.charAt(Ce);break}default:me.charCodeAt($e-1)!==58&&(ke+=a(me,fe,J,me.charCodeAt(2)))}Pt=We=Be=fe=0,me="",J=W.charCodeAt(++Ce)}}switch(J){case 13:case 10:z===47?z=0:1+fe===0&&K!==107&&0<me.length&&(We=1,me+="\0"),0<re*ae&&p(0,me,X,q,G,L,ke.length,K,F,K),L=1,G++;break;case 59:case 125:if(z+j+Se+Q===0){L++;break}default:switch(L++,Ie=W.charAt(Ce),J){case 9:case 32:if(j+Q+z===0)switch(ue){case 44:case 58:case 9:case 32:Ie="";break;default:J!==32&&(Ie=" ")}break;case 0:Ie="\\0";break;case 12:Ie="\\f";break;case 11:Ie="\\v";break;case 38:j+z+Q===0&&(We=Pt=1,Ie="\f"+Ie);break;case 108:if(j+z+Q+Z===0&&0<Be)switch(Ce-Be){case 2:ue===112&&W.charCodeAt(Ce-3)===58&&(Z=ue);case 8:_e===111&&(Z=_e)}break;case 58:j+z+Q===0&&(Be=Ce);break;case 44:z+Se+j+Q===0&&(We=1,Ie+="\r");break;case 34:case 39:z===0&&(j=j===J?0:j===0?J:j);break;case 91:j+z+Se===0&&Q++;break;case 93:j+z+Se===0&&Q--;break;case 41:j+z+Q===0&&Se--;break;case 40:if(j+z+Q===0){if(fe===0)switch(2*ue+3*_e){case 533:break;default:fe=1}Se++}break;case 64:z+Se+j+Q+Be+we===0&&(we=1);break;case 42:case 47:if(!(0<j+Q+Se))switch(z){case 0:switch(2*J+3*W.charCodeAt(Ce+1)){case 235:z=47;break;case 220:$e=Ce,z=42}break;case 42:J===47&&ue===42&&$e+2!==Ce&&(W.charCodeAt($e+2)===33&&(ke+=W.substring($e,Ce+1)),Ie="",z=0)}}z===0&&(me+=Ie)}_e=ue,ue=J,Ce++}if($e=ke.length,0<$e){if(We=X,0<re&&(ce=p(2,ke,We,q,G,L,$e,K,F,K),ce!==void 0&&(ke=ce).length===0))return to+ke+Nt;if(ke=We.join(",")+"{"+ke+"}",U*Z!==0){switch(U!==2||s(ke,2)||(Z=0),Z){case 111:ke=ke.replace(A,":-moz-$1")+ke;break;case 112:ke=ke.replace(I,"::-webkit-input-$1")+ke.replace(I,"::-moz-$1")+ke.replace(I,":-ms-input-$1")+ke}Z=0}}return to+ke+Nt}function o(q,X,W){var K=X.trim().split(C);X=K;var F=K.length,Q=q.length;switch(Q){case 0:case 1:var z=0;for(q=Q===0?"":q[0]+" ";z<F;++z)X[z]=n(q,X[z],W).trim();break;default:var Se=z=0;for(X=[];z<F;++z)for(var j=0;j<Q;++j)X[Se++]=n(q[j]+" ",K[z],W).trim()}return X}function n(q,X,W){var K=X.charCodeAt(0);switch(33>K&&(K=(X=X.trim()).charCodeAt(0)),K){case 38:return X.replace(v,"$1"+q.trim());case 58:return q.trim()+X.replace(v,"$1"+q.trim());default:if(0<1*W&&0<X.indexOf("\f"))return X.replace(v,(q.charCodeAt(0)===58?"":"$1")+q.trim())}return q+X}function a(q,X,W,K){var F=q+";",Q=2*X+3*W+4*K;if(Q===944){q=F.indexOf(":",9)+1;var z=F.substring(q,F.length-1).trim();return z=F.substring(0,q).trim()+z+";",U===1||U===2&&s(z,1)?"-webkit-"+z+z:z}if(U===0||U===2&&!s(F,1))return F;switch(Q){case 1015:return F.charCodeAt(10)===97?"-webkit-"+F+F:F;case 951:return F.charCodeAt(3)===116?"-webkit-"+F+F:F;case 963:return F.charCodeAt(5)===110?"-webkit-"+F+F:F;case 1009:if(F.charCodeAt(4)!==100)break;case 969:case 942:return"-webkit-"+F+F;case 978:return"-webkit-"+F+"-moz-"+F+F;case 1019:case 983:return"-webkit-"+F+"-moz-"+F+"-ms-"+F+F;case 883:if(F.charCodeAt(8)===45)return"-webkit-"+F+F;if(0<F.indexOf("image-set(",11))return F.replace(R,"$1-webkit-$2")+F;break;case 932:if(F.charCodeAt(4)===45)switch(F.charCodeAt(5)){case 103:return"-webkit-box-"+F.replace("-grow","")+"-webkit-"+F+"-ms-"+F.replace("grow","positive")+F;case 115:return"-webkit-"+F+"-ms-"+F.replace("shrink","negative")+F;case 98:return"-webkit-"+F+"-ms-"+F.replace("basis","preferred-size")+F}return"-webkit-"+F+"-ms-"+F+F;case 964:return"-webkit-"+F+"-ms-flex-"+F+F;case 1023:if(F.charCodeAt(8)!==99)break;return z=F.substring(F.indexOf(":",15)).replace("flex-","").replace("space-between","justify"),"-webkit-box-pack"+z+"-webkit-"+F+"-ms-flex-pack"+z+F;case 1005:return b.test(F)?F.replace(f,":-webkit-")+F.replace(f,":-moz-")+F:F;case 1e3:switch(z=F.substring(13).trim(),X=z.indexOf("-")+1,z.charCodeAt(0)+z.charCodeAt(X)){case 226:z=F.replace(D,"tb");break;case 232:z=F.replace(D,"tb-rl");break;case 220:z=F.replace(D,"lr");break;default:return F}return"-webkit-"+F+"-ms-"+z+F;case 1017:if(F.indexOf("sticky",9)===-1)break;case 975:switch(X=(F=q).length-10,z=(F.charCodeAt(X)===33?F.substring(0,X):F).substring(q.indexOf(":",7)+1).trim(),Q=z.charCodeAt(0)+(z.charCodeAt(7)|0)){case 203:if(111>z.charCodeAt(8))break;case 115:F=F.replace(z,"-webkit-"+z)+";"+F;break;case 207:case 102:F=F.replace(z,"-webkit-"+(102<Q?"inline-":"")+"box")+";"+F.replace(z,"-webkit-"+z)+";"+F.replace(z,"-ms-"+z+"box")+";"+F}return F+";";case 938:if(F.charCodeAt(5)===45)switch(F.charCodeAt(6)){case 105:return z=F.replace("-items",""),"-webkit-"+F+"-webkit-box-"+z+"-ms-flex-"+z+F;case 115:return"-webkit-"+F+"-ms-flex-item-"+F.replace(_,"")+F;default:return"-webkit-"+F+"-ms-flex-line-pack"+F.replace("align-content","").replace(_,"")+F}break;case 973:case 989:if(F.charCodeAt(3)!==45||F.charCodeAt(4)===122)break;case 931:case 953:if($.test(q)===!0)return(z=q.substring(q.indexOf(":")+1)).charCodeAt(0)===115?a(q.replace("stretch","fill-available"),X,W,K).replace(":fill-available",":stretch"):F.replace(z,"-webkit-"+z)+F.replace(z,"-moz-"+z.replace("fill-",""))+F;break;case 962:if(F="-webkit-"+F+(F.charCodeAt(5)===102?"-ms-"+F:"")+F,W+K===211&&F.charCodeAt(13)===105&&0<F.indexOf("transform",10))return F.substring(0,F.indexOf(";",27)+1).replace(S,"$1-webkit-$2")+F}return F}function s(q,X){var W=q.indexOf(X===1?":":"{"),K=q.substring(0,X!==3?W:10);return W=q.substring(W+1,q.length-1),te(X!==2?K:K.replace(P,"$1"),W,X)}function l(q,X){var W=a(X,X.charCodeAt(0),X.charCodeAt(1),X.charCodeAt(2));return W!==X+";"?W.replace(M," or ($1)").substring(4):"("+X+")"}function p(q,X,W,K,F,Q,z,Se,j,fe){for(var J=0,ue=X,_e;J<re;++J)switch(_e=le[J].call(y,q,ue,W,K,F,Q,z,Se,j,fe)){case void 0:case!1:case!0:case null:break;default:ue=_e}if(ue!==X)return ue}function d(q){switch(q){case void 0:case null:re=le.length=0;break;default:if(typeof q=="function")le[re++]=q;else if(typeof q=="object")for(var X=0,W=q.length;X<W;++X)d(q[X]);else ae=!!q|0}return d}function u(q){return q=q.prefix,q!==void 0&&(te=null,q?typeof q!="function"?U=1:(U=2,te=q):U=0),u}function y(q,X){var W=q;if(33>W.charCodeAt(0)&&(W=W.trim()),oe=W,W=[oe],0<re){var K=p(-1,X,W,W,G,L,0,0,0,0);K!==void 0&&typeof K=="string"&&(X=K)}var F=t(de,W,X,0,0);return 0<re&&(K=p(-2,F,W,W,G,L,F.length,0,0,0),K!==void 0&&(F=K)),oe="",Z=0,L=G=1,F}var m=/^\0+/g,g=/[\0\r\f]/g,f=/: */g,b=/zoo|gra/,S=/([,: ])(transform)/g,C=/,\r+?/g,v=/([\t\r\n ])*\f?&/g,k=/@(k\w+)\s*(\S*)\s*/,I=/::(place)/g,A=/:(read-only)/g,D=/[svh]\w+-[tblr]{2}/,B=/\(\s*(.*)\s*\)/g,M=/([\s\S]*?);/g,_=/-self|flex-/g,P=/[^]*?(:[rp][el]a[\w-]+)[^]*/,$=/stretch|:\s*\w+\-(?:conte|avail)/,R=/([^-])(image-set\()/,L=1,G=1,Z=0,U=1,de=[],le=[],re=0,te=null,ae=0,oe="";return y.use=d,y.set=u,e!==void 0&&u(e),y}var a7=nee;var uv="/*|*/",ree=uv+"}";function aee(e){e&&Dg.current.insert(e+"}")}var Dg={current:null},iee=function(t,o,n,a,s,l,p,d,u,y){switch(t){case 1:{switch(o.charCodeAt(0)){case 64:return Dg.current.insert(o+";"),"";case 108:if(o.charCodeAt(2)===98)return""}break}case 2:{if(d===0)return o+uv;break}case 3:switch(d){case 102:case 112:return Dg.current.insert(n[0]+o),"";default:return o+(y===0?uv:"")}case-2:o.split(ree).forEach(aee)}},see=function(t){t===void 0&&(t={});var o=t.key||"css",n;t.prefix!==void 0&&(n={prefix:t.prefix});var a=new a7(n),s={},l;{l=t.container||document.head;var p=document.querySelectorAll("style[data-emotion-"+o+"]");Array.prototype.forEach.call(p,function(g){var f=g.getAttribute("data-emotion-"+o);f.split(" ").forEach(function(b){s[b]=!0}),g.parentNode!==l&&l.appendChild(g)})}var d;if(a.use(t.stylisPlugins)(iee),d=function(f,b,S,C){var v=b.name;if(Dg.current=S,0)var k;a(f,b.styles),C&&(m.inserted[v]=!0)},0)var u,y;var m={key:o,sheet:new r7({key:o,container:l,nonce:t.nonce,speedy:t.speedy}),nonce:t.nonce,inserted:s,registered:{},insert:d};return m},i7=see;function lee(e){var t={};return function(o){return t[o]===void 0&&(t[o]=e(o)),t[o]}}var s7=lee;var pee=/[A-Z]|^ms/g,cee=/_EMO_([^_]+?)_([^]*?)_EMO_/g,d7=function(t){return t.charCodeAt(1)===45},l7=function(t){return t!=null&&typeof t!="boolean"},yv=s7(function(e){return d7(e)?e:e.replace(pee,"-$&").toLowerCase()}),p7=function(t,o){switch(t){case"animation":case"animationName":if(typeof o=="string")return o.replace(cee,function(n,a,s){return _r={name:a,styles:s,next:_r},a})}return LI[t]!==1&&!d7(t)&&typeof o=="number"&&o!==0?o+"px":o};function $c(e,t,o,n){if(o==null)return"";if(o.__emotion_styles!==void 0)return o;switch(typeof o){case"boolean":return"";case"object":{if(o.anim===1)return _r={name:o.name,styles:o.styles,next:_r},o.name;if(o.styles!==void 0){var a=o.next;if(a!==void 0)for(;a!==void 0;)_r={name:a.name,styles:a.styles,next:_r},a=a.next;var s=o.styles+";";return s}return dee(e,t,o)}case"function":{if(e!==void 0){var l=_r,p=o(e);return _r=l,$c(e,t,p,n)}break}case"string":if(0)var d,u;break}if(t==null)return o;var y=t[o];return y!==void 0&&!n?y:o}function dee(e,t,o){var n="";if(Array.isArray(o))for(var a=0;a<o.length;a++)n+=$c(e,t,o[a],!1);else for(var s in o){var l=o[s];if(typeof l!="object")t!=null&&t[l]!==void 0?n+=s+"{"+t[l]+"}":l7(l)&&(n+=yv(s)+":"+p7(s,l)+";");else if(Array.isArray(l)&&typeof l[0]=="string"&&(t==null||t[l[0]]===void 0))for(var p=0;p<l.length;p++)l7(l[p])&&(n+=yv(s)+":"+p7(s,l[p])+";");else{var d=$c(e,t,l,!1);switch(s){case"animation":case"animationName":{n+=yv(s)+":"+d+";";break}default:n+=s+"{"+d+"}"}}}return n}var c7=/label:\s*([^\s;\n{]+)\s*;/g;var _r,Pg=function(t,o,n){if(t.length===1&&typeof t[0]=="object"&&t[0]!==null&&t[0].styles!==void 0)return t[0];var a=!0,s="";_r=void 0;var l=t[0];l==null||l.raw===void 0?(a=!1,s+=$c(n,o,l,!1)):s+=l[0];for(var p=1;p<t.length;p++)s+=$c(n,o,t[p],s.charCodeAt(s.length-1)===46),a&&(s+=l[p]);var d;c7.lastIndex=0;for(var u="",y;(y=c7.exec(s))!==null;)u+="-"+y[1];var m=$I(s)+u;return{name:m,styles:s,next:_r}};var uee=!0;function mv(e,t,o){var n="";return o.split(" ").forEach(function(a){e[a]!==void 0?t.push(e[a]):n+=a+" "}),n}var u7=function(t,o,n){var a=t.key+"-"+o.name;if((n===!1||uee===!1&&t.compat!==void 0)&&t.registered[a]===void 0&&(t.registered[a]=o.styles),t.inserted[o.name]===void 0){var s=o;do{var l=t.insert("."+a,s,t.sheet,!0);s=s.next}while(s!==void 0)}};function y7(e,t){if(e.inserted[t.name]===void 0)return e.insert("",t,e.sheet,!0)}function m7(e,t,o){var n=[],a=mv(e,n,o);return n.length<2?o:a+t(n)}var yee=function(t){var o=i7(t);o.sheet.speedy=function(p){this.isSpeedy=p},o.compat=!0;var n=function(){for(var d=arguments.length,u=new Array(d),y=0;y<d;y++)u[y]=arguments[y];var m=Pg(u,o.registered,void 0);return u7(o,m,!1),o.key+"-"+m.name},a=function(){for(var d=arguments.length,u=new Array(d),y=0;y<d;y++)u[y]=arguments[y];var m=Pg(u,o.registered),g="animation-"+m.name;return y7(o,{name:m.name,styles:"@keyframes "+g+"{"+m.styles+"}"}),g},s=function(){for(var d=arguments.length,u=new Array(d),y=0;y<d;y++)u[y]=arguments[y];var m=Pg(u,o.registered);y7(o,m)},l=function(){for(var d=arguments.length,u=new Array(d),y=0;y<d;y++)u[y]=arguments[y];return m7(o.registered,n,mee(u))};return{css:n,cx:l,injectGlobal:s,keyframes:a,hydrate:function(d){d.forEach(function(u){o.inserted[u]=!0})},flush:function(){o.registered={},o.inserted={},o.sheet.flush()},sheet:o.sheet,cache:o,getRegisteredStyles:mv.bind(null,o.registered),merge:m7.bind(null,o.registered,n)}},mee=function e(t){for(var o="",n=0;n<t.length;n++){var a=t[n];if(a!=null){var s=void 0;switch(typeof a){case"boolean":break;case"object":{if(Array.isArray(a))s=e(a);else{s="";for(var l in a)a[l]&&l&&(s&&(s+=" "),s+=l)}break}default:s=a}s&&(o&&(o+=" "),o+=s)}}return o},g7=yee;var wr=g7(),UJe=wr.flush,WJe=wr.hydrate,QJe=wr.cx,qJe=wr.merge,KJe=wr.getRegisteredStyles,f7=wr.injectGlobal,jJe=wr.keyframes,YJe=wr.css,XJe=wr.sheet,JJe=wr.cache;var b7=T(w());var gee=Ak`
  .grecaptcha-badge {
    visibility: hidden;
  }
`,S7=({nonce:e,enableRecaptcha:t,recaptchaClientRef:o,onError:n})=>{(0,b7.useEffect)(()=>{if(!t)return;f7(gee);let a={type:"text/javascript",async:"true",defer:"true"};e&&(a.nonce=e);let s=()=>{o.current||(o.current={run:async l=>{try{return await window.grecaptcha.enterprise.execute(dv,{action:l})}catch(p){let d=Ft(p);throw n?.(d.message),d}}})};fn("google-recaptcha",Z9,()=>{window.grecaptcha?.enterprise.ready(()=>{s()})},a)},[])};var kl=T(zm());var C7={US:"United States",AD:"Andorra",AE:"United Arab Emirates",AF:"Afghanistan",AG:"Antigua and Barbuda",AI:"Anguilla",AL:"Albania",AM:"Armenia",AO:"Angola",AQ:"Antarctica",AR:"Argentina",AT:"Austria",AU:"Australia",AW:"Aruba",AX:"Aland Islands",AZ:"Azerbaijan",BA:"Bosnia and Herzegovina",BB:"Barbados",BD:"Bangladesh",BE:"Belgium",BF:"Burkina Faso",BG:"Bulgaria",BH:"Bahrain",BI:"Burundi",BJ:"Benin",BL:"Saint Barth\xE9lemy",BM:"Bermuda",BN:"Brunei",BO:"Bolivia",BQ:"Bonaire, Sint Eustatius and Saba",BR:"Brazil",BS:"Bahamas",BT:"Bhutan",BV:"Bouvet Island",BW:"Botswana",BY:"Belarus",BZ:"Belize",CA:"Canada",CC:"Cocos (Keeling) Islands",CD:"Congo, the Democratic Republic of the",CF:"Central African Republic",CG:"Congo",CH:"Switzerland",CI:"Cote d'Ivoire",CK:"Cook Islands",CL:"Chile",CM:"Cameroon",CN:"China",CO:"Colombia",CR:"Costa Rica",CU:"Cuba",CV:"Cape Verde",CW:"Cura\xE7ao",CX:"Christmas Island",CY:"Cyprus",CZ:"Czech Republic",DE:"Germany",DJ:"Djibouti",DK:"Denmark",DM:"Dominica",DO:"Dominican Republic",DZ:"Algeria",EC:"Ecuador",EE:"Estonia",EG:"Egypt",EH:"Western Sahara",ER:"Eritrea",ES:"Spain",ET:"Ethiopia",FI:"Finland",FJ:"Fiji",FK:"Falkland Islands (Malvinas)",FO:"Faroe Islands",FR:"France",GA:"Gabon",GB:"United Kingdom",GD:"Grenada",GE:"Georgia",GF:"French Guiana",GG:"Guernsey",GH:"Ghana",GI:"Gibraltar",GL:"Greenland",GM:"Gambia",GN:"Guinea",GP:"Guadeloupe",GQ:"Equatorial Guinea",GR:"Greece",GS:"South Georgia and the South Sandwich Islands",GT:"Guatemala",GW:"Guinea-Bissau",GY:"Guyana",HK:"Hong Kong",HM:"Heard Island and McDonald Islands",HN:"Honduras",HR:"Croatia",HT:"Haiti",HU:"Hungary",ID:"Indonesia",IE:"Ireland",IL:"Israel",IM:"Isle of Man",IN:"India",IO:"British Indian Ocean Territory",IQ:"Iraq",IR:"Iran",IS:"Iceland",IT:"Italy",JE:"Jersey",JM:"Jamaica",JO:"Jordan",JP:"Japan",KE:"Kenya",KG:"Kyrgyzstan",KH:"Cambodia",KI:"Kiribati",KM:"Comoros",KN:"Saint Kitts and Nevis",KP:"Korea, Democratic People's Republic of",KR:"South Korea",KW:"Kuwait",KY:"Cayman Islands",KZ:"Kazakhstan",LA:"Laos",LB:"Lebanon",LC:"Saint Lucia",LI:"Liechtenstein",LK:"Sri Lanka",LR:"Liberia",LS:"Lesotho",LT:"Lithuania",LU:"Luxembourg",LV:"Latvia",LY:"Libya",MA:"Morocco",MC:"Monaco",MD:"Moldova",ME:"Montenegro",MF:"Saint Martin",MG:"Madagascar",MK:"Macedonia",ML:"Mali",MM:"Myanmar",MN:"Mongolia",MO:"Macao",MQ:"Martinique",MR:"Mauritania",MS:"Montserrat",MT:"Malta",MU:"Mauritius",MV:"Maldives",MW:"Malawi",MX:"Mexico",MY:"Malaysia",MZ:"Mozambique",NA:"Namibia",NC:"New Caledonia",NE:"Niger",NF:"Norfolk Island",NG:"Nigeria",NI:"Nicaragua",NL:"Netherlands",NO:"Norway",NP:"Nepal",NR:"Nauru",NU:"Niue",NZ:"New Zealand",OM:"Oman",PA:"Panama",PE:"Peru",PF:"French Polynesia",PG:"Papua New Guinea",PH:"Philippines",PK:"Pakistan",PL:"Poland",PM:"Saint Pierre and Miquelon",PN:"Pitcairn",PS:"Palestine",PT:"Portugal",PY:"Paraguay",QA:"Qatar",RE:"Reunion",RO:"Romania",RS:"Serbia",RU:"Russia",RW:"Rwanda",SA:"Saudi Arabia",SB:"Solomon Islands",SC:"Seychelles",SD:"Sudan",SE:"Sweden",SG:"Singapore",SH:"Saint Helena, Ascension and Tristan da Cunha",SI:"Slovenia",SJ:"Svalbard and Jan Mayen",SK:"Slovakia",SL:"Sierra Leone",SM:"San Marino",SN:"Senegal",SO:"Somalia",SR:"Suriname",SS:"South Sudan",ST:"Sao Tome and Principe",SV:"El Salvador",SX:"Sint Maarten (Dutch part)",SY:"Syrian Arab Republic",SZ:"Swaziland",TC:"Turks and Caicos Islands",TD:"Chad",TF:"French Southern Territories",TG:"Togo",TH:"Thailand",TJ:"Tajikistan",TK:"Tokelau",TL:"Timor-Leste",TM:"Turkmenistan",TN:"Tunisia",TO:"Tonga",TR:"Turkey",TT:"Trinidad and Tobago",TV:"Tuvalu",TW:"Taiwan",TZ:"Tanzania",UA:"Ukraine",UG:"Uganda",UY:"Uruguay",UZ:"Uzbekistan",VA:"Holy See (Vatican City State)",VC:"Saint Vincent and the Grenadines",VE:"Venezuela",VG:"Virgin Islands, British",VN:"Vietnam",VU:"Vanuatu",WF:"Wallis and Futuna",WS:"Samoa",YE:"Yemen",YT:"Mayotte",ZA:"South Africa",ZM:"Zambia",ZW:"Zimbabwe"},fee=Object.entries(C7).sort((e,t)=>e[0]==="US"?-1:t[0]==="US"?1:e[1].localeCompare(t[1])),h7=Object.fromEntries(fee),x7={Countries:{defaultPlaceholder:"Country",data:Object.values(h7).map(e=>({key:e,value:e}))},"Countries (submit country code)":{defaultPlaceholder:"Country/Region",data:Object.keys(h7).map(e=>({key:C7[e],value:e}))}};function v7(e,t){for(let o of e.rowsCollection.items)for(let n of o.fieldsCollection.items)if(n.name===t)return n}var bee=new Map(Object.entries({utmSourceFieldName:"utm_source",utmMediumFieldName:"utm_medium",utmCampaignFieldName:"utm_campaign",utmContentFieldName:"utm_content",utmTermFieldName:"utm_term"})),I7=(e,t)=>{let o=e?.items.find(l=>l.__typename==="ExtraParametersFormFeature");if(!o)return;let{searchParams:n,pathname:a}=new URL(t),s={};for(let[l,p]of Object.entries(o)){if(!p)continue;if(l==="urlPathFieldName"){s[p]=a;continue}let d=bee.get(l);d&&(s[p]=n.get(d)??"")}return s},k7=(e,t)=>{let o=new Map,n=new URL(e),a=new URLSearchParams(n.search);a.forEach((l,p)=>{if(p.startsWith("form_")){let d=p.replace("form_",""),u=a.getAll(p);o.set(d,u.length>1?u:u[0])}});let s=new Map;for(let[l,p]of o){let d=t(l);if(!(!d||!d.name))switch(d.__typename){case"DropdownField":s.set(d.name,p);break;case"MultiselectDropdownField":{let y=(Array.isArray(p)?p:[p]).map(m=>{let g=d.optionsCollection?.items.find(f=>f.key===m)?.value;if(g)return{id:m,name:g}}).filter(Boolean);s.set(d.name,y);break}case"InputField":{let u=Array.isArray(p)?p[0]:p;switch(d.type){case"Checkbox":{s.set(d.name,u==="true");break}case"Number":{s.set(d.name,u);break}default:{s.set(d.name,u);break}}break}case"PresetDropdownField":{s.set(d.name,p);break}default:{console.warn(`Unsupported field type: ${d.__typename} for url form parsing.`);break}}}return s};var See=c`
  width: 100%;
  display: inline-flex;
  justify-content: center;

  ${Mr.over768_desktop_small} {
    width: auto;
  }
`,gv=({contentfulInputField:e,submitText:t,submitSuccessText:o,submitTextDataset:n,submitProps:a,initialValue:s})=>{let l=e.__typename;if(l==="InputField"){let d=Fe({entryId:e.sys.id,fieldIds:["richLabel","label","error","helpText","contentfulDescription"]}),u=e.error?(0,kl.documentToReactComponents)(e.error.json):null,y=e.richLabel?J6(e.richLabel):null,m=(e.type!=="Hidden"?s:void 0)??e.initialValue,g={id:e.name,name:e.name,type:e.type,validation:e.validation,label:e.label,required:e.required,placeholder:e.placeholder,readOnly:e.readOnly,maxLength:e.maxLength,shouldResetToInitial:e.shouldResetToInitial,helpText:e.helpText,minValue:e.minValue,maxValue:e.maxValue,dataset:d.contentfulDescriptionDataset,...d,error:u,richLabel:y,initialValue:m};if(V.site==="stinson"){if(e.type==="Text")return i(void 0,{...g},e.sys.id);if(e.type==="Checkbox")return i(void 0,{...g},e.sys.id)}return i(Ku,{...g},e.sys.id)}let p=Fe({entryId:e.sys.id,fieldIds:["label","error","helpText","contentfulDescription"]});if(l==="DropdownField"){let d=e.optionsCollection?.items??[],u=e.initialOption?.value,y=s??u,m=d.map(({value:b})=>b??""),g=typeof y=="string"&&m.includes(y)?y:u,f=e.error?(0,kl.documentToReactComponents)(e.error.json):null;return i(Mp,{id:e.name,name:e.name,label:e.label,initialValue:g,allValues:m,error:f,shouldResetToInitial:e.shouldResetToInitial,helpText:e.helpText,required:e.required,placeholder:e.placeholder,...Vt(p,"contentfulDescriptionDataset"),fieldDataset:p.contentfulDescriptionDataset,children:d.map(({key:b,value:S})=>i("option",{value:S||b,children:b},b))},e.sys.id)}if(l==="MultiselectDropdownField"){let d=e.optionsCollection?.items??[],u=e.error?(0,kl.documentToReactComponents)(e.error.json):null,y=Array.isArray(s)&&s.every(g=>typeof g=="object")?s:void 0,m=d.map(({key:g,value:f})=>!f||!g?null:{name:f,id:g}).filter(Boolean);return i(Xu,{name:e.name,label:e.label,showCheckbox:!0,options:m,required:e.required,placeholder:e.placeholder,error:u,...Vt(p,"contentfulDescriptionDataset"),dataset:p.contentfulDescriptionDataset,initialValues:y})}if(l==="PresetDropdownField"){let d=e.preset?x7[e.preset]:void 0;if(!d)return null;let u=d.data.map(({value:m})=>m),y=e.error?(0,kl.documentToReactComponents)(e.error.json):null;return i(Mp,{id:e.name,error:y,placeholder:e.placeholder??d.defaultPlaceholder,...Vt(p,"contentfulDescriptionDataset"),name:e.name,label:e.label,fieldDataset:p.contentfulDescriptionDataset,allValues:u,initialValue:s??e.initialValue,required:e.required,children:d.data.map(({key:m,value:g})=>i("option",{value:g,children:m},m))},e.sys.id)}if(l==="RadioSelectField"){let d=e.optionsCollection?.items?.map(({key:f,value:b})=>({key:f,value:b}))??[],u=e.initialOption?.value,y=d.map(({value:f})=>f??""),m=typeof u=="string"&&y.includes(u)?u:void 0,g=e.error?(0,kl.documentToReactComponents)(e.error.json):null;return i(UF,{error:g,helpText:e.helpText,initialValue:m,label:e.label,name:e.name,options:d,required:e.required,shouldResetToInitial:e.shouldResetToInitial},e.sys.id)}if(l==="SubmitButton"&&a){let{handleSubmit:d,disabled:u,loading:y,submitSuccess:m}=a;return i("div",{className:See,children:i(no,{type:"Primary",size:"Large",onClick:d,disabled:u,loading:y,buttonTextDataset:n,children:m?o??t:t})})}return null};var hee=c`
  opacity: 0;
  visibility: hidden;
`,Cee=4e3,fv="mwp-form-data",M7=({rowAsText:e,sys:t,fieldsCollection:o,fieldRender:n})=>{let{rowAsTextDataset:a}=Fe({entryId:t.id,fieldIds:["rowAsText"]});return e?i(qu,{dataset:a,children:Ar(e)},t.id):i(qu,{children:o.items.map(n)},t.id)},xee=(e,t,o,n,a)=>l=>i(pe,{children:e.items.map(p=>Ql(M7,{...p,key:p.sys.id,fieldRender:d=>i(gv,{contentfulInputField:d,submitProps:l,submitText:t,submitSuccessText:o,submitTextDataset:n,initialValue:a?.[d.name]},d.sys.id)}))}),T7=({rowsCollection:e,additionalFeaturesCollection:t,analytics:o,redirectUrl:n,submitText:a,submitSuccessText:s,endpoint:l,responseType:p,redirectTimeout:d=Cee,extraParams:u,callback:y,enableArkose:m=V.enableArkoseOnForms,arkosePublicDevKey:g,arkosePublicProdKey:f,sys:b,persistFieldEdits:S,prepopulatePerQueryParams:C,onFormInit:v,onValueChange:k,renderErrorMessage:I,...A})=>{let[D,B]=(0,nt.useState)({}),M=(0,nt.useRef)({}),{userLocation:_,currentLocale:P,getCurrentUrl:$}=(0,nt.useContext)(ee),R=_.country;(0,nt.useEffect)(()=>{let Ie={};if(S){let me=JSON.parse(rs(fv)??"{}");me[b.id]&&tr(Ie,me[b.id]),M.current[b.id]=Ie}if(C){let me=$(),ke=k7(me,Nt=>v7({rowsCollection:e},Nt));for(let[Nt,to]of ke)Ie[Nt]=to}B(Ie),v?.(Ie)},[S,b.id,$,e,C,v]);let L=(0,nt.useContext)(be).elementLocation,G=(0,nt.useRef)(!1),U=vt().enableRecaptchaOnForms==="true",de=(0,nt.useRef)(),le=(0,nt.useRef)(),re=(0,nt.useRef)();n7({arkoseClientRef:de,enableArkose:m&&!U,arkoseDevKey:g,arkoseProdKey:f,onCompleted:Ie=>{le.current?.({arkoseToken:Ie})},onError:Ie=>{Re({component:"Form",error:Ie,message:"Arkose error",action:"Validate",context:{elementLocation:L}}),re.current?.(Ie??"Arkose error")}});let te=(0,nt.useRef)();S7({recaptchaClientRef:te,enableRecaptcha:m&&U,onError:Ie=>{Re({component:"Form",error:Ie,message:"reCaptcha error",action:"Validate",context:{elementLocation:L}})}});let{formatMessage:ae}=(0,nt.useContext)(qe),oe=ae({id:"formApiResponse400ErrorMessage",defaultMessage:"400 Bad Request"}),q=ae({id:"formApiResponse500ErrorMessage",defaultMessage:"500 Internal Server"}),X=ae({id:"formInvalidErrorMessage",defaultMessage:"Please updates required fields"}),W=ae({id:"formRequiredFieldsMessage",defaultMessage:"Fields marked with * are required."});I=I??(Ie=>Ie===400?oe:q);let[K,F]=(0,nt.useState)(void 0),Q=(0,nt.useRef)(null),{submitTextDataset:z}=Fe({entryId:b.id,fieldIds:["submitText"]});(0,nt.useEffect)(()=>{K&&Q.current&&Q.current.click()},[K]);let Se=(0,nt.useCallback)(async(Ie,me)=>{try{o&&ge({eventCategory:"Form",eventAction:"FormSubmit",eventLabel:o.label,context:{elementLocation:L}}),y&&y(me,Ie);let ke=n;try{if(p==="Downloadable Resource URL"){let Nt=await Ie.json();F(Nt.url)}else p==="Redirect URL"&&!n&&(ke=(await Ie.json()).url??"")}catch{F(void 0)}ke&&setTimeout(()=>{window.location.assign(ke)},d),S&&(delete M.current[b.id],ci(fv,JSON.stringify(M.current)))}catch(ke){Re({component:"Form",error:ke,context:{elementLocation:L}})}},[o,L,y,n,S,p,d,b.id]),j=(0,nt.useCallback)((Ie,me,ke)=>{y&&y(me,ke),Re({component:"Form",error:Ie,message:"Form submit failed",action:"Submit",context:{elementLocation:L,elementText:a,targetUrl:l}})},[y,L,l,a]),fe=(0,nt.useMemo)(()=>e.items.flatMap(Ie=>Ie.fieldsCollection.items).some(({__typename:Ie})=>Ie==="SubmitButton"),[e]),J=D,ue=JSON.stringify(e),_e=JSON.stringify(z),we=JSON.stringify(J),Be=(0,nt.useMemo)(()=>{if(fe)return xee(e,a,s,z,J)},[fe,ue,a,s,_e,we]),Ce=(0,nt.useMemo)(()=>e.items.map(Ie=>Ql(M7,{...Ie,key:Ie.sys.id,fieldRender:me=>i(gv,{contentfulInputField:me,submitText:a,submitSuccessText:s,initialValue:J?.[me.name]},me.sys.id)})),[J,e.items,s,a]),We=(0,nt.useCallback)(async()=>{if(de.current?.run(),!de.current){let Ie=new Error("Arkose enforcement does not exist");return Re({component:"Form",message:Ie.message,action:"Submit",error:Ie,context:{elementLocation:L}}),Promise.resolve({})}return new Promise((Ie,me)=>{le.current=Ie,re.current=me})},[L]),Pt=(0,nt.useCallback)(async()=>{if(!te.current){let me=new Error("reCaptcha client does not exist");return Re({component:"Form",message:me.message,action:"Submit",error:me,context:{elementLocation:L}}),{}}return{recaptchaToken:await te.current.run(cv),recaptchaAction:cv}},[L]),$e=(0,nt.useCallback)(uk({delay:1e3},(Ie,me,ke,Nt)=>{Nt||(me&&(!G.current&&o&&(ge({eventCategory:"Form",eventAction:"FormInitialInteraction",eventLabel:o.label,context:{elementLocation:L}}),G.current=!0),ge({eventCategory:"FormField",eventAction:"Change",eventLabel:me,context:{elementLocation:L}})),k?.(Ie,me,ke),!(!S||ke)&&(M.current[b.id]=Ie,ci(fv,JSON.stringify({...M.current}))))}),[b.id]),Ro=(0,nt.useMemo)(()=>{let Ie=$();return{...I7(t,Ie),...u,locale:P,country:R}},[t,u,$,P,R]);return x(pe,{children:[i(BS,{onSubmitSuccess:Se,onSubmitFailure:j,submitText:a,submitSuccessText:s,submitTextDataset:z,endpoint:l,formChildrenRenderer:Be,extraParams:Ro,extraParamsAsync:m?U?Pt:We:void 0,onFormBodyChange:$e,renderErrorMessage:I,onInvalidClientSideSubmissionMessage:X,renderErrorDetails:V.isLocal,formRequiredFieldsMessage:W,...A,children:Ce}),p==="Downloadable Resource URL"&&i("a",{"data-testid":"test-anchor-download",ref:Q,href:K,download:!0,className:hee,children:"Hidden trigger anchor"})]})};var vee=E`
  fragment FormRowAll on FormRow {
    ...ContentfulSysId
    rowAsText {
      json
    }
    fieldsCollection(limit: 3) {
      items {
        __typename
        ... on InputField {
          ...ContentfulSysId
          name
          type
          label
          richLabel {
            json
          }
          initialValue
          shouldResetToInitial
          placeholder
          required
          validation
          helpText
          error {
            json
          }
          maxLength
          minValue
          maxValue
        }
        ... on SubmitButton {
          ...ContentfulSysId
          name
        }
        ... on PresetDropdownField {
          ...ContentfulSysId
          name
          label
          preset
          placeholder
          required
          helpText
          error {
            json
          }
        }
        ... on DropdownField {
          ...ContentfulSysId
          name
          label
          placeholder
          required
          helpText
          optionsCollection {
            items {
              ... on DropdownFieldOption {
                ...ContentfulSysId
                key
                value
              }
            }
          }
          initialOption {
            ... on DropdownFieldOption {
              ...ContentfulSysId
              key
              value
            }
          }
          shouldResetToInitial
          error {
            json
          }
        }
        ... on MultiselectDropdownField {
          ...ContentfulSysId
          name
          label
          placeholder
          required
          helpText
          optionsCollection {
            items {
              ... on DropdownFieldOption {
                ...ContentfulSysId
                key
                value
              }
            }
          }
          error {
            json
          }
        }
        ... on RadioSelectField {
          ...ContentfulSysId
          name
          helpText
          label
          required
          error {
            json
          }
          optionsCollection {
            items {
              ... on DropdownFieldOption {
                ...ContentfulSysId
                key
                value
              }
            }
          }
          initialOption {
            ... on DropdownFieldOption {
              ...ContentfulSysId
              key
              value
            }
          }
          shouldResetToInitial
        }
      }
    }
  }
  ${O}
`,Iee=E`
  fragment ExtraParametersFormFeatureAll on ExtraParametersFormFeature {
    ...ContentfulSysId
    utmCampaignFieldName
    utmContentFieldName
    utmMediumFieldName
    utmSourceFieldName
    utmTermFieldName
    urlPathFieldName
  }
  ${O}
`,kee={all:E`
    fragment FormAll on Form {
      ...ContentfulSysId
      endpoint
      redirectUrl
      responseType
      redirectTimeout
      submitText
      submitSuccessText
      analytics {
        ...AnalyticsAll
      }
      persistFieldEdits
      prepopulatePerQueryParams
      # limit raised to 20 for avalon form use case
      rowsCollection(limit: 20) {
        items {
          ...FormRowAll
        }
      }
      # current expected case is a 0-1 features, but this way we can accommodate future cases w/ minimal effort
      additionalFeaturesCollection(limit: 5) {
        items {
          ... on ExtraParametersFormFeature {
            ...ExtraParametersFormFeatureAll
          }
        }
      }
    }
    ${vee}
    ${Iee}
    ${O}
    ${bo.all}
  `},Eg={shallow:E`
    query FormQuery($preview: Boolean!, $locale: String!, $id: String!) {
      form(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query FormQuery($preview: Boolean!, $locale: String!, $id: String!) {
      form(preview: $preview, locale: $locale, id: $id) {
        ...FormAll
      }
    }
    ${kee.all}
  `};var Lc=e=>{let{data:t}=se(Eg.all,{variables:{id:e.sys.id}});return t?.form?i(T7,{...t.form}):null};Lc.displayName="Form";var Ml="select_";var Mee={ByDate:"By Date",Unsorted:"Unsorted"},Rg=Mee.ByDate;var P7=T(Hr());var N7=T(w());var Fg="https://images.ctfassets.net/kp51zybwznx4/120IJvdruE5HeC9XBYjFiU/879b8f63bde0d27c0750ade94c4b1a39/Default_Gallery_Image.png",Bg="Snap Inc.",A7={day:"2-digit",month:"short",year:"numeric",timeZone:"UTC"},_7={day:"2-digit",month:"2-digit",year:"2-digit",timeZone:"UTC"},w7=[360,450],Tee=w7.map(e=>`${e}px`).join(", "),$g=e=>({sizeToUrl:w7.map(t=>({size:`${t}w`,settings:{height:t,quality:e}})),sizes:`(max-width: ${jo}px) ${Tee}`});var Lg=T(w());var Aee="ar-EG-u-nu-latn";function Jn(){let{currentLocale:e}=(0,Lg.useContext)(ee);return{formatDate:(0,Lg.useCallback)((o,n)=>{if(!o)return"";let a=e.startsWith("ar")?Aee:e;return new Intl.DateTimeFormat(a,n).format(new Date(o))},[e])}}var _ee=180,wee=280,D7=c`
  height: ${_ee}px;

  ${H} {
    height: ${wee}px;
  }
`;var Hc=({analytics:e,date:t,label:o,media:n,showDates:a,showDescriptions:s,showMedia:l=!0,slugReference:p,sys:d,title:u,url:y,isHeroTile:m=!1,eyebrowText:g})=>{let{formatDate:f}=Jn(),b=(0,N7.useContext)(be).elementLocation,{getImageSources:S}=ve(),C=y??(p?.slug?`/${p.slug}`:void 0),v=()=>{C&&ge({eventAction:"Click",eventCategory:"Summary Card",eventLabel:e?.label?`${e.label} - ${C}`:C,context:{elementText:u?.json?(0,P7.documentToPlainTextString)(u.json):void 0,targetUrl:C,elementLocation:b}})},{imageSource:k,imageAltText:I}=je(n?.media),{imageSource:A}=je(n?.mobileMedia);k||(k=Fg,I=Bg);let D=Xn[n?.quality??"Standard"],B={size:$g(D)},M=Le({desktop:S(k,B),mobile:S(A,B)}),{contentfulDescriptionDataset:_,titleDataset:P,labelDataset:$,mediaDataset:R,dateDataset:L}=Fe({entryId:d.id,fieldIds:["title","label","date","media","contentfulDescription"]}),G=n?.stickersCollection?.items?.map(Z=>({imgSrcs:S(Z?.asset?.url),position:Z?.position,rotation:Z?.rotation}));return i(Np,{onClick:v,title:Po(u),description:Ri(o),imgSrcs:M,imgAltText:I,link:C,showDate:a,showDescription:s,showMedia:l,date:f(t,A7),dateTime:t?new Date(t):void 0,dataset:_,titleDataset:P,descriptionDataset:$,mediaDataset:R,dateDataset:L,className:h({[D7]:m}),eyebrowText:g,stickers:G},d.id)};Hc.displayName="SummaryCard";var ri={immersiveScrollBlockTile:E`
    fragment ImmersiveScrollBlockTile on Tile {
      ...ContentfulSysId
      title {
        json
      }
      label {
        json
      }
      media {
        __typename
        ... on Video {
          ...VideoAll
        }
        ... on Image {
          ...ImageAll
        }
      }
      slugReference {
        ...ContentfulSysId
        slug
        unlistedCriteria {
          ...CriteriaAll
        }
      }
    }
    ${Oe.all}
    ${gt.all}
    ${Xt}
    ${O}
  `,all:E`
    fragment TileAll on Tile {
      ...ContentfulSysId
      title {
        json
      }
      label {
        json
      }
      media {
        __typename
        ... on Video {
          ...VideoAll
        }
        ... on Image {
          ...ImageAll
        }
      }
      date
      secondaryMedia {
        ...ImageAll
      }
      imageSize
      imageFit
      url
      contentfulMetadata {
        tags {
          id
        }
      }
      analytics {
        ...AnalyticsAll
      }
      slugReference {
        ...ContentfulSysId
        slug
        unlistedCriteria {
          ...CriteriaAll
        }
      }
      brand
    }
    ${bo.all}
    ${Oe.all}
    ${gt.all}
    ${Xt}
    ${O}
  `},E7={shallow:E`
    query TileQuery($preview: Boolean!, $locale: String!, $id: String!) {
      tile(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query TileQuery($preview: Boolean!, $locale: String!, $id: String!) {
      tile(preview: $preview, locale: $locale, id: $id) {
        ...TileAll
      }
    }
    ${ri.all}
  `};var Hg=E`
  fragment TopicAll on Topic {
    ...ContentfulSysId
    topicId
    displayText
    linksTo
  }
  ${O}
`;var Dee=E`
  fragment GalleryDropdownAll on GalleryDropdown {
    ...ContentfulSysId
    title
    matchAllOptionsTitle
    dropdownItemsCollection {
      items {
        ... on Topic {
          ...TopicAll
        }
      }
    }
    queryParamKey
  }
  ${O}
  ${Hg}
`,Pee=E`
  fragment GalleryFragment on Gallery {
    ...ContentfulSysId
    dropdownsCollection(limit: 5) {
      total
      items {
        ... on GalleryDropdown {
          ...GalleryDropdownAll
        }
      }
    }
    sortBy
    showDates
    showMedia
    showDescriptions
    defaultImage {
      ...ImageAll
    }
    emptyPlaceholder
    loadMoreCtaCopy
    mobileFiltersWrapperText
    clearFiltersCtaCopy
    itemsPerPage
    hidePagination
    hideFilters
    galleryType
  }
  ${O}
  ${Dee}
  ${Oe.all}
`,Vg=E`
  query GalleryQuery($preview: Boolean!, $locale: String!, $id: String!) {
    gallery(preview: $preview, locale: $locale, id: $id) {
      ...GalleryFragment
    }
  }
  ${Pee}
`,Tl=E`
  query TileQuery($preview: Boolean!, $locale: String!, $ids: [String]!) {
    tileCollection(preview: $preview, locale: $locale, where: { sys: { id_in: $ids } }) {
      total
      items {
        ...TileAll
      }
    }
  }
  ${ri.all}
`;var R7=c`
  margin-left: auto;
  margin-right: auto;
  margin-top: ${r("--spacing-m")};
  margin-bottom: ${r("--spacing-m")};
  scroll-margin-top: var(${Tt});
  width: 100%;
`,Og=c`
  text-align: center;
  margin-top: ${r("--spacing-xl")};
  margin-bottom: ${r("--spacing-xl")};

  ${Ji}
`,Xet=c`
  padding-top: ${r("--spacing-xl")};
  display: flex;
  justify-content: center;
`,F7=c`
  display: flex;
  flex-direction: column;
`,B7=c`
  padding-block-end: ${r("--spacing-xl")};
  padding-block-start: ${r("--spacing-m")};
  padding-inline: ${r("--spacing-xl")};

  ${H} {
    align-self: flex-end;
    padding-block: unset;
    padding-inline: ${r("--spacing-xxxl")};
  }
`;var bv=({emptyPlaceholder:e,tiles:t,emptyPlaceholderDataset:o,showDates:n,showDescriptions:a,showMedia:s,isGalleryLoading:l,defaultTileImage:p,numberOfTiles:d})=>{let u=t?.map(f=>f.tileSysId)??[],{data:y,loading:m}=se(Tl,{variables:{ids:u}}),g=y?.tileCollection?.items.slice().sort((f,b)=>u.indexOf(f.sys.id)-u.indexOf(b.sys.id));return l||m?i(Ha,{children:Array.from({length:d??12}).map((f,b)=>i(vi,{},`skeleton-summary-card-${b}`))}):i(pe,{children:g?.length?i(Ha,{children:g.map(f=>i(Hc,{showDates:n,showDescriptions:a,showMedia:s,...f,media:f.media??p},f.sys.id))}):i("div",{"data-testid":"mwp-gallery-placeholder",className:Og,children:i("p",{...ne(o),children:e})})})};bv.displayName="LazyTiles";var Gg=(e,t=!1)=>{if(e)return e.map(({matchAllOptionsTitle:o,dropdownItemsCollection:n,queryParamKey:a,title:s,sys:l})=>{let{contentfulDescriptionDataset:p}=Fe({entryId:l.id,fieldIds:["contentfulDescription"]});return{title:s,id:t?`${Ml}${er(a)}`:`${er(a)}`,allItemTitle:o,items:n.items.map(({displayText:d,topicId:u})=>({title:d,id:u})).sort((d,u)=>d.title.localeCompare(u.title)),dataset:p}})};var Al={all:E`
    fragment BlockHeroAll on BlockHero {
      ...ContentfulSysId
      header {
        json
      }
      eyebrow
      title {
        json
        links {
          entries {
            inline {
              ...ContentfulSysId
              ... on EmphasizedText {
                ...EmphasizedTextAll
              }
            }
          }
        }
      }
      subTitle {
        json
      }
      body {
        json
      }
      callsToActionCollection(limit: 3) {
        items {
          ... on CallToAction {
            ...CallToActionAll
          }
        }
      }
      foreground {
        __typename
        ... on Image {
          ...ImageAll
        }
        ... on Video {
          ...VideoAll
        }
        ... on CarouselV3 {
          ...ContentfulSysId
        }
        ... on SnapchatEmbed {
          ...SnapchatEmbedAll
        }
      }
      backgroundMediaLayout
      backgroundMediaV2 {
        __typename
        ... on Video {
          ...VideoAll
        }
        ... on Image {
          ...ImageAll
        }
      }
      headerMediaV2 {
        __typename
        ... on Image {
          ...ImageAll
        }
      }
      mediaWrap
      isHeaderDate
      theme
      brandBackgroundColor
      backgroundColor
      textAlign
      textAlignMobile
      verticalTextAlign
      fitWindow
      curtainOpacityPercentage
      useLatestPost
      showMediaMobile
      anchorId
      size
      showScrollButton
      displayTopics
      increaseTitleFontSize
    }
    ${bt}
    ${gt.all}
    ${Oe.all}
    ${$t.all}
    ${vc}
    ${ei}
  `},$7=E`
  query BlockHeroQuery($preview: Boolean!, $locale: String!, $id: String!) {
    blockHero(preview: $preview, locale: $locale, id: $id) {
      ...BlockHeroAll
    }
  }
  ${Al.all}
`;var _l=E`
  fragment PageAssetAll on PageAsset {
    ...ContentfulSysId
    media {
      ...AssetAll
    }
  }
  ${Pn}
  ${O}
`;var Nee=E`
  fragment PageCategoryTitle on Page {
    ...ContentfulSysId
    title
    category {
      ...ContentfulSysId
      title
    }
  }
  ${O}
`,zg=E`
  query LatestPostBlockQuery($preview: Boolean!, $locale: String!, $id: String!) {
    latestPosts(preview: $preview, locale: $locale, id: $id) {
      ...ContentfulSysId
      title
      maxPosts
      brandBackgroundColor
      backgroundColor
      cta {
        ...ContentfulSysId
      }
      anchorId
    }
    slugCollection(
      preview: $preview
      locale: $locale
      limit: 4
      order: postedDate_DESC
      where: { AND: [{ slugType_contains: "Blog" }, { slug_not: "home" }] }
    ) {
      items {
        sys {
          id
          firstPublishedAt
        }
        __typename
        slug
        postedDate
        author {
          ...ContentfulSysId
          name
          position
          slug
        }
        page {
          ...PageAssetAll
          ...ExperimentOnPageLoadingPageCategoryTitle
        }
      }
    }
  }
  ${O}
  ${ti("Page","PageCategoryTitle",Nee)}
  ${_l}
`;var Sv=e=>{let{formatDate:t}=Jn(),{decideExperiment:o}=nn(),{data:n}=se(zg,{variables:{id:e.sys.id}}),a=it(n?.latestPosts?.brandBackgroundColor);if(!n)return null;let{latestPosts:{title:s,maxPosts:l,backgroundColor:p,cta:d,anchorId:u},slugCollection:y}=n,m=Math.min(l,y.items.length),g=Array(m).fill(0).map((b,S)=>{let C=y.items[S],v=t(C.postedDate?C.postedDate:C.sys.firstPublishedAt,{month:"long",day:"2-digit",year:"numeric",weekday:"long"}),k=C.author&&i(Ln,{id:"authorByline",values:{author:C.author.name},defaultMessage:"By <b>{author}</b>"}),I=v&&i(Ln,{id:"postedOn",values:{date:v},defaultMessage:"on {date}"});if(C.page.__typename==="PageAsset")return{title:i(yn,{href:C.slug,children:C.page?.media?.title},C.slug),author:k,date:I};if(C.page.__typename==="Page"||C.page.__typename==="Experiment"){let{decision:A}=o(C.page,{logImpression:!1});return{title:i(cc,{to:C.slug,children:A.title},C.slug),author:k,date:I,category:A.category?.title}}throw new Error("Unknown page type.")}),f=d&&i(St,{...d},d.sys.id);return i(vR,{anchorId:u,title:s,items:g,cta:f,motifScheme:a,backgroundColor:p,preChildren:e.preChildren,postChildren:e.postChildren})};Sv.displayName="LatestPostBlock";var L7=T(w());var hv=e=>{let t=(0,L7.useContext)(be).elementLocation,{getBestBgImgSrc:o,getImageSources:n}=ve(),{tilesCollection:a,columns:s,mobileColumns:l,filtersCollection:p}=e,d=a.items.map(({video:y,preview:m,thumbnail:g,filtersCollection:f,analytics:b,...S})=>{let C=n(g.url,{image:{width:768}}),v=b?.label??S.sys.id,k="MosaicTile";return{...S,onClose:()=>ge({eventAction:"Close",eventCategory:k,eventLabel:v,context:{elementText:v,elementLocation:t}}),onOpen:()=>ge({eventAction:"Open",eventCategory:k,eventLabel:v,context:{elementText:v,elementLocation:t}}),onEnter:()=>ge({eventAction:"Enter",eventCategory:k,eventLabel:v,context:{elementText:v,elementLocation:t}}),onLeave:()=>ge({eventAction:"Leave",eventCategory:k,eventLabel:v,context:{elementText:v,elementLocation:t}}),filters:f?.items?.map(I=>I.sys.id),poster:{src:C?.default,srcSet:C?.defaultSrcSet},video:y?Zm(y,o):void 0,preview:m?Zm(m,o):void 0}}),u=p.items?.map(({sys:y,isAll:m,...g})=>({id:m?"":y.id,...g}));return i(vh,{tiles:d,columns:s,mobileColumns:l,filters:u})};hv.displayName="Mosaic";var Eee={all:E`
    fragment MosaicAll on Mosaic {
      ...ContentfulSysId
      columns
      mobileColumns
      filtersCollection(limit: 20) {
        items {
          ...ContentfulSysId
          ... on MosaicFilters {
            ...ContentfulSysId
            text
            icon
            isAll
          }
        }
      }
      tilesCollection(limit: 100) {
        items {
          ...ContentfulSysId
          ... on MosaicTile {
            ...ContentfulSysId
            analytics {
              ...AnalyticsAll
            }
            title
            highlight
            showOverlay
            duration
            columns
            mobileColumns
            rows
            mobileRows
            preview {
              ...VideoAll
            }
            video {
              ...VideoAll
            }
            thumbnail {
              url
              contentType
            }
            filtersCollection(limit: 50) {
              items {
                ...ContentfulSysId
              }
            }
          }
        }
      }
    }
    ${bo.all}
    ${gt.all}
    ${O}
  `},Ug={shallow:E`
    query MosaicQuery($preview: Boolean!, $locale: String!, $id: String!) {
      mosaic(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query MosaicQuery($preview: Boolean!, $locale: String!, $id: String!) {
      mosaic(preview: $preview, locale: $locale, id: $id) {
        ...MosaicAll
      }
    }
    ${Eee.all}
  `};var Ree={all:E`
    fragment MultiVideoBlockAll on MultiVideoBlock {
      ...ContentfulSysId
      anchorId
      panelPosition
      primaryVideosCollection(limit: 10) {
        items {
          ... on Video {
            ...VideoAll
          }
        }
      }
      secondaryVideosCollection(limit: 10) {
        items {
          ... on Video {
            ...VideoAll
          }
        }
      }
      mobilePrimaryVideosCollection(limit: 10) {
        items {
          ... on Video {
            ...VideoAll
          }
        }
      }
      mobileSecondaryVideosCollection(limit: 10) {
        items {
          ... on Video {
            ...VideoAll
          }
        }
      }
    }
    ${gt.all}
    ${O}
  `},Wg=E`
  query MultiVideoBlockQuery($preview: Boolean!, $locale: String!, $id: String!) {
    multiVideoBlock(preview: $preview, locale: $locale, id: $id) {
      ...MultiVideoBlockAll
    }
  }
  ${Ree.all}
`;var Cv=E`
  fragment SplitBlockAll on SplitBlock {
    ...ContentfulSysId
    callsToActionCollection(limit: 2) {
      items {
        ... on CallToAction {
          ...CallToActionAll
        }
      }
    }
    splitBlockTitle: title
    splitBlockSubtitle: subtitle
    splitBlockBody: body {
      json
    }
    textAlignment
    textAlignmentMobile
    verticalTextAlignment
    media {
      __typename
      ... on Video {
        ...VideoAll
      }
      ... on Image {
        ...ImageAll
      }
    }
    mediaCaption
    mediaDirection
    brandBackgroundColor
    backgroundColor
    fitWindow
    anchorId
  }
  ${O}
  ${bt}
  ${Oe.all}
  ${gt.all}
`,H7=E`
  query SplitBlockQuery($preview: Boolean!, $locale: String!, $id: String!) {
    splitBlock(preview: $preview, locale: $locale, id: $id) {
      ...SplitBlockAll
    }
  }
  ${Cv}
`;var xv=E`
  fragment SubNavigationAll on SubNavigation {
    ...ContentfulSysId
    brandBackgroundColor
    backgroundColor
    subNavigationItemsCollection {
      items {
        ...ContentfulSysId
        text
        anchorId
      }
    }
  }
  ${O}
`,V7=E`
  query SubNavigationQuery($preview: Boolean!, $locale: String!, $id: String!) {
    subNavigation(preview: $preview, locale: $locale, id: $id) {
      ...SubNavigationAll
    }
  }
  ${xv}
`;var Fee={all:E`
    fragment TabsAll on Tabs {
      ...ContentfulSysId
      itemsCollection(limit: 10) {
        items {
          ...ContentfulSysId
          title
          contentsCollection(limit: 10) {
            items {
              ...ContentfulSysId
            }
          }
          maxColumns
        }
      }
    }
    ${O}
  `},Qg={shallow:E`
    query TabsShallowQuery($preview: Boolean!, $locale: String!, $id: String!) {
      tabs(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query TabsQuery($preview: Boolean!, $locale: String!, $id: String!) {
      tabs(preview: $preview, locale: $locale, id: $id) {
        ...TabsAll
      }
    }
    ${Fee.all}
  `};var O7=T(w());var Vc=e=>{let{data:t}=se(rg.all,{variables:{id:e.sys.id}});return t?.content?i(Mc,{...t.content}):null};Vc.displayName="ContentShallow";var vv=e=>{let{data:t}=se(Qg.all,{variables:{id:e.sys.id}}),o=(0,O7.useContext)(be).elementLocation;if(!t||!t.tabs)return null;let{itemsCollection:n}=t.tabs,a=l=>{ge({eventAction:"Click",eventCategory:"Tab",eventLabel:`tab:${l}`,context:{elementLocation:o,elementText:n?.items[l]?.title}})},s=n.items.map(l=>{let p=l.contentsCollection?l.contentsCollection.items.map(u=>{let y=u.sys.id;return u.__typename==="Form"?i(Lc,{...u},y):i(Vc,{...u},y)}):[];return{text:l.title,content:p,maxColumns:l.maxColumns}});return i(a4,{items:s,onSelectTab:a})};vv.displayName="Tabs";var G7=T(w());var Bee=Ko(()=>import("./chunks/LazyBarChart-V2PYHWK6.mjs").then(e=>({default:e.BarChart}))),z7=e=>{let{chartData:t,yAxis:o,xAxes:n,stackKey:a,filters:s,width:l,height:p,hideXAxisLabels:d,hideYAxisLabels:u,hideXPercentLabels:y,hideLegend:m,chartTitle:g,dataColors:f,showAsPercent:b,numberOfDecimalPlaces:S}=e,{isRTL:C}=(0,G7.useContext)(ee);if(!t)return null;let v=Ia(t);return i(Do,{fallbackElement:i(_o,{}),children:i(Bee,{chartTitle:g,width:l,height:p??0,yAxis:o,xAxes:n,stackKey:a,filters:s,hideXAxisLabels:d,hideYAxisLabels:u,hideXPercentLabels:y,showAsPercent:b??!0,numberOfDecimalPlaces:S??1,hideLegend:m??!0,data:v,dataColors:f||["#A05CCC","#FEFC01","#3EDB9A","#3BB2F7"],isRTL:C})})};var Iv=E`
  fragment SeriesAll on Series {
    ...ContentfulSysId
    schema
    headerNames
    localizableProperties
  }
`,Dr=E`
  fragment ChartDataAll on ChartData {
    ...ContentfulSysId
    seriesName {
      ...SeriesAll
    }
    label
    data
    localizedData
  }
  ${O}
  ${Iv}
`;var kv={all:E`
    fragment BarChartAll on BarChart {
      ...ContentfulSysId
      chartTitle
      chartData {
        ...ChartDataAll
      }
      yAxis
      xAxes
      stackKey
      filters
      width
      height
      hideXAxisLabels
      hideYAxisLabels
      hideXPercentLabels
      showAsPercent
      numberOfDecimalPlaces
      hideLegend
      dataColors
    }
    ${O}
    ${Dr}
  `,withTitle:E`
    fragment BarChartWithTitle on BarChart {
      ...ContentfulSysId
      chartTitle
    }
    ${O}
  `},qg={shallow:E`
    query barChartEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      barChart(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query barChartEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      barChart(preview: $preview, locale: $locale, id: $id) {
        ...BarChartAll
      }
    }
    ${kv.all}
  `};var wl=e=>{let t=lo(e)?e.sys.id:void 0,{data:o,loading:n}=se(qg.all,{skip:!t,variables:{id:t}});if(n)return i(_o,{});if(!o)return null;let a=e.chartDataOverride??o.barChart.chartData,s=e.xAxesOverride??o.barChart.xAxes;return i(z7,{...o.barChart,chartData:a,xAxes:s})};var q7=T(w());var Dl=T(w());var $ee=Ko(async()=>import("./chunks/LazyGeoMap-V65C4HOY.mjs").then(e=>({default:e.GeoMap}))),Lee="https://storage.googleapis.com/snap-design-system-marketing/world-topo.json",U7=e=>{let{chartTitle:t,chartData:o,width:n,countryCodeKey:a,valueKey:s,dataScalingMethod:l}=e,[p,d]=(0,Dl.useState)(),{currentLocale:u}=(0,Dl.useContext)(ee);if((0,Dl.useEffect)(()=>{async function m(){let f=await(await En(Lee)).json();d(f)}m().catch(g=>Re({component:"GeoVisualization",error:g}))},[]),!p||!o||!s)return null;let y=Ia(o);return i(Do,{fallbackElement:i(_o,{}),children:i($ee,{width:n,data:y,fieldMetadata:{key:s,title:o.seriesName.headerNames?.[s]??s},countryFieldKey:a,chartTitle:t,topoData:p,locale:u,scaleMode:l})})};var Kg={all:E`
    fragment GeoMapAll on GeoVisualization {
      ...ContentfulSysId
      chartTitle
      chartData {
        ...ChartDataAll
      }
      dataScalingMethod
      countryCodeKey
      valueKey
    }
    ${O}
    ${Dr}
  `,subset:E`
    fragment GeoMapSubset on GeoVisualization {
      ...ContentfulSysId
      countrySelectorFields
    }
    ${O}
  `,withTitle:E`
    fragment GeoMapWithTitle on GeoVisualization {
      ...ContentfulSysId
      chartTitle
    }
    ${O}
  `},jg={shallow:E`
    query geoMapEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      geoVisualization(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query geoMapEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      geoVisualization(preview: $preview, locale: $locale, id: $id) {
        ...GeoMapAll
      }
    }
    ${Kg.all}
  `,subset:E`
    query geoMapEntryQuery($preview: Boolean!, $id: String!) {
      geoVisualization(preview: $preview, id: $id) {
        ...GeoMapSubset
      }
    }
    ${Kg.subset}
  `};var Pl=e=>{let t=lo(e)?e.sys.id:void 0,{data:o,loading:n}=se(jg.all,{skip:!t,variables:{id:t}});if(n)return i(_o,{});if(!o)return null;let a=e.chartDataOverride??o.geoVisualization.chartData,s=e.valueKeyOverride??o.geoVisualization.valueKey;return i(U7,{...o.geoVisualization,width:e.width,chartTitle:e.chartTitle,chartData:a,valueKey:s})};var Hee=Ko(()=>import("./chunks/LazyLineChart-JX263KCR.mjs").then(e=>({default:e.LineChart}))),Vee=(e,t)=>{let o={x:{},y:{}};for(let n of e)o.x[n]=a=>a[t],o.y[n]=a=>a[n];return o},W7=e=>{let{chartData:t,curve:o,xKey:n,yKeys:a,chartTitle:s}=e;if(!t)return null;let l=Ia(t);return i(Do,{fallbackElement:i(_o,{}),children:i(Hee,{data:l,accessors:Vee(a,n),chartTitle:s,curve:o,yKeys:a})})};var Mv={all:E`
    fragment LineChartAll on LineChart {
      ...ContentfulSysId
      chartTitle
      chartData {
        ...ChartDataAll
      }
      xKey
      yKeys
      curve
    }
    ${O}
    ${Dr}
  `,withTitle:E`
    fragment LineChartWithTitle on LineChart {
      ...ContentfulSysId
      chartTitle
    }
    ${O}
  `},Yg={shallow:E`
    query lineChartEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      lineChart(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query lineChartEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      lineChart(preview: $preview, locale: $locale, id: $id) {
        ...LineChartAll
      }
    }
    ${Mv.all}
  `};var Nl=e=>{let t=lo(e)?e.sys.id:void 0,{data:o,loading:n}=se(Yg.all,{skip:!t,variables:{id:t}});if(n)return i(_o,{});if(!o)return null;let a=e.chartDataOverride??o.lineChart.chartData,s=e.yKeysOverride??o.lineChart.yKeys;return i(W7,{...o.lineChart,chartData:a,yKeys:s})};var Tv={all:E`
    fragment TableVisualizationAll on TableVisualization {
      ...ContentfulSysId
      chartTitle
      chartData {
        ...ChartDataAll
      }
      tableColumns
      enableSearch
      initialRowCount
    }
    ${O}
    ${Dr}
  `,withTitle:E`
    fragment TableVisualizationWithTitle on TableVisualization {
      ...ContentfulSysId
      chartTitle
    }
    ${O}
  `},Xg={shallow:E`
    query tableVisualizationEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      tableVisualization(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query tableVisualizationEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      tableVisualization(preview: $preview, locale: $locale, id: $id) {
        ...TableVisualizationAll
      }
    }
    ${Tv.all}
  `};var Jg=T(w());var Oee="date",Gee=Ko(()=>import("./chunks/LazyTable-WACGWLU4.mjs").then(e=>({default:e.Table}))),zee=(e,t,o,n)=>{let a=e.schema.items.properties;if(!a)throw new Error("Series schema is malformed!");let s=t[o],l=a[o].type,p=a[o].format;return l==="integer"||l==="number"?s.toLocaleString(n):p===Oee?s.toLocaleDateString(n):s},Uee=(e,t,o)=>{let n=t.schema.items.properties,a=Object.keys(n);if(a.length!==e?.length)throw new Error("The number of table columns must equal the number of properties on the schema!");if(!a.every(l=>e.includes(l)))throw new Error("Table columns and schema properties do not match!");return e.map(l=>{let p=l;return t.headerNames?.[l]&&(p=t.headerNames[l]),{Header:p,accessor:d=>zee(t,d,l,o)}})},Q7=e=>{let{chartData:t,tableColumns:o,enableSearch:n,initialRowCount:a}=e,{currentLocale:s}=(0,Jg.useContext)(ee),[l,p]=(0,Jg.useState)();if(!t)return null;let d,u;try{d=Ia(t),u=Uee(o,t.seriesName,s)}catch(y){l||(p(y),Me.logError({component:"Table",error:y}))}return l&&V.deploymentType!=="production"?x("section",{children:[i("h5",{children:"Table Visualization Error"}),i("p",{children:`Error: ${l.message}`}),i("p",{children:`Entry id: ${e.id}`})]}):i(Do,{fallbackElement:i(_o,{}),children:i(Gee,{data:d,columns:u,searchable:n,initialRowCount:a})})};var El=e=>{let t=lo(e)?e.sys.id:void 0,{data:o,loading:n}=se(Xg.all,{skip:!t,variables:{id:t}});if(n)return i(_o,{});if(!o)return null;let a=e.chartDataOverride??o.tableVisualization.chartData;return i(Q7,{...o.tableVisualization,chartData:a,id:t})};var Zg=E`
  query ChartToggleQuery($preview: Boolean!, $locale: String!, $id: String!) {
    chartToggle(preview: $preview, locale: $locale, id: $id) {
      ...ContentfulSysId
      label
      itemsCollection(limit: 10) {
        items {
          ...ContentfulSysId
          analytics {
            ...AnalyticsAll
          }
          title
          contentsCollection(limit: 10) {
            items {
              ... on Entry {
                ...ContentfulSysId
              }
            }
            total
          }
        }
      }
    }
  }
  ${O}
  ${bo.all}
`;var K7=e=>{switch(e.__typename){case"ChartToggle":return i(Oc,{...e});case"BarChart":return i(wl,{...e});case"LineChart":return i(Nl,{...e});case"GeoVisualization":return i(Pl,{...e});case"TableVisualization":return i(El,{...e});default:return console.error(`\u{1F4D9} Unknown chart type: ${e.__typename} with id: ${e.sys.id}`),i(pe,{children:"\u{1F4D9}"})}};K7.displayName="Chart";var Oc=e=>{let o=vt().useChartDropdownToggle==="true",{data:n,loading:a}=se(Zg,{variables:{id:e.sys.id}}),s=(0,q7.useContext)(be).elementLocation;if(!n&&!o)return null;let l=n?.chartToggle.itemsCollection.items.map(({analytics:p,title:d,contentsCollection:u,sys:{id:y}})=>{let m=p?.label??y;return{onToggle:()=>ge({eventAction:"Open",eventCategory:"ChartToggle",eventLabel:m,context:{elementLocation:s}}),title:d,content:u.items.map(f=>i(K7,{...f},f.sys.id))}});return o?i($4,{items:l??[],label:n?.chartToggle.label??"",isLoading:a}):i(R4,{items:l??[]})};Oc.displayName="ChartToggle";var Av=e=>vt().useChartDropdownToggle==="true"?i(L4,{children:i(Oc,{...e})}):i(Oc,{...e});Av.displayName="ChartToggleWrapper";var Rl=T(w());var Wee={all:E`
    fragment VisualizationSelectorAll on VisualizationSelector {
      ...ContentfulSysId
      chartTitle
      visualizationsCollection {
        items {
          ... on BarChart {
            ...BarChartWithTitle
          }
          ... on LineChart {
            ...LineChartWithTitle
          }
          ... on GeoVisualization {
            ...GeoMapWithTitle
          }
          ... on TableVisualization {
            ...TableVisualizationWithTitle
          }
        }
      }
      seriesName {
        ...SeriesAll
      }
      chartDataCollection {
        items {
          ...ChartDataAll
        }
      }
      selectableFields
    }
    ${kv.withTitle}
    ${Mv.withTitle}
    ${Kg.withTitle}
    ${Tv.withTitle}
    ${Iv}
    ${Dr}
    ${O}
  `},ef={shallow:E`
    query visualizationSelectorEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      visualizationSelector(preview: $preview, locale: $locale, id: $id) {
        ...ContentfulSysId
      }
    }
    ${O}
  `,all:E`
    query visualizationSelectorEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
      visualizationSelector(preview: $preview, locale: $locale, id: $id) {
        ...VisualizationSelectorAll
      }
    }
    ${Wee.all}
  `};var Qee=Ko(()=>import("./chunks/LazyMultiviz-OMF6GR7O.mjs").then(e=>({default:e.MultiVisualization}))),j7=e=>({id:e.sys.id,label:e.label??""}),Y7=e=>({id:e.sys.id,title:e.chartTitle,key:e.__typename}),qee=(e,t)=>{let o=e.filter(a=>a.seriesName.sys.id===t.sys.id),n=0;return o.map(a=>a.label?{...a,label:a.label}:(n++,{...a,label:`Unnamed Data ${n}`}))},Kee=({chartTitle:e,seriesName:t,chartDataCollection:o,visualizationsCollection:n,selectableFields:a})=>{let{locale:s}=(0,Rl.useContext)(Pi),l=qee(o.items,t),p=n.items.map(Y7),d=l.map(j7),u=a?.map(I=>({key:I,title:t?.headerNames?.[I]??I})),[y,m]=(0,Rl.useState)(l[0]),[g,f]=(0,Rl.useState)(n.items[0]),[b,S]=(0,Rl.useState)(a?.[0]??void 0),C=I=>m(l.find(A=>A.sys.id===I.id)),v=I=>f(n.items.find(A=>A.sys.id===I.id)),k=I=>{if(!g||!y)return null;switch(I.key){case"TableVisualization":return i(El,{...g,chartDataOverride:y});case"BarChart":return i(wl,{...g,chartDataOverride:y,xAxesOverride:b?[b]:void 0});case"LineChart":return i(Nl,{...g,chartDataOverride:y,yKeysOverride:b?[b]:void 0});case"GeoVisualization":return i(Pl,{...g,chartDataOverride:y,valueKeyOverride:b});default:return null}};return!y||!g?null:i(Do,{children:i(Qee,{chartMetadataItems:d,selectedChartMetadata:j7(y),visualizationMetadataItems:p,selectedVisualizationMetadata:Y7(g),visualizationTitle:e,fieldMetadataItems:u,locale:s,onDataSelected:C,onVisualizationSelected:v,onFieldSelected:I=>S(I.key),renderVisualization:k})})},X7=e=>{let t=lo(e)?e.sys.id:void 0,{data:o}=se(ef.all,{skip:!t,variables:{id:t}});return o?i(Kee,{...o.visualizationSelector}):null};var jee={all:E`
    fragment NewsBlockAll on NewsBlock {
      ...ContentfulSysId
      eyebrow
      textAlignment
      textAlignmentMobile
      numberOfNewsItems
      defaultImage {
        ...ImageAll
      }
      callsToActionCollection(limit: 2) {
        items {
          ... on CallToAction {
            ...CallToActionAll
          }
        }
      }
      newsReference {
        sys {
          urn
        }
      }
    }
    ${O}
    ${bt}
    ${Oe.all}
  `},tf=E`
  query NewsBlockQuery($preview: Boolean!, $locale: String!, $id: String!) {
    newsBlock(preview: $preview, locale: $locale, id: $id) {
      ...NewsBlockAll
    }
  }
  ${jee.all}
`;var of=E`
  query SnapHomePageQuery($id: String!, $preview: Boolean!, $locale: String!) {
    snapHomePage(id: $id, preview: $preview, locale: $locale) {
      ...ContentfulSysId
      navigationItemsCollection(limit: 20) {
        items {
          ...ContentfulSysId
          title {
            json
          }
          url
        }
      }
      blocksCollection {
        items {
          ...ContentfulSysId
        }
      }
    }
  }
  ${O}
`;var nf=E`
  query SnapHomePageV2Query($id: String!, $preview: Boolean!, $locale: String!) {
    snapHomePageV2(id: $id, preview: $preview, locale: $locale) {
      ...ContentfulSysId
      title
      carouselTitle
      carouselCardsCollection {
        items {
          ...ContentfulSysId
          body
          media {
            __typename
            ... on Video {
              ...VideoAll
            }
            ... on Image {
              ...ImageAll
            }
          }
          url
          logo {
            __typename
            ... on Image {
              ...ImageAll
            }
          }
        }
      }
    }
  }
  ${O}
  ${Oe.all}
  ${gt.all}
`;var SH={AiAgent:void 0,LatestPosts:zg,MultiVideoBlock:Wg,Content:rg.all,CarouselV3:_g,Gallery:Vg,Tabs:Qg.all,Mosaic:Ug.all,Form:Eg.all,ChartToggle:Zg,BarChart:qg.all,LineChart:Yg.all,GeoVisualization:jg.all,VisualizationSelector:ef.all,TableVisualization:Xg.all,Accordion:vg.all,BlockHero:$7,Break:q9,SubNavigation:V7,LatestGalleryCardHero:void 0,AnimatedAccordion:Ig,AvalonProductHero:void 0,AvalonFormBlock:void 0,MosaicGridBlock:void 0,AvalonScrollSection:void 0,FixedPositionBlock:void 0,ValuePropsBlock:void 0,ArArkoseProtectedFormBlock:void 0,ArDownloadFormBlock:void 0,ArDownloadLinkCard:void 0,ArLinkOutsBlock:void 0,LiveEvent:void 0,MultiValuePropBlock:W9,NewsBlock:tf,SnapHomePage:of,SnapHomePageV2:nf,BlockTabs:Q9,SplitBlock:H7,StinsonBreadcrumbsBlock:void 0,StinsonMediaFeatureBlock:void 0,StinsonMultiVideoBlock:void 0,...void 0,StinsonRevealHome:void 0,StinsonUseCasesBlock:void 0,StinsonVideoBlock:void 0};function pa(e){let t=e.loc?.source.name;return e.definitions.filter(n=>n.kind==="OperationDefinition").map(n=>n).find(n=>n.operation==="query")?.name?.value??t??"Anonymous"}var hH=T(w()),Eo=(0,hH.createContext)({isShareable:!1});var Zt=T(w());var Yee="\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC",Xee=new RegExp(`[${Yee}]`,"g"),CH=e=>e&&Xee.test(e)?"rtl":"ltr";var rf=e=>{let t=e.substring(1);return t===""?"home":rp(t)};var xH=T(w());var Jee=["lang"],Zee=(e=V.metadataQueryParamsAllowlist??[])=>new Set([...Jee,...e]),af=(e,t=Zee())=>{let o=new URL(e),n=new URL(o.href);n.hash="",n.search="";for(let[a,s]of o.searchParams.entries())t.has(a)&&n.searchParams.append(a,s);return n},sf=(e,t)=>{let o=new URL(e),n=new URL(o.href);n.hash="",n.search="";for(let[a,s]of o.searchParams.entries())t[a]?.includes(s)&&n.searchParams.append(a,s);return n};var IH=({localizedIn:e=[so]})=>{let{getCurrentUrl:t}=(0,xH.useContext)(ee),o=V.site==="stinson"?sf(t(),void 0):af(t());o.searchParams.delete("lang");let n=e.filter(a=>a!==so);return x(Mt,{children:[i("link",{rel:"alternate",hrefLang:"x-default",href:o.href}),i("link",{rel:"alternate",hrefLang:so,href:o.href},so),n?.map(a=>{let s=new URL(o.href);return s.searchParams.set("lang",a),i("link",{rel:"alternate",hrefLang:a,href:s.href},a)})]})};var wH=T(w());var kH=T(w());var pst=c`
  ${H} {
    padding-top: ${32}px;
  }
`,MH=e=>{let t=(0,kH.useContext)(be).elementLocation,{data:o}=se(Ig,{variables:{id:e.sys.id}}),{accordionContentsCollection:n,mediaDirection:a="End",autoPlaySpeed:s=10,textAlignmentMobile:l=ie.Start}=o?.animatedAccordion??{},{getImageSources:p}=ve(),d=(n?.items??[]).map(u=>{let{imageSource:y,imageAltText:m}=je(u.image?.media),{imageSource:g}=je(u.image?.mobileMedia),{desktopSettings:f,mobileSettings:b}=Dt({desktopHeight:u.image?.media?.height??0,mobileHeight:u.image?.mobileMedia?.height,enableHighDpi:u.image?.enableHighDpi,quality:u.image?.quality}),S=Le({desktop:p(y,f),mobile:p(g,b)});return{title:Po(u.title),body:fo(u.body),imgSrcs:S,imageAltText:m}});return i(iA,{items:d,mediaDirection:a,autoPlaySpeed:s,textAlignmentMobile:l,onItemSelect:u=>{ge({eventCategory:"AnimatedAccordion",eventAction:"Click",eventLabel:`section: ${u}`,context:{elementLocation:t}})}})};var ho=T(w());var lf=T(w());var _v=({analytics:e,date:t,label:o,media:n,slugReference:a,sys:s,title:l,url:p,brand:d})=>{let{formatDate:u}=Jn(),{logEvent:y}=(0,lf.useContext)(en),{getImageSources:m}=ve(),{isRTL:g}=(0,lf.useContext)(ee),{formatMessage:f}=(0,lf.useContext)(qe),b=p??(a?.slug?`/${a.slug}`:void 0),S=()=>{b&&y?.({component:"Editorial Gallery Card",type:"Click",label:e?.label?`${e.label} - ${b}`:b,url:b})},{imageSource:C,imageAltText:v}=je(n?.media),{imageSource:k}=je(n?.mobileMedia);C||(C=Fg,v=Bg);let I=Xn[n?.quality??"Standard"],A={size:$g(I)},D=Le({desktop:m(C,A),mobile:m(k,A)}),{contentfulDescriptionDataset:B,brandDataset:M,titleDataset:_,labelDataset:P,mediaDataset:$,dateDataset:R}=Fe({entryId:s.id,fieldIds:["title","brand","label","date","media","contentfulDescription"]});return i(eS,{brand:d,title:Po(l),description:Po(o),dateTime:t?new Date(t):void 0,date:u(t,_7).replaceAll("/","."),onClick:S,imgSrcs:D,imgAltText:v,link:b,ctaLabel:f({id:"editorial-gallery-cta-label",defaultMessage:"Read More"}),isRtl:g,dataset:B,brandDataset:M,titleDataset:_,descriptionDataset:P,mediaDataset:$,dateDataset:R},s.id)};_v.displayName="EditorialGalleryCard";var wv=({emptyPlaceholder:e,tiles:t,emptyPlaceholderDataset:o,isGalleryLoading:n,defaultTileImage:a,numberOfTiles:s})=>{let l=t?.map(y=>y.tileSysId)??[],{data:p,loading:d}=se(Tl,{variables:{ids:l},skip:l.length===0||n}),u=p?.tileCollection?.items.slice().sort((y,m)=>l.indexOf(y.sys.id)-l.indexOf(m.sys.id));return n||d?i(pe,{children:Array.from({length:s??6}).map((y,m)=>i(tS,{},`skeleton-editorial-gallery-card-${m}`))}):i(pe,{children:u?.length?u.map(y=>i(_v,{...y,media:y.media??a},y.sys.id)):i("div",{"data-testid":"mwp-editorial-gallery-placeholder",className:Og,children:i("p",{...ne(o),children:e})})})};wv.displayName="EditorialGalleryLazyTiles";var So=T(w());var Hi=T(w());function pf({galleryId:e,page:t,tags:o,pageSize:n=12,sortBy:a=Rg}){let s=(0,Hi.useContext)(ee),l=(0,Hi.useContext)(Ze),p=(0,Hi.useRef)(0),d=(0,Hi.useMemo)(()=>{let f=new URLSearchParams;f.append("galleryId",e),f.append("pageSize",`${n}`),f.append("sortBy",a),o.length&&f.append("tags",o.join(",")),f.append("page",`${t-1}`),s.currentLocale&&f.append("locale",s.currentLocale),s.userLocation.country&&f.append("country",s.userLocation.country);let b=l.getLowEntropyHints().platform;b&&f.append("platform",b);let S=l.getLowEntropyHints().isMobile?"Mobile":"Non-Mobile";return S&&f.append("device",S),f},[e,o,t,n,s.currentLocale,s.userLocation.country,l,a]),y=`${V.isClient?"":`http://localhost:${process.env.PORT??3e3}`}/api/gallery?${d}`,{data:m,isLoading:g}=an({dataId:`/api/gallery?${d}`,dataAsync:async()=>{try{return await(await fetch(y)).json()}catch(f){Me.logError({component:"UseGalleryTiles",message:"Error loading gallery tiles",error:f})}}});return m?.total&&(p.current=m?.total),{paginationData:g?{tiles:[],total:p.current}:m,isLoading:g}}var Dv=e=>{window.requestAnimationFrame(()=>{let t=Number.parseInt(getComputedStyle(document.documentElement).getPropertyValue(Tt),10),o=e?.getBoundingClientRect().top??0,n=window.scrollY;window.scrollTo({top:o+n-(t+20),behavior:"smooth"})})},Pv=e=>{let{gallery:t}=e,o=t.sys.id,{getUrlParams:n,setUrlParams:a}=(0,So.useContext)(en),{onRedirect:s,getCurrentUrl:l}=(0,So.useContext)(ee),p=n?.()??{},[d,u]=(0,So.useState)(t.hidePagination?1:Number(p?.page??1)),y=(0,So.useMemo)(()=>{if(t?.dropdownsCollection)return Gg(t.dropdownsCollection.items,!0)},[t]),m=(0,So.useMemo)(()=>y?y.map(M=>M.id):[],[y]),[g,f]=(0,So.useState)(oi(p,m));(0,So.useEffect)(()=>{let M=n?.()??{},_=oi(M,m),P=Number(M?.page??1);f(_),u(P)},[m,n]);let{paginationData:b,isLoading:S}=pf({galleryId:o,page:d,pageSize:t?.itemsPerPage,tags:Object.values(g),sortBy:t?.sortBy}),C=(0,So.useRef)(null),v=(0,So.useCallback)((M,_)=>{if(!a)return;let P=Io(g),$=n?.()??{},R=Vt($,m);_?P[M]=_:P=Vt(P,M),f(P),u(1),a({...R,...P,page:"1"})},[m,n,a,g]),k=(0,So.useCallback)(M=>{if(!a)return;let _=n?.()??{},P=Io(_);P.page=`${M}`,u(M),a(P),Dv(C.current)},[n,a,C.current]),I=(0,So.useCallback)(()=>{if(!a)return;let M=n?.()??{},_=Vt(M,m);u(1),f({}),a({..._,page:"1"})},[m,n,a]),{mobileFiltersWrapperTextDataset:A,clearFiltersCtaCopyDataset:D,emptyPlaceholderDataset:B}=Fe({entryId:o,fieldIds:["emptyPlaceholder","loadMoreCtaCopy","mobileFiltersWrapperText","clearFiltersCtaCopy"]});if(s&&V?.redirects?.queryRedirects){let M=new Set(Object.keys(V.redirects.queryRedirects));if(Object.keys(p).some($=>M.has($))){let $=new URL(l()),R=new URL(`${$.protocol}//${$.host}${$.pathname}`);for(let[L,G]of Object.entries(p)){if(M.has(L)){R.searchParams.set(`${Ml}${L}`,String(G));continue}R.searchParams.set(L,String(G))}return R.hash=$.hash,s(`${R.pathname}${R.search}${R.hash}`,{newTab:!1}),null}}return x("div",{"data-testid":"mwp-lazy-gallery",ref:C,className:R7,children:[y&&!t.hideFilters?i(Ap,{searchMenus:y,selectedFilters:g,onChangeFilter:(M,_)=>v(M,_),onClearFilters:I,clearButtonLabel:t?.clearFiltersCtaCopy,mobileFiltersToggleLabel:t?.mobileFiltersWrapperText,mobileFiltersWrapperTextDataset:A,clearFiltersCtaCopyDataset:D}):null,i(bv,{emptyPlaceholder:t.emptyPlaceholder,tiles:b?.tiles,showDates:t.showDates,showDescriptions:t.showDescriptions,showMedia:t.showMedia,emptyPlaceholderDataset:B,isGalleryLoading:S,defaultTileImage:t.defaultImage??void 0,numberOfTiles:t?.itemsPerPage??12}),b?.total&&!t.hidePagination?i(Mi,{totalPages:Math.floor((b.total-1)/(t?.itemsPerPage??12))+1,currentPage:d,onChange:k}):null]})};Pv.displayName="Gallery";var Nv=e=>{let{gallery:t}=e,o=t.sys.id,{getUrlParams:n,setUrlParams:a}=(0,ho.useContext)(en),{onRedirect:s,getCurrentUrl:l}=(0,ho.useContext)(ee),p=n?.()??{},[d,u]=(0,ho.useState)(t.hidePagination?1:Number(p?.page??1)),y=(0,ho.useMemo)(()=>{if(t?.dropdownsCollection)return Gg(t.dropdownsCollection.items,!0)},[t]),m=(0,ho.useMemo)(()=>y?y.map(M=>M.id):[],[y]),[g,f]=(0,ho.useState)(oi(p,m));(0,ho.useEffect)(()=>{let M=n?.()??{},_=oi(M,m),P=Number(M?.page??1);f(_),u(P)},[m,n]);let{paginationData:b,isLoading:S}=pf({galleryId:o,page:d,pageSize:t?.itemsPerPage||6,tags:Object.values(g),sortBy:t?.sortBy}),C=(0,ho.useRef)(null),v=(0,ho.useCallback)((M,_)=>{if(!a)return;let P=Io(g),$=n?.()??{},R=Vt($,m);_?P[M]=_:P=Vt(P,M),f(P),u(1),a({...R,...P,page:"1"})},[m,n,a,g]),k=(0,ho.useCallback)(M=>{if(!a)return;let _=n?.()??{},P=Io(_);P.page=`${M}`,u(M),a(P),Dv(C.current)},[n,a,C.current]),I=(0,ho.useCallback)(()=>{if(!a)return;let M=n?.()??{},_=Vt(M,m);u(1),f({}),a({..._,page:"1"})},[m,n,a]),{mobileFiltersWrapperTextDataset:A,clearFiltersCtaCopyDataset:D,emptyPlaceholderDataset:B}=Fe({entryId:o,fieldIds:["emptyPlaceholder","loadMoreCtaCopy","mobileFiltersWrapperText","clearFiltersCtaCopy"]});if(s&&V?.redirects?.queryRedirects){let M=new Set(Object.keys(V.redirects.queryRedirects));if(Object.keys(p).some($=>M.has($))){let $=new URL(l()),R=new URL(`${$.protocol}//${$.host}${$.pathname}`);for(let[L,G]of Object.entries(p)){if(M.has(L)){R.searchParams.set(`${Ml}${L}`,String(G));continue}R.searchParams.set(L,String(G))}return R.hash=$.hash,s(`${R.pathname}${R.search}${R.hash}`,{newTab:!1}),null}}return x("div",{"data-testid":"mwp-lazy-editorial-gallery",ref:C,className:F7,children:[y&&!t.hideFilters?i(Ap,{searchMenus:y,selectedFilters:g,onChangeFilter:(M,_)=>v(M,_),onClearFilters:I,clearButtonLabel:t?.clearFiltersCtaCopy,mobileFiltersToggleLabel:t?.mobileFiltersWrapperText,mobileFiltersWrapperTextDataset:A,clearFiltersCtaCopyDataset:D}):null,i("div",{className:h({[W1]:!S&&b&&b?.tiles?.length>0}),children:i(wv,{emptyPlaceholder:t.emptyPlaceholder,tiles:b?.tiles,emptyPlaceholderDataset:B,isGalleryLoading:S,defaultTileImage:t.defaultImage??void 0,numberOfTiles:t?.itemsPerPage??6})}),b?.total&&!t.hidePagination?i(Mi,{totalPages:Math.floor((b.total-1)/(t?.itemsPerPage??6))+1,currentPage:d,onChange:k,className:B7}):null]})};Nv.displayName="EditorialGallery";var Ev=e=>{let t=e.sys.id,{data:o}=se(Vg,{variables:{id:t}}),n=o?.gallery,a=n?.galleryType==="Editorial";return n?a?i(Nv,{gallery:n}):i(Pv,{gallery:n}):null};Ev.displayName="LazyGallery";var Rv=e=>{let{data:t}=se(Ug.all,{variables:{id:e.sys.id}});return t?.mosaic?i(hv,{...t.mosaic,__typename:"Mosaic"}):null};Rv.displayName="Mosaic";var Fv=T(Hr());var Bv=T(w());var TH=E`
  query TileAndRelatedContentQuery(
    $preview: Boolean!
    $locale: String!
    $ids: [String]!
    $relatedContentId: String!
    $slugId: String
  ) {
    tileCollection(
      preview: $preview
      locale: $locale
      where: { sys: { id_in: $ids }, slugReference: { sys: { id_not: $slugId } } }
    ) {
      total
      items {
        ...TileAll
      }
    }
    relatedContent(preview: $preview, locale: $locale, id: $relatedContentId) {
      defaultImage {
        ...ImageAll
      }
    }
  }
  ${ri.all}
  ${Oe.all}
`;var Vi=T(w());function AH({page:e,tags:t,pageSize:o=12,sortBy:n=Rg}){let a=(0,Vi.useContext)(ee),s=(0,Vi.useContext)(Ze),l=(0,Vi.useRef)(0),p=(0,Vi.useMemo)(()=>{let g=new URLSearchParams;g.append("pageSize",`${o}`),g.append("sortBy",n),t.length&&g.append("tags",t.join(",")),g.append("page",`${e-1}`),a.currentLocale&&g.append("locale",a.currentLocale),a.userLocation.country&&g.append("country",a.userLocation.country);let f=s.getLowEntropyHints().platform;f&&g.append("platform",f);let b=s.getLowEntropyHints().isMobile?"Mobile":"Non-Mobile";return b&&g.append("device",b),g},[t,e,o,a.currentLocale,a.userLocation.country,s,n]),u=`${V.isClient?"":`http://localhost:${process.env.PORT??3e3}`}/api/related-content?${p}`,{data:y,isLoading:m}=an({dataId:`/api/related-content?${p}`,dataAsync:async()=>{try{return await(await fetch(u)).json()}catch(g){Me.logError({component:"UseRelatedContent",message:"Error loading related content tiles",error:g})}}});return y?.total&&(l.current=y?.total),{paginationData:m?{tiles:[],total:l.current}:y,isLoading:m}}var ete=10,tte={day:"2-digit",month:"2-digit",year:"2-digit",timeZone:"UTC"},_H=e=>{let{topics:t,slugId:o=""}=(0,Bv.useContext)(Eo),{getImageSources:n}=ve(),{isRTL:a}=(0,Bv.useContext)(ee),{formatDate:s}=Jn(),l=t?.map(C=>C.topicId||"")??[],{paginationData:p,isLoading:d}=AH({page:1,pageSize:ete,tags:l}),{data:u,loading:y}=se(TH,{variables:{ids:p?.tiles?.map(C=>C?.tileSysId)??[],relatedContentId:e.sys.id,slugId:o}}),m="https://images.ctfassets.net/kp51zybwznx4/120IJvdruE5HeC9XBYjFiU/879b8f63bde0d27c0750ade94c4b1a39/Default_Gallery_Image.png",{media:{imageSource:g,imageAltText:f},mobileMedia:{imageSource:b}}=Yt(u?.relatedContent?.defaultImage),S=u?.tileCollection?.items.length||0;return!d&&!y&&S>0?i(dr,{isRtl:a,children:u?.tileCollection?.items.map(C=>{let v=C.media?.media?.contentType,k=v?.startsWith("video/"),I=!!v,A=Le({desktop:n(I?C.media?.media.url:g||m),mobile:n(I?C.media?.mobileMedia?.url:b)}),D=C.slugReference?.slug||"",B=C.title?.json?C.title.json:"",M=C.label?.json?C.label?.json:"",_=C.date?s(C.date,tte).replaceAll("/","."):"";return i(Gn,{title:(0,Fv.documentToPlainTextString)(B),body:(0,Fv.documentToPlainTextString)(M),date:_,brand:C?.brand,url:D?`/${D}`:void 0,imgSrcs:k?void 0:A,imgAltText:C.media?.media?.description||f,videoSource:k?C.media?.media?.url:void 0,mobileVideoSource:k?C.media?.mobileMedia?.url:void 0,aspectRatio:"9:16",hideLinkArrow:wd[V.site]?.includes("snap"),relatedContent:!0},`${C.__typename}-${C.sys.id}`)})}):null};var DH=e=>{switch(e.__typename){case"Gallery":return i(Ev,{...e});case"CarouselV3":return i(Fc,{...e});case"Tabs":return i(vv,{...e});case"Mosaic":return i(Rv,{...e,__typename:"Mosaic"});case"Form":return i(Lc,{...e});case"ChartToggle":return i(Av,{...e});case"BarChart":return i(wl,{...e});case"LineChart":return i(Nl,{...e});case"GeoVisualization":return i(Pl,{...e});case"VisualizationSelector":return i(X7,{...e});case"TableVisualization":return i(El,{...e});case"Content":return i(Vc,{...e});case"Accordion":return i(H9,{...e});case"AnimatedAccordion":return i(MH,{...e});case"RelatedContent":return i(_H,{...e});default:return Re({component:"Block",message:`Unknown content type: ${e.__typename} with id: ${e.sys.id}`}),i(pe,{children:"\u{1F47F}"})}};DH.displayName="BlockContent";var Fl=e=>{let{maxColumns:t,eyebrow:o,title:n,subtitle:a,titleAlignment:s,titleAlignmentMobile:l,contentsCollection:p,callsToActionCollection:d,anchorId:u,isNarrow:y,widthStyle:m,fullHeight:g,brandBackgroundColor:f,backgroundColor:b,backgroundMediaV2:S,theme:C,isNextSameBackgroundColor:v,isPreviousSameBackgroundColor:k,className:I,sys:A,preChildren:D,postChildren:B,showCurtain:M,denseLayout:_}=e,P=it(f),{replacements:$}=(0,wH.useContext)(Eo),R=p;if(p?.items.length&&$){let Q=[...p.items];for(let z=0;z<Q.length;z++){let Se=Q[z]?.sys?.id,j=Q[z]?.__typename;if(Se&&$&&Se in $){let fe=$[Se];fe===void 0?Q.splice(z,1):fe&&fe.__typename===j&&(Q[z]={sys:{id:fe.sys.id},__typename:fe.__typename})}}R={items:Q}}let{media:{imageSource:L,imageAltText:G,videoSource:Z},mobileMedia:{imageSource:U,imageAltText:de,videoSource:le},thumbnailSource:re}=Yt(S),te=(R?.items??[]).map(Q=>i(DH,{...Q},Q.sys.id)),ae=d.items.map(Q=>i(St,{...Q},Q.sys.id)),{getImageSources:oe}=ve(),q;if(S?.__typename==="Image"){let{desktopSettings:Q,mobileSettings:z}=Dt({desktopHeight:S.media?.height??0,mobileHeight:S.mobileMedia?.height,enableHighDpi:S.enableHighDpi,quality:S.quality});q=Le({desktop:oe(L,Q),mobile:oe(U,z)})}let X=S?.stickersCollection?.items?.map(Q=>({imgSrcs:oe(Q?.asset?.url),position:Q?.position,rotation:Q?.rotation})),W=Fe({entryId:A.id,fieldIds:["eyebrow","title","subtitle"]}),K=(!!q||!!Z)&&M!==!1,F=i(ao,{callsToAction:ae,anchorId:u,maxColumns:t??void 0,subtitle:Ri(a),eyebrow:o,title:co(n),titleAlignment:s,titleAlignmentMobile:l,widthStyle:m??(y?"narrow":void 0),motifScheme:P,backgroundColor:b??C,isNextSameBackgroundColor:v,isPreviousSameBackgroundColor:k,fullHeight:g,className:I,...W,preChildren:D,postChildren:B,backgroundVideoSource:Z,backgroundPosterSource:re,mobileBackgroundVideoSource:le,backgroundImageSources:q,backgroundImageAltText:G??de,showCurtain:K,backgroundMediaStickers:X,denseLayout:_,children:te});return u?i(be.Provider,{value:{elementLocation:`block#${u}`},children:F}):F};Fl.displayName="Block";var PH=T(w());var EH=({localizedIn:e=[so]})=>{let{currentLocale:t,getCurrentUrl:o}=(0,PH.useContext)(ee),n=V.site==="stinson"?sf(o(),void 0):af(o());return n.searchParams.delete("lang"),t!==so&&e.includes(t)&&n.searchParams.set("lang",t),i(Mt,{children:i("link",{rel:"canonical",href:n.href})})};var ote=Symbol.for("react.lazy"),nte=e=>e.$$typeof===ote,Oi=({component:e})=>nte(e)?i(Do,{children:i(e,{})}):i(e,{});Oi.displayName="ContentlessRenderer";var cf=T(w());var RH=E`
  query CookieInformation($preview: Boolean!, $locale: String!) {
    cookieModalCollection(limit: 1, preview: $preview, locale: $locale) {
      items {
        sys {
          publishedAt
        }
        cookieCategoriesCollection(limit: 13) {
          items {
            title
            cookiesCollection(limit: 50) {
              items {
                name
                provider {
                  json
                }
                domains {
                  json
                }
                purpose {
                  json
                }
                expiration {
                  json
                }
              }
            }
          }
        }
      }
    }
  }
`;var rte=c`
  table-layout: fixed;
  width: 100%;
  overflow-wrap: break-word;
  min-width: 600px;
`,ate=c`
  overflow-x: auto;
`,FH=()=>{let e=qa(),{globalApolloClient:t}=(0,cf.useContext)(ze),{currentLocale:o}=(0,cf.useContext)(ee),{formatMessage:n}=(0,cf.useContext)(qe),a=n({id:"name",defaultMessage:"Name"}),s=n({id:"provider",defaultMessage:"Provider"}),l=n({id:"domains",defaultMessage:"Domains"}),p=n({id:"purpose",defaultMessage:"Purpose"}),d=n({id:"expiration",defaultMessage:"Expiration"}),u=n({id:"cookieInformation",defaultMessage:"Cookie Information"}),y=n({id:"updatedOn",defaultMessage:"Updated On: "}),{data:m}=hn(RH,{currentLocale:e.locale,isPreview:e.preview,isSSR:V.isSSR},{client:t}),g=br(m?.cookieModalCollection.items);if(!g)return i(xd,{});let f=g.sys?.publishedAt,S=new Date(f).toLocaleDateString(o,{year:"numeric",month:"long",day:"numeric"}),C=g.cookieCategoriesCollection.items,v=[{Header:a,accessor:"name"},{Header:s,accessor:I=>{let A=I.provider;return fo(A)}},{Header:l,accessor:I=>{let A=I.domains;return fo(A)}},{Header:p,accessor:I=>{let A=I.purpose;return fo(A)}},{Header:d,accessor:I=>{let A=I.expiration;return fo(A)}}],k=C.map(I=>{let A=I.title,D=I.cookiesCollection.items.map(B=>({name:B.name,purpose:B.purpose,provider:B.provider,expiration:B.expiration,domains:B.domains}));return i(As,{anchorId:er(A.toLowerCase()),title:A,body:i("section",{className:ate,children:i(d0,{data:D,columns:v,className:rte})})},A)});return i(ao,{title:u,maxColumns:1,subtitle:`${y} ${S}`,children:k})};var ff=T(w());var BH=e=>{let{data:t}=se(u8,{variables:{id:e.sys.id}});return t?.block?i(Fl,{...t.block}):null};var QH=T(w());var OH=T(w());var $H=c`
  height: 100%;
  object-fit: contain;
  pointer-events: none;
  position: relative;
  width: 65%;
`,LH=c`
  align-items: center;
  border: 2px solid ${r("--palette-black-v50")};
  border-radius: ${r("--border-radius-l")};
  box-shadow: none;
  display: flex;
  justify-content: center;
  height: 185px;
  overflow: hidden;
  position: relative;
  transition: border-color 0.2s linear, box-shadow 0.2s linear;
  width: 100%;

  :hover {
    border-color: ${r("--palette-black-v200")};
    box-shadow: ${r("--box-shadow-m")};
  }

  ${Ht} {
    height: 148px;
  }
`,HH=c`
  align-items: center;
  bottom: 0;
  display: flex;
  justify-content: center;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;

  img {
    transition: transform 0.2s linear;
  }

  :hover img {
    transform: scale(1.2);
  }
`,VH=c`
  height: 100%;
  object-fit: cover;
  width: 100%;
`,$v=c`
  display: flex;
  justify-content: center;
  height: 100%;
  width: 100%;
`;function GH({url:e,backgroundImageSources:t,foregroundImageSources:o}){let n=(0,OH.useContext)(be).elementLocation;return x(yn,{href:e,className:LH,onClick:()=>{ge({eventCategory:"AnimatedMediaCard",eventAction:"Click",eventLabel:`to: ${e}`,context:{targetUrl:e,elementLocation:n}}),io(e)&&Me.flush()},children:[i("div",{className:HH,children:i(et,{imgSrcs:t,imgClassName:VH,className:$v})}),i(et,{imgSrcs:o,imgClassName:$H,className:$v})]})}var zH=c`
  display: grid;
  gap: ${r("--spacing-xl")};
  grid-template-columns: repeat(2, minmax(0, 1fr));

  ${vo} {
    gap: ${r("--spacing-m")};
    grid-template-columns: minmax(0, 1fr);
  }
`,UH=c`
  margin-top: ${r("--spacing-xl")};
`,WH=c`
  margin-bottom: ${r("--spacing-l")};
`;var qH=({callsToActionCollection:e,cardsCollection:t,eyebrow:o,textAlignment:n=ie.Center,textAlignmentMobile:a=ie.Center})=>{let{getImageSources:s}=ve(),l=Rt(),p=(0,QH.useMemo)(()=>l?1:t?.items?.length===3?3:2,[l,t?.items?.length]),d=e?.items?.map(u=>i(St,{...u},u.sys.id));return i(ao,{callsToAction:d,eyebrow:o,maxColumns:p,titleAlignment:n,titleAlignmentMobile:a,children:i("div",{className:h(zH,{[UH]:!!o,[WH]:!!d?.length}),children:t?.items?.map(u=>i(GH,{url:u.url,backgroundImageSources:s(u.backgroundMedia.url),foregroundImageSources:s(u.foregroundMedia.url)},u.sys.id))})})};var ite=E`
  fragment AnimatedMediaCardAll on AnimatedMediaCard {
    ...ContentfulSysId
    backgroundMedia {
      ...AssetAll
    }
    foregroundMedia {
      ...AssetAll
    }
    url
  }
  ${$t.all}
  ${O}
`,ste=E`
  fragment CardBlockAll on CardBlock {
    ...ContentfulSysId
    eyebrow
    cardsCollection(limit: 4) {
      items {
        ...AnimatedMediaCardAll
      }
    }
    callsToActionCollection(limit: 9) {
      items {
        ... on CallToAction {
          ...CallToActionAll
        }
      }
    }
    textAlignment
    textAlignmentMobile
  }
  ${bt}
  ${O}
  ${ite}
`,KH=E`
  query CardBlockQuery($preview: Boolean!, $locale: String!, $id: String!) {
    cardBlock(preview: $preview, locale: $locale, id: $id) {
      ...ContentfulSysId
      ...CardBlockAll
    }
  }
  ${O}
  ${ste}
`;var jH=e=>{let{data:t}=se(KH,{variables:{id:e.id}});return t?.cardBlock?i(qH,{...t.cardBlock}):null};var YH=c`
  ${vo} {
    .${"sdsm-gallery"} > * {
      width: 100%;
    }
  }
`,XH=c`
  margin-top: ${r("--spacing-xl")};
`;var uf=T(w());function Lv(e){return new gn(function(t,o){return new qi(function(n){var a,s,l;try{a=o(t).subscribe({next:function(p){if(p.errors&&(l=e({graphQLErrors:p.errors,response:p,operation:t,forward:o}),l)){s=l.subscribe({next:n.next.bind(n),error:n.error.bind(n),complete:n.complete.bind(n)});return}n.next(p)},error:function(p){if(l=e({operation:t,networkError:p,graphQLErrors:p&&p.result&&p.result.errors,forward:o}),l){s=l.subscribe({next:n.next.bind(n),error:n.error.bind(n),complete:n.complete.bind(n)});return}n.error(p)},complete:function(){l||n.complete.bind(n)()}})}catch(p){e({networkError:p,operation:t,forward:o}),n.error(p)}return function(){a&&a.unsubscribe(),s&&a.unsubscribe()}})})}var ldt=(function(e){cd(t,e);function t(o){var n=e.call(this)||this;return n.link=Lv(o),n}return t.prototype.request=function(o,n){return this.link.request(o,n)},t})(gn);var Hv=class extends dd{writeQuery(t){let o=No().startSpan(`InMemoryCache.writeQuery: ${pa(t.query)}`),n=super.writeQuery(t);return o.endSpan(),n}diff(t){let o=No().startSpan(`InMemoryCache.diff: ${pa(t.query)}`),n=super.diff(t);return o.endSpan(),n}readQuery(t,o){let n=No().startSpan(`InMemoryCache.readQuery: ${pa(t.query)}`),a=super.readQuery(t,o);return n.endSpan(),a}};function JH(e,t){let o=(l,p)=>{let d=l;return d.sys?.id?`${p.typename}:${d.sys.id}`:sk(d.sys)?`${p.typename}:${d.sys.__ref.split(":")[1]}`:(console.info(`Apollo Query missing { sys { id }}. Add '...ContentfulSysId' field. Type: ${p.typename}`),pk(l))},n=Object.fromEntries(e.Entry.flatMap(l=>[[l,{keyFields:o}]])),a={possibleTypes:e,typePolicies:n},s=new Hv(a);if(t){let l=No().startSpan("restoringContentfulCache");s.restore(t),l.endSpan()}return s}var ZH=(e="")=>{let t=0;return()=>`${e}${++t}`},eV=new gn((e,t)=>{let o={},n={},a=ZH("f"),s=ZH("v");zf(e.query,{VariableDefinition:u=>{let y=u.variable.name.value;n[y]||(n[y]=s())},FragmentDefinition:u=>{let y=u.name.value;o[y]||(o[y]=a())}});let l={};for(let u in e.variables){let y=n[u]||u;l[y]=e.variables[u]}e.variables=l;let p=Io(e.query),d={VariableDefinition:u=>{let y=n[u.variable.name.value];return y?{...u,variable:{...u.variable,name:{...u.variable.name,value:y}}}:!1},Variable:u=>{let y=n[u.name.value];return y?{...u,name:{...u.name,value:y}}:!1},FragmentDefinition:u=>{let y=o[u.name.value];return y?{...u,name:{...u.name,value:y}}:!1},FragmentSpread:u=>{let y=o[u.name.value];return y?{...u,name:{...u.name,value:y}}:!1}};return e.query=zf(p,d),t(e)});var tV=new gn((e,t)=>{let o=e.operationName,n=e.variables.locale??"en-US",a="Contentful",s="request_duration",l=e.getContext().currentUrl,p=l?new URL(l).pathname:"/",d={queryName:o,locale:n,requestPath:p};return new qi(u=>{e.setContext({startMs:performance.now()});let y=t(e).subscribe({next:m=>{u.next(m)},complete:()=>{let m=performance.now()-e.getContext().startMs,g=e.getContext().response,f=g?.status??200;Or({eventCategory:a,eventVariable:s,eventValue:m,eventLabel:null,context:{...d,responseStatus:f,contentfulRequestStatus:"complete","x-contentful-region":g?.headers?.get("x-contentful-region"),"x-cache":g?.headers?.get("x-cache"),"x-contentful-request-id":g?.headers?.get("x-contentful-request-id"),"x-served-by":g?.headers?.get("x-served-by")}}),u.complete()},error:m=>{let g=performance.now()-e.getContext().startMs,f=e.getContext().response,b=f?.status??500;Or({eventCategory:a,eventVariable:s,eventValue:g,eventLabel:null,context:{...d,responseStatus:b,contentfulRequestStatus:"error","x-contentful-region":f?.headers?.get("x-contentful-region"),"x-cache":f?.headers?.get("x-cache"),"x-contentful-request-id":f?.headers?.get("x-contentful-request-id"),"x-served-by":f?.headers?.get("x-served-by")}}),u.error(m)}});return()=>{y.unsubscribe()}})});var lte="https://unknown.url",pte=new Map().set(400,"BadRequest").set(401,"AccessTokenInvalid").set(403,"AccessDenied").set(404,"NotFound").set(409,"VersionMismatch").set(422,"ValidationFailed").set(429,"RateLimitExceeded").set(500,"ServerError").set(502,"Hibernated"),Vv=e=>{let t=e.environmentName?`https://graphql.contentful.com/content/v1/spaces/${e.spaceId}/environments/${e.environmentName}`:`https://graphql.contentful.com/content/v1/spaces/${e.spaceId}`,o={Authorization:`Bearer ${V.isPreview&&e.previewAccessToken?e.previewAccessToken:e.accessToken}`};return V.isClient||(o["fastly-debug"]="1"),{uri:t,credentials:"same-origin",headers:o,fetch:En,print(n,a){return ik(a(n))}}},df=(e,t,o)=>{let n=new l5({delay:{max:100},attempts:{max:f0,retryIf:(d,u)=>{if(d){let y=Ft(d),m=u.getContext().response,g=m?.status??500,f=g===429||g>=500&&g<600;return f&&Hn({eventAction:"RetryFetch",eventCategory:"Apollo",eventLabel:pa(u.query),context:{responseCode:String(g),errorMessage:y.message,"x-contentful-region":m?.headers?.get("x-contentful-region"),"x-cache":m?.headers?.get("x-cache"),"x-contentful-request-id":m?.headers?.get("x-contentful-request-id")}}),f}return!1}}}),a=Lv(({graphQLErrors:d,networkError:u,operation:y})=>{if(d&&d.forEach(m=>{let g=m.extensions?.contentful?.code,f=y.getContext().response;Re({component:"Contentful",error:m,action:"GraphQlError",message:m.message,context:{errorName:g?.toLowerCase()??"unknown",variables:JSON.stringify(y.variables),queryName:pa(y.query),queryPath:m.path?.join(","),locations:m.locations?.join(","),requestUrl:y.getContext().currentUrl,"x-contentful-region":f?.headers?.get("x-contentful-region"),"x-cache":f?.headers?.get("x-cache"),"x-contentful-request-id":f?.headers?.get("x-contentful-request-id")}})}),u){let m=u.name==="ServerError"?u:void 0,g=y.getContext().response,f=m?.statusCode??599,b=pte.get(f)??"Unknown";Re({component:"Contentful",error:u,action:"NetworkError",message:`${u.name}/${b} (${f})`,context:{name:u.name,errorCode:f,errorName:b,url:new URL(m?.response?.url??lte),requestUrl:y.getContext().currentUrl,"x-contentful-region":g?.headers?.get("x-contentful-region"),"x-cache":g?.headers?.get("x-cache"),"x-contentful-request-id":g?.headers?.get("x-contentful-request-id")}})}}),s=new gn((d,u)=>{let y=No().startSpan(`ApolloQuery: ${d.operationName}`);return u(d).map(m=>(y.endSpan(),m))}),l=gn.from([eV,s,tV,a,n,lk(Vv(e))]);return new ud({link:l,cache:JH(t,o),ssrMode:!V.isClient,ssrForceFetchDelay:V.isSSR?100:0})};var cte=3e4,zc=new Map;!V.isClient&&!V.isTest&&setInterval(()=>{for(let[e,[t,o]]of Array.from(zc.entries())){let n=o();zc.set(e,[n,o])}},cte);var Uc=(e,t)=>{if(V.isPreview)return df(...t);let n=`${t[0].spaceId}/${e}`;if(zc.has(n)){let[s]=zc.get(n);return s}let a=df(...t);return zc.set(n,[a,()=>df(...t)]),a};var yf=()=>{let{currentLocale:e}=(0,uf.useContext)(ee),t=dte.has(e)?e:so;return(0,uf.useMemo)(()=>{let n={spaceId:x0.newsroom,environmentName:"production",accessToken:h0.newsroom},a=Uc(t,[n,{Entry:["Tile"]},{}]);return{locale:t,preview:!1,fetchPolicy:"cache-first",apolloClient:a}},[t])},dte=new Set(["ar","bn-BD","bn-IN","da-DK","de-DE","el-GR","en-GB","en-US","es-AR","es-ES","es-MX","es","fi-FI","fil-PH","fr-FR","gu-IN","hi-IN","id-ID","it-IT","ja-JP","kn-IN","ko-KR","ml-IN","mr-IN","ms-MY","nb-NO","nl-NL","pa","pl-PL","pt-BR","pt-PT","ro-RO","ru-RU","sv-SE","ta-IN","te-IN","th-TH","tr-TR","ur-PK","vi-VN","zh-Hans","zh-Hant"]);var Gi=T(w());function oV({galleryId:e,locale:t,pageSize:o=2}){let n=(0,Gi.useContext)(ee),a=(0,Gi.useContext)(Ze),s=(0,Gi.useRef)(0),l=(0,Gi.useMemo)(()=>{let y=new URLSearchParams;y.append("galleryId",e),y.append("pageSize",`${o}`),y.append("sortBy","By Date"),y.append("spaceId","newsroom"),y.append("page","0"),y.append("locale",t),n.userLocation.country&&y.append("country",n.userLocation.country);let m=a.getLowEntropyHints().platform;m&&y.append("platform",m);let g=a.getLowEntropyHints().isMobile?"Mobile":"Non-Mobile";return g&&y.append("device",g),y},[e,o,t,n.userLocation.country,a]),p=`https://newsroom.snap.com/api/gallery?${l}`,{data:d,isLoading:u}=an({dataId:`/api/gallery?${l}`,dataAsync:async()=>{try{return await(await fetch(p)).json()}catch(y){Me.logError({component:"UseNewsroomGalleryTiles",message:"Error loading gallery tiles",error:y})}}});return d?.total&&(s.current=d?.total),{paginationData:u?{tiles:[],total:s.current}:d,isLoading:u}}var nV=T(w());function rV(e){let{getCurrentUrl:t}=(0,nV.useContext)(ee),{locale:o,preview:n,fetchPolicy:a,apolloClient:s}=yf(),l={client:s,fetchPolicy:a,...e,context:{currentUrl:t(),...e?.context},variables:{preview:n,locale:o,...e?.variables},ssr:e?.ssr??V.isSSR};return yd(Tl,l)}var aV=({numOfCards:e=2})=>i(Ha,{children:Array.from({length:e}).map((t,o)=>i(vi,{},o))});var iV=({tileIds:e,defaultTileImage:t})=>{let{data:o,loading:n}=rV({variables:{ids:e}});if(n)return i(aV,{numOfCards:e.length});let a=o?.tileCollection?.items.slice().map(s=>{let l=s.url,p=s.slugReference?.slug??"";if(!l){let d=new URL("https://newsroom.snap.com/");d.pathname=p,l=d.href}return{...s,url:l}}).sort((s,l)=>e.indexOf(s.sys.id)-e.indexOf(l.sys.id));return i(Ha,{children:a?.map(s=>i(Hc,{...s,media:s.media??t,showDates:!0,showDescriptions:!0,showMedia:!0},s.sys.id))})};var sV=({galleryId:e,defaultTileImage:t,pageSize:o})=>{let{locale:n}=yf(),{paginationData:a}=oV({galleryId:e,locale:n,pageSize:o}),s=a?.tiles?.map(l=>l.tileSysId)??[];return s?.length?i(iV,{tileIds:s,defaultTileImage:t}):null};var lV=({eyebrow:e,numberOfNewsItems:t,textAlignment:o=ie.Center,textAlignmentMobile:n=ie.Center,callsToActionCollection:a,newsReference:s,defaultImage:l})=>{let p=s?.sys?.urn.split("/").at(-1)??"",d=a?.items?.map(u=>i(St,{...u},u.sys.id));return i(ao,{eyebrow:e,callsToAction:d,maxColumns:1,titleAlignment:o,titleAlignmentMobile:n,children:p?i("div",{className:h(YH,{[XH]:!!e}),children:i(sV,{galleryId:p,pageSize:t,defaultTileImage:l})}):null})};var pV=({id:e})=>{let{data:t}=se(tf,{variables:{id:e}});return t?.newsBlock?i(lV,{...t?.newsBlock}):null};var Ov=T(Hr());var yV=T(w());var cV=c`
  display: none;
  min-width: 300px;

  ${H} {
    display: block;
  }
`,dV=c`
  list-style: none;
  position: sticky;
  top: var(${Tt});
`,uV=c`
  font-size: 26px;
  font-weight: 600;
  height: 54px;
  line-height: 54px;

  a {
    color: ${r("--neutral-v700")};
    overflow: hidden;
    padding-inline-start: ${r("--spacing-xxxxl")};
    text-decoration: none;
    text-overflow: ellipsis;
    white-space: nowrap;

    &::before {
      background-color: ${r("--global-header-item-hover-color")};
      border-radius: ${r("--border-radius-xs")};
      content: ' ';
      height: 32px;
      left: 0;
      margin-top: 10px;
      position: absolute;
      visibility: hidden;
      width: 7px;

      *[dir='rtl'] & {
        left: unset;
        right: 0;
      }
    }

    &:hover::before,
    &:active::before {
      visibility: visible;
    }
  }
`;var mV=({navItems:e})=>{let t=(0,yV.useContext)(be).elementLocation,o=(n,a)=>{ge({eventCategory:"SnapSideMenu",eventAction:"Click",eventLabel:`to: ${n}`,context:{targetUrl:n,elementText:a,elementLocation:t}}),io(n)&&Me.flush()};return i("nav",{className:cV,children:i("ol",{className:dV,children:e?.map((n,a)=>i("li",{className:uV,children:i(Yr,{title:(0,Ov.documentToPlainTextString)(n?.title?.json),href:n.url,onClick:()=>o(n.url,(0,Ov.documentToPlainTextString)(n?.title?.json))})},`list-item-${a}`))})})};Kf();var zi=T(w());var gV=c`
  display: flex;
  flex-direction: row;
  gap: 0 ${r("--spacing-xxxxl")};
  max-width: 100%;

  ${vo} {
    flex-wrap: wrap;
  }
`,fV=c`
  flex-grow: 2;
  padding: ${r("--spacing-xl")} 0;

  > h1 {
    display: flex;
    flex-direction: column;
    min-width: 375px;
    position: relative;
  }

  ${N} {
    display: block;
    width: 100%;

    > h1 {
      min-width: unset;
    }
  }
`,bV=c`
  opacity: 0;
  position: absolute;
  /* Short animation to hide the ghost when user starts resizing */
  transition: opacity 0.25s ease-in-out;

  /* The following styles are to ensure consistent sizing for both image and video implementations */
  div.sdsm-media-wrapper {
    height: 100%;
  }

  img,
  video {
    height: 100%;
    margin: 0;
    object-fit: contain;
  }
`,SV=c`
  opacity: 1;
  /* Longer animation to show the ghost after user stops resizing */
  transition: opacity 2s ease-in-out;
`,hV=c`
  right: 0;
  top: calc(-1 * ${r("--spacing-xl")});

  *[dir='rtl'] & {
    right: unset;
    left: 0;
  }
`,CV=c`
  right: 0;

  /* Horizontally center the media in the container.
     This is meant to fill the space to the side of the Hero text so the component is visually balanced. */
  img,
  video {
    margin: auto;
  }

  *[dir='rtl'] & {
    right: unset;
    left: 0;
  }
`,xV=c`
  bottom: calc(-1 * ${r("--spacing-xl")});
  right: 0;

  *[dir='rtl'] & {
    right: unset;
    left: 0;
  }
`,vV=c`
  min-width: 200px;
  padding: ${r("--spacing-xl")} 0;

  /* handle edge case (wide screen) where left container has a greater height than right container */
  display: flex;
  flex-direction: column;

  p {
    margin-bottom: 1em;
  }

  ${Xe} {
    max-width: 50%;
  }
`;var IV=({title:e,title2:t,title3:o,media:n,body:a})=>{let s=[e];t&&s.push(t),o&&s.push(o);let l=(0,zi.useRef)(null),p=(0,zi.useRef)(Array.from({length:s.length})),[d,u]=(0,zi.useState)({width:0,height:0,position:"Top",isVisible:!1});(0,zi.useEffect)(()=>{if(!n)return;let f=pi(()=>{u(C=>({...C,isVisible:!1}))},500,{leading:!0,trailing:!1}),b=pi(()=>{let v=window.innerWidth<1025,k=l.current?.offsetWidth??0,I=p.current[0]?.offsetHeight??0,A=p.current[0]?.offsetWidth??0,D=p.current[s.length-1]?.offsetHeight??0,B=p.current[s.length-1]?.offsetWidth??0,M=p.current.reduce((G,Z)=>{let U=Z?.offsetWidth??0;return Math.max(G,U)},0),_=A<B,P=v&&M<k*.6,$=0,R=32,L=_&&k-A-$<50;u(L?G=>({...G,isVisible:!1}):P?{width:k-M-$,height:I*s.length,position:"Middle",isVisible:!0}:_?{width:k-A-$,height:I+R,position:"Top",isVisible:!0}:{width:k-B-$,height:D+R,position:"Bottom",isVisible:!0})},500),S=()=>{f(),b()};return b(),window.addEventListener("resize",S),()=>{window.removeEventListener("resize",S)}},[n]);let y=tg(!1,!1),m=n?.media,g=n?.mobileMedia;return i(ao,{maxColumns:1,children:x("div",{className:gV,children:[i("div",{ref:l,className:fV,children:x("h1",{children:[s.map((f,b)=>i("span",{children:i("span",{ref:S=>{p.current[b]=S},children:f})},b)),i("span",{style:{width:d.width,height:d.height},className:h(bV,{[SV]:d.isVisible,[hV]:d.position==="Top",[CV]:d.position==="Middle",[xV]:d.position==="Bottom"}),children:m&&i(Ke,{imageSource:m.url,altText:m.description,videoSource:m.url,sourceType:m.contentType,mobileVideoSource:g?.url})})]})}),a&&i("div",{className:vV,children:y(a)})]})})};var ute=E`
  fragment SnapHomeHeroFragment on SnapHomeHero {
    ...ContentfulSysId
    title
    title2
    title3
    media {
      __typename
      ... on Video {
        ...VideoAll
      }
      ... on Image {
        ...ImageAll
      }
    }
    body {
      json
    }
  }
  ${Oe.all}
  ${gt.all}
  ${O}
`,kV=E`
  query SnapHomeHero($id: String!, $locale: String!, $preview: Boolean!) {
    snapHomeHero(id: $id, locale: $locale, preview: $preview) {
      ...SnapHomeHeroFragment
    }
  }
  ${ute}
`;var MV=e=>{let{data:t}=se(kV,{variables:{id:e.id}});return t?.snapHomeHero?i(IV,{...t?.snapHomeHero}):null};var gf=T(w());var mf="--snap-com-background-color";var TV=c`
  display: flex;
  margin-top: calc(0px - var(${Tt}));
  min-height: 100vh;
  min-width: 100%;
  padding-top: var(${Tt});

  /* TODO: determine whether there is a more appropriate place to put the styles below */

  /* Override styles of Carousel component for better alignment with custom components: CardBlock, NewsBlock */
  .${"sdsm-carousel"}.${"sdsm-carousel-multi-view"} > div {
    margin-inline-start: calc((${r("--carousel-card-mobile-grid-gap")} / 2) * -1);
    width: calc(100% + (${r("--carousel-card-mobile-grid-gap")} / 2));

    ${H} {
      margin-inline-start: calc((${r("--carousel-card-desktop-grid-gap")} / 2) * -1);
      width: calc(100% + (${r("--carousel-card-desktop-grid-gap")} / 2));
    }
  }
`;var AV=({children:e})=>((0,gf.useLayoutEffect)(()=>(document.body.style.setProperty(mf,"transparent"),()=>{document.body.style.removeProperty(mf)})),(0,gf.useEffect)(()=>{let t=()=>{let o=gl(),a=Math.min(.4,window.scrollY/o);document.body.style.setProperty(mf,`rgba(255, 252, 0, ${a})`)};return window.addEventListener("scroll",t,{passive:!0}),()=>{window.removeEventListener("scroll",t)}},[]),i("section",{className:TV,children:e}));var _V=c`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  margin-bottom: ${r("--spacing-xxxl")};

  ${Ht} {
    margin-bottom: ${r("--spacing-xl")};
  }
`;var wV=e=>{let{data:t}=se(of,{variables:{id:e.id}}),{setHasCustomSideNav:o}=(0,ff.useContext)(on);(0,ff.useEffect)(()=>{o?.(!0)},[o]);let n=t?.snapHomePage.blocksCollection?.items??[],a=t?.snapHomePage.navigationItemsCollection?.items??[];return x(AV,{children:[a.length?i(mV,{navItems:a}):null,i("div",{className:_V,children:n?.map(s=>{let l=s.sys.id;switch(s.__typename){case"SnapHomeHero":return i(MV,{id:l},l);case"CardBlock":return i(jH,{id:l},l);case"NewsBlock":return i(pV,{id:l},l);case"Block":return i(BH,{...s},l);default:return null}})})]})};var LV=T(w());var yte=1024,Gv=$r({min:yte+1}),mte=$r({max:vk}),DV=c`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  /* Set font-family here or the var from the default motif is used */
  font-family: ${r("--font-family")};
  margin-bottom: ${r("--spacing-xxxxl")};
  padding-inline: ${r("--spacing-xl")};

  ${H} {
    /* Minus header height (64px) and footer height (66px) */
    min-height: calc(100vh - 64px - 66px);
  }

  ${Gv} {
    margin-inline: auto;
    max-width: ${Qt}px;
    padding-inline: ${r("--spacing-xxxxl")};
    width: 100%;
  }
`,PV=c`
  /* Override the desktop grid gap so that smaller desktop screens have the same gap as mobile */
  ${mte} {
    --carousel-card-desktop-grid-gap: ${r("--carousel-card-mobile-grid-gap")};
  }

  .sdsm-carousel {
    /**
     * Remove the vertical spacing from the carousel container to allow the bottom of the cards
     * to be closer to the bottom of the screen. This is because there will be extra space below
     * the cards if there are no pagination dots.
     * */
    & > div > div {
      margin-block: 0;
    }

    /* Add spacing to the top of the pagination dots to make up for the removed container spacing above. */
    & > nav {
      margin-top: ${r("--spacing-xl")};
    }

    /*
    * Override the height of the carousel card text container to 120px for SnapHomePageV2.
    */
    & :has(> .sdsm-carousel-card-text) {
      ${N} {
        height: 120px;
      }
    }

    /* Remove the min-height and absolute positioning from the carousel card text container */
    .sdsm-carousel-card-text {
      min-height: unset;
      position: unset;

      p {
        ${H} {
          text-align: center;
        }
        /**
         * The carousel changes font size for mobile and desktop,
         * but we need to increase at a different breakpoint
         * */
        ${Gv} {
          font-size: 16px;
        }
      }
    }
  }
`,NV=c`
  align-items: center;
  display: flex;
  flex-grow: 1;
  && {
    font-size: 26px;
    font-weight: 400;
  }
  max-width: 540px;
  /* Minus header height (64px) and height of carousel title and arrow indicator (70px) */
  min-height: calc(100vh - 64px - 70px);
  padding-block: 56px;
  text-wrap: pretty;
  width: 100%;

  /* If supported, use dvh for min-height to avoid address bar covering content on mobile */
  @supports (min-height: 100dvh) {
    min-height: calc(100dvh - 64px - 70px);
  }

  ${H} {
    && {
      font-size: 28px;
    }
    max-width: calc(590px + (2 * ${r("--spacing-xxxl")}));
    min-height: unset;
    padding: 56px ${r("--spacing-xxxl")};
  }

  ${Gv} {
    && {
      font-size: 44px;
    }
    max-width: calc(1040px + (2 * ${r("--spacing-xxxl")}));
  }
`,EV=c`
  align-items: center;
  color: ${r("--block-eyebrow-color")};
  display: flex;
  flex-direction: column;
  font-size: 14px;
  font-weight: 600;
  gap: ${r("--spacing-xs")};
  justify-content: center;
  letter-spacing: -0.01em;
  line-height: 20px;
  margin-bottom: ${r("--spacing-m")};
  text-align: center;

  ${H} {
    margin-bottom: ${r("--spacing-xxxl")};
  }
`,RV=c`
  ${H} {
    display: none;
  }
`,gte=qo`
  from {
    opacity: 0;
    transform: translateY(-64px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`,fte=qo`
  from {
    opacity: 0;
    transform: translateY(-48px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`,FV=c`
  animation-delay: 600ms;
  animation-duration: 800ms;
  animation-fill-mode: forwards;
  animation-timing-function: ease-in-out;
  opacity: 0; /* Start hidden immediately */

  @media (prefers-reduced-motion: reduce) {
    animation: none;
    opacity: 1;
    transform: none;
  }
`,BV=c`
  ${FV}
  animation-name: ${gte};
`,$V=c`
  ${FV}
  animation-name: ${fte};
`,zv=c`
  opacity: 0;
`;var HV=e=>{let{isRTL:t}=(0,LV.useContext)(ee),{data:o}=se(nf,{variables:{id:e.id}}),n=o?.snapHomePageV2?.title,a=o?.snapHomePageV2?.carouselTitle,s=o?.snapHomePageV2?.carouselCardsCollection?.items;return x("div",{className:h("sdsm-quinary",DV),children:[i("h1",{className:h(NV,o?BV:zv),children:n}),!!s?.length&&x("div",{className:h(PV,o?$V:zv),children:[x("div",{className:EV,children:[a,i(De,{className:RV,name:"chevron-down",size:28})]}),i(dr,{isSingleView:!1,autoPlay:!1,isRtl:t,enableOverflowDecoration:!0,isResponsiveWidth:!0,children:s.map(l=>{let p=l;return p?.media?.__typename==="Video"?i(Rc,{cardItem:p,mediaAspectRatio:"16:9",enableVideoControls:!1,isResponsiveWidth:!0,hideLinkArrow:!0},p.sys.id):i(Ec,{cardItem:p,mediaAspectRatio:"16:9",isResponsiveWidth:!0,hideLinkArrow:!0},p.sys.id)})})]})]})};var VV={questionnaireAll:E`
    fragment QuestionnaireBlockAll on QuestionnaireBlock {
      ...ContentfulSysId
      questionnaireTitle: title
      body {
        json
      }
      image {
        url
      }
      questionsCollection(limit: 20) {
        items {
          ...QuestionnaireQuestionAll
        }
      }
      startLabel
      submitLabel
      nextLabel
      backLabel
      skipLabel
      trackingIdLabel
      anchorId
    }
  `,questionnaireQuestionAll:E`
    fragment QuestionnaireQuestionAll on QuestionnaireQuestion {
      ...ContentfulSysId
      questionType
      question
      backgroundImage {
        url
      }
      body {
        json
      }
      answersCollection {
        items {
          ... on QuestionnaireAnswer {
            ...ContentfulSysId
            title
            description {
              json
            }
            image {
              url
            }
          }
        }
      }
      required
    }
    ${O}
  `},OV=E`
  query QuestionnaireEntryQuery($preview: Boolean!, $locale: String!, $id: String!) {
    questionnaireBlock(preview: $preview, locale: $locale, id: $id) {
      ...QuestionnaireBlockAll
    }
  }
  ${VV.questionnaireAll}
  ${VV.questionnaireQuestionAll}
`;var Uv=e=>{let{data:t}=se(OV,{variables:{id:e.id}}),o=bte(t);return o?i(void 0,{...o}):null};Uv.displayName="QuestionnaireBlock";function bte(e){if(!e)return null;let{questionnaireBlock:t}=e,{questionsCollection:o}=t,n=o.items.map(a=>({id:a.sys.id,question:a.question,body:a.body,questionType:a.questionType,image:a.backgroundImage?.url,answers:Ste(a.answersCollection),required:a.required}));return{title:t.questionnaireTitle,body:t.body,image:t.image?.url,submitLabel:t.submitLabel,startLabel:t.startLabel,nextLabel:t.nextLabel,backLabel:t.backLabel,skipLabel:t.skipLabel,anchorId:t.anchorId,questions:n}}function Ste(e){return e?e.items.map(o=>({id:o.sys.id,text:o.title,imageUrl:o.image?.url,isSelected:!1})):[]}function Wv(){return{AiAgent:void 0,ArDownloadFormBlock:void 0,ArDownloadIdCaptureBlock:void 0,ArDownloadLinkCard:void 0,ArLinkOutsBlock:void 0,AvalonHomeHero:void 0,AvalonDeepLinkBlock:void 0,AvalonProductHero:void 0,AvalonFormBlock:void 0,AvalonScrollSection:void 0,FixedPositionBlock:void 0,ValuePropsBlock:void 0,CheeriosBlock:void 0,CheeriosStaticBlock:void 0,ChiliPiperFormBlock:void 0,CookieInformationBlock:FH,JobApplyNowBlock:void 0,JobDescriptionBlock:void 0,JobHero:void 0,JobPostings:void 0,JobMobileCallToAction:void 0,QuestionnaireBlock:Uv,SandboxCookieTest:void 0,LatestGalleryCardHero:void 0,RegistrationFormBlock:void 0,ArArkoseProtectedFormBlock:void 0,LeadGenFormBlock:void 0,ExperienceSps2024Registration:void 0,ExperienceSps2024Confirmation:void 0,CventAuthenticator:void 0,ZkipsterAuthenticator:void 0,MosaicGridBlock:void 0,LiveEvent:void 0,SnapHomePage:wV,SnapHomePageV2:HV,StinsonBreadcrumbsBlock:void 0,StinsonMediaFeatureBlock:void 0,StinsonMultiVideoBlock:void 0,StinsonPhaseOneHome:void 0,StinsonPhaseOnePdpHero:void 0,StinsonRevealHome:void 0,StinsonUseCasesBlock:void 0,StinsonVideoBlock:void 0}}var Bl=T(w());var Qv=E`
  fragment BreadcrumbsAll on Slug {
    breadcrumbText
    slugParent {
      ...ContentfulSysId
      slug
      breadcrumbText
      slugParent {
        ...ContentfulSysId
        slug
        breadcrumbText
        slugParent {
          ...ContentfulSysId
          slug
          breadcrumbText
        }
      }
    }
  }
  ${O}
`,xmt=E`
  query BreadcrumbsQuery($preview: Boolean!, $locale: String!, $id: String!) {
    slug(preview: $preview, locale: $locale, id: $id) {
      ...ContentfulSysId
      slug
      ...BreadcrumbsAll
    }
  }
  ${O}
  ${Qv}
`;var qv=e=>{if(!e)return;let t=e.slugParent,o=e.breadcrumbText;if(!t||!o)return;let n=[];return e.slugParent?.slugParent?.breadcrumbText&&n.push({slug:e.slugParent.slugParent?.slug?`/${e.slugParent.slugParent.slug}`:void 0,breadcrumbText:e.slugParent.slugParent.breadcrumbText}),e?.slugParent?.breadcrumbText&&n.push({slug:e.slugParent?.slug?`/${e.slugParent.slug}`:void 0,breadcrumbText:e.slugParent.breadcrumbText}),e.breadcrumbText&&n.push({slug:e?.slug?`/${e.slug}`:void 0,breadcrumbText:e.breadcrumbText}),n.length>1?n:void 0},TO=e=>{if(typeof window>"u")return;let t=qv(e);if(t?.length)return{"@context":"https://schema.org","@type":"BreadcrumbList",itemListElement:t.map((o,n)=>({"@type":"ListItem",position:n+1,name:o.breadcrumbText,item:o.slug?`${window.location.origin}${o.slug}`:void 0}))}};var AO=T(Hr()),_O=e=>{if(e)return typeof e=="string"?e:(0,AO.documentToPlainTextString)(e.json)};var wO={month:"long",day:"2-digit",year:"numeric",timeZone:"UTC"},DO=({fallbackDate:e,header:t,isExpectingDate:o})=>{if(!o&&t)return()=>i(pe,{children:Po(t)});let n=typeof t=="string"?t:_O(t)??"",a=new Date(n),s=!Number.isNaN(a.getTime());return o&&s?()=>{let{formatDate:l}=Jn();return i(pe,{children:l(a,wO)})}:o&&e?()=>{let{formatDate:l}=Jn();return i(pe,{children:l(e,wO)})}:null};var Kv=e=>e?.__typename==="CarouselV3";var hte={sizeToUrl:[84,168,252].map((e,t)=>({size:`${t+1}x`,settings:{width:e}})),sizes:Cm},Cte=(e,t,o,n,a)=>{let s;if((bc(e)||Xm(e))&&(s=e?.stickersCollection?.items?.map(l=>({imgSrcs:t(l?.asset?.url),position:l?.position,rotation:l?.rotation}))),bc(e)){let l=je(e.mobileMedia).videoSource;return i(xn,{mobileVideoSource:l,videoSource:n,posterSource:a,dataset:o,stickers:s})}if(Xm(e)){let{imageSource:l,imageAltText:p}=je(e.media),{imageSource:d}=je(e.mobileMedia),{desktopSettings:u,mobileSettings:y}=Dt({desktopHeight:e.media?.height??0,mobileHeight:e.mobileMedia?.height,desktopDefaultHeight:650,mobileDefaultHeight:650,enableHighDpi:e.enableHighDpi,quality:e.quality}),m=Le({desktop:t(l,u),mobile:t(d??l,y)});return i(xn,{imgSrcs:m,altText:p,dataset:o,stickers:s})}if(Kv(e))return i(Fc,{...e});if(e.__typename==="SnapchatEmbed")return i(Gs,{...e,dataset:o})},Wc=e=>{let{eyebrow:t,title:o,subTitle:n,body:a,backgroundMediaLayout:s=Ii.FullScreen,backgroundMediaV2:l,callsToActionCollection:p,isHeaderDate:d=!1,header:u,headerMediaV2:y,brandBackgroundColor:m,backgroundColor:g,theme:f,textAlign:b,textAlignMobile:S,verticalTextAlign:C,fitWindow:v=!1,curtainOpacityPercentage:k,foreground:I,mediaWrap:A,className:D,footer:B,showMediaMobile:M,anchorId:_,sys:P,postChildren:$,size:R,showScrollButton:L,topics:G=[],displayTopics:Z,increaseTitleFontSize:U}=e,de=it(m),le=(0,Bl.useContext)(Ze),re=(0,Bl.useContext)(be).elementLocation,{breadcrumbData:te}=(0,Bl.useContext)(Eo),ae=qv(te),oe=(0,Bl.useRef)(null),{fallbackDate:q,shareable:X=!1}=e,{media:{imageSource:W,imageAltText:K,videoSource:F,imageSize:Q},mobileMedia:{imageSource:z,imageAltText:Se,videoSource:j,imageSize:fe},thumbnailSource:J}=Yt(l),ue=y?.media,{imageSource:_e,imageAltText:we}=je(ue),Be=y?.mobileMedia,{imageSource:Ce}=je(Be),We=p?.items?.map(Ye=>i(St,{...Ye},Ye.sys.id)),Pt=Fe({entryId:P.id,fieldIds:["eyebrow","title","subTitle","body","header","foreground"]}),{getImageSources:$e}=ve(),{media:{videoSource:Ro},thumbnailSource:eo}=Yt(I&&bc(I)?I:void 0),Ie=I?Cte(I,$e,Pt.foregroundDataset,Ro,eo):void 0,me=Ct(g)?void 0:g,ke=Ct(f)?void 0:f,Nt=DO({header:u,isExpectingDate:d,fallbackDate:q}),to={size:hte},ce=Le({desktop:$e(_e,to),mobile:$e(Ce,to)}),ht=vC(800,Q?.height??0),st;if(l?.__typename==="Image"){let{desktopSettings:Ye,mobileSettings:si}=Dt({desktopHeight:Q?.height??0,mobileHeight:fe?.height,enableHighDpi:l.enableHighDpi,quality:l.quality});st=Le({desktop:$e(W,Ye),mobile:$e(z,si)})}let rt,Et;if(pd(le.getLowEntropyHints())&&W&&st){let Ye=st.sources?.find(si=>si.type==="image/avif")?.url;ht.additionalDpr?(rt={url:vr(W,{image:{format:"avif",...ht.baseDprSettings}}),dpr:ht.additionalDpr.dpr-1e-4},Et={url:vr(W,{image:{...ht.additionalDpr.settings,format:"avif"}}),dpr:ht.additionalDpr.dpr}):Ye&&(rt={url:Ye})}let Uo=R??"Regular";I&&Kv(I)&&(Uo="Regular");let oo=()=>{if(!oe.current)return;ge({eventCategory:"Hero",eventAction:"Click",eventLabel:null,context:{elementLocation:re}});let Ye=gl()??0,td=oe.current.getBoundingClientRect().bottom+window.scrollY-Ye;window.scrollTo({top:td,left:0,behavior:"smooth"})},mn=Z&&G.map(Ye=>i(k4,{displayText:Ye.displayText||"",url:Ye.linksTo},Ye.sys.id)),Wo=l?.stickersCollection?.items?.map(Ye=>({imgSrcs:$e(Ye?.asset?.url),position:Ye?.position,rotation:Ye?.rotation}));return x(pe,{children:[!V.isClient&&rt&&x(Mt,{children:[i("link",{rel:"preload",href:rt.url,as:"image",fetchpriority:"high",media:Et?`(-webkit-max-device-pixel-ratio: ${rt.dpr})`:""}),Et&&i("link",{rel:"preload",href:Et.url,as:"image",fetchpriority:"high",media:`(-webkit-min-device-pixel-ratio: ${Et.dpr})`})]}),i(Sh,{ref:oe,eyebrow:t,title:co(o),subTitle:Ar(n),body:Ar(a),backgroundMediaLayout:s,backgroundVideoSource:F,backgroundPosterSource:J,mobileBackgroundVideoSource:j,callsToAction:We?.length?We:void 0,header:Nt?i(Nt,{}):void 0,foregroundMedia:Ie,motifScheme:de,backgroundColor:me||ke,bgImgSrcs:st,bgImgAltText:K??Se,headerImgSrcs:ce,headerImgAltText:we,textAlign:b,textAlignMobile:S,verticalTextAlign:C,fitWindow:Ct(v)?!1:v,curtainOpacityPercentage:k??void 0,wrapMedia:A,shareable:X,className:D,footer:B,showMediaMobile:M,anchorId:_,...Vt(Pt,"foregroundDataset"),postChildren:$,size:Uo,showScrollButton:L,onScrollDownButtonClick:oo,breadcrumbs:ae,breadcrumbsPropsOverride:V.theme?.componentPropsOverrides?.breadcrumbs,topics:mn,backgroundMediaStickers:Wo,increaseTitleFontSize:U})]})};Wc.displayName="Hero";var jv=T(u0());var EO=T(w());var PO=E`
  fragment PageBlocksCollection on Page {
    ...ContentfulSysId
    blocksCollection(limit: ${Fi}) {
      items {
        __typename
        ... on BlockHero {
          ...BlockHeroAll
        }
        ... on Block {
          ...ContentfulSysId
          title {
            json
          }
        }
      }
    }
  }
  ${O}
`,NO=E`
  query LatestPostHero($locale: String!, $preview: Boolean!) {
    slugCollection(
      limit: 1
      order: postedDate_DESC
      where: { AND: [{ slugType_contains: "Blog" }] }
      locale: $locale
      preview: $preview
    ) {
      items {
        ...ContentfulSysId
        slug
        postedDate
        author {
          ...ContentfulSysId
          name
          position
          slug
        }
        page {
          ...PageAssetAll
          ...ExperimentOnPageLoadingPageBlocksCollection
        }
      }
    }
  }
  ${O}
  ${Al.all}
  ${PO}
  ${ti("Page","PageBlocksCollection",PO)}
  ${_l}
`;var RO=({backgroundColor:e,postChildren:t})=>{let{data:o}=se(NO),{formatMessage:n}=(0,EO.useContext)(qe),{pathname:a}=zt(),s=n({id:"viewArticle",defaultMessage:"View Article"}),l={json:{data:{},content:[{data:{},content:[{data:{},marks:[],value:s,nodeType:"text"}],nodeType:jv.BLOCKS.PARAGRAPH}],nodeType:jv.BLOCKS.DOCUMENT},links:void 0},p=o?.slugCollection.items[0],d=p?.slug,u,y;switch(p?.page.__typename){case"Page":y=p.page.blocksCollection,u=y.items.find(f=>f.__typename==="BlockHero");break;case"PageAsset":u={__typename:"BlockHero",sys:{id:"asset_block_hero"},title:p?.page?.media?.title,body:p?.page?.media?.description};break;case"Experiment":{y=p.page.defaultReference.blocksCollection,u=y.items.find(f=>f.__typename==="BlockHero");break}}if(!u&&y){let f=y.items.find(b=>!!(b&&"title"in b&&b.title));f&&(Re({component:"LatestPostHero",message:`Latest post "${d}" does not have a hero. Using fallback title from ${f.__typename}`}),u={__typename:"BlockHero",sys:{id:`fallback_from_${f.__typename}`},title:f.title,backgroundColor:Lt.Black})}let m={items:[{_id:"generated",sys:{id:"generated"},url:d,analytics:{_id:"generated",sys:{id:"generated"},label:`Latest Post Hero CTA: ${a}`},presentation:{__typename:"Button",_id:"generated",sys:{id:"generated"},url:d,title:l,buttonType:"Primary"}}]};if(!u)return null;let g=u.backgroundColor??e??Lt.White;return e??(e=Lt.White),i(Wc,{...u,callsToActionCollection:m,backgroundColor:g,theme:e,postChildren:t})};var Sf=T(w());var FO=e=>window.matchMedia(e),xte=(e,t=FO)=>{let o=e.getAttribute("media");return o?t(o).matches:!0},BO=(e,t=FO)=>{let o=Array.from(e.querySelectorAll("source"));for(let n of o){let a=n.getAttribute("src");if(a&&xte(n,t))return a}return null};var Qc="activeHlsSource",$O=e=>{let t=BO(e);return t?.endsWith(".m3u8")?t:null},LO=(e,t,o)=>e.dataset[Qc]!==t?!1:o.has(e)?!0:!!(window.Hls&&!window.Hls.isSupported()),HO=(e,t,o)=>e.isConnected?o.get(e)!==t:!0,VO=e=>({savedCurrentTime:e.currentTime,wasPlaying:!e.paused}),OO=(e,t)=>{e.dataset[Qc]=t},GO=(e,t,o,n,a,s)=>{let l=new window.Hls({startLevel:-1,autoStartLoad:!s});return l.loadSource(t),l.attachMedia(e),l.on(window.Hls.Events.MANIFEST_PARSED,()=>{a.initGenerationByVideo.get(e)===o&&(e.currentTime=n.savedCurrentTime,n.wasPlaying&&e.play()?.catch(()=>{}))}),a.hlsByVideo.set(e,l),a.managedVideos.add(e),e.dataset[Qc]=t,l},zO=(e,t,o,n)=>{let a=e.getAttribute("preload")==="auto",s=new AbortController;o.preloadListenerAbortByVideo.set(e,s);let{signal:l}=s;if(!a){e.addEventListener("loadedmetadata",()=>{e.paused&&t.stopLoad()},{once:!0,signal:l}),e.addEventListener("play",()=>t.startLoad(),{signal:l}),e.paused||t.startLoad();return}n&&(e.addEventListener("play",()=>t.startLoad(),{signal:l}),e.paused||t.startLoad())};var UO=({children:e})=>{let t=vt(),o=(0,Sf.useRef)(null),n=t.enableHlsPlayback==="true",a=V.site==="stinson";return(0,Sf.useEffect)(()=>{if(!n||!o.current)return;let s=!0,l=new WeakMap,p=new Set,d=new WeakMap,u=new WeakMap,y=C=>{let v=u.get(C);v&&(v.abort(),u.delete(C));let k=l.get(C);k&&(k.destroy(),l.delete(C)),p.delete(C),delete C.dataset[Qc]},m=()=>new Promise(C=>{if(window.Hls){C();return}fn("hls.js","/hls.min.1.5.18.js",C)}),g={hlsByVideo:l,managedVideos:p,initGenerationByVideo:d,preloadListenerAbortByVideo:u},f=async C=>{let v=$O(C);if(!v||LO(C,v,l))return;let k=(d.get(C)??0)+1;if(d.set(C,k),await m(),!s||HO(C,k,d))return;let I=VO(C);if(y(C),!window.Hls.isSupported()){OO(C,v);return}let A=GO(C,v,k,I,g,a);zO(C,A,g,a)};(()=>{let C=o.current?.querySelectorAll("video")??[];for(let v of Array.from(C))f(v).catch(k=>{Re({component:"HlsInitializer",message:"Failed to initialize Hls for video",error:k})})})();let S=new MutationObserver(C=>{for(let M of p)M.isConnected||y(M);let k=C.filter(M=>M.type==="childList").flatMap(M=>Array.from(M.addedNodes)).filter(M=>M instanceof HTMLElement),I=k.filter(M=>M instanceof HTMLVideoElement),D=k.filter(M=>!(M instanceof HTMLVideoElement)).flatMap(M=>Array.from(M.querySelectorAll("video"))),B=[...I,...D];for(let M of B)f(M).catch(_=>{Re({component:"HlsInitializer",message:"Failed to initialize Hls for video",error:_})})});return S.observe(o.current,{childList:!0,subtree:!0}),()=>{s=!1;for(let C of[...p])y(C);S.disconnect()}},[n,a]),i("article",{ref:o,"data-testid":"mwp-hls-init",children:e})};var Yv=T(Hr());var WO=e=>{let{getImageSources:t}=ve(),{media:{imageSource:o,videoSource:n,contentType:a},mobileMedia:{imageSource:s,videoSource:l,contentType:p},thumbnailSource:d}=Yt(e.media),u,y;if(e.media?.__typename==="Image"){let{desktopSettings:b,mobileSettings:S}=Dt({desktopHeight:e.media.media?.height??0,mobileHeight:e.media.mobileMedia?.height,enableHighDpi:e.media.enableHighDpi,quality:e.media.quality});u=Le({desktop:t(o,b),mobile:t(s,S)})}e.media?.__typename==="Video"&&(y={source:n??"",mobileSource:l,sourceType:a,mobileSourceType:p,posterSource:d});let m=e.slugReference?.slug||"",g=e.title?.json?e.title.json:"",f=e.label?.json?e.label?.json:"";return i(Gn,{title:(0,Yv.documentToPlainTextString)(g),body:(0,Yv.documentToPlainTextString)(f),url:m?`/${m}`:void 0,imgSrcs:u,imgAltText:e.media?.media?.description,videoSource:y?.source,mobileVideoSource:y?.mobileSource,posterSource:y?.posterSource,aspectRatio:"9:16",shouldLoad:!0},`${e.__typename}-${e.sys.id}`)};var Xv=e=>{let{title:t,tilesDirection:o,text:n,textAlignmentMobile:a,eyebrow:s,brandBackgroundColor:l,backgroundColor:p,anchor:d,tilesCollection:u}=e,y=it(l);return i(Ch,{title:co(t),eyebrow:s,tilesDirection:o,text:n,textAlignmentMobile:a,motifScheme:y,backgroundColor:p,anchor:d,children:u.items.map(m=>WO(m))})};Xv.displayName="ImmersiveScrollBlock";var Jv=T(w());var vte=e=>{let{isRTL:t}=(0,Jv.useContext)(ee),{getImageSources:o}=ve(),n=(0,Jv.useContext)(be).elementLocation,{data:a}=se(E7.all,{skip:Gm(e),variables:{id:e.sys.id}}),s=a?.tile??e;if(!s)return null;let{url:l}=e,{title:p,label:d,media:u,imageSize:y,imageFit:m,url:g}=s,{afterClick:f,beforeClick:b,onClick:S,imageSize:C,imageFit:v}=e,{imageSource:k,imageAltText:I}=je(u?.media),A=()=>{b?.(),S?.(),ge({eventCategory:"Tile",eventAction:"Click",eventLabel:null,context:{targetUrl:M,elementLocation:n}}),f?.()},D=y??C,B=m??v,M=g??l,_=o(k,{image:{height:qp[D??fr.Large]*2}});return i(Zh,{title:Po(p),label:Po(d),onClick:A,imageSize:D,imageFit:B,imgSrcs:_,imgAltText:I,imagePadding:D===fr.Small&&B===Un.Contain,link:M,isRTL:t})};vte.displayName="Tile";var Zv=E`
  fragment ImmersiveScrollBlockAll on ImmersiveScrollBlock {
    ...ContentfulSysId
    eyebrow
    title {
      json
      links {
        entries {
          inline {
            ...ContentfulSysId
            ... on EmphasizedText {
              ...EmphasizedTextAll
            }
          }
        }
      }
    }
    text
    tilesCollection(limit: 4) {
      items {
        ...ContentfulSysId
        ...ImmersiveScrollBlockTile
      }
    }
    tilesDirection
    textAlignmentMobile
    brandBackgroundColor
    backgroundColor
    anchor
  }
  ${O}
  ${ei}
  ${ri.immersiveScrollBlockTile}
`,vft=E`
  query ImmersiveScrollBlockQuery($preview: Boolean!, $locale: String!, $id: String!) {
    immersiveScrollBlock(preview: $preview, locale: $locale, id: $id) {
      ...ImmersiveScrollBlockAll
    }
  }
  ${Zv}
`;function Ite(e){if(e=e.trim(),e.startsWith("<meta")){let t=/name="([^"]+)"/.exec(e)?.[1]??"unknown",o=/content="([^"]+)"/.exec(e)?.[1]??"unknown";return{name:encodeURIComponent(t),content:encodeURIComponent(o)}}if(!/['"><]/.test(e)&&e.includes("=")){let[t,o]=e.split("=");return{name:encodeURIComponent(t.trim()),content:encodeURIComponent(o.trim())}}return Me.logWarning({component:"Meta",action:"parse-custom-meta",message:`Unable to parse custom metadata: "${encodeURIComponent(e)}"`}),{name:"unparseable-meta",content:encodeURIComponent(e)}}var eI=e=>{let{customMetas:t}=e,o=t?.map(Ite)??[],n=e.ogImage&&Tn({imageUrl:e.ogImage.url,settings:{height:512}}),a={description:e.description,ogTitle:e.ogTitle,ogImage:n,ogVideo:e.ogVideo?.url,noIndex:!!e.noIndex,noFollow:!!e.noFollow,customMetas:o};return i(hi,{...a})};eI.displayName="Metas";var QO=E`
  fragment BlogSchemaAll on BlogSchema {
    ...ContentfulSysId
    headline
    description
    imagesCollection(limit: 10) {
      items {
        url
      }
    }
  }
  ${O}
`;var qO=E`
  fragment FaqPageSchemaAll on FaqPageSchema {
    itemsCollection {
      items {
        ...ContentfulSysId
        question
        answer {
          json
        }
      }
    }
  }
  ${O}
`;var KO=T(sC()),tI="https://schema.org";function jO(e,t,o,n,a){switch(t.__typename){case"BlogSchema":return kte(e,t,o,n,a);case"OrganizationSchema":return Mte(e,t);case"FaqPageSchema":return Tte(t);default:return}}function YO(e){return{"@type":"Organization",name:e.name,logo:e.logo?.url&&{"@type":"ImageObject",url:e.logo?.url},url:e.url}}function kte(e,t,o,n,a){let s=a&&YO(a),l=t.imagesCollection?.items?.map(p=>p.url).filter(p=>p!==void 0);return{"@context":tI,"@type":"BlogPosting",mainEntityOfPage:{"@type":"WebPage","@id":e},headline:t.headline,description:t.description,image:l,author:s,publisher:s,datePublished:o?.toISOString(),dateModified:n?.toISOString()}}function Mte(e,t){let o=YO(t);return{"@context":tI,"@type":"Organization",brand:o,description:t?.description,name:t?.name,sameAs:t?.sameAs,url:e}}function Tte(e){let t=e.itemsCollection?.items?.map(o=>({"@type":"Question",name:o.question,acceptedAnswer:{"@type":"Answer",text:(0,KO.documentToHtmlString)(o.answer.json)}}))??[];return{"@context":tI,"@type":"FAQPage",mainEntity:t}}var oI=E`
  fragment OrganizationSchemaAll on OrganizationSchema {
    ...ContentfulSysId
    name
    description
    url
    logo {
      url
    }
    sameAs
  }
  ${O}
`,XO=E`
  query OrganizationSchemaCollectionQuery($preview: Boolean!, $locale: String!) {
    organizationSchemaCollection(preview: $preview, locale: $locale, limit: 1) {
      items {
        ...OrganizationSchemaAll
      }
    }
  }
  ${oI}
`;var nI=T(w());var rI=e=>{let{schemas:t}=e,{getCurrentUrl:o}=(0,nI.useContext)(ee),{publishedAt:n,postedDate:a}=(0,nI.useContext)(Eo),s=o(),{data:l}=se(XO),p=t.map(d=>jO(s,d,a,n,Ki(l?.organizationSchemaCollection?.items||[])));return i(Mt,{children:p.map((d,u)=>d&&i("script",{type:"application/ld+json",children:JSON.stringify(d)},`schema-${u}`))})};rI.displayName="WebSchemas";var aI={all:E`
    fragment MetaAll on Metas {
      ...ContentfulSysId
      description
      ogTitle
      ogImage {
        url
      }
      ogVideo {
        url
      }
      noIndex
      noFollow
      customMetas
      schemasCollection(limit: 5) {
        items {
          ...ContentfulSysId
          ...BlogSchemaAll
          ...OrganizationSchemaAll
          ...FaqPageSchemaAll
        }
      }
    }
    ${QO}
    ${oI}
    ${qO}
    ${O}
  `},ibt=E`
  query MetasQuery($preview: Boolean!, $locale: String!, $id: String!) {
    metas(preview: $preview, locale: $locale, id: $id) {
      ...MetaAll
    }
  }
  ${aI.all}
`;var hf=e=>!e||!e.length?[]:e.map(t=>({...t,id:t.sys.id})),iI=({children:e,id:t,togglePanelClassName:o,togglePanelLabel:n,preChildren:a,postChildren:s,...l})=>{let{data:p}=se(Wg,{variables:{id:t}});if(p){let{anchorId:d,panelPosition:u,primaryVideosCollection:y,secondaryVideosCollection:m,mobilePrimaryVideosCollection:g,mobileSecondaryVideosCollection:f}=p.multiVideoBlock;return i(_h,{anchorId:d,id:t,toggleButtonIcons:["hover","reveal","follow","orbit"],panelPosition:u,primaryVideos:hf(y?.items),secondaryVideos:hf(m?.items),mobilePrimaryVideos:hf(g?.items),mobileSecondaryVideos:hf(f?.items),togglePanelLabel:n,togglePanelClassName:o,preChildren:a,postChildren:s,...l,children:e})}return null};iI.displayName="MultiVideoBlock";var $l=T(w());var JO=c`
  background-color: ${r("--bg-color")};
  bottom: 0;
  opacity: 0;
  padding: ${r("--spacing-xs")};
  position: sticky;
  transition: opacity 300ms ease-in-out, visibility 0s 300ms;
  visibility: hidden;
  z-index: ${Ee.MOBILE_CTA};

  .${"sdsm-button"}.${"sdsm-button"} {
    align-items: center;
    border-radius: ${r("--border-radius-s")};
    display: flex;
    justify-content: center;
    min-height: 54px; /* Custom for this feature. */
  }
`,ZO=c`
  opacity: 1;
  transition: opacity 300ms ease-in-out, visibility 0s 0s;
  visibility: visible;
`;var sI=({mobileCta:e,shouldScrollToShow:t})=>{let[o,n]=(0,$l.useState)(!t),a=(0,$l.useMemo)(()=>e.presentation?{...e.presentation,buttonType:rn.Primary}:void 0,[e.presentation]);return(0,$l.useEffect)(()=>{if(!a||!t)return;let s=()=>{let l=window.scrollY>=window.innerHeight;n(l)};return document.addEventListener("scroll",s,{passive:!0}),s(),()=>{document.removeEventListener("scroll",s)}},[a,t]),a?i("aside",{"data-testid":"mwp-persistent-cta",className:h("sdsm-secondary",JO,{[ZO]:o}),"aria-hidden":!o,children:i(St,{...e,presentation:a})}):null};sI.displayName="PersistentCta";var Ate=E`
  fragment ScrollAnimatedVideoAll on ScrollAnimatedVideo {
    ...ContentfulSysId
    mp4Source {
      ...AssetAll
    }
    webmSource {
      ...AssetAll
    }
    scrubStart
    scrubEnd
    videoStart
    videoEnd
  }
  ${O}
  ${Pn}
`,lI=E`
  fragment ScrollAnimatedSectionAll on ScrollAnimatedSection {
    ...ContentfulSysId
    scrollHeight
    animatedContentCollection {
      items {
        ...ScrollAnimatedVideoAll
      }
    }
    mobileContentCollection {
      items {
        ...BlockAll
      }
    }
    anchorId
  }
  ${Ate}
  ${O}
  ${Pn}
  ${pl}
`,Fbt=E`
  query ScrollAnimatedSectionQuery($preview: Boolean!, $locale: String!, $id: String!) {
    scrollAnimatedSection(preview: $preview, locale: $locale, id: $id) {
      ...ScrollAnimatedSectionAll
    }
  }
  ${lI}
`;var ca=T(w());var _te=c`
  height: calc(100vh - var(${Tt}));
  top: var(${Tt});
`,wte=c`
  position: absolute;
  object-fit: cover;
  width: 100%;
  height: 100%;
`,eG=({anchorId:e,scrollHeight:t=1,animatedContentCollection:o})=>{let n=(0,ca.useRef)(null),a=(0,ca.useRef)(64);(0,ca.useEffect)(()=>{a.current=gl()},[]);let s=(0,ca.useCallback)(()=>{if(!n.current)return 0;let p=(n.current.getBoundingClientRect().top-a.current)*-1,d=n.current.offsetHeight-window.innerHeight;return p/d},[]),l=(0,ca.useMemo)(()=>({height:`${t*100}vh`}),[t]);return i(qF,{anchorId:e,innerContainerClassName:_te,containerRef:n,style:l,children:o?.items.map(p=>{let{sys:d,mp4Source:u,webmSource:y,videoStart:m,videoEnd:g,scrubStart:f=0,scrubEnd:b=100}=p;return!u?.url||!y?.url?null:i(KF,{calculateScrollProgress:s,className:wte,scrubEnd:b,scrubStart:f,videoEnd:g,videoMp4Src:u.url,videoStart:m,videoWebmSrc:y?.url},d.id)})})};var Cf=c`
  display: flex;
  width: 100%;
  justify-content: left;
  margin: auto;
  max-width: ${Qt}px;

  html[dir='rtl'] & {
    justify-content: right;
  }

  ${N} {
    display: block;
  }
`,xf=c`
  ::before {
    background-color: ${r("--gutter-color")};
    content: '';
    height: 100vh;
    inset: 0;
    position: fixed;
    width: 100vw;
    z-index: -10;
  }
`,tG=c`
  overflow: clip;
`,Ll=c`
  min-height: calc(100vh - var(--total-header-height));
  min-height: calc(100dvh - var(--total-header-height));
`;var oG=e=>{let{getImageSources:t}=ve(),{splitBlockTitle:o,splitBlockSubtitle:n,splitBlockBody:a,media:s,callsToActionCollection:l,splitBlockBody:p,mediaCaption:d,anchorId:u,brandBackgroundColor:y,...m}=e,g=it(y),{media:{imageSource:f,imageAltText:b,videoSource:S,contentType:C},mobileMedia:{imageSource:v,imageAltText:k,videoSource:I,contentType:A},thumbnailSource:D}=Yt(s),B=s.__typename,M,_;if(B==="Image"){let{desktopSettings:R,mobileSettings:L}=Dt({desktopHeight:s.media?.height??0,mobileHeight:s.mobileMedia?.height,enableHighDpi:s.enableHighDpi,quality:s.quality});M=Le({desktop:t(f,R),mobile:t(v,L)})}B==="Video"&&(_={videoSource:S,mobileVideoSource:I,mediaContentType:C,mobileMediaContentType:A,posterSource:D});let P=l?.items?.map(R=>i(St,{...R},R.sys.id)),$=s?.stickersCollection?.items?.map(R=>({imgSrcs:t(R?.asset?.url),position:R?.position,rotation:R?.rotation}));return i(DB,{title:o,subtitle:n,body:fo(a),callsToAction:P?.length?P:void 0,imageSources:M,imageAltText:b??k??d,mediaCaption:d,stickers:$,motifScheme:g,anchorId:u,..._,...m})};var da=T(w());var nG="mwp-page-sibling";var vf=E`
  fragment PageShallow on Page {
    ...ContentfulSysId
    blocksCollection(limit: ${Fi}) {
      items {
        # For non-standard blocks, just preload their ids.
        ...ContentfulSysId
        # For blocks, alse preload the content ids.
        ... on Block {
          ...BlockShallow
        }
      }
    }
  }
  ${ag}
  ${O}
`,Dte=E`
  fragment BannerAll on Banner {
    ...ContentfulSysId
    content {
      json
      links {
        entries {
          inline {
            ... on CallToAction {
              ...CallToActionAll
            }
          }
        }
      }
    }
    brandBackgroundColor
    backgroundColor
  }
  ${O}
  ${bt}
`,Pte={all:E`
    fragment PageAll on Page {
      ...ContentfulSysId
      title
      metas {
        ...MetaAll
      }
      banner {
        ...BannerAll
        # In case there's a MobileCta inside banner, we want to retrieve its ID.
        ...ContentfulSysId
      }
      brandBackgroundColor
      backgroundColor
      backgroundMediaV2 {
        __typename
        ... on Video {
          ...VideoAll
        }
        ... on Image {
          ...ImageAll
        }
      }
      backgroundMediaStyle
      stretchPageBackgroundColor
      blocksCollection(limit: ${Fi}) {
        items {
          ...ContentfulSysId
          ... on Block {
            ...BlockAll
          }
          ... on BlockHero {
            ...BlockHeroAll
          }
          ... on LatestPosts {
            brandBackgroundColor
            backgroundColor
          }
          ... on Break {
            ...BreakAll
          }
          ... on SubNavigation {
            ...SubNavigationAll
          }
          ... on ScrollAnimatedSection {
            ...ScrollAnimatedSectionAll
          }
          ... on SplitBlock {
            ...SplitBlockAll
          }
          ... on MultiValuePropBlock {
            ...MultiValuePropBlockAll
          }
          ... on BlockTabs {
            ...BlockTabsAll
          }
          ... on ImmersiveScrollBlock {
            ...ImmersiveScrollBlockAll
          }
        }
      }
      mobileCta {
        ...CallToActionAll
      }
      footnotesCollection(limit: 50) {
        items {
          ... on FootNotes {
            ...FootNotesAll
          }
        }
      }
      collapseFootnotes
      footerView
      headerView
      scrollSnap
      localizedIn
      showAiLocalizationBanner
      denseLayout
    }
    ${Dte}
    ${pl}
    ${lI}
    ${$t.all}
    ${bt}
    ${Al.all}
    ${Tc.all}
    ${aI.all}
    ${O}
    ${xv}
    ${sv}
    ${Cv}
    ${Nc}
    ${iv}
    ${Zv}
  `},rG=E`
  fragment PageNavigationShallow on Page {
    ...ContentfulSysId
    sideNavigation {
      ...ContentfulSysId
    }
  }
  ${O}
`,aG=E`
  query PageQuery($preview: Boolean!, $locale: String!, $id: String!) {
    page(preview: $preview, locale: $locale, id: $id) {
      ...PageAll
    }
  }
  ${Pte.all}
`,iG=E`
  fragment SiteMapPage on Page {
    sys {
      id
    }
    metas {
      noIndex
    }
    localizedIn
  }
`,sG=E`
  query PageBlocksCollectionQuery(
    $preview: Boolean!
    $locale: String!
    $ids: [String]!
    $limit: Int = 10
  ) {
    entryCollection(
      preview: $preview
      locale: $locale
      where: { sys: { id_in: $ids } }
      limit: $limit
    ) {
      items {
        ...ContentfulSysId
        ... on Block {
          ...BlockAll
        }
        ... on BlockHero {
          ...BlockHeroAll
        }
      }
    }
  }
  ${O}
  ${pl}
  ${Al.all}
`;var qc="--page-sticky-height";var Nte=(e,t)=>{let o=e.getBoundingClientRect(),n=t.getBoundingClientRect();return o.left>=n.left&&o.right<=n.right},Ete=c`
  top: calc(var(${qc}) + var(${Tt}));
`,lG=({brandBackgroundColor:e,backgroundColor:t,sys:o,items:n=[]})=>{let a=it(e),s=(0,da.useRef)(null),[l,p]=(0,da.useState)(),d=(0,da.useRef)(typeof window<"u"?-1:0),u=(0,da.useRef)();(0,da.useEffect)(()=>{let g=()=>{let f=window.scrollY;d.current===-1&&(d.current=f),f>d.current?u.current="DOWN":f<d.current&&(u.current="UP"),d.current=f<=0?0:f};return window.addEventListener("scroll",g,{passive:!0}),()=>{window.removeEventListener("scroll",g)}},[]),(0,da.useEffect)(()=>{let g=b=>{let S=b.filter(v=>v.isIntersecting),C=u.current==="DOWN"?S[S.length-1]:S[0];if(C){let v=C.target.id;p(v);let k=s?.current,I=k?.querySelector(`a[href='#${v}']`);k&&I&&!Nte(I,k)&&k?.scroll({left:I?.offsetLeft-64,behavior:"smooth"})}},f=new IntersectionObserver(g,{rootMargin:"-30% 0px -70% 0px"});return n?.map(b=>b.anchorId).filter(b=>!!b).map(b=>document.getElementById(b)).filter(b=>!!b).forEach(b=>f.observe(b)),()=>{f.disconnect()}},[n]);let y=g=>f=>{if(f.preventDefault(),!g)return;let b=document.getElementById(g);if(!b)return;let S=Number(getComputedStyle(document.documentElement).getPropertyValue("--total-header-height").replace("px",""));window?.scrollTo({behavior:"smooth",top:b.getBoundingClientRect().top-document.body.getBoundingClientRect().top-S-56})},{contentfulDescriptionDataset:m}=Fe({entryId:o.id,fieldIds:["contentfulDescription"]});return i(zB,{motifScheme:a,backgroundColor:t,className:Ete,horizontalScrollRef:s,dataset:m,children:n?.map(g=>{let f=g.anchorId,{textDataset:b}=Fe({entryId:g.sys.id,fieldIds:["text"]});return i(Wh,{href:`#${f}`,onLinkClick:y(f),isActive:f===l,dataset:b,children:g.text},f)})})};var If=T(w());var kf=()=>{let e=(0,If.useRef)(null);return(0,If.useEffect)(()=>No().addEventListener((t,o,n,a)=>{e.current&&(e.current.dataset.events=`${a}`)}),[]),i("div",{"data-testid":"mwp-active-traced-events",ref:e,"data-events":"0",hidden:!0})};var pG=c`
  flex-grow: 1;
  max-width: ${Qt}px;
`,cG=c`
  max-width: ${Qt-To}px;
`,pI=c`
  position: sticky;
  top: var(${Tt});
  z-index: ${Ee.SUB_NAVIGATION};
`,dG=c`
  line-height: 20px;
  white-space: pre-wrap;

  /* TODO: Swap this rule when use a proper <p> element for paragraphs */
  .sdsm-p {
    margin-bottom: 0;
  }

  .${Ix} {
    font-size: 14px;
    /*
    need to unset lineheight because it messes with alignment :(
    also need vertical align bottom to make it actually aligned for some reason
    */
    line-height: unset;
    vertical-align: bottom;

    /*
    hack because icons mess up alignment due to their taller size and
    we don't want to use flex because the text nodes won't be able to wrap
    properly then
    */
    i {
      font-size: 14px;
      transform: scale(1.25);
    }

    /* same as above for images, bad and will update in future */
    img {
      height: 14px;
      transform: scale(1.5);
      margin-left: 2px;
    }
  }
`,uG=c`
  position: sticky;
  bottom: 0;
  z-index: ${Ee.MOBILE_CTA};
`,yG=c`
  position: fixed;
  bottom: 0;
  z-index: ${Ee.PAGE_FIXED_PORTAL};
`;var Mf=T(w()),Rte=T(ma());var Fte="mwp-page-bottom-sticky-portal",mG=(0,Mf.memo)(e=>{let{pageBottomStickyPortalRef:t}=(0,Mf.useContext)(ee);return i("aside",{className:e.className,"data-testid":Fte,ref:t})});var Hl=T(w()),Bte=T(ma());var $te="mwp-page-fixed-portal",gG=(0,Hl.memo)(e=>{let{pageFixedPortalRef:t}=(0,Hl.useContext)(ee);return i("aside",{className:e.className,"data-testid":$te,ref:t})});var Lte=[tt.Straight,tt.Skirt,tt.Straight,tt.HeadFlipped,tt.Straight,tt.Head],Hte=c`
  display: flex;
  flex-direction: column;
  min-height: calc(100vh - var(${Tt}));
`,Vte=c`
  display: flex;
  flex-direction: column;
  margin-top: auto;
`,Ote=60,Gte=c`
  display: flex;
  flex-direction: column;
  min-height: calc(100vh - calc(var(${Tt}) + ${Ote}px));
`,zte={lazy:!0},Ute={lazy:!1},Wte=["Break","SubNavigation","BlockHero","LatestPosts","MultiVideoBlock","Block","SplitBlock","MultiValuePropBlock","BlockTabs"],fG=e=>!Wte.includes(e),cI=e=>{let{pathname:t}=zt(),o=vt(),{formatMessage:n}=(0,Zt.useContext)(qe),{currentLocale:a}=(0,Zt.useContext)(ee),{getImageSources:s}=ve(),l=Rt(),d=ol()==="snap",u=it(e.brandBackgroundColor),y=it(e.banner?.__typename==="Banner"?e.banner?.brandBackgroundColor:void 0),m=Ya(V,"page"),g=(0,Zt.useRef)(null),f=(0,Zt.useRef)(null),b=(0,Zt.useRef)(e.banner&&e.banner.__typename==="Banner"?50:0),S=(0,Zt.useMemo)(()=>{if(typeof window<"u")return new ResizeObserver(ce=>{let{height:ht}=ce[0].contentRect;b.current!==ht&&(b.current=ht,f.current?.style.setProperty(qc,`${ht}px`))})},[]);(0,Zt.useEffect)(()=>{if(g.current&&S)return S.observe(g.current,{box:"border-box"}),()=>{S.disconnect()}},[S]),zo(()=>{ot({subscribedEventType:"page_load"})},[t]);let{headerView:C,footerView:v,hasSideNav:k,hasSubNav:I,setHeaderView:A,setFooterView:D}=(0,Zt.useContext)(on),B=e.headerView??"Full Header",M=e.footerView??"Full Footer";V.isClient||(A?.(B),D?.(M)),(0,Zt.useEffect)(()=>{B!==C&&A?.(B)},[B,C,A]),(0,Zt.useEffect)(()=>{M!==v&&D?.(M)},[M,v,D]);let _=(0,Zt.useContext)(Eo),{title:P,metas:$,blocksCollection:R,footnotesCollection:L,collapseFootnotes:G,backgroundColor:Z,backgroundMediaV2:U,backgroundMediaStyle:de,scrollSnap:le,mobileCta:re,showAiLocalizationBanner:te=[],denseLayout:ae}=e,oe=o.testFeatureFlag,q=Z??V.theme?.defaultPageBackgroundColor,X=(void 0)?.[rf(t)],W=L?.items?.map(ce=>i(Bx,{...ce},ce.sys.id)),K=n({id:"footnotesTitle",defaultMessage:""}),F=W?.length?i(NS,{title:K,isOpenInitially:!G,children:W}):void 0,Q=n({id:"aiLocalizationBannerTitle",defaultMessage:""}),z=n({id:"aiLocalizationBannerDescription",defaultMessage:""}),Se=te?.includes(a)?i(oT,{title:Q,description:z}):void 0,j=[];j.push(...R?.items??[]);let fe=m?.breakTemplates??V.theme?.breakTemplates??Lte,J=0,ue=-1,_e=[];j.forEach((ce,ht)=>{let{sys:st,__typename:rt}=ce,Et=ht===j.length-1,Uo=j?.[ht-1],oo=j?.[ht+1],mn=ce?.backgroundColor,Wo=Uo?.backgroundColor,Ye=oo?.backgroundColor,si=ce?.brandBackgroundColor,td=Uo?.brandBackgroundColor,od=oo?.brandBackgroundColor,Gf=!!ce?.backgroundMediaV2,DU=!!Uo?.backgroundMediaV2,nd=!!oo?.backgroundMediaV2,RI=Gf||!si&&!mn?void 0:si??Pe(mn),FI=nd||!od&&!Ye?void 0:od??Pe(Ye);switch(ue===-1&&rt!=="SubNavigation"&&(ue=ht),rt){case"Break":{let Rr=ce.brandType??ce.type;if(Rr&&Rr!=="None"){let ua=d?void 0:ce.topColor?ce.topColor==="Transparent"?"Transparent":Pe(ce.topColor):void 0,Fn=d?void 0:ce.bottomColor?ce.bottomColor==="Transparent"?"Transparent":Pe(ce.bottomColor):void 0,rd=DU||!td&&!Wo?"Transparent":td??Pe(Wo),Ui;Et&&F?Ui=Pe(Q2):Ui=nd||!od&&!Ye?"Transparent":od??Pe(Ye);let Wi=(d?ce.brandTopColor||"sdsm-default":ce.brandTopColor)??ua??rd,Qi=(d?ce.brandBottomColor||"sdsm-default":ce.brandBottomColor)??Fn??Ui,PU=Wi==="Transparent"?void 0:Wi,NU=Qi==="Transparent"?void 0:Qi,{desktopSettings:EU,mobileSettings:RU}=Dt({desktopHeight:ce.media?.media?.height??0,mobileHeight:ce.media?.mobileMedia?.height,enableHighDpi:ce.media?.enableHighDpi,quality:ce.media?.quality}),FU=Le({desktop:s(ce.media?.media.url,EU),mobile:s(ce.media?.mobileMedia?.url,RU)});_e.push({data:{...ce,brandTopColor:Wi,brandBottomColor:Qi},component:i(Tu,{template:tt[Rr],imgSrcs:FU,topColor:PU,bottomColor:NU,isOverlaid:ce.isOverlaid&&!Et},ce.sys.id)})}break}case"ScrollAnimatedSection":{if(l){let Rr=ce.mobileContentCollection?.items??[];for(let ua of Rr){let Fn=ua;_e.push({data:ce,component:i(Fl,{...Fn,isPreviousSameBackgroundColor:Fn.backgroundColor===Wo,isNextSameBackgroundColor:Fn.backgroundColor===Ye,fullHeight:le||Fn.fullHeight},st.id)})}break}_e.push({data:ce,component:i(eG,{...ce},st.id)});break}case"SubNavigation":{_e.push({data:ce,component:i(lG,{items:ce?.subNavigationItemsCollection?.items??[],...ce},st.id)});break}case"BlockHero":{_e.push({data:ce,component:ce.useLatestPost?i(RO,{backgroundColor:ce.backgroundColor},st.id):i(Wc,{...ce,fitWindow:le||ce.fitWindow,fallbackDate:_.postedDate??_.publishedAt,shareable:_.isShareable,topics:_.topics},st.id)});break}case"LatestPosts":{_e.push({data:ce,component:Ql(Sv,{...ce,key:st.id})});break}case"MultiVideoBlock":{_e.push({data:ce,component:i(iI,{id:st.id},st.id)});break}case"Block":{_e.push({data:ce,component:i(Fl,{...ce,isPreviousSameBackgroundColor:ce.backgroundColor===Wo,isNextSameBackgroundColor:ce.backgroundColor===Ye,fullHeight:le||ce.fullHeight,denseLayout:ce.denseLayout??ae},st.id)});break}case"SplitBlock":{_e.push({data:ce,component:i(oG,{...ce},st.id)});break}case"MultiValuePropBlock":{_e.push({data:ce,component:i(kg,{...ce},st.id)});break}case"BlockTabs":{_e.push({data:ce,component:i(U9,{...ce},st.id)});break}case"ImmersiveScrollBlock":{_e.push({data:ce,component:i(Xv,{...ce},st.id)});break}default:{let Rr=Wv();if(rt in Rr){let ua=Rr[rt];_e.push({data:ce,component:i(ua,{id:st.id},st.id)})}else _e.push({data:{__typename:"Break",sys:{id:"__generated_error"},brandType:"Straight"},component:i(Zt.Fragment,{children:!V.isCompilationModeProd&&`Dev error: Unknown component type ${rt} with id ${st.id}`},st.id)})}}if(!Et&&!(rt==="Break"||oo?.__typename==="Break"||rt==="SubNavigation"||oo?.__typename==="SubNavigation"||fG(rt)||fG(oo?.__typename)||Gf&&nd||RI===FI&&!Gf&&!nd||fe.length<=0)){let ua=m?.heroBreakTemplate??V.theme?.heroBreakTemplate,Fn;ua===tt.None?Fn=tt.None:ua===tt.Straight?Fn=tt.Straight:Fn=tt.Skirt3;let rd=rt==="BlockHero"?Fn:fe[J],Ui=RI,Wi=FI,Qi=!1;_e.push({data:{__typename:"Break",sys:{id:"__generated"},brandType:rd,brandTopColor:Ui,brandBottomColor:Wi,isOverlaid:Qi},component:i(Tu,{template:rd,topColor:Ui,bottomColor:Wi,isOverlaid:Qi},`break ${ht}`)}),rt!=="BlockHero"&&(J=(J+1)%fe.length)}});let we=_e.map((ce,ht)=>{let{component:st}=ce,rt=_e?.[ht-1],Et=_e?.[ht+1],Uo={};if(rt&&rt.data.__typename==="Break"){let oo=rt?.data.brandType??rt?.data.type;if(oo!==tt.Straight&&oo!=="None"){let mn=rt.data.brandTopColor??rt.data.topColor,Wo=rt.data.brandBottomColor??rt.data.bottomColor,Ye=bp({template:oo,isTopTransparent:!mn||mn==="Transparent",isBottomTransparent:!Wo||Wo==="Transparent",isOverlaid:rt.data.isOverlaid});Uo.preChildren=i(Sp,{type:Ye,location:"top"})}}if(Et&&Et.data.__typename==="Break"){let oo=Et?.data.brandType??Et?.data.type;if(oo!==tt.Straight&&oo!=="None"){let mn=Et.data.brandTopColor??Et.data.topColor,Wo=Et.data.brandBottomColor??Et.data.bottomColor,Ye=bp({template:oo,isTopTransparent:!mn||mn==="Transparent",isBottomTransparent:!Wo||Wo==="Transparent",isOverlaid:Et.data.isOverlaid});Uo.postChildren=i(Sp,{type:Ye,location:"bottom"})}}return!Et&&!Uo.postChildren&&(Uo.postChildren=i(Sp,{type:"topHalf",location:"bottom"})),(0,Zt.cloneElement)(st,Uo)}),Be=F||Se?x("div",{className:Vte,children:[F,Se]}):void 0,{media:{imageSource:Ce,videoSource:We},mobileMedia:{imageSource:Pt,videoSource:$e},thumbnailSource:Ro}=Yt(U),eo;if(U?.__typename==="Image"){let{desktopSettings:ce,mobileSettings:ht}=Dt({desktopHeight:U.media?.height??0,mobileHeight:U.mobileMedia?.height,enableHighDpi:U.enableHighDpi,quality:U.quality});eo=Le({desktop:s(Ce,ce),mobile:s(Pt,ht)})}let Ie=CH(P),me=e.contentless?i(Oi,{component:e.contentless.component}):null,ke=x(pe,{children:[e.contentless?.placement==="before-blocks"&&me,x(_6,{children:[i(Zl.Provider,{value:Ute,children:we.slice(0,ue+1)}),i(Zl.Provider,{value:zte,children:we.slice(ue+1)}),i(fx,{})]}),e.contentless?.placement==="after-blocks"&&me,Be]}),Nt=null,to=null;if(e?.banner?.__typename==="Banner"){let{contentfulDescriptionDataset:ce}=Fe({entryId:e.banner.sys.id,fieldIds:["contentfulDescription"]});Nt=i(LA,{className:pI,contentClassName:dG,motifScheme:y,backgroundColor:e.banner?.backgroundColor,dataset:ce,children:fo(e.banner?.content)})}else if(e?.banner?.__typename){let ce=Wv();if(ce[e.banner.__typename]){let ht=ce[e.banner.__typename];to=i(ht,{id:e.banner.sys.id})}}return x("div",{"data-testid":"page",ref:f,className:h(pG,u??Pe(q),{[cG]:k},Ll,"mwp-page"),dir:Ie,"data-test-feature":oe,style:{[qc]:`${b.current}px`,...X?{maxWidth:X}:{}},children:[i(EH,{localizedIn:e.localizedIn}),i(IH,{localizedIn:e.localizedIn}),!!$&&i(eI,{...$}),!!$?.schemasCollection?.items&&i(rI,{schemas:$.schemasCollection.items}),Nt?i("div",{className:pI,ref:g,children:Nt}):null,x(UO,{children:[i(hi,{title:P,ogTitle:$?.ogTitle}),x(Ph,{motifScheme:u,backgroundColor:q,backgroundImageSources:eo,backgroundMediaStyle:de,backgroundVideoSource:We,gutterMatchesPageBackground:e.stretchPageBackgroundColor,mobileBackgroundVideoSource:$e,backgroundPosterSource:Ro,className:h({[Hte]:!I,[Gte]:I}),scrollSnap:le,children:[ke,to,l&&re&&i(sI,{mobileCta:re,shouldScrollToShow:o.enablePersistentCtaScrollVisibility==="true"}),i(mG,{className:uG}),i(gG,{className:yG})]}),i("div",{className:nG})]}),i(kf,{})]})};cI.displayName="Page";var Vl=e=>{let{data:t}=se(aG,{variables:{id:e.sys.id}}),o=(0,Kc.useRef)(new Set),n=ck(),{currentLocale:a,getCurrentUrl:s}=(0,Kc.useContext)(ee),{replacements:l}=(0,Kc.useContext)(Eo),p=l?e.blocksCollection.items.reduce((f,b)=>(l?.[b.sys.id]&&f.push(l[b.sys.id]?.sys.id??""),f),[]):[],d=se(sG,{skip:!p.length,variables:{ids:p}});function u(f){let b=SH[f.__typename];if(!b){Vr({component:"PageShallow",message:`Cannot preload item "${f.__typename}". Add it to 'contentfulTypeQueries'`,context:{type:f.__typename}});return}let S=`${pa(b)}:${f.sys.id}`;o.current.has(S)||(n.query({query:b,context:{currentUrl:s()},variables:{id:f.sys.id,preview:V.isPreview,locale:a}}).catch(C=>{Vr({component:"PageShallow",message:`Failed to preload item "${f.__typename}" due to error: ${Ft(C).message}`,context:{type:f.__typename}})}),o.current.add(S))}function y(){for(let f of e.blocksCollection.items)if(f.__typename==="Block"){let b=f;l?.[f.sys.id]?.sys.id&&(b={...f,sys:{id:l[f.sys.id]?.sys.id}});for(let S of b.contentsCollection.items)u(S)}else u(f)}if(!t||d.loading)return y(),null;let m=t.page.banner,g=t.page.blocksCollection;if(l&&t.page.banner&&t.page.banner.sys.id in l&&(m=d.data?.entryCollection.items.find(f=>t.page.banner?f.sys.id===l[t.page.banner.sys.id]?.sys.id:!1)),t.page.blocksCollection&&l){let f=[...t.page.blocksCollection.items];for(let b=0;b<f.length;b++){let S=f[b]?.sys?.id;if(S&&S in l){let C=d.data?.entryCollection.items.find(v=>v.sys.id===l[S]?.sys.id);C===void 0?f.splice(b,1):C&&C.__typename!=="Banner"&&(f[b]=C)}}g={items:f}}return i(cI,{...t.page,blocksCollection:g,banner:m,contentless:e.contentless})};Vl.displayName="PageShallow";var vG=T(w());var SG=V.theme?.defaultPageBackgroundColor??Lt.White,bCt=c`
  display: flex;
  justify-content: center;
`,hG=c`
  align-items: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  background-color: ${r("--bg-color")};
  color: ${r("--fg-color")};
  min-height: max(600px, calc(100vh - var(--total-header-height)));
  padding: ${r("--spacing-xxl")};
  text-align: center;
  width: 100%;
`,CG=c`
  margin-bottom: 10px;

  ${Mr.over1024_desktop_medium} {
    font-size: 5rem;
    line-height: 5.5rem;
  }
`,xG=c`
  min-height: calc(100vh - var(--total-header-height));
  min-height: calc(100dvh - var(--total-header-height));
`;var Qte=c`
  max-width: 500px;
  width: 80%;
`,jc=()=>{let{formatMessage:e}=(0,vG.useContext)(qe),t=e({id:"noMatch.title",defaultMessage:"Well, this is awkward!"}),o=e({id:"noMatch.subtitle",defaultMessage:"We could not find what you were looking for."});return x("div",{className:h(Pe(SG),hG,xG),"data-testid":"mwp-404-page",children:[i("h1",{className:CG,children:t}),i("h2",{children:o}),i("img",{className:Qte,src:"/images/404.png",alt:"404 Ghost Image"})]})};jc.displayName="NoMatchDefault";var qte=E`
  fragment Custom404 on Slug {
    ...ContentfulSysId
    page {
      ...ExperimentOnPageLoadingPageShallow
    }
  }
  ${ig("Page","PageShallow",vf)}
  ${O}
`,IG=E`
  query Custom404CollectionQuery($preview: Boolean!, $locale: String!) {
    slugCollection(preview: $preview, locale: $locale, where: { slug: "not-found" }, limit: 1) {
      items {
        ...Custom404
      }
    }
  }
  ${qte}
`;var Zn=()=>{let{staticContext:e}=(0,kG.useContext)(kr),{data:t}=se(IG),{decideExperiment:o}=nn();if(e&&(e.statusCode=404),!t)return null;let n=t.slugCollection.items?.[0]?.page;if(!n)return i(jc,{});if(n.__typename==="Page")return i("section",{className:h(Cf,Ll,xf),"data-testid":"mwp-404-page",children:i(Vl,{...n})});let a=o(n,{logImpression:!0});return i(Eo.Provider,{value:{isShareable:!1,replacements:a.replacements},children:i("section",{"data-testid":"mwp-404-page",children:i(Vl,{...a.decision})})})};Zn.displayName="NoMatch";function Tf(e){switch(e){case"sandbox":return void 0;default:return{}}}var dI=({match:e})=>{let t=Tf(V.site)[e.params.name];return t?i(Oi,{component:t}):i(Zn,{})};dI.displayName="ContentlessPreview";var nxt=E`
  query AllPageSideNavQuery($preview: Boolean!, $locale: String!, $limit: Int, $skip: Int) {
    slugCollection(
      limit: $limit
      skip: $skip
      preview: $preview
      locale: $locale
      where: { page_exists: true }
    ) {
      total
      items {
        ...ContentfulSysId
        slug
        page {
          ...ExperimentOnPageLoadingPageNavigationShallow
        }
        unlistedCriteria {
          ...CriteriaAll
        }
      }
    }
  }
  ${O}
  ${ti("Page","PageNavigationShallow",rG)}
`;var Gl=T(w());var uI=E`
  fragment NavigationItemLink on NavigatorItem {
    ...ContentfulSysId
    title {
      json
    }
    url
    hideCriteria {
      ...CriteriaAll
    }
    analytics {
      ...AnalyticsAll
    }
  }
  ${O}
  ${Xt}
  ${bo.all}
`;var Kte={all:E`
    fragment SideNavigationAll on SideNavigation {
      ...ContentfulSysId
      brandBackgroundColor
      backgroundColor
      brandBackgroundColorMobile
      mobileBackgroundColor
      navigatorItemsCollection(limit: 14) {
        items {
          ...NavigationItemLink
          navigatorItemsCollection(limit: 15) {
            items {
              ...NavigationItemLink
            }
          }
        }
      }
    }
    ${uI}
  `},TG=E`
  query SideNavigationQuery($preview: Boolean!, $locale: String!, $id: String!) {
    sideNavigation(preview: $preview, locale: $locale, id: $id) {
      ...SideNavigationAll
    }
  }
  ${Kte.all}
`;var yI=T(Hr());var _G=T(w());var AG=c`
  ${H} {
    & > * {
      position: sticky;
      top: var(--total-header-height);
    }
  }

  ${N} {
    position: sticky;
    top: var(--total-header-height);
  }
`;var jte=({navigatorItemsCollection:e,brandBackgroundColor:t,backgroundColor:o,brandBackgroundColorMobile:n,mobileBackgroundColor:a,sys:s})=>{let l=it(t),p=it(n),{checkCriteria:d}=nn(),{isUrlCurrent:u}=ug(),y=b=>d(b.hideCriteria),m=e.items.filter(y).map(b=>{let{titleDataset:S}=Fe({entryId:b.sys.id,fieldIds:["title"]});return{title:b.title?(0,yI.documentToPlainTextString)(b.title.json):"",links:(b.navigatorItemsCollection?.items??[]).filter(y).map(C=>{let{titleDataset:v}=Fe({entryId:C.sys.id,fieldIds:["title"]});return{title:C.title?(0,yI.documentToPlainTextString)(C.title.json):"",url:C.url??"",dataset:v}}),dataset:S}}),{contentfulDescriptionDataset:g}=Fe({entryId:s.id,fieldIds:["contentfulDescription"]}),f=(0,_G.useContext)(be).elementLocation;return i(AS,{className:AG,items:m,isUrlCurrent:u,dataset:g,motifScheme:l,motifSchemeMobile:p,backgroundColor:o,mobileBackgroundColor:a,onSectionClick:(b,S)=>{ge({eventCategory:"SideNavigation",eventAction:S?"Open":"Close",eventLabel:null,context:{elementText:b,elementLocation:f}})}})},mI=e=>{let t=lo(e)?e.sys.id:void 0,{data:o}=se(TG,{skip:!t,variables:{id:t}});return o?i(jte,{...o.sideNavigation}):null};mI.displayName="SideNavigation";var wG={"latest-dev":0,staging:1,production:2};function DG(e){let t=V.contentlessComponentsBySlug?.[e];if(!t||wG[V.deploymentType]>wG[t.applyUpTo])return;let o=Tf(V.site)[t.component];return o?{component:o,placement:t.placement}:void 0}var Af=T(w());var Yte=c`
  padding: 20px;
`,Ol=({path:e,newTab:t,isPermanent:o})=>{let{onRedirect:n}=(0,Af.useContext)(ee);return V.isClient||n?.(e,{isPermanent:o,newTab:t}),(0,Af.useEffect)(()=>{n?.(e,{isPermanent:o,newTab:t})},[n,e,t,o]),x("section",{className:Yte,children:["Redirecting to ",i("a",{href:e,children:e}),"."]})};var gI=E`
  fragment Redirect on Redirect {
    ...ContentfulSysId
    externalUrl
    isPermanent
    slug {
      sys {
        id
      }
      slug
    }
  }
  ${O}
`,PG=E`
  fragment SiteMapRedirect on Redirect {
    ...ContentfulSysId
  }
  ${O}
`;var NG=E`
  fragment Slug on Slug {
    sys {
      id
      publishedAt
      firstPublishedAt
    }
    __typename
    slug
    postedDate
    page {
      ...PageAssetAll
      ...ExperimentOnPageLoadingPageShallow
      ...ExperimentOnRedirectLoadingRedirect
      ...Redirect
    }
    unlistedCriteria {
      ...CriteriaAll
    }
    shareable
    ...BreadcrumbsAll
    topicsCollection {
      items {
        ...TopicAll
      }
    }
  }
  ${ig("Page","PageShallow",vf)}
  ${ti("Redirect","Redirect",gI)}
  ${O}
  ${_l}
  ${gI}
  ${Qv}
  ${Hg}
`,ovt=E`
  fragment SiteMapSlug on Slug {
    sys {
      id
      firstPublishedAt
    }
    __typename
    postedDate
    slug
    page {
      ...SiteMapPage
      ...SiteMapExperiment
      ...SiteMapRedirect
    }
    unlistedCriteria {
      ...CriteriaAll
    }
  }
  ${iG}
  ${y8}
  ${PG}
  ${Xt}
`;var EG=E`
  query SlugCollectionQuery($preview: Boolean!, $locale: String!, $slug: String!) {
    slugCollection(preview: $preview, locale: $locale, where: { slug: $slug }, limit: 1) {
      total
      items {
        ...Slug
      }
    }
  }
  ${NG}
`;var Xte="/404",fI=e=>{let{decideExperiment:t}=nn(),{data:o}=se(EG,{variables:{slug:e.slug}}),n=DG(e.slug);if(!o)return null;let a=Ki(o?.slugCollection.items),s=a?.page,l,p;if(s?.__typename==="Experiment"){let f=t(s,{logImpression:!0});if(V.isClient){let b=document.getElementsByTagName("main")[0];f?.experimentId&&b.setAttribute("data-experiment-id",f.experimentId),f.variantId&&b.setAttribute("data-experiment-arm-id",f.variantId)}l=f.decision,p=f.replacements}else l=s;if(!l||!a)return n?i(Oi,{component:n.component}):(ot({eventCategory:"NoMatch",eventAction:"404-redirect",eventLabel:e.slug,subscribedEventType:"internal"}),i(Ol,{path:Xte}));if(l.__typename==="PageAsset")return l.media?.url?i(Ol,{path:l.media.url,newTab:!1}):i(Zn,{});if(l.__typename==="Redirect")return ot({eventCategory:"Redirect",eventAction:"page-redirect",eventLabel:l.slug?.slug??l.externalUrl??null,subscribedEventType:"internal"}),l.slug?.slug?l.slug.slug==="home"?i(Ol,{path:"",newTab:!1,isPermanent:l.isPermanent}):i(Ol,{path:`/${l.slug.slug}`,newTab:!1,isPermanent:l.isPermanent}):l.externalUrl?i(Ol,{path:l.externalUrl,newTab:!1,isPermanent:l.isPermanent}):i(Zn,{});let d;a.sys.publishedAt&&(d=new Date(a.sys.publishedAt));let u=a.postedDate??a.sys.firstPublishedAt,y=u?new Date(u):void 0,m={slug:a.slug,breadcrumbText:a.breadcrumbText,slugParent:a.slugParent},g=TO(m);return x(pe,{children:[g&&i(Mt,{children:i("script",{type:"application/ld+json",children:JSON.stringify(g)})}),i(Eo.Provider,{value:{publishedAt:d,postedDate:y,isShareable:a.shareable??!1,replacements:p,breadcrumbData:m,topics:a.topicsCollection?.items,slugId:a.sys.id},children:i(Vl,{...l,contentless:n})})]})};fI.displayName="SlugCollection";var RG=E`
  query PagesWithSubOrSideNavQuery($preview: Boolean!) {
    pageCollection(
      locale: "en-US" # Always en-US because "linkedFrom" do not work in other languages.
      preview: $preview
      where: { sideNavigation_exists: true }
      limit: 500
    ) {
      total
      items {
        sideNavigation {
          ...ContentfulSysId
        }
        linkedFrom {
          entryCollection {
            total
            items {
              ...ContentfulSysId
              ... on Slug {
                slug
              }
            }
          }
        }
        ...ContentfulSysId
      }
    }
  }
  ${O}
`,FG=E`
  query ExperimentsByIdsLinkingToSlugsQuery($preview: Boolean!, $ids: [String]!) {
    experimentCollection(
      locale: "en-US" # Always en-US because "linkedFrom" do not work in other languages.
      preview: $preview
      where: { sys: { id_in: $ids } }
      limit: 500
    ) {
      total
      items {
        ...ContentfulSysId
        linkedFrom {
          entryCollection {
            total
            items {
              ...ContentfulSysId
              ... on Slug {
                slug
              }
            }
          }
        }
      }
    }
  }
  ${O}
`;function BG(){let e=new Map,t=new Map,o=new Map,n=new Map,{data:a}=se(RG);for(let p of a?.pageCollection.items??[])for(let d of p.linkedFrom.entryCollection.items)if(d)switch(d.__typename){case"Experiment":{p.sideNavigation&&o.set(d.sys.id,p.sideNavigation),p.subNavigation&&n.set(d.sys.id,p.subNavigation);break}case"Slug":{d.slug&&p.sideNavigation&&e.set(d.slug,p.sideNavigation),d.slug&&p.subNavigation&&t.set(d.slug,p.subNavigation);break}}let s=new Set([...o.keys(),...n.keys()]),{data:l}=se(FG,{variables:{ids:[...s]},skip:s.size===0});for(let p of l?.experimentCollection.items??[])for(let d of p.linkedFrom.entryCollection.items)if(d.__typename==="Slug"&&d.slug){let u=o.get(p.sys.id);u&&e.set(d.slug,u);let y=n.get(p.sys.id);y&&t.set(d.slug,y)}return{sideNavMap:e,subNavMap:t}}var LG=()=>{let e=zt(),t=e.pathname.substring(1),o=rf(e.pathname),n=vt(),a=(void 0)?.[o],s=n.homeRedirect==="true";(0,Gl.useEffect)(()=>{if(s&&t==="home"&&V.isClient){let b=new URL(window.location.href);b.pathname="",window.history.replaceState(null,"",b)}},[t,s]),(0,Gl.useEffect)(()=>{window.scrollTo(0,0)},[o]);let{sideNavMap:l,subNavMap:p}=BG(),d=l.has(o),u=l.get(o)?.sys.id,y=p.has(o),m=p.get(o)?.sys.id,{setHasSideNav:g,setHasSubNav:f}=(0,Gl.useContext)(on);return(0,Gl.useEffect)(()=>{g?.(d),f?.(y)},[d,y,g,f]),u&&m&&Vr({component:"Slug",message:"Having both a SideNav and a SubNav isn't supported.",context:{slug:o}}),x("div",{"data-testid":"mwp-slug",className:h(Cf,Ll,xf,{[tG]:d}),style:a?{maxWidth:a}:void 0,children:[u&&i(be.Provider,{value:{elementLocation:"SideNavigation"},children:i(mI,{sys:{id:u}})}),i(fI,{slug:o},o)]})};var _f=T(w());var Jte=Lt.White,HG=c`
  padding-top: 0;
`,VG=({cookieDomain:e,deploymentType:t,domainName:o,isClient:n,backgroundColor:a=Jte,globalPrivacyControl:s})=>{(0,_f.useEffect)(()=>{window.scrollTo(0,0)},[]);let{store:l}=(0,_f.useContext)(Kt);t!=="production"&&(o="",e="");let p=V.site==="stinson",u=vt().submitShopifyTrackingConsent==="true",y=o===e||o===`www.${e}`,m=a===Lt.Black?"Black":"White";return y?n?i(ao,{backgroundColor:a,className:HG,children:i(mC,{cookieDomain:e,backgroundType:m,onSubmit:g=>{l&&u&&Lm({cookieAcceptance:g.cookieAcceptance,store:l,saleOfData:!s}).catch(f=>Re({component:"CookieSettings",error:f}))}})}):p?i(ao,{backgroundColor:a,className:HG}):null:i(jc,{})};var Wt=T(w());var OG=c`
  align-items: center;
  display: flex;
  flex-direction: column;
  padding-block: ${r("--spacing-xl")} 128px;
  width: 100%;
`,GG=c`
  margin-block-end: ${r("--spacing-xs")};
`,zG=c`
  ${ut}
  margin-block-end: ${r("--spacing-l")};
`,UG=c`
  width: 268px;
  max-width: 90%;
`;var bI=()=>x("div",{className:OG,children:[i("h4",{className:GG,children:i(Ln,{id:"searchNotFoundTitle",defaultMessage:"Sorry, no results were found"})}),i("p",{className:zG,children:i(Ln,{id:"searchNotFoundSubtitle",defaultMessage:"Please try again with a different keyword."})}),i("img",{alt:"confused ghost logo",src:"/images/404.png",className:UG})]});bI.displayName="NoResultsFound";var WG="query",QG="offset",qG="page",KG="locale";var jG=c`
  margin-block: 0 ${r("--spacing-xxs")};
`,YG=c`
  border-radius: ${r("--spacing-xxxs")};
  color: ${r("--action-text-default-color")};
  text-decoration: none;

  @media (hover: hover) {
    &:hover {
      color: ${r("--action-text-hover-color")};
      text-decoration-thickness: ${r("--spacing-xxxs")};
      text-decoration: underline;
      text-underline-offset: ${r("--spacing-xxxs")};
    }
  }
`,XG=c`
  ${ut}
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 4;
  color: ${r("--fg-color")};
  display: -webkit-box;
  hyphens: auto;
  overflow: hidden;
  text-overflow: ellipsis;
  word-break: break-word;
  word-wrap: break-word;

  ${H} {
    -webkit-line-clamp: 2;
  }

  & strong {
    font-weight: 600;
  }
`;var Zte=e=>{let t=/<em>(.*?)<\/em>/gi;return e.split(t).map((n,a)=>a%2===1?i("strong",{children:n},a):n)},SI=({description:e,pageTitle:t,slug:o,onClick:n})=>x("article",{className:"sdsm-search",children:[i("h6",{className:jG,children:i(yn,{href:o,className:YG,onClick:n,children:t})}),e&&i("p",{className:XG,children:Zte(e)})]});SI.displayName="SearchResultItem";var Yc=T(w());function JG(e,t,o=1,n=20){let a=(0,Yc.useRef)([]),s=(0,Yc.useRef)(0),l={results:[],total:0},p=l,d=(0,Yc.useMemo)(()=>{let b=new URLSearchParams,S=Math.max(0,(o-1)*n);return b.append(WG,e??""),b.append(KG,t),b.append(QG,`${S}`),b.append(qG,`${n}`),b},[e,t,o,n]),y=`${V.isClient?"":`http://localhost:${process.env.PORT??3e3}`}/api/search?${d}`,{data:m,isLoading:g,error:f}=an({dataId:`/api/search?${d}`,dataAsync:async()=>{if(!e)return l;let b=await fetch(y);if(!b.ok){let C=await b.text();throw new Error(C)}return await b.json()}});return f&&Me.logError({component:"useSearchResults",message:"Error loading search results",error:f}),m&&(a.current=m.results,s.current=m.total,p=m),{data:g?{results:a.current,total:s.current}:p,isLoading:g,isErrored:!!f}}var ZG=c`
  padding-block: ${r("--spacing-xl")};
  margin-inline: auto;
  max-width: ${r("--search-container-max-width")};
  padding-inline: ${r("--spacing-xl")};
  width: 100%;
  min-height: calc(100vh - ${64}px);
  min-height: calc(100dvh - ${64}px);

  ${N} {
    margin-block: ${r("--spacing-xxxl")};
  }
`,ez=c`
  margin-block-end: ${r("--spacing-xxxl")};

  ${N} {
    margin-block-end: ${r("--spacing-xl")};
  }
`,tz=c`
  ${qt};
  color: ${r("--search-subtitle-color")};
  margin-block-start: ${r("--spacing-s")};
`,oz=c`
  margin-block-end: ${r("--spacing-xxxl")};

  ${N} {
    margin-block-end: ${r("--spacing-xl")};
  }
`,nz=c`
  display: flex;
  flex-wrap: wrap;
  gap: ${r("--search-results-list-gap")};
  list-style: none;
  > li {
    width: 100%;
  }
`,rz=c`
  display: flex;
  justify-content: center;
`;var az=20,eoe=250,toe=1e3,ooe=e=>e.map(o=>o.replace(/ ?(\u2063+)/gm,"\u2026").replace(/^\u2026+|\u2026+$/g,"")).join("\u2026 "),noe=e=>{window.requestAnimationFrame(()=>{let t=Number.parseInt(getComputedStyle(document.documentElement).getPropertyValue(Tt),10),o=e?.getBoundingClientRect().top??0,n=window.scrollY;window.scrollTo({top:o+n-(t+20),behavior:"smooth"})})},iz=()=>{let e=Zs(),t=e.get("q")??"",o=Number(e.get("page")??"1"),[n,a]=(0,Wt.useState)(!0);Y("sdsm-search");let{currentLocale:s}=(0,Wt.useContext)(ee),{formatMessage:l}=(0,Wt.useContext)(qe),{getUrlParams:p,setUrlParams:d}=(0,Wt.useContext)(en),u=(0,Wt.useContext)(be).elementLocation,y=(0,Wt.useRef)(null),[m,g]=(0,Wt.useState)(o),[f,b]=(0,Wt.useState)(t),[S,C]=(0,Wt.useState)(f);(0,Wt.useEffect)(()=>{if(f===S)return;let M=setTimeout(()=>{C(f),g(1),a(!0)},eoe);return()=>{clearTimeout(M)}},[f,S]),(0,Wt.useEffect)(()=>{let M=setTimeout(()=>{ot({subscribedEventType:"page_load"})},toe);return()=>{clearTimeout(M)}});let v=JG(S,s,m,az);(0,Wt.useEffect)(()=>{v.isLoading||a(!1)},[v.isLoading]),(0,Wt.useEffect)(()=>{if(!p||!d)return;let M=new URLSearchParams(p());S===(M.get("q")??"")&&m.toString()===M.get("page")||(M.set("q",S),M.set("page",`${m}`),d({...Object.fromEntries(M)}))},[s,S,m,p,d]),(0,Wt.useEffect)(()=>{let M=o,_=t;g(M),b(_),C(_)},[o,t]);let k=M=>{let _=M.trimStart();b(_)},I=(0,Wt.useCallback)(M=>{g(M),noe(y.current)},[y.current]),A=n&&v.isLoading&&!v.isErrored,D=!A&&!!v.data.total,B=!A&&!v.data.total;return x(pe,{children:[i(hi,{noIndex:!0}),x("div",{"data-testid":"mwp-search",className:ZG,ref:y,children:[x("div",{className:ez,children:[i(pu,{autocompleteResults:[],collapsible:!1,hideSuggestions:!0,initialText:r0(rp(f)),loadingAutocompleteTerms:!1,onChange:k,onSelect:xo,placeholder:l({id:"placeholderSearchPageInput",defaultMessage:"Search..."})}),v&&i("p",{className:tz,children:i(Ln,{id:"searchResultsSubtitle",defaultMessage:'{total} search results for "{term}"',values:{total:String(v.data.total),term:rp(S)}})})]}),x("div",{className:oz,children:[A&&i("div",{className:rz,children:i(xd,{})}),D&&i("ul",{className:nz,children:v.data.results.map((M,_)=>i("li",{children:i(SI,{description:ooe(M.highlights),pageTitle:M.pageTitle,slug:M.slug,onClick:()=>ge({eventCategory:"SearchResult",eventAction:"Click",eventLabel:M.slug,context:{targetUrl:`/${M.slug}`,elementText:M.pageTitle,elementLocation:u}})})},M.pageTitle+f+_*m))}),B&&i(bI,{})]}),D?i(Mi,{currentPage:m,onChange:I,totalPages:Math.floor((v.data.total-1)/az)+1}):null,!v.isLoading&&i(kf,{})]})]})};var wf=T(w());var sz=c`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: calc(100vh - var(--total-header-height));
  min-height: calc(100dvh - var(--total-header-height));
  img,
  video {
    max-width: 300px;
    border-radius: ${r("--spacing-s")};
  }
`,lz=c`
  border-radius: ${r("--spacing-s")};
  box-shadow: 0 ${r("--spacing-xs")} ${r("--spacing-xl")} 0 rgba(0, 0, 0, 0.16);
  border: ${r("--spacing-s")} solid #fff;
`;var roe=["mp4","mov"],aoe="https://storage.googleapis.com/ad-manager-political-ads-dump-shadow",pz=({match:e})=>{let t=e?.params.assetId,{getCurrentUrl:o}=(0,wf.useContext)(ee),[n,a]=(0,wf.useState)(!1);if(zo(()=>{ot({subscribedEventType:"page_load"})},[t]),!t)return i(Zn,{});let s=o(),p=new URL(s).searchParams.get("mediaType"),d=`${aoe}/${t}.${p}`,u=()=>{Re({component:"PoliticalAdsAsset",action:"Loading asset failed"}),a(!0)};if(n)return i(Zn,{});let y=roe.includes(p||"")?i("video",{src:d,autoPlay:!0,controls:!0,onError:u}):i("img",{src:d,onError:u,alt:"ad"});return i("article",{className:sz,children:i("section",{className:lz,children:y})})};var cz=({globalPrivacyControl:e})=>{let t=zt(),o=na(),a=vt().enableSiteSearch==="true";return(0,hI.useEffect)(()=>{if(!t.hash)return;let l=setTimeout(()=>{document.getElementById(t.hash.slice(1))?.scrollIntoView({behavior:"smooth"})},1e3);return()=>{clearTimeout(l)}},[]),(0,hI.useEffect)(()=>o.listen(p=>{if(!p.hash)return;document.getElementById(p.hash.slice(1))?.scrollIntoView({behavior:"smooth"})}),[o.listen]),x(OC,{children:[i(Wa,{exact:!0,path:v0,render:()=>i(VG,{backgroundColor:V.theme?.defaultPageBackgroundColor,cookieDomain:V.trackingSettings.cookieDomain,deploymentType:V.deploymentType,domainName:V.domainName,isClient:V.isClient,globalPrivacyControl:e})}),a&&i(Wa,{exact:!0,path:"/search",component:iz}),V.site==="snap"&&i(Wa,{path:"/political-ads/asset/:assetId",component:pz}),i(Wa,{path:"/404",component:Zn}),!V.isDeploymentTypeProd&&i(Wa,{exact:!0,path:"/preview/contentless/:name",component:dI}),i(Wa,{path:"*",component:LG})]})};var dz=()=>{switch(V.site){case"arcadia":return;case"avalon":return;case"cheerios":return;default:return DM}};function fz(){switch(V.site){case"arcadia":return void 0;case"avalon":return void 0;case"cheerios":return void 0;case"careers":case"citizen":case"diversity":case"eng-blog":case"experience":case"newsroom":case"snap":case"trust":return bg;case"stinson":return void 0;default:return Yi}}var ii,Jc,Az,Pf,II,_z=-1,Ul=function(e){addEventListener("pageshow",(function(t){t.persisted&&(_z=t.timeStamp,e(t))}),!0)},wz=function(){return window.performance&&performance.getEntriesByType&&performance.getEntriesByType("navigation")[0]},kI=function(){var e=wz();return e&&e.activationStart||0},Nr=function(e,t){var o=wz(),n="navigate";return _z>=0?n="back-forward-cache":o&&(document.prerendering||kI()>0?n="prerender":document.wasDiscarded?n="restore":o.type&&(n=o.type.replace(/_/g,"-"))),{name:e,value:t===void 0?-1:t,rating:"good",delta:0,entries:[],id:"v3-".concat(Date.now(),"-").concat(Math.floor(8999999999999*Math.random())+1e12),navigationType:n}},Wl=function(e,t,o){try{if(PerformanceObserver.supportedEntryTypes.includes(e)){var n=new PerformanceObserver((function(a){Promise.resolve().then((function(){t(a.getEntries())}))}));return n.observe(Object.assign({type:e,buffered:!0},o||{})),n}}catch{}},Er=function(e,t,o,n){var a,s;return function(l){t.value>=0&&(l||n)&&((s=t.value-(a||0))||a===void 0)&&(a=t.value,t.delta=s,t.rating=(function(p,d){return p>d[1]?"poor":p>d[0]?"needs-improvement":"good"})(t.value,o),e(t))}},MI=function(e){requestAnimationFrame((function(){return requestAnimationFrame((function(){return e()}))}))},Ef=function(e){var t=function(o){o.type!=="pagehide"&&document.visibilityState!=="hidden"||e(o)};addEventListener("visibilitychange",t,!0),addEventListener("pagehide",t,!0)},TI=function(e){var t=!1;return function(o){t||(e(o),t=!0)}},zl=-1,bz=function(){return document.visibilityState!=="hidden"||document.prerendering?1/0:0},Nf=function(e){document.visibilityState==="hidden"&&zl>-1&&(zl=e.type==="visibilitychange"?e.timeStamp:0,ioe())},Sz=function(){addEventListener("visibilitychange",Nf,!0),addEventListener("prerenderingchange",Nf,!0)},ioe=function(){removeEventListener("visibilitychange",Nf,!0),removeEventListener("prerenderingchange",Nf,!0)},AI=function(){return zl<0&&(zl=bz(),Sz(),Ul((function(){setTimeout((function(){zl=bz(),Sz()}),0)}))),{get firstHiddenTime(){return zl}}},Rf=function(e){document.prerendering?addEventListener("prerenderingchange",(function(){return e()}),!0):e()},hz=[1800,3e3],soe=function(e,t){t=t||{},Rf((function(){var o,n=AI(),a=Nr("FCP"),s=Wl("paint",(function(l){l.forEach((function(p){p.name==="first-contentful-paint"&&(s.disconnect(),p.startTime<n.firstHiddenTime&&(a.value=Math.max(p.startTime-kI(),0),a.entries.push(p),o(!0)))}))}));s&&(o=Er(e,a,hz,t.reportAllChanges),Ul((function(l){a=Nr("FCP"),o=Er(e,a,hz,t.reportAllChanges),MI((function(){a.value=performance.now()-l.timeStamp,o(!0)}))})))}))},Cz=[.1,.25],Dz=function(e,t){t=t||{},soe(TI((function(){var o,n=Nr("CLS",0),a=0,s=[],l=function(d){d.forEach((function(u){if(!u.hadRecentInput){var y=s[0],m=s[s.length-1];a&&u.startTime-m.startTime<1e3&&u.startTime-y.startTime<5e3?(a+=u.value,s.push(u)):(a=u.value,s=[u])}})),a>n.value&&(n.value=a,n.entries=s,o())},p=Wl("layout-shift",l);p&&(o=Er(e,n,Cz,t.reportAllChanges),Ef((function(){l(p.takeRecords()),o(!0)})),Ul((function(){a=0,n=Nr("CLS",0),o=Er(e,n,Cz,t.reportAllChanges),MI((function(){return o()}))})),setTimeout(o,0))})))},Xc={passive:!0,capture:!0},loe=new Date,xz=function(e,t){ii||(ii=t,Jc=e,Az=new Date,Nz(removeEventListener),Pz())},Pz=function(){if(Jc>=0&&Jc<Az-loe){var e={entryType:"first-input",name:ii.type,target:ii.target,cancelable:ii.cancelable,startTime:ii.timeStamp,processingStart:ii.timeStamp+Jc};Pf.forEach((function(t){t(e)})),Pf=[]}},poe=function(e){if(e.cancelable){var t=(e.timeStamp>1e12?new Date:performance.now())-e.timeStamp;e.type=="pointerdown"?(function(o,n){var a=function(){xz(o,n),l()},s=function(){l()},l=function(){removeEventListener("pointerup",a,Xc),removeEventListener("pointercancel",s,Xc)};addEventListener("pointerup",a,Xc),addEventListener("pointercancel",s,Xc)})(t,e):xz(t,e)}},Nz=function(e){["mousedown","keydown","touchstart","pointerdown"].forEach((function(t){return e(t,poe,Xc)}))},vz=[100,300],Ez=function(e,t){t=t||{},Rf((function(){var o,n=AI(),a=Nr("FID"),s=function(d){d.startTime<n.firstHiddenTime&&(a.value=d.processingStart-d.startTime,a.entries.push(d),o(!0))},l=function(d){d.forEach(s)},p=Wl("first-input",l);o=Er(e,a,vz,t.reportAllChanges),p&&Ef(TI((function(){l(p.takeRecords()),p.disconnect()}))),p&&Ul((function(){var d;a=Nr("FID"),o=Er(e,a,vz,t.reportAllChanges),Pf=[],Jc=-1,ii=null,Nz(addEventListener),d=s,Pf.push(d),Pz()}))}))},Rz=0,CI=1/0,Df=0,coe=function(e){e.forEach((function(t){t.interactionId&&(CI=Math.min(CI,t.interactionId),Df=Math.max(Df,t.interactionId),Rz=Df?(Df-CI)/7+1:0)}))},Fz=function(){return II?Rz:performance.interactionCount||0},doe=function(){"interactionCount"in performance||II||(II=Wl("event",coe,{type:"event",buffered:!0,durationThreshold:0}))},Iz=[200,500],Bz=0,kz=function(){return Fz()-Bz},Pr=[],xI={},Mz=function(e){var t=Pr[Pr.length-1],o=xI[e.interactionId];if(o||Pr.length<10||e.duration>t.latency){if(o)o.entries.push(e),o.latency=Math.max(o.latency,e.duration);else{var n={id:e.interactionId,latency:e.duration,entries:[e]};xI[n.id]=n,Pr.push(n)}Pr.sort((function(a,s){return s.latency-a.latency})),Pr.splice(10).forEach((function(a){delete xI[a.id]}))}},$z=function(e,t){t=t||{},Rf((function(){var o;doe();var n,a=Nr("INP"),s=function(p){p.forEach((function(y){y.interactionId&&Mz(y),y.entryType==="first-input"&&!Pr.some((function(m){return m.entries.some((function(g){return y.duration===g.duration&&y.startTime===g.startTime}))}))&&Mz(y)}));var d,u=(d=Math.min(Pr.length-1,Math.floor(kz()/50)),Pr[d]);u&&u.latency!==a.value&&(a.value=u.latency,a.entries=u.entries,n())},l=Wl("event",s,{durationThreshold:(o=t.durationThreshold)!==null&&o!==void 0?o:40});n=Er(e,a,Iz,t.reportAllChanges),l&&("PerformanceEventTiming"in window&&"interactionId"in PerformanceEventTiming.prototype&&l.observe({type:"first-input",buffered:!0}),Ef((function(){s(l.takeRecords()),a.value<0&&kz()>0&&(a.value=0,a.entries=[]),n(!0)})),Ul((function(){Pr=[],Bz=Fz(),a=Nr("INP"),n=Er(e,a,Iz,t.reportAllChanges)})))}))},Tz=[2500,4e3],vI={},Lz=function(e,t){t=t||{},Rf((function(){var o,n=AI(),a=Nr("LCP"),s=function(d){var u=d[d.length-1];u&&u.startTime<n.firstHiddenTime&&(a.value=Math.max(u.startTime-kI(),0),a.entries=[u],o())},l=Wl("largest-contentful-paint",s);if(l){o=Er(e,a,Tz,t.reportAllChanges);var p=TI((function(){vI[a.id]||(s(l.takeRecords()),l.disconnect(),vI[a.id]=!0,o(!0))}));["keydown","click"].forEach((function(d){addEventListener(d,(function(){return setTimeout(p,0)}),!0)})),Ef(p),Ul((function(d){a=Nr("LCP"),o=Er(e,a,Tz,t.reportAllChanges),MI((function(){a.value=performance.now()-d.timeStamp,vI[a.id]=!0,o(!0)}))}))}}))};var Hz=()=>{let e="WebVitals";Dz(t=>Ma({eventValue:t.value,eventLabel:window.location.pathname,eventVariable:"cumulative_layout_shift",eventCategory:e})),Ez(t=>Or({eventValue:t.value,eventLabel:window.location.pathname,eventVariable:"first_input_delay",eventCategory:e})),Lz(t=>Or({eventValue:t.value,eventLabel:window.location.pathname,eventVariable:"largest_contentful_paint",eventCategory:e})),$z(t=>{Or({eventValue:t.value,eventLabel:window.location.pathname,eventVariable:"interaction_to_next_paint",eventCategory:e})})};function Vz(e){let t=e.getLowEntropyHints(),o=t.browsers[0]?.majorVersion;return{isMobile:t.isMobile,brand:t.browsers[0]?.brand,brandVersion:o?String(o):void 0,platform:t.platform}}var uoe=({onHistory:e})=>{let t=na();return e?.(t),null},Gz=({getCurrentUrl:e,currentLocale:t,supportedLocales:o,routerContext:n,userLocation:a,shopifyData:s,helmetContext:l,pageLayoutContext:p,apolloClient:d,globalApolloClient:u,siteData:y,browserFeatures:m,onRedirect:g,onHistory:f,asyncDataController:b,globalPrivacyControl:S,cookieManager:C,getUserInfo:v,getPersona:k,createUuidV4:I,singleCallbackCache:A,onHlsVideo:D,initialPersonas:B,updatePersonas:M})=>{let _=No().startSpan("appRender"),P=new URL(e()),$;V.isClient?$=({children:j})=>x(V5,{children:[i(uoe,{onHistory:f}),j]}):$=({children:j})=>i(VC,{location:P.pathname,context:n,children:j}),$.displayName="Router",m.getHighEntropyHintsAsync({hints:["connection","reduceMotion"]});let R=Vz(m),L=Hm(t)==="rtl";Br(()=>{let j=()=>{let fe=new URL(e());return{locale:t,url:fe,hostname:fe.hostname,userAgentHints:R,uaBrand:R?.brand,uaPlatform:R?.platform,path:fe.pathname,userCountry:a.country,isRtl:L}};return Me.addContextProvider(j),()=>Me.removeContextProvider(j)},[t,P,L,R,a.country]),(0,Rn.useEffect)(()=>{Hz()},[t,e,L,P.hostname,P.pathname,R,a.country]);let G={supportedLocales:o,currentLocale:o[t??as.currentLocale].code,logEvent:({type:j,label:fe,url:J,component:ue})=>{j&&(fe||J)&&ot({subscribedEventType:"user_interaction",eventCategory:ue??"CTA",eventAction:j,eventLabel:fe??(J?`to: ${J}`:null)})},isUrlCurrent:WC(e),getUrlParams:()=>{let j=new URL(e()).search;return nL(j)},setUrlParams:j=>{if(!V.isClient)return;let{pathname:fe}=window.location,J=oL(j),ue=`${fe}?${J}`;window.history.pushState(null,"",ue)}};if(at.displayName!=="GlobalHeaderContextSDSM")throw new Error("Duplicate SDS-M packages found. See https://jira.sc-corp.net/browse/ENTWEB-4284");let Z={onError:j=>{Re({component:"GlobalComponents",error:j instanceof Error?j:void 0,message:typeof j=="string"?j:void 0})},Anchor:yn,currentLocale:t,isPreview:V.isPreview,isSSR:V.isSSR,hostname:V.domainName,onEvent:({component:j,action:fe,label:J,url:ue})=>{ot({subscribedEventType:"user_interaction",event:Pc,eventCategory:j??"GlobalComponent",eventAction:fe,eventLabel:J??(ue?`to: ${ue}`:"generic")}),ue&&!un(new URL(ue,e()))&&Me.flush()},supportedLocales:o,onLocaleChange:j=>{let fe=new URL(window.location.href);fe.searchParams.set("lang",j),window.location.replace(fe)},isUrlCurrent:WC(e),globalApolloClient:u},[U,de]=(0,Rn.useState)(y),le=(0,Rn.useRef)(null),re=(0,Rn.useRef)(null),te=(0,Rn.useRef)(null),ae=(0,Rn.useRef)(null),oe=(0,Rn.useRef)(B),q={currentLocale:t,supportedLocales:o,userLocation:a,getCurrentUrl:e,isRTL:L,siteData:U,setSiteData:de,headerPortalRef:le,pageBottomStickyPortalRef:re,pageFixedPortalRef:te,appPortalRef:ae,onRedirect:g,cookieManager:C,getUserInfo:v,getPersona:k,createUuidV4:I,onHlsVideo:D,personasRef:oe,updatePersonas:j=>{V.isClient||M?.(j),oe.current=j}},X=t6(t,P.searchParams),W=I0(V.domainName,V.trackingSettings.cookieDomain),K=fz(),F=dz(),Q=F?RM(t,K,F):K,z={...e0,Anchor:yn};V.globalStyles&&dk(V.globalStyles);let Se=i(Rn.StrictMode,{children:i(Cg,{tracer:No(),children:i($,{children:i(Pi.Provider,{value:X,children:i(n6,{children:i(Kl,{client:d,children:i(ib.Provider,{value:{controller:b},children:i(en.Provider,{value:G,children:i(He.Provider,{value:z,children:i(uC,{value:Z,children:i(Ze.Provider,{value:m,children:i(Si,{context:l,children:i(Z8,{children:i(ee.Provider,{value:q,children:x(Hx.Provider,{value:A,children:[i(p9,{}),i(u9,{}),i(i9,{}),i(y9,{}),i(ax,{}),i(Kx,{}),i(r6,{}),i(y6,{}),i(C9,{}),i(w9,{}),V.site==="stinson"&&i(void 0,{}),x(M9,{children:[i(T8,{}),i(x9,{sessionValue:p,children:i(qC,{shopifyData:s,children:i(Pm,{children:x(S9,{motif:Q,tag:"section",children:[i(be.Provider,{value:{elementLocation:"Header"},children:i(K8,{config:V})}),i(jx,{}),i(be.Provider,{value:{elementLocation:"Page"},children:i(cz,{globalPrivacyControl:S})}),i(G5,{}),i(be.Provider,{value:{elementLocation:"Footer"},children:i(k8,{cookieSettingsUrl:W})}),i(i6,{backgroundColor:V.theme?.defaultPageBackgroundColor,isClient:V.isClient,globalPrivacyControl:S}),V.shopify&&V.site!=="stinson"&&i(tx,{})]})})})})]})]})})})})})})})})})})})})})})});return _.endSpan(),Se};var Ff=class{constructor(){Ae(this,"getCookieJson",t=>{let o=this.getCookie(t);if(o)try{return JSON.parse(o)}catch(n){Re({component:"CookieManager",message:`Error parsing cookie: "${o}"`,error:n});return}});Ae(this,"setCookieJson",(t,o,n)=>{o?this.setCookie(t,JSON.stringify(o),n):this.setCookie(t,"",n)})}};var Bf=class extends Ff{constructor(){super(...arguments);Ae(this,"getCookie",o=>ro.get(o));Ae(this,"setCookie",(o,n,a)=>{ro.set(o,n,a)});Ae(this,"deleteCookie",o=>ro.remove(o))}};var yoe="XXXXXXXX-XXXX-4XXX-YXXX-XXXXXXXXXXXX",moe=()=>{let e=0,t=window.crypto.getRandomValues(new Uint8Array(32));return yoe.replace(/[XY]/g,o=>{let n=t[e++]%16;return o==="X"?n.toString(16):o==="Y"?(n>>2&128).toString(16):"0"})},zz=()=>"randomUUID"in window.crypto?window.crypto.randomUUID():moe();function goe(e){return function(t,o,n){var a=Object(t);if(!ya(t)){var s=Jo(o,3);t=ld(t),o=function(p){return s(a[p],p,a)}}var l=e(t,o,n);return l>-1?a[s?t[l]:l]:void 0}}var Uz=goe;var foe=Math.max,boe=Math.min;function Soe(e,t,o){var n=e==null?0:e.length;if(!n)return-1;var a=n-1;return o!==void 0&&(a=N0(o),a=o<0?foe(n+a,0):boe(a,n-1)),E0(e,Jo(t,3),a,!0)}var Wz=Soe;var hoe=Uz(Wz),Qz=hoe;LU();HU();var Coe="[object String]";function xoe(e){return typeof e=="string"||!Qo(e)&&UI(e)&&VI(e)==Coe}var qz=xoe;var voe=oy("length"),Kz=voe;var Yz="\\ud800-\\udfff",Ioe="\\u0300-\\u036f",koe="\\ufe20-\\ufe2f",Moe="\\u20d0-\\u20ff",Toe=Ioe+koe+Moe,Aoe="\\ufe0e\\ufe0f",_oe="["+Yz+"]",_I="["+Toe+"]",wI="\\ud83c[\\udffb-\\udfff]",woe="(?:"+_I+"|"+wI+")",Xz="[^"+Yz+"]",Jz="(?:\\ud83c[\\udde6-\\uddff]){2}",Zz="[\\ud800-\\udbff][\\udc00-\\udfff]",Doe="\\u200d",eU=woe+"?",tU="["+Aoe+"]?",Poe="(?:"+Doe+"(?:"+[Xz,Jz,Zz].join("|")+")"+tU+eU+")*",Noe=tU+eU+Poe,Eoe="(?:"+[Xz+_I+"?",_I,Jz,Zz,_oe].join("|")+")",jz=RegExp(wI+"(?="+wI+")|"+Eoe+Noe,"g");function Roe(e){for(var t=jz.lastIndex=0;jz.test(e);)++t;return t}var oU=Roe;function Foe(e){return t0(e)?oU(e):Kz(e)}var nU=Foe;var Boe="[object Map]",$oe="[object Set]";function Loe(e){if(e==null)return 0;if(ya(e))return qz(e)?nU(e):e.length;var t=XI(e);return t==Boe||t==$oe?e.size:QI(e).length}var rU=Loe;var Hoe=(e,t)=>{let o=t.url??new URL(window.location.href),n={host:o.host,path:o.pathname,query:JSON.stringify(Object.fromEntries(o.searchParams.entries())),page_locale:t.locale};switch(t.variantId&&(n.experiment_category="Page",n.experiment_group=t.variantId,n.experiment_id=t.experimentId??"None"),e.type){case Te.CUSTOM:{switch(e.subscribedEventType){case"page_load":case"first_page_load":return{event_name:"MARKETING_WEB_PAGE_VIEW",...n,is_landing_page:e.subscribedEventType==="first_page_load"};case"experiment_impression":return{event_name:"MARKETING_WEB_INTERNAL_EVENT",...n,type:"useExperiment",category:"Experiment",label:`${e.experimentId?.replace(/[ _]/,"-")}:${er(e.variantId)}`,element_location:t.elementLocation,element_text:t.elementText,target_url:t.targetUrl};case"ecommerce":return{event_name:"MARKETING_WEB_SHOPIFY_EVENT",...n,type:e.eventAction,category:e.eventCategory,label:e.eventLabel??void 0,element_location:t.elementLocation,element_text:t.elementText,shopify_data:JSON.stringify(e.ecommerce)}}break}case Te.USER_ACTION:return{event_name:"MARKETING_WEB_USER_INTERACTION",...n,type:e.action,category:e.component,label:e.label,element_location:t.elementLocation,element_text:t.elementText,target_url:t.targetUrl};case Te.INFO:return{event_name:"MARKETING_WEB_INTERNAL_EVENT",...n,type:e.action,category:e.component,label:e.label,element_location:t.elementLocation,element_text:t.elementText,target_url:t.targetUrl};case Te.VALUE:return{event_name:"MARKETING_WEB_VALUE_EVENT",...n,metric:e.value,type:e.variable,category:e.component,label:e.label,element_location:t.elementLocation,element_text:t.elementText,target_url:t.targetUrl};case Te.TIMING:return{event_name:"MARKETING_WEB_TIMING_EVENT",...n,duration:e.valueMs,type:e.variable,category:e.component,label:e.label,element_location:t.elementLocation,element_text:t.elementText,target_url:t.targetUrl}}},Voe=(e,t)=>{if(t.pixelId)return{event_name:"MARKETING_WEB_SNAP_PIXEL_EVENT",pixel_id:t.pixelId,triggering_event_name:e.event_name}},Ooe=(e,t)=>{if(t.webClientId)return{event_name:"MARKETING_WEB_CLIENT_ID_EVENT",web_client_id:t.webClientId,triggering_event_name:e.event_name}},$f=new Set;var Zc=(e,t)=>{let o=[],n=Hoe(e,t);if(!n)return o;o.push(n);let a=Voe(n,t);if(a){let l=[a.event_name,a.pixel_id].join(":");$f.has(l)||(o.push(a),$f.add(l))}let s=Ooe(n,t);if(s){let l=[s.event_name,s.web_client_id].join(":");$f.has(l)||(o.push(s),$f.add(l))}return o};var DI=(e,t)=>{let o=t.url??new URL(window.location.href),a={uri_info:JSON.stringify({href:o.href,host:o.host,path:o.pathname,filename:Qz(o.pathname.split("/"),rU)??"",query:Object.fromEntries(o.searchParams.entries())}),experiment_name:t.experimentId,experiment_variation:t.variantId,page_locale:t.locale},s=Zc(e,t);switch(e.type){case Te.CUSTOM:{switch(e.subscribedEventType){case"first_page_load":{s.push({event_name:"FOR_BUSINESS_PAGE_VIEW",...a});break}case"page_load":{s.push({event_name:"FOR_BUSINESS_PAGE_NAVIGATION",...a});break}}break}case Te.USER_ACTION:{s.push({event_name:"FOR_BUSINESS_CLICK",...a,event_category:e.component,event_action:e.action,event_label:e.label,element_location:t.elementLocation,element_text:t.elementText,target_url:t.targetUrl});break}}return s};var aU=new Set([Te.INFO,Te.DEBUG,Te.USER_ACTION,Te.CUSTOM]),iU=e=>{switch(e.type){case Te.TIMING:return"app_measure_event";case Te.VALUE:return"app_measure_event";case Te.ERROR:{if(e.component==="Csp")return"csp_error";if(e.component==="Contentful")return"contentful_error"}}return null},sU=e=>({blockedUri:e.blockedUri,sourceFile:e.sourceFile,violatedDirective:e.violatedDirective,errorCode:e.errorCode,errorName:e.errorName,region:e.region,locale:e.locale,uaBrand:e.uaBrand,uaPlatform:e.uaPlatform}),lU=e=>{if((e.type===Te.TIMING||e.type===Te.VALUE)&&e.component==="NavigationTiming"){let t=ap(e);return t.label="[REDACTED]",t}if(e.type===Te.INFO&&e.component==="PersonaMatch"){let t=ap(e);return t.label="[REDACTED]",t}if((e.type===Te.TIMING||e.type===Te.VALUE)&&e.component==="WebVitals"){let t=ap(e);return t.label="[REDACTED]",t}if(e.type===Te.TIMING&&e.component==="Video"){let t=ap(e);return t.label="[REDACTED]",t}return e};var Goe=["Can't find variable: ResizeObserver","Importing a module script failed.","o.flush is not a function","ResizeObserver loop limit exceeded","Cannot read properties of null (reading 'querySelector')","Form submit failed","Missing fields in LS download form: eula"],zoe=["Refused to evaluate a string as JavaScript because 'unsafe-eval' is not an allowed"];function pU(){return(e,t)=>{let o=e?.exception?.values?.[0]?.stacktrace?.frames,n=e.exception?.values?.[0]?.value??e.message;if(!n&&!o)return e;if(n?.includes("599")||zoe.some(l=>n?.includes(l)))return null;let a=n?.match(/Query execution error\. Link from entry(.*)cannot be resolved/);if(a?.length&&a[0])return e.fingerprint=[a[0]],e;if(n?.includes("Failed to fetch dynamically imported module"))return e.fingerprint=["Failed to fetch dynamically imported module"],e;if(n?.includes("Response closed without headers")&&o?.some(l=>l.module?.includes("@improbable-eng/grpc-web")))return e.fingerprint=["[grpc-web] Response closed without headers"],e;if(n?.includes("Failed to fetch")&&e.request?.url?.includes("download"))return e.fingerprint=["[download] Failed to fetch"],e;let s=e.request?.url??"/";for(let l of Goe)if(n?.includes(l))return e.fingerprint=[s,l],e;return e}}var Uoe="X-Snap-Mwp-Auth",Lf=class extends Dd{constructor(o){super({requiredPermissions:["logging"],filter:o.filter});Ae(this,"props");Ae(this,"events");Ae(this,"timeout");Ae(this,"fetch");Ae(this,"clock");Ae(this,"exportEvents",async()=>{if(this.timeout=void 0,this.events.length===0)return;let o={events:this.getSerializedEvents(),timestamp:this.clock()};this.events=[];try{let n={events:[o.events[0]],timestamp:o.timestamp},a=await Woe(n),s=window.btoa(a),l=await this.fetch("/api/events",{method:"POST",body:JSON.stringify(o),headers:{[Uoe]:s,"Content-Type":"application/json"}});if(!l.ok){let p=await l.text();throw new Error(`Events export request failed - status: ${l.status}, value:${p} `)}}catch(n){this.props.onError?.(Ft(n))}this.ensureTimeout()});Ae(this,"getSerializedEvents",()=>this.events.map(o=>{if(o.event.type!=="error")return o;let n=o.event;return n.message||!n.error||(n.message=Ft(n.error).message),o}));Ae(this,"init",()=>Promise.resolve());Ae(this,"flushInternal",async()=>{this.timeout&&clearTimeout(this.timeout),await this.exportEvents()});this.props=o,this.fetch=o.fetch??En,this.events=[],this.clock=o.clock??Date.now}ensureTimeout(){this.timeout===void 0&&(this.timeout=setTimeout(this.exportEvents,this.props.logTimeIntervalMs))}logEventInternal(o,n){this.events.push({event:o,context:n??{}}),this.ensureTimeout()}};async function Woe(e){let t=typeof e=="string"?e:JSON.stringify(e),n=new TextEncoder().encode(t),a=await window.crypto.subtle.digest("SHA-256",n);return Array.from(new Uint8Array(a)).map(s=>s.toString(16).padStart(2,"0")).join("")}var cU=5e3;function dU(e){return new RegExp(`${e}=([^;]+);`).exec(document.cookie)?.[1]}function Qoe(){return{pixelId:dU("_scid")}}var PI=class{constructor(){Ae(this,"experimentContext",{});Ae(this,"getExperimentContext",()=>this.experimentContext);Ae(this,"allow",()=>Promise.resolve());Ae(this,"deny",()=>Promise.resolve());Ae(this,"flush",()=>Promise.resolve())}logEvent(t,o){t.type===Te.CUSTOM&&t.subscribedEventType==="experiment_impression"&&(t.experimentId?(this.experimentContext.experimentId=t.experimentId,this.experimentContext.variantId=t.variantId):(this.experimentContext.experimentId=void 0,this.experimentContext.variantId=void 0))}},uU=e=>{if(e.isTest||!e.isClient)return;Me.addContextProvider(()=>({region:e.region,buildNumber:e.buildNumber,eventOrigin:"client"}));let t=new PI;Me.addEventListeners(t),Me.addContextProvider(()=>t.getExperimentContext()),Me.addContextProvider(Qoe),Me.addContextProvider(()=>({webClientId:dU("sc-wcid")}));for(let o of e.trackingSettings.eventListeners)switch(o.vendor){case"Graphene":{Me.addEventListeners(new B9({partitionName:o.partitionName,variant:e.site,flavor:e.isDeploymentTypeProd?"production":"development",logTimeInterval:cU,getMetricName:iU,getAdditionalDimensions:sU,filter:n=>!aU.has(n.type),eventRewrite:lU}));break}case"MwpClientEventExport":{if(!e.isCompilationModeProd||!e.isDeploymentTypeProd||!e.buildNumber)break;Me.addEventListeners(new Lf({useAsync:!0,logTimeIntervalMs:cU,onError:n=>console.error(n)}));break}case"GoogleTagManager":{let n=document.querySelector("script[nonce]")?.nonce,a=new xg({useAsync:!0,gtmId:o.googleTagManagerId,nonce:n,initialContext:{locale:e.locale,globalPrivacyControl:e.globalPrivacyControl}});Me.addEventListeners(a);break}case"Blizzard":{let n=o.eventFormat==="ForBusiness"?DI:Zc;Me.addEventListeners(new av({useAsync:!0,isProd:e.isDeploymentTypeProd,cookieDomain:e.trackingSettings.cookieDomain,eventFormatter:n}));break}case"Sentry":{if(!e.isDeploymentTypeProd)break;let n=e.commit?.slice(0,9)??"unknown",a={dsn:o.dsn,tracesSampleRate:1,useAsync:!0,getContext:(s,l)=>({contexts:{location:{userCountry:l.userCountry??"unknown_country",locale:l.locale??"unknown_locale",region:l.region??"unknown_region"}}}),environment:e.deploymentType,release:`${o.projectName}@${n}`,filter(s,l){return!(s.type===Te.ERROR&&s.component==="Csp"||s.type===Te.DEBUG)},beforeSend:pU()};o.allowUrls&&(a.allowUrls=o.allowUrls),Me.addEventListeners(new $9(a));break}case"Console":{Me.addEventListeners(new D9({filter(n,a){return!(n.type===Te.TIMING&&n.component==="Contentful"&&n.variable==="request_duration"&&n.valueMs<1e3)},getFlatContext(n){return{elementLocation:n.elementLocation,elementText:n.elementText,targetUrl:n.targetUrl}},customEventFormatter(n,a){return n.subscribedEventType==="experiment_impression"?!n.experimentId||!n.variantId?null:`Experiment: Impression on ${n.experimentId}.${n.variantId}`:[Vt(n,"type")]}}));break}}};var yU=5e3;function mU(e){let t=e.featureFlags?.disableLazyLoadLogging==="true"||!e.isDeploymentTypeProd,o=performance.now(),n=()=>{Me.allow("logging");let a=performance.now();Me.logTiming({component:"logInit",variable:"allowLogging",valueMs:a-o})};t?setTimeout(n,10):typeof globalThis.requestIdleCallback=="function"?setTimeout(()=>{requestIdleCallback(n,{timeout:yU})},1e3):typeof globalThis.requestAnimationFrame=="function"?setTimeout(()=>{requestAnimationFrame(n)},1e3):setTimeout(n,yU)}function gU(e,t){return V.isDeploymentTypeProd?e:{...e,environmentName:t.get("contentfulEnvironmentName")??e.environmentName}}var MU=T(kU());var NI=(0,MU.default)(async e=>{let t=Vv(e),o=No().startSpan("generateFragmentTypes"),a=await(await En(t.uri,{method:"POST",headers:{Authorization:t.headers?.Authorization??"","Content-Type":"application/json"},body:JSON.stringify({variables:{},query:"{__schema{types{kind name possibleTypes{name}}}}"})})).json();if(!a.data)throw Error(`Schema request failed: ${JSON.stringify(a)}`);let s=rne(a.data);return o.endSpan(),s});function rne(e){let t={};return e.__schema.types.forEach(o=>{o.possibleTypes&&(t[o.name]=o.possibleTypes.map(n=>n.name))}),t}var Vf=class{constructor(){Ae(this,"spanCount",0);Ae(this,"listeners",new Set);Ae(this,"activeEvents",0);Ae(this,"startSpan",t=>{let o=`${this.spanCount++}: ${t}`;return this.activeEvents++,this.listeners.forEach(n=>n(o,t,"START",this.activeEvents)),performance.mark(`${o} start`),{endSpan:()=>this.endSpan(t,o)}});Ae(this,"endSpan",(t,o)=>{performance.mark(`${o} end`),performance.measure(t,`${o} start`,`${o} end`),this.activeEvents--,this.listeners.forEach(n=>n(o,t,"END",this.activeEvents))});Ae(this,"addEventListener",t=>(this.listeners.add(t),()=>{this.listeners.delete(t)}))}};var TU=new Set([".snapchat.com",".snap.com",".arcadiacreativestudio.com",".pixy.com",".yellowla.com",".specs.com",".spectacles.com",".snap-dev.net",".sc-corp.net","localhost"]),AU="EssentialSession",EI="sc-wcid";function _U(e){let{currentUrl:t,userLocation:o,cookieManager:n,createUuidV4:a}=e;if(n.getCookie(AU)==="false")return;let s=n.getCookie(EI);if(s)return s;let l=o.country?g0.has(o.country):!0,p=new Date;l?p.setDate(p.getDate()+1):p.setFullYear(p.getFullYear()+1);let d=va(t.hostname);d!=="localhost"&&(d=`.${d}`),d===".appspot.com"&&(d=".sc-corp.net");let u={expires:new Date(p),path:"/",secure:!0,httpOnly:!1,credentials:"same-origin",domain:TU.has(d)?d:void 0},y=a();return n.setCookie(EI,y,u),y}var ine={currentLocale:as.currentLocale,supportedLocales:as.supportedLocales,userLocation:as.userLocation,pageLayoutContext:{footerView:"Full Footer",headerView:"Full Header",hasSubNav:!1,hasSideNav:!1,hasCustomSideNav:!1}};async function sne(){let e=window.APP_STATE??ine;(0,wU.printWarning)(e.currentLocale);let t={...V,locale:e.currentLocale,globalPrivacyControl:navigator.globalPrivacyControl};if(uU(t),mU(t),n9(new Vf),window.location.pathname.startsWith(`/${e.currentLocale}`)){let P=new URL(window.location.href);P.pathname=P.pathname.replace(`/${e.currentLocale}`,""),e.currentLocale!==so&&P.searchParams.set("lang",e.currentLocale),window.history.pushState({},"",P)}let o=window.APOLLO_STATE,n=window.GLOBAL_APOLLO_STATE,a=new URLSearchParams(window.location.search),s=gU(V.contentful,a),l=window.APOLLO_FRAGMENTS&&Object.keys(window.APOLLO_FRAGMENTS).length>0?window.APOLLO_FRAGMENTS:await NI(s),p=window.GLOBAL_APOLLO_FRAGMENTS&&Object.keys(window.GLOBAL_APOLLO_FRAGMENTS).length>0?window.GLOBAL_APOLLO_FRAGMENTS:await NI(V.contentfulGlobal),d=Uc(e.currentLocale,[s,l,o]),u=Uc(e.currentLocale,[V.contentfulGlobal,p,n]),y=new Map;window.ASYNC_DATA_CONTROLLER_CACHE&&(y=new Map(Object.entries(window.ASYNC_DATA_CONTROLLER_CACHE??{})));let m=new ob({cache:y,defaultExpiryTimeMs:363e4,clock:Date.now}),g=new Bf,f=zz,b=_U({cookieManager:g,createUuidV4:f,currentUrl:new URL(window.location.href),userLocation:e.userLocation}),S=()=>b?Promise.resolve({experimentBucket:{id:b}}):fetch("/api/userinfo").then(P=>P.json()).catch(()=>({experimentBucket:{id:"default"}})),C=()=>{let P=new URLSearchParams(window.location.search).get("overrideHashedIp"),R=`/api/persona${!V.isDeploymentTypeProd&&!!P?`?overrideHashedIp=${P}`:""}`;return fetch(R).then(L=>L.json()).catch(()=>({}))},v=(P,$)=>{let R=$?.newTab;if(P.startsWith("http")){window.open(P,R?"_blank":"_self");return}if(I&&!R){I.push(P),window.history.pushState(null,"",new URL(P,window.location.href));return}window.open(P,R?"_blank":"_self")},k=new F0,I,A={...e,getCurrentUrl:()=>window.location.href,routerContext:{},helmetContext:{},apolloClient:d,globalApolloClient:u,onRedirect:v,onHistory:P=>{I=P},browserFeatures:k,asyncDataController:m,globalPrivacyControl:navigator.globalPrivacyControl,cookieManager:g,createUuidV4:f,getUserInfo:S,getPersona:C,singleCallbackCache:new Map,onHlsVideo:()=>{}},D=BI({key:"marketing-web-emotion"}),B=i(HI,{value:D,children:i(Gz,{...A})}),M=document.querySelector("main");M?M.hasChildNodes()??!1?(0,Of.hydrateRoot)(M,B):(0,Of.createRoot)(M).render(B):console.error("HTML must contain a <main> element.");let _=0;if(V.isLocal&&V.compilationMode==="development"){let P=new EventSource("/esbuild",{});P.addEventListener("error",()=>{console.error("/esbuild server disconnected."),_++,_>1e3&&(P.close(),console.info("Esbuild could not connnect after a 1000 attempts. Closing connection. Please reload."))}),P.addEventListener("change",$=>{let R=JSON.parse($.data);R.errors?.length?R.errors.forEach(L=>{let G=L.location,Z=`${G.file}:${G.line}:${G.column}`;console.error(` 'Build failed. Not reloading.', ${L.text} (${Z})`)}):(console.info("Served content changed. Reloading"),location.reload())})}}sne().catch(e=>console.error(e));
/*! Bundled license information:

@contentful/rich-text-html-renderer/dist/rich-text-html-renderer.es5.js:
  (*!
   * escape-html
   * Copyright(c) 2012-2013 TJ Holowaychuk
   * Copyright(c) 2015 Andreas Lubbe
   * Copyright(c) 2015 Tiancheng "Timothy" Gu
   * MIT Licensed
   *)
*/
