<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		image gallery
	</title><g fill="#36c"><path d="M12 16H4l3-3 1 1 4-4zM5.25 8a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5"/><path d="M16 20H0V4h16zM2 18h12V6H2z"/><path d="M20 16h-2V2H6V0h14z"/></g></svg>
