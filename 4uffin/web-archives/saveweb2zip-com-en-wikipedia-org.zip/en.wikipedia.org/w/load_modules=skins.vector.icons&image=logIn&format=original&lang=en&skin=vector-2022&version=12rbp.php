<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		login
	</title><g fill="#000"><path d="M19 19H1v-2h16V3H1V1h18z"/><path d="M14.018 9.293v1.414L9.31 15.414 7.896 14l3-3H1V9h9.896l-3-3L9.31 4.586z"/></g></svg>
