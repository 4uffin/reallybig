<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		lab flask
	</title><g fill="#36c"><path d="M14.5 4H13v4.667l5.8 7.733L18 18H2l-.8-1.6L7 8.667V4H5.5V2h9zm-8.251 9-2.25 3h12.002l-2.25-3zM9 9.333 7.75 11h4.5L11 9.333V4H9z"/></g></svg>
