//#region \0@oxc-project+runtime@0.127.0/helpers/checkPrivateRedeclaration.js
function e(e, t) {
	if (t.has(e)) throw TypeError("Cannot initialize the same private elements twice on an object");
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/classPrivateMethodInitSpec.js
function t(t, n) {
	e(t, n), n.add(t);
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/classPrivateFieldInitSpec.js
function n(t, n, r) {
	e(t, n), n.set(t, r);
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/typeof.js
function r(e) {
	"@babel/helpers - typeof";
	return r = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, r(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/toPrimitive.js
function i(e, t) {
	if (r(e) != "object" || !e) return e;
	var n = e[Symbol.toPrimitive];
	if (n !== void 0) {
		var i = n.call(e, t || "default");
		if (r(i) != "object") return i;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/toPropertyKey.js
function a(e) {
	var t = i(e, "string");
	return r(t) == "symbol" ? t : t + "";
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/defineProperty.js
function o(e, t, n) {
	return (t = a(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/assertClassBrand.js
function s(e, t, n) {
	if (typeof e == "function" ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
	throw TypeError("Private element is not present on this object");
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/classPrivateFieldSet2.js
function c(e, t, n) {
	return e.set(s(e, t), n), n;
}
//#endregion
//#region \0@oxc-project+runtime@0.127.0/helpers/classPrivateFieldGet2.js
function l(e, t) {
	return e.get(s(e, t));
}
//#endregion
//#region ../../shared/players/common/facade.ts
var u = /* @__PURE__ */ new WeakMap(), d = /* @__PURE__ */ new WeakMap(), f = /* @__PURE__ */ new WeakMap(), p = /* @__PURE__ */ new WeakSet(), ee = class {
	constructor(e, r, i) {
		t(this, p), n(this, u, void 0), n(this, d, void 0), n(this, f, !1), o(this, "id", void 0), o(this, "play", void 0), o(this, "pause", void 0), o(this, "stop", void 0), o(this, "on", void 0), o(this, "destroy", void 0), c(u, this, e), c(d, this, i), this.id = r, this.play = () => {
			s(p, this, m).call(this, "play"), l(u, this).play();
		}, this.pause = () => {
			s(p, this, m).call(this, "pause"), l(u, this).pause();
		}, this.stop = () => {
			s(p, this, m).call(this, "stop"), l(u, this).stop();
		}, this.on = (e, t) => {
			s(p, this, m).call(this, "on");
			let n = l(u, this).on(e, t);
			return () => {
				l(f, this) || n();
			};
		}, this.destroy = () => {
			if (!l(f, this)) {
				c(f, this, !0);
				try {
					l(u, this).destroy();
				} finally {
					l(d, this)?.call(this);
				}
			}
		};
	}
	get type() {
		return l(u, this).type;
	}
};
function m(e) {
	if (l(f, this)) throw Error(`[VideoPlayerFacade] Cannot call "${e}" on a destroyed player.`);
}
//#endregion
//#region ../../node_modules/.pnpm/@fandom+odyssey-tracking-client@1.0.2/node_modules/@fandom/odyssey-tracking-client/dist/index.js
var te = () => {
	let e = window.fandomTrack ?? {
		q: [],
		cmd: [],
		registry: {}
	};
	return window.fandomTrack = e, e;
}, ne = "shortlivedtrackingevent", re = "trackingevent", ie = (e, t = {}, n = { requiresConsent: !0 }) => {
	if (e === ne) throw Error("shortlivedtrackingevent cannot be re-registered via buildBasicTrackingFunction, use buildShortlivedTrackingFunction instead.");
	if (e === re) throw Error("trackingevent usage is discouraged, use shortlived or register your own custom event type in event catalog.");
	return (r) => {
		let i = te();
		i.registry[e] || i.cmd.push((t) => {
			if (typeof t.createAndRegisterBasicTracker != "function") throw Error("fandomTrack.createAndRegisterBasicTracker is not available");
			t.createAndRegisterBasicTracker(e, n);
		}), i.q.push({
			event: e,
			payload: {
				...t,
				...r
			}
		});
	};
}, ae = 20, oe = [];
function h(e) {
	oe.push({
		action: e,
		ts: typeof performance < "u" ? performance.now() : -1
	}), oe.length > ae && oe.shift();
}
function se() {
	return oe.map((e) => `${Math.round(e.ts)}ms:${e.action}`).join(" → ");
}
//#endregion
//#region ../../shared/utils/src/issue-tracking.ts
var ce = "morpheus_performance", le = { requiresConsent: !1 }, ue = {
	engine_version: "unknown",
	env: "unknown"
};
function de(e) {
	ue = e;
}
var fe, g = [], pe, me = 0, he = 64, ge = 250, _e = 40;
function ve(e) {
	if (typeof e != "object" || !e) return !1;
	let t = e;
	return Array.isArray(t.q) && Array.isArray(t.cmd) && typeof t.registry == "object" && t.registry !== null;
}
function ye() {
	return typeof window < "u" && ve(window.fandomTrack);
}
function be(e) {
	fe ?? (fe = ie(ce, { category: "morpheus" }, le)), fe(e);
}
function xe() {
	if (g.length === 0) return;
	let e = g;
	g = [];
	for (let t of e) be(t);
}
function Se() {
	pe || (pe = setTimeout(() => {
		if (pe = void 0, g.length !== 0) {
			if (ye() || ++me >= _e) {
				try {
					xe();
				} catch {}
				return;
			}
			Se();
		}
	}, ge));
}
function _(e, t = {}) {
	try {
		let n = {
			...ue,
			component: "video-engine",
			action: "issue",
			issue_code: e.code,
			constant_name: e.constantName,
			issue_priority: e.priority
		};
		if (t.label && (n.label = t.label), t.error_type && (n.error_type = t.error_type), t.error_message && (n.error_message = Ce(t.error_message, 500)), t.player_type && (n.player_type = t.player_type), t.player_mode && (n.player_mode = t.player_mode), t.exp_bucket && (n.exp_bucket = t.exp_bucket), t.experiment_groups && (n.experiment_groups = t.experiment_groups), e.code.startsWith("U")) {
			let e = se();
			e && (n.label = n.label ? `${n.label} | ${e}` : e);
		}
		if (ye()) {
			xe(), be(n);
			return;
		}
		g.push(n), g.length > he && g.shift(), Se();
	} catch {}
}
function Ce(e, t) {
	return e.length > t ? e.slice(0, t) : e;
}
function v(e) {
	return e instanceof Error ? {
		error_type: e.constructor.name || "Error",
		error_message: e.message
	} : {
		error_type: "NonError",
		error_message: String(e)
	};
}
var we = { get: (e) => {
	let t = ("; " + document.cookie).split("; " + e + "=");
	return t.length >= 2 ? t.pop().split(";").shift() : null;
} };
//#endregion
//#region ../../shared/utils/src/experiments.ts
function Te(e, t) {
	let n = e.featureFlags?.get("icExperiments");
	return n ? n.includes(t) : !1;
}
var Ee = /^(?:v\d+-)?(\d{2})$/;
function De() {
	return we.get("exp_bucket")?.match(Ee)?.[1] ?? "";
}
function Oe(e) {
	return e ? Object.entries(e).toSorted(([e], [t]) => e.localeCompare(t)).map(([e, t]) => `${e}:${t}`).join(",") : "";
}
//#endregion
//#region ../../packages/contracts/src/issue-codes.ts
var y = /* @__PURE__ */ function(e) {
	return e.P1 = "P1", e.P2 = "P2", e.P3 = "P3", e.P4 = "P4", e;
}({}), ke = {
	code: "E001",
	constantName: "EngineBootstrapFailed",
	priority: y.P1,
	description: "Fatal error during engine bootstrap; runtime never initialized"
}, b = {
	code: "E002",
	constantName: "PluginHookExecutionFailed",
	priority: y.P2,
	description: "A plugin hook threw; isolated so other plugins continue"
}, Ae = {
	code: "E003",
	constantName: "PlayerFactoryAttachConfigFailed",
	priority: y.P2,
	description: "factory.attachConfig() threw during factory registration"
}, je = {
	code: "E004",
	constantName: "PlayerCreateFailed",
	priority: y.P2,
	description: "Player instance could not be created from the queued command"
}, Me = {
	code: "E005",
	constantName: "ConfigInitializationFailed",
	priority: y.P2,
	description: "window.__morpheusConfig missing/invalid; engine cannot configure"
}, Ne = {
	code: "E006",
	constantName: "InstantConfigFetchFailed",
	priority: y.P3,
	description: "Instant Config (ICBM) flags could not be fetched"
}, Pe = {
	code: "E007",
	constantName: "TrackingFlushFailed",
	priority: y.P4,
	description: "FTL enqueue/flush threw while reporting telemetry"
}, x = {
	code: "E101",
	constantName: "PlayerScriptLoadFailed",
	priority: y.P2,
	description: "Vendor SDK/script/bundle failed to inject/load"
}, Fe = {
	code: "E102",
	constantName: "PlayerSetupFailed",
	priority: y.P2,
	description: "Adapter setup() / vendor init threw or rejected"
}, Ie = {
	code: "E103",
	constantName: "PlayerMountFailed",
	priority: y.P2,
	description: "Target container missing / DOM attach failed"
}, Le = {
	code: "E104",
	constantName: "PlayerReadyTimeout",
	priority: y.P3,
	description: "Player never signaled ready within budget"
}, Re = {
	code: "E105",
	constantName: "PlayerMediaLoadError",
	priority: y.P2,
	description: "Vendor media/network error (manifest 404, CORS, source unreachable)"
}, ze = {
	code: "E106",
	constantName: "PlayerPlaybackFatalError",
	priority: y.P2,
	description: "Vendor fatal playback error (decode, unrecoverable buffer/DRM)"
}, S = {
	code: "E107",
	constantName: "PlayerDestroyFailed",
	priority: y.P3,
	description: "Teardown threw (facade isolates, still reported)"
}, Be = {
	code: "E108",
	constantName: "AdCustomElementNotDefined",
	priority: y.P3,
	description: "Custom element wait budget exceeded; element never defined"
}, Ve = {
	code: "D001",
	constantName: "FandomTrackQueueUnavailable",
	priority: y.P3,
	description: "window.fandomTrack never appeared after cold-start poll window; buffered events dropped"
}, He = {
	code: "D002",
	constantName: "PluginWaitingTimeout",
	priority: y.P3,
	description: "onConfigLoaded plugin init exceeded timeout; bootstrap proceeded"
}, Ue = {
	code: "D003",
	constantName: "PlayerFactoryNotRegistered",
	priority: y.P2,
	description: "Queue drain found no registered factory for requested player type"
}, We = {
	code: "D004",
	constantName: "InstantConfigLocalStorageError",
	priority: y.P3,
	description: "LocalStorage access error while reading/caching instant config"
}, Ge = {
	code: "D005",
	constantName: "PerfMarkMissing",
	priority: y.P4,
	description: "No matching start/render mark when measuring a perf duration"
}, C = {
	code: "D101",
	constantName: "PlayerMediaResolveMissing",
	priority: y.P3,
	description: "No mediaId / empty playlist / unresolved source; player skipped"
}, Ke = {
	code: "D102",
	constantName: "PlayerFormatUnsupported",
	priority: y.P3,
	description: "Codec/format/DRM unsupported in env; fallback/skip"
}, qe = {
	code: "D103",
	constantName: "PlayerAutoplayBlocked",
	priority: y.P4,
	description: "Browser blocked autoplay; degraded to muted / click-to-play"
}, Je = {
	code: "D104",
	constantName: "PlayerRecoverableMediaError",
	priority: y.P4,
	description: "Vendor recoverable media error, auto-retried"
}, Ye = {
	code: "D201",
	constantName: "AdConsentTimeout",
	priority: y.P3,
	description: "Consent listener timed out; ad plugin degraded"
}, Xe = {
	code: "D202",
	constantName: "AdSlotRequestRenderFailed",
	priority: y.P3,
	description: "requestRender failed for a slot; slot skipped"
}, Ze = {
	code: "D204",
	constantName: "BucketExperimentUnknownGroup",
	priority: y.P4,
	description: "setExperimentGroup received unrecognized group; defaulted to control"
}, w = {
	code: "U001",
	constantName: "UnexpectedRuntimeError",
	priority: y.P2,
	description: "Uncaught error with no specific issue code; indicates a gap in error handling"
}, Qe = {
	code: "U002",
	constantName: "UnhandledPromiseRejection",
	priority: y.P2,
	description: "Unhandled promise rejection originating from Morpheus code"
};
new Map([
	[ke.code, ke],
	[b.code, b],
	[Ae.code, Ae],
	[je.code, je],
	[Me.code, Me],
	[Ne.code, Ne],
	[Pe.code, Pe],
	[x.code, x],
	[Fe.code, Fe],
	[Ie.code, Ie],
	[Le.code, Le],
	[Re.code, Re],
	[ze.code, ze],
	[S.code, S],
	[Be.code, Be],
	[Ve.code, Ve],
	[He.code, He],
	[Ue.code, Ue],
	[We.code, We],
	[Ge.code, Ge],
	[C.code, C],
	[Ke.code, Ke],
	[qe.code, qe],
	[Je.code, Je],
	[Ye.code, Ye],
	[Xe.code, Xe],
	[Ze.code, Ze],
	[w.code, w],
	[Qe.code, Qe]
]);
var $e = { requiresConsent: !1 }, et = {
	engine_version: "unknown",
	env: "unknown"
}, tt, T;
function nt(e) {
	et = e;
}
function rt(e) {
	tt = e, T = void 0;
}
function it() {
	if (T) return T;
	if (tt !== void 0) {
		try {
			T = {
				exp_bucket: De(),
				experiment_groups: Oe(tt)
			};
		} catch {
			return;
		}
		return T;
	}
}
var at, E = [], ot, st = 0, ct = 64, lt = 250, ut = 40;
function dt(e) {
	if (typeof e != "object" || !e) return !1;
	let t = e;
	return Array.isArray(t.q) && Array.isArray(t.cmd) && typeof t.registry == "object" && t.registry !== null;
}
function ft() {
	return typeof window < "u" && dt(window.fandomTrack);
}
function pt(e) {
	at ?? (at = ie("morpheus_performance", { category: "morpheus" }, $e)), at(e);
}
function mt() {
	if (E.length === 0) return;
	let e = E;
	E = [];
	for (let t of e) pt(t);
}
function ht() {
	ot || (ot = setTimeout(() => {
		if (ot = void 0, E.length !== 0) {
			if (ft() || ++st >= ut) {
				ft() || _(Ve);
				try {
					mt();
				} catch (e) {
					_(Pe, v(e));
				}
				return;
			}
			ht();
		}
	}, lt));
}
function D(e) {
	try {
		let t = {
			...et,
			...it(),
			...e
		};
		if (ft()) {
			mt(), pt(t);
			return;
		}
		E.push(t), E.length > ct && E.shift(), ht();
	} catch {}
}
function O() {
	return typeof performance < "u" ? performance.now() : NaN;
}
function k(e) {
	let t = O() - e;
	return Number.isFinite(t) && t >= 0 ? t : -1;
}
//#endregion
//#region ../../shared/utils/src/logger.ts
var gt = "morpheus_debug", A = !1;
function _t(e) {
	A = e;
}
function vt() {
	return A;
}
function yt(e = globalThis.location?.search ?? "") {
	let t = new URLSearchParams(e);
	if (!t.has("morpheus_debug")) return !1;
	let n = t.get(gt);
	return n !== "false" && n !== "0";
}
function j(e) {
	let t = `[${e}]`;
	return {
		log: (...e) => {
			A && console.log(t, ...e);
		},
		info: (...e) => {
			A && console.info(t, ...e);
		},
		debug: (...e) => {
			A && console.debug(t, ...e);
		},
		warn: (...e) => {
			console.warn(t, ...e);
		},
		error: (...e) => {
			console.error(t, ...e);
		}
	};
}
//#endregion
//#region runtime/run-hook.ts
var bt = j("RunHook"), xt = [];
function M(e, t, ...n) {
	h(`hook:${t}`);
	let r = [], i = [];
	for (let a of e) {
		let e = a.hooks[t];
		if (typeof e != "function") continue;
		let o = (e) => {
			r.push(a.name), bt.error(`Plugin "${a.name}" threw in hook "${t}":`, e), _(b, {
				label: `${a.name}:${t}`,
				...v(e)
			});
		}, s = Promise.resolve();
		try {
			s = Promise.resolve(e.call(a, ...n)).catch(o);
		} catch (e) {
			o(e);
		}
		i.push(s);
	}
	return vt() && Ct(t, n, r, i), i;
}
async function St(e, t, ...n) {
	h(`hook:${t}`);
	let r = [];
	for (let i of e) {
		let e = i.hooks[t];
		if (typeof e == "function") try {
			await e.call(i, ...n);
		} catch (e) {
			r.push(i.name), bt.error(`Plugin "${i.name}" threw in hook "${t}":`, e), _(b, {
				label: `${i.name}:${t}`,
				...v(e)
			});
		}
	}
	vt() && Ct(t, n, r, []);
}
function Ct(e, t, n, r) {
	let i = {
		time: typeof performance < "u" ? performance.now() : -1,
		name: e,
		params: t,
		failures: n
	};
	Promise.allSettled(r).then(() => xt.push(i));
}
//#endregion
//#region runtime/create-runtime.ts
var wt = "v9";
function Tt(e, t = []) {
	let n = j("CreateRuntime"), r = [];
	for (let i of t) try {
		i.setConfig?.(e), i.setPlugins(t), r.push(i);
	} catch (e) {
		n.error(`Plugin "${i.name}" threw in setPlugins(), skipping:`, e), _(b, {
			label: `${i.name}:setPlugins`,
			...v(e)
		});
	}
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map();
	return {
		version: wt,
		config: e,
		getPlugin(e) {
			return r.find((t) => t.name === e);
		},
		getPlugins() {
			return [...r];
		},
		registerPlayerFactory(t) {
			h(`factory:register:${t.type}`), i.has(t.type) && n.warn(`Player factory "${t.type}" is already registered; overwriting.`);
			try {
				t.attachConfig?.(e);
			} catch (e) {
				n.error(`Player factory "${t.type}" threw in attachConfig():`, e), _(Ae, {
					label: t.type,
					...v(e)
				});
			}
			i.set(t.type, t);
		},
		async createPlayer(e, t, s) {
			h(`player:create:${e}`);
			let c = i.get(e);
			if (!c) throw _(Ue, { label: e }), Error(`[Morpheus] No player factory registered for type "${e}"`);
			let l = O(), u = {
				type: e,
				container: t,
				options: s
			};
			await St(r, "onBeforePlayerCreate", u);
			let d;
			try {
				d = await c.create(t, u.options);
			} catch (t) {
				throw _(je, {
					label: e,
					player_type: e,
					...v(t)
				}), t;
			}
			let f, p = {
				type: e,
				container: t
			}, m = Et(t, e, o, n);
			return Dt(a, m), f = new ee(d, m, () => {
				h(`player:destroy:${e}`), a.get(m) === f && a.delete(m), St(r, "onAfterPlayerDestroy", p);
			}), a.set(m, f), D({
				component: "video-engine",
				action: "player-created",
				duration_ms: k(l),
				label: e
			}), St(r, "onAfterPlayerCreate", {
				type: e,
				container: t,
				player: f
			}), f;
		},
		getPlayers() {
			return [...a.values()];
		},
		findPlayer(e) {
			return a.get(e);
		}
	};
}
function Et(e, t, n, r) {
	if (e.id) return e.id;
	let i = (n.get(t) ?? 0) + 1;
	n.set(t, i);
	let a = `${t}-${i}`;
	return r.warn(`Player container has no id; using fallback "${a}". Set container.id for stable, reusable player identifiers.`), a;
}
function Dt(e, t) {
	if (e.has(t)) throw Error(`[Morpheus] Duplicate player id "${t}": a player with this id is already tracked. Destroy the existing player before creating a new one with the same id.`);
}
function Ot(e, t) {
	let n = e;
	for (let [r, ...i] of t) {
		let t = n[r];
		typeof t == "function" && t.apply(e, i);
	}
}
//#endregion
//#region runtime/initialize-plugins.ts
var kt = j("InitializePlugins");
function At(e, t) {
	return e.filter((e) => {
		try {
			return e.isEnabled(t);
		} catch (t) {
			return kt.error(`Plugin "${e.name}" threw in isEnabled():`, t), _(w, {
				label: `${e.name}:isEnabled`,
				...v(t)
			}), !1;
		}
	});
}
//#endregion
//#region ../../shared/instant-config/src/repository.ts
var jt = {}, Mt = "icbm__";
function Nt(e) {
	if (e === "true" || e === "false") return e === "true";
	let t = parseInt(e, 10);
	if (e === `${t}`) return t;
	try {
		return JSON.parse(e);
	} catch {
		return e;
	}
}
function Pt(e, t) {
	let n = new URLSearchParams(t), r = [...n.keys()].filter((e) => e.startsWith(Mt) && n.get(e) !== null).reduce((e, t) => (e[t.slice(6)] = Nt(n.get(t)), e), {});
	return {
		...e,
		...r
	};
}
//#endregion
//#region ../../shared/instant-config/src/instant-config-service.ts
var Ft = j("InstantConfig"), It = "instantConfigLoaded", Lt = 2e3, Rt = class {
	constructor() {
		o(this, "repository", { ...jt });
	}
	async init(e) {
		let t = await zt(e), n = {
			...jt,
			...t
		};
		return this.repository = Pt(n, e.location?.search ?? ""), Ft.info("initialized with", this.repository), this;
	}
	get(e, t) {
		return this.repository[e] ?? t;
	}
	getAll() {
		return { ...this.repository };
	}
	toJSON() {
		return this.getAll();
	}
};
function zt(e) {
	return e.icbm?.config ? Promise.resolve(e.icbm.config) : new Promise((t) => {
		let n = () => {
			clearTimeout(r), t(e.icbm?.config ?? {});
		}, r = setTimeout(() => {
			e.removeEventListener(It, n), Ft.warn("host did not provide instant-config in time; using defaults"), t({});
		}, Lt);
		e.addEventListener(It, n, { once: !0 });
	});
}
//#endregion
//#region runtime/initialize-instant-config.ts
var Bt = j("InstantConfig:bootstrap");
async function Vt() {
	let e = globalThis.window;
	try {
		return await new Rt().init(e);
	} catch (e) {
		return Bt.error("failed to initialize instant-config; using defaults", e), _(Ne, { ...v(e) }), new Rt();
	}
}
//#endregion
//#region runtime/attach-debug-info.ts
function Ht(e) {
	vt() && (e.debug = {
		version: e.version,
		config: e.config,
		activePlugins: e.getPlugins().map((e) => e.name)
	});
}
//#endregion
//#region runtime/constants.ts
var Ut = 2e3, Wt = /* @__PURE__ */ Object.assign({ "../config/default.ts": () => import("./default-BQtT_IEv.js") }), Gt = j("LoadConfig");
async function Kt(e) {
	let t = "../config/default.ts", n = Wt[e ? `../config/${e}/${e}.ts` : t] ?? Wt[t];
	try {
		return (await n()).default;
	} catch (t) {
		throw Gt.error("Could not load config for app", {
			app: e,
			error: t
		}), _(Me, {
			label: e ?? "default",
			...v(t)
		}), Error(`[VideoEngine] [LoadConfig] Could not load config for app: ${e}`, { cause: t });
	}
}
//#endregion
//#region ../../shared/utils/src/geo.ts
var qt = "ZZ", Jt = {
	country: qt,
	region: qt,
	continent: qt
};
async function Yt() {
	let e = window.fandomHost?.geo;
	if (e && e.country) return e;
	let t = we.get("Geo");
	if (t) try {
		return JSON.parse(decodeURIComponent(t));
	} catch {}
	return Jt;
}
//#endregion
//#region ../../shared/utils/src/device.ts
var Xt = new Set([
	"desktop",
	"smartphone",
	"tablet"
]);
function Zt(e) {
	return Xt.has(e);
}
var Qt = /Mobile|iPhone|Android|Silk|Kindle|Windows Phone|KFAPWI|(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i, $t = /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i, en = /iPad|Android(?!.*Mobile)/i;
function tn() {
	return sn(window.fandomHost?.device, window.navigator.userAgent);
}
function nn(e) {
	return e ?? tn();
}
function rn(e) {
	return nn(e) === "smartphone";
}
function an(e) {
	return nn(e) === "tablet";
}
function on(e) {
	return rn(e) || an(e);
}
function sn(e, t = "") {
	return e && Zt(e) ? e : cn(t);
}
function cn(e) {
	return en.test(e) ? "tablet" : Qt.test(e) || $t.test(e.substring(0, 4)) ? "smartphone" : "desktop";
}
//#endregion
//#region runtime/build-page-context.ts
async function ln() {
	return {
		geo: await Yt(),
		device: tn()
	};
}
//#endregion
//#region runtime/initialize-config.ts
async function un(e) {
	let t = await Kt(), n = await ln(), r = { ...t.players };
	for (let [n, i] of Object.entries(e.players ?? {})) r[n] = {
		...t.players?.[n],
		...i
	};
	return {
		...t,
		...e,
		players: r,
		pageContext: n
	};
}
//#endregion
//#region ../../shared/plugins/morpheus-plugin/morpheus-plugin.ts
var N = /* @__PURE__ */ new WeakMap(), dn = /* @__PURE__ */ new WeakMap(), fn = class {
	constructor(e) {
		o(this, "hooks", {}), o(this, "api", void 0), n(this, N, []), n(this, dn, void 0), this.pluginConfig = e;
	}
	isEnabled(e) {
		return this.pluginConfig.enabled !== !1;
	}
	setPlugins(e) {
		c(N, this, e);
	}
	setConfig(e) {
		c(dn, this, e);
	}
	useFeatureFlag(e, t) {
		return l(dn, this)?.featureFlags?.get(e) ?? t;
	}
	usePlugin(e) {
		return l(N, this).find((t) => t.name === e);
	}
	useExperiment(e) {
		return l(N, this).find((t) => t.experimentName === e.experimentName);
	}
}, pn = "fandom-video-ad", mn = j("FandomVideoAdPlugin");
function hn(e) {
	let t = document.getElementById(e);
	return t && t.localName === "fandom-video-ad" ? t : null;
}
function gn(e, t) {
	let n = t.parentNode;
	if (!n) return mn.warn(`Container has no parent; cannot create ad element for slot "${e}".`), null;
	let r = document.createElement(pn);
	return r.id = e, n.insertBefore(r, t), r;
}
//#endregion
//#region ../../shared/plugins/fandom-video-ad/consents.ts
var _n = null;
function vn(e, t) {
	return t.consentString !== e?.consentString || t.optOut !== e?.optOut;
}
function yn(e) {
	return _n || (window.fandomCmp?.allowed.ads ? Promise.resolve(!0) : (_n = new Promise((t) => {
		let n, r = (e) => {
			(e.detail?.allowed.ads || window.fandomCmp?.allowed.ads) && (clearTimeout(n), window.removeEventListener("fandomConsentUpdate", r), t(!0));
		};
		window.addEventListener("fandomConsentUpdate", r), n = setTimeout(() => {
			window.removeEventListener("fandomConsentUpdate", r), t(!1);
		}, e);
	}).finally(() => {
		_n = null;
	}), _n));
}
//#endregion
//#region ../../shared/plugins/fandom-video-ad/fandom-video-ad-plugin.ts
var bn = 1e3, xn = 5e3, Sn = 1e4, Cn = 3;
function wn(e, t) {
	let n = new URLSearchParams();
	t && n.set("player", t);
	let r = (e) => {
		if (e) for (let [t, r] of Object.entries(e)) n.set(t, Array.isArray(r) ? r.join(",") : r);
	};
	return e && (e.vpos && n.set("vpos", e.vpos), r(e.pageTargeting), r(e.slotTargeting)), n.toString() || void 0;
}
var P = /* @__PURE__ */ new WeakMap(), Tn = /* @__PURE__ */ new WeakMap(), En = /* @__PURE__ */ new WeakMap(), Dn = /* @__PURE__ */ new WeakMap(), On = /* @__PURE__ */ new WeakMap(), F = /* @__PURE__ */ new WeakSet(), kn = class extends fn {
	constructor(e = {}) {
		super(e), t(this, F), o(this, "name", "FandomVideoAdPlugin"), n(this, P, j("FandomVideoAdPlugin")), n(this, Tn, /* @__PURE__ */ new WeakMap()), n(this, En, /* @__PURE__ */ new Map()), n(this, Dn, null), n(this, On, null), o(this, "hooks", {
			onRuntimeReady: async () => {
				s(F, this, jn).call(this);
			},
			onBeforePlayerCreate: (e) => s(F, this, An).call(this, e),
			onAfterPlayerDestroy: (e) => s(F, this, Fn).call(this, e)
		});
	}
};
async function An(e) {
	let t = e.options, n = t.adSlotName;
	if (!n) return;
	let r = e.container;
	if (l(En, this).set(r, {
		slotName: n,
		resolveApplyAdTag: () => r.isConnected ? t.applyAdTag : void 0
	}), !window.fandomCmp?.allowed.ads && (l(P, this).log(`ad request deferred for slot "${n}" — waiting for consent`), !await yn(this.pluginConfig.consentTimeoutMs ?? Sn))) {
		l(P, this).log(`ad request skipped for slot "${n}" — consent timeout`), _(Ye, { label: n });
		return;
	}
	let i = this.pluginConfig.whenDefinedTimeoutMs ?? bn, a = this.pluginConfig.requestRenderTimeoutMs ?? xn, o;
	if (!await Promise.race([customElements.whenDefined("fandom-video-ad").then(() => (clearTimeout(o), !0)), new Promise((e) => {
		o = setTimeout(() => e(!1), i);
	})])) {
		l(P, this).warn(`"<${pn}>" not defined within ${i}ms — playing without ads.`), _(Be, { label: n });
		return;
	}
	let c = s(F, this, Pn).call(this, n, e.container);
	if (!c) return;
	let u, d = null, f;
	try {
		[u, d] = await Promise.race([Promise.all([c.requestRender(), Promise.resolve().then(() => c.getAdUnitPath()).catch(() => null)]).finally(() => clearTimeout(f)), new Promise((e, t) => {
			f = setTimeout(() => t(/* @__PURE__ */ Error(`requestRender timed out after ${a}ms`)), a);
		})]);
	} catch (e) {
		l(P, this).warn(`requestRender failed for slot "${n}":`, e), _(Xe, {
			label: n,
			...v(e)
		});
		return;
	}
	if (u.vastUrl) {
		t.adVastUrl = u.vastUrl, t.adUnitPath = d, t.adTargetingParams = wn(u.vastParams, e.type);
		try {
			let e = c.getMonetizationTier();
			if (e != null) {
				let n = Number(e);
				Number.isFinite(n) && (t.adTier = n);
			}
		} catch {}
		t.adTier ?? (t.adTier = Cn), l(P, this).log(`slot "${n}" enriched: adTier=${t.adTier}, hasVastUrl=${!!t.adVastUrl}, adUnitPath=${t.adUnitPath ?? "none"}`);
	}
}
function jn() {
	l(On, this) || (c(Dn, this, {
		consentString: window.fandomCmp?.consentString,
		optOut: window.fandomCmp?.optOut
	}), c(On, this, (e) => {
		s(F, this, Mn).call(this, e).catch((e) => {
			l(P, this).warn("consent update handler failed:", e), _(w, {
				label: "FandomVideoAdPlugin:consentUpdate",
				...v(e)
			});
		});
	}), window.addEventListener("fandomConsentUpdate", l(On, this)));
}
async function Mn(e) {
	let { consentString: t, optOut: n } = e.detail;
	vn(l(Dn, this), e.detail) && (c(Dn, this, {
		consentString: t,
		optOut: n
	}), l(P, this).log("consent change detected — triggering ad tag renewal"), await Promise.allSettled([...l(En, this).entries()].map(([e, t]) => s(F, this, Nn).call(this, e, t))));
}
async function Nn(e, { slotName: t, resolveApplyAdTag: n }) {
	let r = n();
	if (!r) return;
	let i = hn(t) ?? s(F, this, Pn).call(this, t, e);
	if (!i) return;
	if (!window.fandomCmp?.allowed.ads) {
		l(P, this).log(`ad tag renewal gated for slot "${t}" — consent not granted`);
		return;
	}
	let a;
	try {
		a = await i.requestRender();
	} catch (e) {
		l(P, this).warn(`requestRender failed during consent update for slot "${t}":`, e), _(Xe, {
			label: t,
			...v(e)
		});
		return;
	}
	if (a.vastUrl) try {
		await r(a.vastUrl);
	} catch (e) {
		l(P, this).warn(`applyAdTag failed during consent update for slot "${t}":`, e), _(w, {
			label: `FandomVideoAdPlugin:applyAdTag:${t}`,
			...v(e)
		});
	}
}
function Pn(e, t) {
	let n = hn(e);
	if (n) return n;
	let r = gn(e, t);
	return r ? (l(Tn, this).set(t, r), r) : null;
}
async function Fn(e) {
	l(En, this).delete(e.container);
	let t = l(Tn, this).get(e.container);
	t && (l(Tn, this).delete(e.container), t.isConnected && t.localName === "fandom-video-ad" && t.parentNode && t.remove());
}
//#endregion
//#region ../../shared/players/jwplayer/consts.ts
var I = "jwplayer", L = "jwplayer-dsr", In = "https://cdn.jwplayer.com/", Ln = 1e4, R = "connatix", Rn = 1e4, zn = {
	floating: "playerFloating",
	closed: "playerFloatingClosed",
	stopped: "playerFloatingStopped"
}, Bn = .5, Vn = 50, z = "mve-floating", Hn = "mve-floating-close", Un = "mve-floating-close-container", Wn = "mve-floating-close--ad", Gn = ".jwplayer .jw-wrapper", Kn = "cnx, [class*=\"cnx-\"]";
function qn(e, t) {
	let n = 0, r, i = () => {
		n = Date.now(), e();
	};
	return {
		run() {
			let e = t - (Date.now() - n);
			e <= 0 ? (r && (clearTimeout(r), r = void 0), i()) : r || (r = setTimeout(() => {
				r = void 0, i();
			}, e));
		},
		cancel() {
			r && clearTimeout(r), r = void 0;
		}
	};
}
var B = /* @__PURE__ */ new WeakMap(), V = /* @__PURE__ */ new WeakMap(), H = /* @__PURE__ */ new WeakMap(), Jn = /* @__PURE__ */ new WeakMap(), U = /* @__PURE__ */ new WeakMap(), Yn = /* @__PURE__ */ new WeakMap(), W = /* @__PURE__ */ new WeakMap(), Xn = /* @__PURE__ */ new WeakMap(), G = /* @__PURE__ */ new WeakMap(), Zn = /* @__PURE__ */ new WeakMap(), K = /* @__PURE__ */ new WeakMap(), Qn = /* @__PURE__ */ new WeakMap(), q = /* @__PURE__ */ new WeakMap(), $n = /* @__PURE__ */ new WeakMap(), J = /* @__PURE__ */ new WeakMap(), er = /* @__PURE__ */ new WeakMap(), tr = /* @__PURE__ */ new WeakMap(), nr = /* @__PURE__ */ new WeakMap(), rr = /* @__PURE__ */ new WeakMap(), ir = /* @__PURE__ */ new WeakMap(), ar = /* @__PURE__ */ new WeakMap(), or = /* @__PURE__ */ new WeakMap(), Y = /* @__PURE__ */ new WeakSet(), sr = /* @__PURE__ */ new WeakMap(), cr = class {
	constructor(e) {
		t(this, Y), n(this, B, void 0), n(this, V, void 0), n(this, H, void 0), n(this, Jn, void 0), n(this, U, void 0), n(this, Yn, void 0), n(this, W, void 0), n(this, Xn, qn(() => s(Y, this, dr).call(this), Vn)), n(this, G, void 0), n(this, Zn, void 0), n(this, K, void 0), n(this, Qn, void 0), n(this, q, !1), n(this, $n, !0), n(this, J, !1), n(this, er, !1), n(this, tr, !1), n(this, nr, !1), n(this, rr, () => l(Xn, this).run()), n(this, ir, () => {
			c(tr, this, !0), s(Y, this, yr).call(this, !1), l(J, this) && s(Y, this, vr).call(this);
		}), n(this, ar, () => {
			c(tr, this, !0), s(Y, this, yr).call(this, !0), l(J, this) && s(Y, this, vr).call(this);
		}), n(this, or, () => s(Y, this, yr).call(this, !1)), n(this, sr, () => s(Y, this, gr).call(this)), c(B, this, e.container), c(V, this, e.player), c(H, this, e.isMobile), c(Jn, this, e.scrollThreshold), c(U, this, e.closeButtonIcon), c(Yn, this, e.logger);
	}
	start() {
		if (!l(q, this)) {
			if (typeof IntersectionObserver > "u") {
				l(Yn, this).warn("IntersectionObserver unavailable — floating disabled.");
				return;
			}
			if (!l(B, this).parentNode) {
				l(Yn, this).warn("Container is detached — floating disabled.");
				return;
			}
			if (c(W, this, new IntersectionObserver((e) => s(Y, this, lr).call(this, e), { threshold: Bn })), l(W, this).observe(l(B, this)), l(H, this)) {
				let e = [
					l(V, this).on("play", l(ir, this)),
					l(V, this).on("adImpression", l(ar, this)),
					l(V, this).on("adPlay", l(ar, this)),
					l(V, this).on("adComplete", l(or, this)),
					l(V, this).on("adError", l(or, this))
				];
				c(Qn, this, () => e.forEach((e) => e()));
			}
			window.addEventListener("scroll", l(rr, this), { passive: !0 }), c(q, this, !0), s(Y, this, dr).call(this);
		}
	}
	destroy() {
		l(W, this)?.disconnect(), c(W, this, void 0), l(q, this) && window.removeEventListener("scroll", l(rr, this)), l(Xn, this).cancel(), l(Qn, this)?.call(this), c(Qn, this, void 0), s(Y, this, xr).call(this), l(J, this) && (l(K, this)?.classList.remove(z, s(Y, this, _r).call(this)), c(K, this, void 0), c(J, this, !1));
	}
};
function lr(e) {
	let t = e[0];
	t && (c($n, this, typeof t.intersectionRatio == "number" ? t.intersectionRatio >= Bn : t.isIntersecting), s(Y, this, dr).call(this));
}
function ur() {
	return !!l(B, this).querySelector(Gn) && !l(B, this).querySelector(Kn);
}
function dr() {
	l(er, this) || (s(Y, this, ur).call(this) && !l($n, this) && window.scrollY > l(Jn, this) ? s(Y, this, pr).call(this) : s(Y, this, mr).call(this, zn.stopped));
}
function fr() {
	return l(B, this).querySelector("div");
}
function pr() {
	if (l(J, this)) return;
	let e = s(Y, this, fr).call(this);
	e && (c(J, this, !0), c(K, this, e), e.classList.add(z, s(Y, this, _r).call(this)), (!l(H, this) || l(tr, this)) && s(Y, this, vr).call(this), s(Y, this, hr).call(this), s(Y, this, Sr).call(this, zn.floating));
}
function mr(e) {
	l(J, this) && (c(J, this, !1), l(K, this)?.classList.remove(z, s(Y, this, _r).call(this)), c(K, this, void 0), s(Y, this, xr).call(this), s(Y, this, hr).call(this), s(Y, this, Sr).call(this, e));
}
function hr() {
	window.dispatchEvent(new Event("resize"));
}
function gr() {
	c(er, this, !0);
	try {
		l(V, this).pause();
	} catch {}
	s(Y, this, mr).call(this, zn.closed);
}
function _r() {
	return `${z}--${l(H, this) ? "mobile" : "desktop"}`;
}
function vr() {
	if (l(G, this)) return;
	let e = l(B, this).ownerDocument, t = e.createElement("button");
	if (t.type = "button", t.className = `${Hn} ${Hn}--${l(H, this) ? "mobile" : "desktop"}`, t.setAttribute("aria-label", "Close floating video"), l(U, this) ? t.innerHTML = l(U, this) : t.textContent = "×", t.addEventListener("click", l(sr, this)), l(H, this)) {
		let n = e.createElement("div");
		n.className = Un, n.appendChild(t), (l(B, this).parentElement ?? e.body).appendChild(n), c(Zn, this, n);
	} else {
		let e = l(K, this)?.firstElementChild;
		(e instanceof HTMLElement ? e : l(K, this))?.appendChild(t);
	}
	c(G, this, t), s(Y, this, br).call(this);
}
function yr(e) {
	l(nr, this) !== e && (c(nr, this, e), s(Y, this, br).call(this));
}
function br() {
	l(G, this)?.classList.toggle(Wn, l(H, this) && l(nr, this));
}
function xr() {
	l(G, this) && (l(G, this).removeEventListener("click", l(sr, this)), l(G, this).remove(), c(G, this, void 0), l(Zn, this)?.remove(), c(Zn, this, void 0));
}
function Sr(e) {
	l(B, this).dispatchEvent(new CustomEvent(e, { bubbles: !0 }));
}
function Cr(e, t) {
	let n = e?.scrollThresholds;
	return (t ? n?.mobile : n?.desktop) ?? (t ? 300 : 580);
}
//#endregion
//#region ../../shared/plugins/custom-floating/custom-floating-plugin.ts
var wr = j("CustomFloatingPlugin"), Tr = /* @__PURE__ */ new WeakMap(), Er = /* @__PURE__ */ new WeakMap(), Dr = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakMap(), Or = /* @__PURE__ */ new WeakSet(), kr = class extends fn {
	constructor(e = {}) {
		super(e), t(this, Or), o(this, "name", "CustomFloatingPlugin"), n(this, Tr, void 0), n(this, Er, void 0), n(this, Dr, void 0), n(this, X, /* @__PURE__ */ new WeakMap()), o(this, "hooks", {
			onConfigLoaded: async (e) => {
				c(Tr, this, e.pageContext?.device), c(Dr, this, e.players);
				let t = e.customFloating?.closeButtonIcon;
				c(Er, this, typeof t == "string" ? t : void 0);
			},
			onAfterPlayerCreate: async (e) => {
				e.type === "jwplayer" && s(Or, this, Ar).call(this, e);
			},
			onAfterPlayerDestroy: async (e) => {
				let t = l(X, this).get(e.container);
				t && (l(X, this).delete(e.container), t.destroy());
			}
		});
	}
	isEnabled(e) {
		let t = e;
		return super.isEnabled(e) && t.customFloating?.enabled === !0;
	}
};
function Ar(e) {
	l(X, this).get(e.container)?.destroy();
	let t = on(l(Tr, this)), n = l(Dr, this)?.[e.type], r = typeof n == "object" && n ? n.customFloating : void 0, i = new cr({
		container: e.container,
		player: e.player,
		isMobile: t,
		scrollThreshold: Cr(r, t),
		closeButtonIcon: l(Er, this),
		logger: wr
	});
	l(X, this).set(e.container, i), i.start();
}
//#endregion
//#region ../../shared/plugins/bucket-experiment/types.ts
var jr = "control", Mr = j("BucketExperimentPlugin"), Nr = class extends fn {
	constructor(e = {}) {
		super(e), o(this, "experimentName", void 0), o(this, "currentGroup", jr), this.experimentName = this.constructor.experimentName;
	}
	setExperimentGroup(e) {
		["control", ...this.variantNames].includes(e) ? this.currentGroup = e : (Mr.warn(`Unknown experiment group "${e}" for ${this.experimentName}; defaulting to control`), _(Ze, { label: `${this.experimentName}:${e}` }), this.currentGroup = jr);
	}
	getDebugState() {
		return {
			experimentName: this.experimentName,
			currentGroup: this.currentGroup,
			variantNames: [...this.variantNames],
			codeDeletionDate: this.codeDeletionDate.toISOString()
		};
	}
};
o(Nr, "experimentName", "missing");
//#endregion
//#region ../../shared/plugins/bucket-experiment/get-server-side-experiment.ts
var Pr = /^sse-(?<experimentString>.+)$/, Fr = /^(?<team>[a-zA-Z]+)-(?<ticketId>[0-9]+)-(?<mode>variant|control)-?(?<variant>[1-6])?$/;
function Ir(e) {
	let t = e.toLowerCase().match(Fr);
	if (!t?.groups) return;
	let { team: n, ticketId: r, mode: i, variant: a } = t.groups;
	if (i === "variant" && !a) return;
	let o = a ? `${i}${a}` : i;
	return {
		name: `${n}-${r}`,
		group: o
	};
}
function Lr() {
	let { classList: e } = document.documentElement;
	for (let t of e) {
		let e = t.toLowerCase().match(Pr);
		if (e?.groups) return e.groups.experimentString;
	}
}
function Rr() {
	let e = Lr();
	if (e) return Ir(e);
}
//#endregion
//#region ../../shared/plugins/bucket-experiment/bucket-experiment-manager.ts
var zr = j("BucketExperimentManager");
function Br() {
	return new URLSearchParams(globalThis.location?.search ?? "").get("force-sse");
}
var Vr = /* @__PURE__ */ new WeakMap(), Hr = /* @__PURE__ */ new WeakSet(), Ur = class {
	constructor(e, r) {
		t(this, Hr), n(this, Vr, void 0);
		let i = s(Hr, this, Wr).call(this, r);
		if (!i) return;
		let a = s(Hr, this, Kr).call(this, e, i.name);
		if (!a || a.isEligible && !a.isEligible(r)) return;
		let o = new a({});
		o.setExperimentGroup(i.group), r.experiments ?? (r.experiments = {}), r.experiments[i.name] = o.currentGroup;
		try {
			o.adjustRuntimeConfig?.(r);
		} catch (e) {
			zr.error(`adjustRuntimeConfig failed for ${i.name}:`, e), _(w, {
				label: `${i.name}:adjustRuntimeConfig`,
				...v(e)
			});
		}
		c(Vr, this, o);
	}
	getActivePlugin() {
		return l(Vr, this);
	}
};
function Wr(e) {
	let t = Br();
	if (t) {
		let e = Ir(t);
		if (e) return e;
	}
	return Rr() || s(Hr, this, Gr).call(this, e);
}
function Gr(e) {
	let t = e.experiments;
	if (!t) return;
	let [n, r] = Object.entries(t)[0] ?? [];
	if (!(!n || !r)) return {
		name: n,
		group: r
	};
}
function Kr(e, t) {
	return Object.values(e).find((e) => e.experimentName === t);
}
//#endregion
//#region ../../shared/plugins/experiments/ExampleExperiment/example-experiment.ts
var qr = j("ExampleExperiment"), Jr = class extends Nr {
	constructor(...e) {
		super(...e), o(this, "name", "ExampleExperiment"), o(this, "variantNames", ["variant1", "variant2"]), o(this, "codeDeletionDate", /* @__PURE__ */ new Date("2045-08-01")), o(this, "hooks", { onRuntimeReady: async () => {
			qr.log("onRuntimeReady from an example experiment", { group: this.currentGroup });
		} });
	}
	isEnabled(e) {
		return super.isEnabled(e) && Te(e, this.name);
	}
	adjustRuntimeConfig(e) {
		this.isEnabled(e) && (e.exampleFeatureEnabled = this.currentGroup === "variant1");
	}
};
o(Jr, "experimentName", "fake-1234");
//#endregion
//#region ../../shared/plugins/bucket-experiment/index.ts
var Yr = { ExampleExperiment: Jr };
//#endregion
//#region runtime/load-plugins-list.ts
function Xr(e) {
	let t = new Ur(Yr, e).getActivePlugin();
	return [
		...t ? [t] : [],
		new kn(),
		new kr()
	];
}
//#endregion
//#region ../../shared/players/define-player-factory.ts
function Zr(e, t) {
	let n = {};
	return {
		type: e,
		attachConfig(t) {
			let r = t.players?.[e];
			if (r === void 0) {
				n = {};
				return;
			}
			if (typeof r != "object" || !r) {
				console.warn(`[${e}] config.players.${e} is not an object; ignoring.`), n = {};
				return;
			}
			n = r;
		},
		create: (e, r) => {
			for (let e of Object.keys(n)) {
				let t = n[e];
				t !== void 0 && (r[e] ?? (r[e] = t));
			}
			return t(e, r);
		}
	};
}
//#endregion
//#region ../../shared/players/jwplayer/jwplayer-adapter.ts
var Qr = class {
	constructor(e, t) {
		o(this, "type", I), this.instance = e, this.onDestroy = t;
	}
	play() {
		this.instance.play();
	}
	pause() {
		this.instance.pause();
	}
	stop() {
		this.instance.stop();
	}
	on(e, t) {
		let n = t;
		return this.instance.on(e, n), () => this.instance.off(e, n);
	}
	destroy() {
		this.onDestroy();
	}
}, $r = /* @__PURE__ */ new Map();
function ei(e, t) {
	$r.set(e, t);
}
function ti(e) {
	let t = window.jwDsrPartners?.[e]?.partner ?? "jwplayer", n = $r.get(t);
	if (!n) throw Error(`[${L}] No adapter registered for DSR partner "${t}". Register one with registerPartnerAdapter() or add support for this partner.`);
	return n;
}
ei(I, Qr);
//#endregion
//#region ../../shared/players/jwplayer/modes/dsr.ts
function ni(e) {
	return (t) => {
		var n, r;
		let i = (n = window).jwDataStore ?? (n.jwDataStore = { custom: {} });
		i.custom ?? (i.custom = {}), (r = i.custom)[e] ?? (r[e] = {}), i.custom[e].preroll_ad_tag = t;
	};
}
var ri = `${I}-dsr`, ii = (e, t) => `${In}v2/sites/${e}/placements/${t}/embed.js`, ai = {
	name: "dsr",
	async bootstrap(e, t) {
		let { siteId: n, placementId: r, playlistId: i, mediaId: a, adVastUrl: o, adTier: s } = t;
		if (h(`dsr:bootstrap:${r}`), t.applyAdTag ?? (t.applyAdTag = ni(r)), !i && !a) throw _(C, {
			player_type: I,
			player_mode: "dsr",
			label: r
		}), Error(`[${L}] At least one of \`playlistId\` or \`mediaId\` is required — without it the DSR bundle has nothing to play and aborts.`);
		let c = {};
		i && (c.playlist_id = i), a && (c.media_id = a), o && (c.preroll_ad_tag = o), s != null && Number.isFinite(s) && (c.tier = s);
		let l = Object.keys(c), u;
		try {
			ci(r, c);
			let t = `player_${r}`, i = document.getElementById(t);
			if (i && i !== e) throw Error(`[${L}] A DSR player for placement "${r}" is already mounted in another container. Re-use the existing container or provide a different placementId.`);
			e.id = t;
			let a = O(), o = (e) => D({
				component: ri,
				action: e,
				duration_ms: k(a),
				label: ri,
				placement_id: r
			});
			u = li(e, ii(n, r)), h("dsr:script-inject"), o("player-script-inject");
			let s = await ui(r);
			h("dsr:placement-ready"), o("player-placement-ready"), await oi(s, Ln, r), h("dsr:player-ready"), o("player-ready");
			let d = ti(r);
			return {
				instance: s,
				script: u,
				destroyPlayer: () => {},
				Adapter: d,
				cleanup: () => {
					si(r, l), delete window.jwplacements, delete window.jwplacementsMap;
				}
			};
		} catch (e) {
			e instanceof Error && e.message.includes("did not emit 'ready'") || _(x, {
				player_type: I,
				player_mode: "dsr",
				label: r,
				...v(e)
			});
			try {
				u?.remove(), si(r, l);
			} catch {}
			throw e;
		}
	}
};
function oi(e, t, n) {
	return e.getState() == null ? new Promise((r, i) => {
		let a = setTimeout(() => {
			_(Le, {
				player_type: I,
				player_mode: "dsr",
				label: n
			}), i(/* @__PURE__ */ Error(`[${L}] Player did not emit 'ready' within ${t}ms — JW registered the placement but its underlying player never finished booting.`));
		}, t);
		e.once("ready", () => {
			clearTimeout(a), r();
		});
	}) : Promise.resolve();
}
function si(e, t) {
	let n = window.jwDataStore?.custom?.[e];
	if (n) {
		for (let e of t) delete n[e];
		Object.keys(n).length === 0 && delete window.jwDataStore.custom[e];
	}
}
function ci(e, t) {
	var n;
	let r = (n = window).jwDataStore ?? (n.jwDataStore = { custom: {} });
	r.custom ?? (r.custom = {}), r.custom[e] = {
		...r.custom[e],
		...t
	};
}
function li(e, t) {
	let n = e.querySelector(`script[src="${t}"]`);
	if (n) return n;
	let r = document.createElement("script");
	return r.src = t, r.async = !0, e.appendChild(r), r;
}
async function ui(e) {
	let t = Date.now();
	for (; Date.now() - t < Ln;) {
		let t = window.jwplacements?._getPlacementReadyPromise(e);
		if (t) return (await t).player;
		await new Promise((e) => setTimeout(e, 100));
	}
	throw Error(`[${L}] placement "${e}" did not become ready within ${Ln}ms`);
}
//#endregion
//#region ../../shared/players/jwplayer/modes/index.ts
var di = /* @__PURE__ */ new Map();
function fi(e) {
	di.set(e.name, {
		name: e.name,
		bootstrap: (t, n) => e.bootstrap(t, n)
	});
}
fi(ai);
function pi(e) {
	let t = di.get(e);
	if (!t) throw Error(`[${I}] Unknown mode "${e}". Registered modes: ${[...di.keys()].join(", ") || "(none)"}`);
	return t;
}
//#endregion
//#region ../../shared/players/jwplayer/safe-instance.ts
var mi = new Set(["remove"]);
function hi(e) {
	return new Proxy(e, { get(e, t, n) {
		if (typeof t == "string" && mi.has(t)) return (...e) => {
			console.warn(`[${I}] "${t}()" is blocked on the safe instance. Call JwPlayer.destroy() instead to tear the player down cleanly.`);
		};
		let r = Reflect.get(e, t, n);
		return typeof r == "function" ? r.bind(e) : r;
	} });
}
//#endregion
//#region ../../shared/players/jwplayer/jwplayer.ts
var gi = /* @__PURE__ */ new WeakMap(), _i = /* @__PURE__ */ new WeakMap(), vi = /* @__PURE__ */ new WeakMap(), yi = /* @__PURE__ */ new WeakMap(), bi = /* @__PURE__ */ new WeakMap(), xi = /* @__PURE__ */ new WeakMap(), Si = /* @__PURE__ */ new WeakMap(), Ci = class e {
	constructor(e, t, r, i, a) {
		o(this, "type", I), n(this, gi, void 0), n(this, _i, void 0), n(this, vi, void 0), n(this, yi, void 0), n(this, bi, void 0), n(this, xi, void 0), n(this, Si, !1), c(gi, this, e), c(_i, this, t), c(vi, this, hi(t)), c(bi, this, i), c(xi, this, a), c(yi, this, new r(l(vi, this), () => this.destroy()));
	}
	get adapter() {
		return l(yi, this);
	}
	static async create(t, n) {
		let { instance: r, script: i, cleanup: a, destroyPlayer: o, Adapter: s } = await pi(n.mode).bootstrap(t, n);
		return new e(i, r, s, a, o);
	}
	getInstance() {
		if (l(Si, this)) throw Error(`[${I}] Player has been destroyed; instance is no longer available.`);
		return l(vi, this);
	}
	destroy() {
		if (!l(Si, this)) {
			c(Si, this, !0);
			try {
				l(xi, this) ? l(xi, this).call(this) : l(_i, this).remove();
			} catch (e) {
				_(S, {
					player_type: I,
					...v(e)
				});
			}
			l(gi, this).remove();
			try {
				l(bi, this)?.call(this);
			} catch (e) {
				_(w, {
					label: `${I}:cleanup`,
					player_type: I,
					...v(e)
				});
			}
		}
	}
}, wi = Zr(I, async (e, t) => (await Ci.create(e, t)).adapter), Ti = {
	play: "play",
	complete: "videoCompleted100",
	error: "playError",
	adImpression: "adImpression",
	adPlay: "adPlay",
	adComplete: "adCompleted100",
	adError: "adError",
	ready: "videoStarted"
}, Z = /* @__PURE__ */ new WeakMap(), Ei = /* @__PURE__ */ new WeakMap(), Di = /* @__PURE__ */ new WeakMap(), Oi = class {
	constructor(e, t) {
		o(this, "type", R), n(this, Z, void 0), n(this, Ei, void 0), n(this, Di, !1), o(this, "play", () => {
			l(Z, this).play();
		}), o(this, "pause", () => {
			l(Z, this).pause();
		}), o(this, "stop", () => {
			l(Z, this).pause(), l(Z, this).setVideoPosition(0);
		}), o(this, "on", (e, t) => {
			let n = Ti[e];
			return n && l(Z, this).on(n, t), () => {};
		}), o(this, "destroy", () => {
			if (!l(Di, this)) {
				c(Di, this, !0);
				try {
					l(Z, this).destroy();
				} catch (e) {
					_(S, {
						player_type: R,
						...v(e)
					});
				}
				l(Ei, this).remove();
			}
		}), c(Z, this, e), c(Ei, this, t);
	}
}, ki = (e) => (function(t) {
	if (!window.cnx) {
		window.cnx = {}, window.cnx.cmd = [];
		var n = t.createElement("iframe");
		n.src = "javascript:false", n.display = "none", n.onload = function() {
			var t = n.contentWindow.document, r = t.createElement("script");
			r.src = `//cd.connatix.com/connatix.player.js?cid=${e}`, r.setAttribute("async", "1"), r.setAttribute("type", "text/javascript"), t.body.appendChild(r);
		}, t.head.appendChild(n);
	}
})(document);
//#endregion
//#region ../../shared/players/connatix/render.ts
function Ai(e, t, n) {
	window.cnx?.cmd?.push(function() {
		window.cnx?.(t).render(e, n);
	});
}
//#endregion
//#region ../../shared/players/connatix/connatix.ts
var ji = 0;
function Mi(e) {
	return {
		renderId: `${e.renderId ?? "cnx"}-${++ji}`,
		playerId: e.playerId ?? ""
	};
}
function Ni(e, t) {
	let n = {
		playerId: e,
		settings: t.adVastUrl ? {
			disableAdvertising: !1,
			advertising: { lineItems: [{
				id: e,
				url: t.adVastUrl
			}] }
		} : { disableAdvertising: !0 }
	};
	return t.mediaId && (n.mediaId = t.mediaId), t.playlistId && (n.playlistId = t.playlistId), n;
}
function Pi(e, t) {
	return new Promise((n, r) => {
		let i = !1, a = setTimeout(() => {
			i || (i = !0, _(Le, { player_type: R }), r(/* @__PURE__ */ Error(`[${R}] render timed out after ${Rn}ms — SDK may not have loaded`)));
		}, Rn);
		Ai(e, t, (e, t) => {
			i || (i = !0, clearTimeout(a), e ? (_(x, {
				player_type: R,
				error_type: e.type,
				error_message: e.message
			}), r(/* @__PURE__ */ Error(`[${R}] ${e.type}: ${e.message}`))) : n(t));
		});
	});
}
function Fi(e, t) {
	let n = {};
	t.adUnitPath && (n.path = t.adUnitPath), t.adTargetingParams && (n.custmac = t.adTargetingParams), Object.keys(n).length > 0 && e.setMacros(n);
}
var Ii = Zr(R, async (e, t) => {
	let n = t.customerId;
	if (!n) throw Error(`[${R}] customerId is required — set it in window.__morpheusConfig.players.${R}.customerId`);
	let { renderId: r, playerId: i } = Mi(t);
	if (!i) throw _(C, { player_type: R }), Error(`[${R}] playerId is required — set players.${R}.playerId in config or pass it directly`);
	let a = O(), o = (e) => D({
		component: R,
		action: e,
		duration_ms: k(a),
		label: R
	});
	ki(n), o("player-script-inject");
	let s = document.createElement("div");
	s.id = r, e.appendChild(s);
	let c;
	try {
		c = await Pi(r, Ni(i, t));
	} catch (e) {
		throw s.remove(), e;
	}
	return o("player-ready"), Fi(c, t), new Oi(c, s);
}), Li = "v9";
function Ri(e, t) {
	if (typeof t.env == "string" && t.env) return t.env;
	let n = e.fandomContext?.app?.env;
	return typeof n == "string" && n ? n : "unknown";
}
var zi = O(), Q = (e, t) => {
	h(`bootstrap:${e}`), D({
		component: "video-engine",
		action: e,
		duration_ms: k(zi),
		...t
	});
};
_t(yt()), window.addEventListener("unhandledrejection", (e) => {
	let t = e.reason, n = t instanceof Error ? t.message : String(t);
	!n.includes("[Morpheus]") && !n.includes("[jwplayer") && !n.includes("[VideoEngine]") || _(Qe, v(t));
});
var $ = j("VideoEngine"), Bi = window, Vi, Hi;
Bi.MorpheusReady = new Promise((e, t) => {
	Vi = e, Hi = t;
}), (async function(e) {
	$.log("bootstrap starting");
	let t = await un(e.__morpheusConfig ?? {}), n = {
		engine_version: Li,
		env: Ri(e, t)
	};
	nt(n), de(n), rt(t.experiments), D({
		component: "video-engine",
		action: "script-execution-start",
		duration_ms: zi >= 0 ? zi : -1
	}), Q("config-fetch"), $.log("config initialized", t);
	let r = await Vt();
	t.featureFlags = r, $.log("instant-config resolved", r.getAll());
	let i = Array.isArray(e.Morpheus) ? e.Morpheus : [], a = At(Xr(t), t);
	Q("plugin-init"), $.log("active plugins", a.map((e) => e.name));
	let o = !1, s = Promise.allSettled(M(a, "onConfigLoaded", t)).then(() => {
		o = !0;
	});
	await Promise.race([s, new Promise((e) => setTimeout(e, Ut))]), o || (Q("plugin-waiting-timeout"), _(He)), Q("config-loaded-hook");
	let c = Tt(t, a);
	Q("runtime-create"), Ht(c), M(a, "onRuntimeReady", c);
	let l = [wi, Ii];
	for (let e of l) c.registerPlayerFactory(e), Q("player-factory-register", { label: e.type });
	M(a, "onPlayersRegistered", c), e.Morpheus = c, Ot(c, i), Q("queue-drain"), M(a, "onQueueDrained"), Vi(c), M(a, "onInitializationEnded"), Q("bootstrap-complete", { active_plugins: a.map((e) => e.name) }), $.log("runtime ready", t);
})(Bi).catch((e) => {
	$.error("fatal init error:", e), _(ke, {
		label: "main.ts",
		...v(e)
	}), Hi(e);
});
//#endregion
