<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		watchlist
	</title><g fill="#36c"><path d="M15.313 10.556H18l.304.897-2.196 1.676.842 2.723-.781.546L14 14.74l-2.169 1.658-.781-.546.84-2.723-2.194-1.676.304-.897h2.688l.835-2.703h.954zM9 16H2v-2h7zm-1-5H2V9h6zm10-5H2V4h16z"/></g></svg>
