<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		user talk
	</title><g fill="#fff"><path d="M13 10a2.5 2.5 0 0 1-2.5 2.5h-1A2.5 2.5 0 0 1 7 10zM6.25 6a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m7.5 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5"/><path d="M19 16h-6.685l-4.742 3.32L6 18.5V16H1V2h18zM3 14h5v2.58L11.685 14H17V4H3z"/></g></svg>
