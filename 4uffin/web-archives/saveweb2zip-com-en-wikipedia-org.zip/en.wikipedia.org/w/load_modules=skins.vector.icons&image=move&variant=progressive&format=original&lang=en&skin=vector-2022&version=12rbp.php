<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		move
	</title><g fill="#36c"><path d="M12.5 3.5v1H11V9h4.5V7.5h1L19 10l-2.5 2.5h-1V11H11v4.5h1.5v1L10 19l-2.5-2.5v-1H9V11H4.5v1.5h-1L1 10l2.5-2.5h1V9H9V4.5H7.5v-1L10 1z"/></g></svg>
