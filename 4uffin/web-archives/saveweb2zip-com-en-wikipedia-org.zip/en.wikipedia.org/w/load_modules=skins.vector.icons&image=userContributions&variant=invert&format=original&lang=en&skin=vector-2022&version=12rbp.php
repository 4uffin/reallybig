<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		user contributions
	</title><g fill="#fff"><path d="M16.143 13.063c1.578 0 2.857 1.259 2.857 2.812V17h-8v-1.125c0-1.553 1.28-2.813 2.857-2.813h2.286ZM9 16H2v-2h7zm6-8c1.105 0 2 .881 2 1.969 0 1.087-.895 1.969-2 1.969s-2-.882-2-1.97C13 8.882 13.895 8 15 8m-4 3H2V9h9zm7-5H2V4h16z"/></g></svg>
