<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		unlock
	</title><g fill="#d73333"><path d="M11 15H9v-3h2z"/><path d="M10 1a4 4 0 0 1 4 4v3h3v11H3V8h9V5a2 2 0 1 0-4 0v.5H6V5a4 4 0 0 1 4-4M5 17h10v-7H5z"/></g></svg>
