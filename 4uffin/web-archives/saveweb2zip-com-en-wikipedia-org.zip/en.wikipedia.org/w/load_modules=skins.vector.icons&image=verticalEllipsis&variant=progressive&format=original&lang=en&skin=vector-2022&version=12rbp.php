<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		ellipsis vertical
	</title><g fill="#36c"><path d="M11.5 18h-3v-3h3zm0-6.5h-3v-3h3zm0-6.5h-3V2h3z"/></g></svg>
