<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		menu
	</title><g fill="#36c"><path d="M18 16H2v-2h16zm0-5H2V9h16zm0-5H2V4h16z"/></g></svg>
