<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		heart
	</title><g fill="#fff"><path d="M11.039 3.656c2.158-2.332 5.937-2.179 7.893.318a4.99 4.99 0 0 1-.272 6.487L10.757 19H9.243L1.34 10.461a4.99 4.99 0 0 1-.272-6.487c1.956-2.497 5.735-2.65 7.893-.318L10 4.776z"/></g></svg>
